/*
 *  FilterAnalyzer - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ FilterAnalyzer class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "filter_analyzer.h"
#include <string.h>
#include <math.h>

/* High-pass filter coefficients (cutoff ~600 Hz) */
static const float kHpCoeffs[3] = {0.7929742f, -0.36072128f, -0.47047766f};

static int FindPeakIndex(const float* filter, int peak_index_in,
                         int start, int end) {
    int peak = peak_index_in;
    float max_h2 = filter[peak] * filter[peak];
    int k;
    for (k = start; k <= end; k++) {
        float tmp = filter[k] * filter[k];
        if (tmp > max_h2) {
            peak = k;
            max_h2 = tmp;
        }
    }
    return peak;
}

static void ConsistentFilterDetector_Init(ConsistentFilterDetector* self,
                                          const Aec3Config* config) {
    self->significant_peak = 0;
    self->filter_floor_accum = 0.0f;
    self->filter_secondary_peak = 0.0f;
    self->filter_floor_low_limit = 0;
    self->filter_floor_high_limit = 0;
    self->active_render_threshold =
        config->render_levels_active_render_limit *
        config->render_levels_active_render_limit *
        AEC3_FFT_LENGTH_BY2;
    self->consistent_estimate_counter = 0;
    self->consistent_delay_reference = -10;
}

static void ConsistentFilterDetector_Reset(ConsistentFilterDetector* self) {
    self->significant_peak = 0;
    self->filter_floor_accum = 0.0f;
    self->filter_secondary_peak = 0.0f;
    self->filter_floor_low_limit = 0;
    self->filter_floor_high_limit = 0;
    self->consistent_estimate_counter = 0;
    self->consistent_delay_reference = -10;
}

static int ConsistentFilterDetector_Detect(ConsistentFilterDetector* self,
                                           const float* filter,
                                           int filter_len,
                                           const FilterRegion* region,
                                           const float* x_block,
                                           int peak_index,
                                           int delay_blocks) {
    int k;
    float filter_floor, abs_peak, x_energy;
    int active_render_block;

    if (region->start_sample == 0) {
        self->filter_floor_accum = 0.0f;
        self->filter_secondary_peak = 0.0f;
        self->filter_floor_low_limit = (peak_index < 64) ? 0 : peak_index - 64;
        self->filter_floor_high_limit =
            (peak_index > filter_len - 129) ? 0 : peak_index + 128;
    }

    /* Accumulate floor outside peak region */
    for (k = region->start_sample;
         k < region->end_sample + 1 && k < self->filter_floor_low_limit; k++) {
        float abs_h = fabsf(filter[k]);
        self->filter_floor_accum += abs_h;
        if (abs_h > self->filter_secondary_peak) {
            self->filter_secondary_peak = abs_h;
        }
    }
    {
        int start2 = self->filter_floor_high_limit;
        if (start2 < region->start_sample) start2 = region->start_sample;
        for (k = start2; k <= region->end_sample; k++) {
            float abs_h = fabsf(filter[k]);
            self->filter_floor_accum += abs_h;
            if (abs_h > self->filter_secondary_peak) {
                self->filter_secondary_peak = abs_h;
            }
        }
    }

    if (region->end_sample == filter_len - 1) {
        int denom = self->filter_floor_low_limit + filter_len - self->filter_floor_high_limit;
        filter_floor = (denom > 0) ? self->filter_floor_accum / denom : 0.0f;
        abs_peak = fabsf(filter[peak_index]);
        self->significant_peak = (abs_peak > 10.0f * filter_floor &&
                                  abs_peak > 2.0f * self->filter_secondary_peak);
    }

    if (self->significant_peak) {
        x_energy = 0.0f;
        for (k = 0; k < AEC3_BLOCK_SIZE; k++) {
            x_energy += x_block[k] * x_block[k];
        }
        active_render_block = (x_energy > self->active_render_threshold);

        if (self->consistent_delay_reference == delay_blocks) {
            if (active_render_block) {
                self->consistent_estimate_counter++;
            }
        } else {
            self->consistent_estimate_counter = 0;
            self->consistent_delay_reference = delay_blocks;
        }
    }

    return (self->consistent_estimate_counter > (int)(1.5f * AEC3_NUM_BLOCKS_PER_SECOND));
}

void FilterAnalyzer_Init(FilterAnalyzer* self, const Aec3Config* config) {
    memset(self, 0, sizeof(FilterAnalyzer));
    self->use_preprocessed_filter = 1;
    self->bounded_erl = config->ep_strength_bounded_erl;
    self->default_gain = config->ep_strength_lf;
    self->use_incremental_analysis = 1;
    self->h_highpass_len = config->filter_main_initial_length_blocks * AEC3_FFT_LENGTH_BY2;
    self->filter_length_blocks = config->filter_main_initial_length_blocks;
    ConsistentFilterDetector_Init(&self->consistent_filter_detector, config);
    FilterAnalyzer_Reset(self);
}

void FilterAnalyzer_Reset(FilterAnalyzer* self) {
    self->delay_blocks = 0;
    self->blocks_since_reset = 0;
    self->gain = self->default_gain;
    self->peak_index = 0;
    self->consistent_estimate = 0;
    self->region.start_sample = 0;
    self->region.end_sample = 0;
    ConsistentFilterDetector_Reset(&self->consistent_filter_detector);
}

static void PreProcessFilter(FilterAnalyzer* self,
                             const float* filter, int filter_len) {
    int k, j;
    int start = self->region.start_sample;
    int end = self->region.end_sample;

    if (filter_len > AEC3_MAX_FILTER_TIME_DOMAIN) {
        filter_len = AEC3_MAX_FILTER_TIME_DOMAIN;
    }
    self->h_highpass_len = filter_len;

    /* Clear region */
    for (k = start; k <= end && k < filter_len; k++) {
        self->h_highpass[k] = 0.0f;
    }

    /* Apply high-pass FIR */
    {
        int hp_start = (2 > start) ? 2 : start;
        for (k = hp_start; k <= end && k < filter_len; k++) {
            self->h_highpass[k] = 0.0f;
            for (j = 0; j < 3; j++) {
                if (k >= j) {
                    self->h_highpass[k] += filter[k - j] * kHpCoeffs[j];
                }
            }
        }
    }
}

static void SetRegionToAnalyze(FilterAnalyzer* self, int filter_len) {
    FilterRegion* r = &self->region;
    if (self->use_incremental_analysis) {
        r->start_sample = (r->end_sample == filter_len - 1) ? 0 : r->end_sample + 1;
        r->end_sample = r->start_sample + AEC3_BLOCK_SIZE - 1;
        if (r->end_sample >= filter_len) {
            r->end_sample = filter_len - 1;
        }
    } else {
        r->start_sample = 0;
        r->end_sample = filter_len - 1;
    }
}

static void UpdateFilterGain(FilterAnalyzer* self,
                             const float* filter, int peak_index) {
    int sufficient_time = (++self->blocks_since_reset > 5 * AEC3_NUM_BLOCKS_PER_SECOND);
    float abs_peak = fabsf(filter[peak_index]);

    if (sufficient_time && self->consistent_estimate) {
        self->gain = abs_peak;
    } else {
        if (self->gain > 0.0f && abs_peak > self->gain) {
            self->gain = abs_peak;
        }
    }

    if (self->bounded_erl && self->gain > 0.0f) {
        if (self->gain < 0.01f) {
            self->gain = 0.01f;
        }
    }
}

void FilterAnalyzer_Update(FilterAnalyzer* self,
                           const float* filter_time_domain,
                           int filter_len,
                           const RenderBuffer* render_buffer) {
    const float* filter_to_analyze;

    SetRegionToAnalyze(self, filter_len);
    PreProcessFilter(self, filter_time_domain, filter_len);

    filter_to_analyze = self->use_preprocessed_filter ?
                        self->h_highpass : filter_time_domain;

    self->peak_index = FindPeakIndex(filter_to_analyze, self->peak_index,
                                     self->region.start_sample,
                                     self->region.end_sample);
    self->delay_blocks = self->peak_index >> AEC3_BLOCK_SIZE_LOG2;
    UpdateFilterGain(self, filter_to_analyze, self->peak_index);
    self->filter_length_blocks = filter_len / AEC3_BLOCK_SIZE;

    /* Consistency detection */
    {
        const float* x_block = RenderBuffer_Block(render_buffer,
                                                   -self->delay_blocks, 0);
        if (x_block) {
            self->consistent_estimate = ConsistentFilterDetector_Detect(
                &self->consistent_filter_detector,
                filter_to_analyze, filter_len,
                &self->region, x_block,
                self->peak_index, self->delay_blocks);
        }
    }
}

int FilterAnalyzer_DelayBlocks(const FilterAnalyzer* self) {
    return self->delay_blocks;
}

int FilterAnalyzer_Consistent(const FilterAnalyzer* self) {
    return self->consistent_estimate;
}

float FilterAnalyzer_Gain(const FilterAnalyzer* self) {
    return self->gain;
}

int FilterAnalyzer_FilterLengthBlocks(const FilterAnalyzer* self) {
    return self->filter_length_blocks;
}

const float* FilterAnalyzer_GetAdjustedFilter(const FilterAnalyzer* self) {
    return self->h_highpass;
}
