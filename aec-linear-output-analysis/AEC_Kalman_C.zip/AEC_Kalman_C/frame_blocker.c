/*
 *  Frame Blocker - Pure C Version
 *
 *  Converts 80-sample sub-frames into 64-sample processing blocks.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#include "frame_blocker.h"
#include <string.h>
#include <assert.h>

void FrameBlocker_Init(FrameBlocker* self, int num_bands) {
    assert(self != NULL);
    assert(num_bands > 0 && num_bands <= AEC3_MAX_BANDS);
    memset(self->buffer, 0, sizeof(self->buffer));
    self->buffer_count = 0;
    self->num_bands = num_bands;
}

int FrameBlocker_InsertSubFrame(FrameBlocker* self,
                                const float sub_frame[][AEC3_SUB_FRAME_LENGTH],
                                float block[][AEC3_BLOCK_SIZE],
                                int num_bands) {
    int i;
    int samples_to_block;
    int remaining;

    assert(self != NULL);
    assert(num_bands == self->num_bands);
    assert(self->buffer_count <= AEC3_BLOCK_SIZE - 16);

    samples_to_block = AEC3_BLOCK_SIZE - self->buffer_count;

    for (i = 0; i < num_bands; ++i) {
        /* Copy buffered samples to the beginning of the block */
        if (self->buffer_count > 0) {
            memcpy(block[i], self->buffer[i],
                   sizeof(float) * (size_t)self->buffer_count);
        }
        /* Fill the rest of the block from the sub-frame */
        memcpy(block[i] + self->buffer_count, sub_frame[i],
               sizeof(float) * (size_t)samples_to_block);
    }

    /* Store remaining sub-frame samples in the buffer */
    remaining = AEC3_SUB_FRAME_LENGTH - samples_to_block;
    for (i = 0; i < num_bands; ++i) {
        if (remaining > 0) {
            memcpy(self->buffer[i], sub_frame[i] + samples_to_block,
                   sizeof(float) * (size_t)remaining);
        }
    }
    self->buffer_count = remaining;

    return 1; /* block always produced from an 80-sample sub-frame */
}

int FrameBlocker_IsBlockAvailable(const FrameBlocker* self) {
    assert(self != NULL);
    return (self->buffer_count == AEC3_BLOCK_SIZE) ? 1 : 0;
}

void FrameBlocker_ExtractBlock(FrameBlocker* self,
                               float block[][AEC3_BLOCK_SIZE],
                               int num_bands) {
    int i;
    assert(self != NULL);
    assert(FrameBlocker_IsBlockAvailable(self));
    assert(num_bands == self->num_bands);

    for (i = 0; i < num_bands; ++i) {
        memcpy(block[i], self->buffer[i],
               sizeof(float) * AEC3_BLOCK_SIZE);
    }
    self->buffer_count = 0;
}
