/*
 *  ErlEstimator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ErlEstimator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "erl_estimator.h"
#include <string.h>
#include <math.h>

static const float kMinErl = 0.01f;
static const float kMaxErl = 1000.f;
static const float kX2Min = 44015068.0f;  /* WGN power -46 dBFS */

void ErlEstimator_Init(ErlEstimator* self, int startup_phase_length_blocks) {
    int i;
    self->startup_phase_length_blocks = startup_phase_length_blocks;
    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; i++) {
        self->erl[i] = kMaxErl;
    }
    memset(self->hold_counters, 0, sizeof(self->hold_counters));
    self->erl_time_domain = kMaxErl;
    self->hold_counter_time_domain = 0;
    self->blocks_since_reset = 0;
}

void ErlEstimator_Reset(ErlEstimator* self) {
    self->blocks_since_reset = 0;
}

void ErlEstimator_Update(ErlEstimator* self,
                         int converged_filter,
                         const float* render_spectrum,
                         const float* capture_spectrum,
                         int use_erl_update) {
    const float* X2 = render_spectrum;
    const float* Y2 = capture_spectrum;
    int k;
    float X2_sum, Y2_sum, new_erl;

    self->blocks_since_reset++;

    if (self->blocks_since_reset < self->startup_phase_length_blocks ||
        !converged_filter) {
        return;
    }
    if (use_erl_update) {
        return;
    }

    /* Update per-bin ERL in maximum-statistics manner */
    for (k = 1; k < AEC3_FFT_LENGTH_BY2; k++) {
        if (X2[k] > kX2Min) {
            new_erl = Y2[k] / X2[k];
            if (new_erl < self->erl[k]) {
                self->hold_counters[k - 1] = 1000;
                self->erl[k] += 0.1f * (new_erl - self->erl[k]);
                if (self->erl[k] < kMinErl) {
                    self->erl[k] = kMinErl;
                }
            }
        }
    }

    /* Decrement hold counters and release ERL toward kMaxErl */
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_MINUS1; k++) {
        self->hold_counters[k]--;
        if (self->hold_counters[k] <= 0) {
            float val = 2.f * self->erl[k + 1];
            self->erl[k + 1] = (val < kMaxErl) ? val : kMaxErl;
        }
    }

    /* Mirror edge bins */
    self->erl[0] = self->erl[1];
    self->erl[AEC3_FFT_LENGTH_BY2] = self->erl[AEC3_FFT_LENGTH_BY2 - 1];

    /* Compute broadband time-domain ERL */
    X2_sum = 0.0f;
    Y2_sum = 0.0f;
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        X2_sum += X2[k];
        Y2_sum += Y2[k];
    }

    if (X2_sum > kX2Min * AEC3_FFT_LENGTH_BY2_PLUS1) {
        new_erl = Y2_sum / X2_sum;
        if (new_erl < self->erl_time_domain) {
            self->hold_counter_time_domain = 1000;
            self->erl_time_domain += 0.1f * (new_erl - self->erl_time_domain);
            if (self->erl_time_domain < kMinErl) {
                self->erl_time_domain = kMinErl;
            }
        }
    }

    self->hold_counter_time_domain--;
    if (self->hold_counter_time_domain <= 0) {
        float val = 2.f * self->erl_time_domain;
        self->erl_time_domain = (val < kMaxErl) ? val : kMaxErl;
    }
}

const float* ErlEstimator_Erl(const ErlEstimator* self) {
    return self->erl;
}

float ErlEstimator_ErlTimeDomain(const ErlEstimator* self) {
    return self->erl_time_domain;
}
