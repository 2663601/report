/*
 *  ReverbFrequencyResponse - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ReverbFrequencyResponse class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "reverb_frequency_response.h"
#include <string.h>

void ReverbFrequencyResponse_Init(ReverbFrequencyResponse* self) {
    memset(self->tail_response, 0, sizeof(self->tail_response));
    self->average_decay = 0.0f;
    self->enable_smooth_updates = 1;
}

void ReverbFrequencyResponse_Update(ReverbFrequencyResponse* self,
                                    const float (*H2)[AEC3_FFT_LENGTH_BY2_PLUS1],
                                    int num_partitions,
                                    int filter_delay_blocks,
                                    float linear_filter_quality,
                                    int has_quality,
                                    int stationary_block) {
    int k;
    float direct_path_energy, tail_energy, average_decay, smoothing;
    const float* freq_resp_direct;
    const float* freq_resp_tail;

    if (num_partitions <= 0) return;

    if (self->enable_smooth_updates) {
        if (stationary_block || !has_quality) return;
    }

    /* Use filter_delay_blocks for direct path, last partition for tail */
    if (filter_delay_blocks >= num_partitions) {
        filter_delay_blocks = num_partitions - 1;
    }
    freq_resp_direct = H2[filter_delay_blocks];
    freq_resp_tail = H2[num_partitions - 1];

    /* Compute energy ratio (skip DC) */
    direct_path_energy = 0.0f;
    tail_energy = 0.0f;
    for (k = 1; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        direct_path_energy += freq_resp_direct[k];
        tail_energy += freq_resp_tail[k];
    }

    if (direct_path_energy == 0.0f) {
        average_decay = 0.0f;
    } else {
        average_decay = tail_energy / direct_path_energy;
    }

    smoothing = self->enable_smooth_updates ?
                0.2f * linear_filter_quality : 0.5f;
    self->average_decay += smoothing * (average_decay - self->average_decay);

    /* Compute tail response */
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        self->tail_response[k] = freq_resp_direct[k] * self->average_decay;
    }

    /* Smooth neighbors */
    for (k = 1; k < AEC3_FFT_LENGTH_BY2; k++) {
        float avg_neighbour = 0.5f * (self->tail_response[k - 1] +
                                       self->tail_response[k + 1]);
        if (avg_neighbour > self->tail_response[k]) {
            self->tail_response[k] = avg_neighbour;
        }
    }
}

const float* ReverbFrequencyResponse_GetResponse(
    const ReverbFrequencyResponse* self) {
    return self->tail_response;
}
