/*
 *  SuppressionGainUpperLimiter - Pure C Version
 *
 *  Applies a smoothly increasing limit for the suppression gain
 *  during call startup and after in-call resets.
 *  Ported from WebRTC AEC3 C++ SuppressionGainUpperLimiter class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef SUPPRESSION_GAIN_LIMITER_H_
#define SUPPRESSION_GAIN_LIMITER_H_

#include "aec3_common.h"
#include "aec3_config.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    /* Rampup configuration (from Aec3Config) */
    float   initial_gain;
    float   first_non_zero_gain;
    int     non_zero_gain_blocks;
    int     full_gain_blocks;

    float   gain_rampup_increase;
    int     call_startup_phase;
    int     realignment_counter;
    int     active_render_seen;
    float   suppressor_gain_limit;
    int     recent_reset;
} SuppressionGainUpperLimiter;

/**
 * Initialize the suppression gain limiter.
 */
void SuppressionGainUpperLimiter_Init(SuppressionGainUpperLimiter* self,
                                      const Aec3Config* config);

/**
 * Reset the limiting behavior.
 */
void SuppressionGainUpperLimiter_Reset(SuppressionGainUpperLimiter* self);

/**
 * Update the limiting behavior for the current capture block.
 */
void SuppressionGainUpperLimiter_Update(SuppressionGainUpperLimiter* self,
                                        int render_activity,
                                        int transparent_mode);

/**
 * Returns the current suppressor gain limit.
 */
float SuppressionGainUpperLimiter_Limit(const SuppressionGainUpperLimiter* self);

/**
 * Returns whether the suppressor gain limit is active.
 */
int SuppressionGainUpperLimiter_IsActive(const SuppressionGainUpperLimiter* self);

/**
 * Deactivate the limiter.
 */
void SuppressionGainUpperLimiter_Deactivate(SuppressionGainUpperLimiter* self);

#ifdef __cplusplus
}
#endif

#endif /* SUPPRESSION_GAIN_LIMITER_H_ */
