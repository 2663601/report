/*
 *  Subtractor - Pure C Version
 *
 *  Linear echo cancellation using main and shadow adaptive filters.
 *  Ported from WebRTC AEC3 C++ Subtractor class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords.
 */

#ifndef SUBTRACTOR_H_
#define SUBTRACTOR_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "aec3_fft.h"
#include "adaptive_fir_filter.h"
#include "main_filter_update_gain.h"
#include "subtractor_output.h"
#include "render_buffer.h"
#include "render_signal_analyzer.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declaration */
struct AecState_;

/* ================================================================
 * FilterMisadjustmentEstimator - Inlined in Subtractor
 *
 * Detects when the main filter prediction error energy is
 * significantly larger than the microphone signal energy,
 * indicating filter misadjustment.
 * ================================================================ */
typedef struct {
    int     n_blocks;
    int     n_blocks_acum;
    float   e2_acum;
    float   y2_acum;
    float   inv_misadjustment;
    int     overhang;

    /* PFDKF frequency-domain accumulators */
    float   E2_acum;
    float   Y2_acum;
} FilterMisadjustmentEstimator;

/* ================================================================
 * NearendEnergyFix - PFDKF nearend energy correction
 *
 * Computes coherence-based E2_fix and E2_fix_suppress arrays
 * used by MainFilterUpdateGain_ComputePfdkf for speed gain.
 * Ported from C++ Subtractor::NearendEnergyFix.
 * ================================================================ */
typedef struct {
    FftDataPfdkf ES;                                    /* smoothed cross-spectrum E*S */
    float   E2[AEC3_LF_FFT_LENGTH_BY2_PLUS1];          /* smoothed E2 */
    float   S2[AEC3_LF_FFT_LENGTH_BY2_PLUS1];          /* smoothed S2 */
    float   E2_fix[AEC3_LF_FFT_LENGTH_BY2_PLUS1];      /* corrected E2 (cohes clamped to 0.5) */
    float   E2_fix_suppress[AEC3_LF_FFT_LENGTH_BY2_PLUS1]; /* corrected E2 (cohes clamped to 1.0) */
    float   ES2[AEC3_LF_FFT_LENGTH_BY2_PLUS1];         /* |ES|^2 */
    float   cohes;
} NearendEnergyFix;

void NearendEnergyFix_Init(NearendEnergyFix* self);
void NearendEnergyFix_Update(NearendEnergyFix* self,
                              const SubtractorOutputFrequency* output);

void FilterMisadjustmentEstimator_Init(FilterMisadjustmentEstimator* self);
void FilterMisadjustmentEstimator_Update(FilterMisadjustmentEstimator* self,
                                         const SubtractorOutput* output);
void FilterMisadjustmentEstimator_UpdateFrequency(
         FilterMisadjustmentEstimator* self,
         const SubtractorOutputFrequency* output);
void FilterMisadjustmentEstimator_Reset(FilterMisadjustmentEstimator* self);
void FilterMisadjustmentEstimator_ResetFrequency(FilterMisadjustmentEstimator* self);
int  FilterMisadjustmentEstimator_IsAdjustmentNeeded(
         const FilterMisadjustmentEstimator* self);
float FilterMisadjustmentEstimator_GetMisadjustment(
          const FilterMisadjustmentEstimator* self);

/* ================================================================
 * Subtractor - Linear echo subtraction
 *
 * Coordinates main and shadow adaptive filters, computes
 * prediction errors, and manages filter adaptation.
 * ================================================================ */
typedef struct {
    Aec3Fft                 fft_pfdkf;
    Aec3Config              config;

    AdaptiveFirFilter       main_filter;
    MainFilterUpdateGain    G_main;

    FilterMisadjustmentEstimator filter_misadjustment_estimator;

    int     poor_shadow_filter_counter;
    int     main_filter_last_selected_cache;
    int     main_reset_hangover_blocks;
    int     main_reset_shadow_hangover_blocks;
    int     earphone_flag;
    int     voip_flag;
    int     aec_H_usage;

    /* Feature flags (always enabled in pure C port) */
    int     adaptation_during_saturation;
    int     enable_misadjustment_estimator;

    /* PFDKF work buffers (externally allocated, sized by aec_H_usage) */
    float   y_old_print[AEC3_LF_BLOCK_LENGTH];
    float   y_old[AEC3_LF_FFT_DISTANCE];
    FftDataPfdkf* G_pfdkf;
    FftDataPfdkf* G_pfdkf_speed;
    int     max_pfdkf_partitions;
    NearendEnergyFix nearend_energy_fix;
} Subtractor;

/**
 * Initialize the subtractor.
 *
 * @param self              Pointer to subtractor
 * @param config            AEC3 configuration
 * @param G_pfdkf_mem       Pre-allocated memory for G_pfdkf (aec_H_usage elements)
 * @param G_pfdkf_speed_mem Pre-allocated memory for G_pfdkf_speed (aec_H_usage elements)
 * @param H_error_pfdkf_mem Pre-allocated memory for H_error_pfdkf (aec_H_usage * 257 floats)
 * @param H_pf_mem          Pre-allocated memory for H_pf (aec_H_usage elements)
 * @param H_pf_speed_mem    Pre-allocated memory for H_pf_speed (aec_H_usage elements)
 * @param H_pf_update_mem   Pre-allocated memory for H_pf_update (aec_H_usage elements)
 * @param H2_pf_update_mem  Pre-allocated memory for H2_pf_update (aec_H_usage * 257 floats)
 * @param aec_H_usage       Number of PFDKF partitions to use
 */
void Subtractor_Init(Subtractor* self, const Aec3Config* config,
                     FftDataPfdkf* G_pfdkf_mem,
                     FftDataPfdkf* G_pfdkf_speed_mem,
                     float* H_error_pfdkf_mem,
                     FftDataPfdkf* H_pf_mem,
                     FftDataPfdkf* H_pf_speed_mem,
                     FftDataPfdkf* H_pf_update_mem,
                     float* H2_pf_update_mem,
                     int aec_H_usage);

/**
 * Handle echo path change: reset filters and gains.
 */
void Subtractor_HandleEchoPathChange(Subtractor* self,
                                     const EchoPathVariability* variability);

/**
 * Set earphone flag.
 */
void Subtractor_SetEarphoneFlag(Subtractor* self, int flag);

/**
 * Set voip flag.
 */
void Subtractor_SetVoipFlag(Subtractor* self, int flag);

/**
 * Set AEC H usage and resize PFDKF arrays.
 */
void Subtractor_SetAecHUsage(Subtractor* self, int size);

/**
 * Process one 64-sample capture block through the PFDKF subtractor.
 *
 * Performs PFDKF echo prediction using 512-point FFT, computes
 * frequency-domain prediction error, selects best error output,
 * detects misadjustment, computes Kalman gain, and adapts filter.
 *
 * @param self              Pointer to subtractor
 * @param render_buffer     Render buffer for PFDKF filter convolution
 * @param capture           Capture block (AEC3_LF_BLOCK_LENGTH = 64 samples)
 * @param output            Output: PFDKF frequency-domain subtractor results
 * @param update            Whether to execute filter update (0 = skip adaptation)
 */
void Subtractor_ProcessPfdkf(Subtractor* self,
                              const RenderBuffer* render_buffer,
                              const float* capture,
                              SubtractorOutputFrequency* output,
                              int update);

/**
 * Get the main filter's current partition count.
 */
int Subtractor_FilterLengthBlocks(const Subtractor* self);

#ifdef __cplusplus
}
#endif

#endif /* SUBTRACTOR_H_ */
