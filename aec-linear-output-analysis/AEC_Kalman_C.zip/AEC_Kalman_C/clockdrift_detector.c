/*
 *  ClockdriftDetector - Pure C Version (Forwarding Module)
 *
 *  The ClockdriftDetector implementation lives entirely in
 *  echo_path_delay_estimator.c. This file exists only to satisfy
 *  build systems that expect a .c file for every .h file.
 *
 *  No additional code is needed here.
 */

#include "clockdrift_detector.h"

/* Implementation is in echo_path_delay_estimator.c */
