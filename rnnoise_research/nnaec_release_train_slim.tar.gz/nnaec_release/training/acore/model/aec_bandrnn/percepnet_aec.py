#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
PercepNet 式 AEC 后置滤波器

严格对照开源 PercepNet 官方实现:
  AEC/_ref_opensource/PercepNet/rnn_train.py  (class PercepNet)
原版结构 (input_dim=70 -> 68 维输出 = 34 gb + 34 rb):
  fc(70->128, ReLU)
  conv1(128->512, k5, pad4, ReLU)   # 因果, 末尾裁 4
  conv2(512->512, k3, pad2, Tanh)   # 因果, 末尾裁 2
  gru1/gru2/gru3/gru_gb (都是 512->512)
  fc_gb: cat(conv,g1,g2,g3,ggb)=512*5 -> 34, Sigmoid   (band gain)
  gru_rb(1024->128) <- cat(gru3, conv);  fc_rb: 128 -> 34, Sigmoid  (comb r)
  output = cat(gb, rb)  # 68

AEC 适配 (仅改输入/输出维度, 其余层拓扑/通道/激活严格照搬):
  1. 输入维度: 70 -> nbands*num_inputs   (三路 band 特征拼接)
  2. 输出 band 数: 34 -> nbands           (gb 和 rb 各 nbands)
  3. forward 返回 (band_gain, comb_r, hidden), 与 system 对接;
     comb_r 对应原版 rb(谐波增强梳状强度), 可用可不用。
原版 512 通道偏大(PercepNet 全频带 48k 设计), 这里保留原始通道以忠实复刻;
如需轻量化, 用 conv_channels/gru_hidden 参数缩小 (不改拓扑)。
"""
import torch
import torch.nn as nn


class PercepNetAEC(nn.Module):
    def __init__(self,
                 nbands=32,
                 num_inputs=3,
                 fc_hidden=128,
                 conv_channels=512,
                 gru_hidden=512,
                 rb_gru_hidden=128,
                 **kwargs):
        super().__init__()
        self.nbands = nbands
        self.num_inputs = num_inputs
        in_dim = nbands * num_inputs

        # 严格对照 PercepNet:
        self.fc = nn.Sequential(nn.Linear(in_dim, fc_hidden), nn.ReLU())
        # padding for align with c++ dnn (因果, forward 里裁掉末尾)
        self.conv1 = nn.Sequential(
            nn.Conv1d(fc_hidden, conv_channels, 5, stride=1, padding=4), nn.ReLU())
        self.conv2 = nn.Sequential(
            nn.Conv1d(conv_channels, conv_channels, 3, stride=1, padding=2), nn.Tanh())
        self.gru1 = nn.GRU(conv_channels, gru_hidden, 1, batch_first=True)
        self.gru2 = nn.GRU(gru_hidden, gru_hidden, 1, batch_first=True)
        self.gru3 = nn.GRU(gru_hidden, gru_hidden, 1, batch_first=True)
        self.gru_gb = nn.GRU(gru_hidden, gru_hidden, 1, batch_first=True)
        # cat(conv, g1, g2, g3, ggb) = conv_channels + 4*gru_hidden
        self.fc_gb = nn.Sequential(
            nn.Linear(conv_channels + 4 * gru_hidden, nbands), nn.Sigmoid())
        # rb 分支: cat(gru3, conv) = gru_hidden + conv_channels
        self.gru_rb = nn.GRU(gru_hidden + conv_channels, rb_gru_hidden, 1, batch_first=True)
        self.fc_rb = nn.Sequential(nn.Linear(rb_gru_hidden, nbands), nn.Sigmoid())

    def forward(self, feat, hidden=None):
        """
        feat: [B, T, nbands*num_inputs]
        return: band_gain(gb) [B,T,nbands], comb_r(rb) [B,T,nbands], hidden(None)
        """
        x = self.fc(feat)
        x = x.permute([0, 2, 1])                 # B, D, T
        x = self.conv1(x)
        x = x[:, :, :-4]                         # 因果裁 4 (对齐 c++ dnn)
        convout = self.conv2(x)
        convout = convout[:, :, :-2]             # 因果裁 2
        convout = convout.permute([0, 2, 1])     # B, T, D

        gru1_out, _ = self.gru1(convout)
        gru2_out, _ = self.gru2(gru1_out)
        gru3_out, _ = self.gru3(gru2_out)
        gru_gb_out, _ = self.gru_gb(gru3_out)
        concat_gb = torch.cat((convout, gru1_out, gru2_out, gru3_out, gru_gb_out), -1)
        gb = self.fc_gb(concat_gb)

        concat_rb = torch.cat((gru3_out, convout), -1)
        rnn_rb_out, _ = self.gru_rb(concat_rb)
        rb = self.fc_rb(rnn_rb_out)

        return gb, rb, None


if __name__ == "__main__":
    nbands = 32
    model = PercepNetAEC(nbands=nbands, num_inputs=3)
    nparam = sum(p.numel() for p in model.parameters())
    print(f"PercepNetAEC params = {nparam} ({nparam/1e3:.1f}K)")
    feat = torch.randn(2, 50, nbands * 3)
    gb, rb, h = model(feat)
    print("gb:", gb.shape, "rb:", rb.shape)
