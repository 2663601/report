/*
 *  FftData Types - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ FftData struct.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Holds complex frequency-domain data produced from real-valued FFTs.
 *
 *  Independent types:
 *    FftData128   — 128-point FFT (re[65], im[65]), 520 bytes
 *    FftDataPfdkf — PFDKF/512-point FFT (relf[257], imlf[257]), 2056 bytes
 */

#ifndef FFT_DATA_H_
#define FFT_DATA_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * FftData128 — 128-point FFT frequency-domain data (520 bytes)
 * ================================================================ */
typedef struct {
    float re[AEC3_FFT_LENGTH_BY2_PLUS1];   /* 65 floats = 260 bytes */
    float im[AEC3_FFT_LENGTH_BY2_PLUS1];   /* 65 floats = 260 bytes */
} FftData128;

/* ================================================================
 * FftDataPfdkf — PFDKF / 512-point FFT frequency-domain data (2056 bytes)
 * ================================================================ */
typedef struct {
    float relf[AEC3_LF_FFT_LENGTH_BY2_PLUS1];   /* 257 floats = 1028 bytes */
    float imlf[AEC3_LF_FFT_LENGTH_BY2_PLUS1];   /* 257 floats = 1028 bytes */
} FftDataPfdkf;

/* Compile-time size verification (Property 1) */
#ifdef __cplusplus
static_assert(sizeof(FftData128)   == 520,  "FftData128 must be 520 bytes (65*2*4)");
static_assert(sizeof(FftDataPfdkf) == 2056, "FftDataPfdkf must be 2056 bytes (257*2*4)");
#elif defined(_MSC_VER)
/* MSVC C mode: use negative array size trick for compile-time check */
typedef char _FftData128_size_check[(sizeof(FftData128) == 520) ? 1 : -1];
typedef char _FftDataPfdkf_size_check[(sizeof(FftDataPfdkf) == 2056) ? 1 : -1];
#else
_Static_assert(sizeof(FftData128)   == 520,  "FftData128 must be 520 bytes (65*2*4)");
_Static_assert(sizeof(FftDataPfdkf) == 2056, "FftDataPfdkf must be 2056 bytes (257*2*4)");
#endif

/* ----------------------------------------------------------------
 * FftData128 functions
 * ---------------------------------------------------------------- */

/* Clear all fields to zero */
void FftData128_Clear(FftData128* self);

/* Copy all fields from src to dst */
void FftData128_Assign(FftData128* dst, const FftData128* src);

/* Compute power spectrum: power_spectrum[k] = re[k]^2 + im[k]^2 */
void FftData128_Spectrum(const FftData128* self, float* power_spectrum);

/*
 * Copy from packed (interleaved) 128-point FFT array to FftData128 fields.
 * Packed format: v[0] = DC, v[1] = Nyquist, then pairs (re[k], im[k])
 * for k = 1..63.
 */
void FftData128_CopyFromPackedArray(FftData128* self, const float* v);

/* Copy from FftData128 fields to packed (interleaved) 128-point FFT array */
void FftData128_CopyToPackedArray(const FftData128* self, float* v);

/* ----------------------------------------------------------------
 * FftDataPfdkf functions
 * ---------------------------------------------------------------- */

/* Clear all fields to zero */
void FftDataPfdkf_Clear(FftDataPfdkf* self);

/* Copy all fields from src to dst */
void FftDataPfdkf_Assign(FftDataPfdkf* dst, const FftDataPfdkf* src);

/* Compute power spectrum: power_spectrum[k] = relf[k]^2 + imlf[k]^2 */
void FftDataPfdkf_Spectrum(const FftDataPfdkf* self, float* power_spectrum);

/*
 * Copy from packed (interleaved) 512-point FFT array to FftDataPfdkf fields.
 * Packed format: v[0] = DC, v[1] = Nyquist, then pairs (relf[k], imlf[k])
 * for k = 1..255.
 */
void FftDataPfdkf_CopyFromPackedArray(FftDataPfdkf* self, const float* v);

/* Copy from FftDataPfdkf fields to packed (interleaved) 512-point FFT array */
void FftDataPfdkf_CopyToPackedArray(const FftDataPfdkf* self, float* v);

#ifdef __cplusplus
}
#endif

#endif /* FFT_DATA_H_ */
