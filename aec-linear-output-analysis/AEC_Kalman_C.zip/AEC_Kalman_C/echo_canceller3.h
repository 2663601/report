/*
 *  EchoCanceller3 - Pure C Version
 *
 *  Frame-level scheduler: manages frame-to-block conversion,
 *  high-pass filtering, render queue, and BlockProcessor coordination.
 *  Ported from WebRTC AEC3 C++ EchoCanceller3 class.
 *  Original copyright (c) 2016 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords.
 */

#ifndef ECHO_CANCELLER3_H_
#define ECHO_CANCELLER3_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "block_framer.h"
#include "frame_blocker.h"
#include "block_processor.h"
#include "cascaded_biquad_filter.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * EchoCanceller3
 *
 * Top-level AEC3 module. Handles:
 *   - Frame-to-block conversion (160 samples -> 64-sample blocks)
 *   - High-pass filtering of capture and render
 *   - Render queue (ring buffer replacing C++ SwapQueue)
 *   - Coordination of BlockProcessor
 * ================================================================ */
typedef struct {
    Aec3Config          config;
    int                 sample_rate_hz;
    int                 num_bands;
    int                 frame_length;       /* 160 for 16kHz */

    BlockFramer         output_framer;
    FrameBlocker        capture_blocker;
    FrameBlocker        render_blocker;

    BlockProcessor      block_processor;

    /* High-pass filter for capture */
    CascadedBiQuadFilter capture_highpass_filter;
    int                 use_highpass_filter;

    /* High-pass filter for render (in RenderWriter equivalent) */
    CascadedBiQuadFilter render_highpass_filter;
    int                 use_render_highpass_filter;

    /* Working block buffer */
    float               block[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE];

    int                 saturated_microphone_signal;

    /* Render buffer size (dynamically configurable) */
    int                 render_buffer_size;

    /* Runtime configuration */
    AecRuntimeConfig    aec_config_parameter;
    int                 echo_process_enable;

    /* Noise gate hold counter: set to 100 when AEC detects echo
     * (energy after AEC < 0.3 * energy before AEC), decrements by 1 each frame.
     * Used by external noise gate to decide whether to apply suppression. */
    int                 noise_gate_hold_counter;
    float               aec_energy_before;  /* capture energy before AEC */
    float               aec_energy_after;   /* capture energy after AEC */

    /* Render queue output frame */
    float               render_queue_output[AEC3_MAX_BANDS][AEC3_SUB_FRAME_LENGTH];
} EchoCanceller3;

/**
 * Initialize the EchoCanceller3.
 *
 * @param self              Pointer to EchoCanceller3
 * @param config            AEC3 configuration
 * @param sample_rate_hz    Sample rate in Hz
 * @param render_buffer_size Ring buffer slot count (0 = use default AEC3_RENDER_BUFFER_SIZE)
 * @param blocks_mem        Pre-allocated memory for time-domain ring buffer
 * @param spectra_mem       Pre-allocated memory for spectrum ring buffer (PFDKF only)
 * @param ffts2_mem         Pre-allocated memory for PFDKF FFT ring buffer
 * @param low_rate_mem      Pre-allocated memory for downsampled render buffer
 * @param low_rate_size     Size of downsampled render buffer
 * @param binary_dyn_mem    Pre-allocated memory for binary delay estimator
 */
void EchoCanceller3_Init(EchoCanceller3* self, const Aec3Config* config,
                         int sample_rate_hz, int render_buffer_size,
                         float* blocks_mem, float* spectra_mem,
                         FftDataPfdkf* ffts2_mem,
                         float* low_rate_mem, int low_rate_size,
                         float* binary_dyn_mem,
                         FftDataPfdkf* H_pf_mem,
                         FftDataPfdkf* H_pf_speed_mem,
                         FftDataPfdkf* H_pf_update_mem,
                         float* H2_pf_update_mem,
                         FftDataPfdkf* G_pfdkf_mem,
                         FftDataPfdkf* G_pfdkf_speed_mem,
                         float* H_error_pfdkf_mem,
                         int aec_H_usage);

/**
 * Analyze and buffer render (far-end) audio.
 * Called from the render thread / BufferFarend path.
 *
 * @param self          Pointer to EchoCanceller3
 * @param farend        Far-end audio samples (frame_length samples per band)
 * @param num_bands     Number of frequency bands
 * @param frame_length  Number of samples per band
 */
void EchoCanceller3_AnalyzeRender(EchoCanceller3* self,
                                  const float* farend,
                                  int num_bands,
                                  int frame_length);

/**
 * Analyze capture audio for saturation detection.
 *
 * @param self          Pointer to EchoCanceller3
 * @param capture       Capture audio samples
 * @param num_samples   Number of samples
 */
void EchoCanceller3_AnalyzeCapture(EchoCanceller3* self,
                                   const float* capture,
                                   int num_samples);

/**
 * Process capture audio: echo cancellation.
 *
 * @param self                      Pointer to EchoCanceller3
 * @param capture                   Capture audio (modified in-place)
 * @param num_samples               Number of samples per band
 * @param num_bands                 Number of frequency bands
 * @param level_change              Whether gain level changed
 * @param apm_submodule_switch      Submodule switch flag
 * @param earphone_flag             Earphone mode flag
 * @param sample_rate               Sample rate
 * @param adm_mute                  ADM mute flag
 */
void EchoCanceller3_ProcessCapture(EchoCanceller3* self,
                                   float* capture,
                                   int num_samples,
                                   int num_bands,
                                   int level_change,
                                   int apm_submodule_switch,
                                   int earphone_flag,
                                   int sample_rate,
                                   int adm_mute);

/**
 * Reset the echo canceller state.
 */
void EchoCanceller3_Reset(EchoCanceller3* self);

/**
 * Set the audio buffer delay.
 */
void EchoCanceller3_SetAudioBufferDelay(EchoCanceller3* self, int delay_ms);

/**
 * Set fixed delay mode: skip internal delay estimation to save computation.
 *
 * @param self                Pointer to EchoCanceller3
 * @param fixed_delay_blocks  >=0: use fixed delay (in blocks, 1 block ≈ 4ms);
 *                            <0: restore automatic delay estimation (default)
 */
void EchoCanceller3_SetFixedDelay(EchoCanceller3* self, int fixed_delay_blocks);

/**
 * Set the AEC runtime configuration.
 */
void EchoCanceller3_SetConfig(EchoCanceller3* self,
                              const AecRuntimeConfig* config);

#ifdef __cplusplus
}
#endif

#endif /* ECHO_CANCELLER3_H_ */
