/*
 *  Render Delay Controller - Pure C Version
 *
 *  Based on WebRTC AEC3 RenderDelayControllerImpl2.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Manages delay estimation and buffer delay computation with
 *  hysteresis to prevent frequent delay changes.
 */

#include "render_delay_controller.h"

#include <string.h>
#include <assert.h>

/* ================================================================
 * ComputeBufferDelay - Compute render buffer delay with hysteresis
 * ================================================================ */
static DelayEstimate ComputeBufferDelay(
    const DelayEstimate* current_delay,
    int has_current_delay,
    int delay_headroom_blocks,
    int hysteresis_limit_1_blocks,
    int hysteresis_limit_2_blocks,
    const DelayEstimate* estimated_delay)
{
    int echo_path_delay_blocks;
    int new_delay_blocks;
    DelayEstimate new_delay;

    /* Truncating division is intentional */
    echo_path_delay_blocks = (int)estimated_delay->delay >> AEC3_BLOCK_SIZE_LOG2;

    /* Compute buffer delay to achieve desired latency */
    new_delay_blocks = echo_path_delay_blocks - delay_headroom_blocks;
    if (new_delay_blocks < 0) {
        new_delay_blocks = 0;
    }

    /* Add hysteresis */
    if (has_current_delay) {
        int current_delay_blocks = (int)current_delay->delay;
        if (new_delay_blocks > current_delay_blocks) {
            if (new_delay_blocks <= current_delay_blocks + hysteresis_limit_1_blocks) {
                new_delay_blocks = current_delay_blocks;
            }
        } else if (new_delay_blocks < current_delay_blocks) {
            int hysteresis_limit = current_delay_blocks - hysteresis_limit_2_blocks;
            if (hysteresis_limit < 0) {
                hysteresis_limit = 0;
            }
            if (new_delay_blocks >= hysteresis_limit) {
                new_delay_blocks = current_delay_blocks;
            }
        }
    }

    new_delay = *estimated_delay;
    new_delay.delay = new_delay_blocks;
    return new_delay;
}

/* ================================================================
 * Public API
 * ================================================================ */

int RenderDelayController_GetDynMemSize(int render_buffer_size)
{
    return BinaryDelayEstimator_GetDynMemSize(render_buffer_size);
}

void RenderDelayController_Init(RenderDelayController* self,
                                const Aec3Config* config,
                                int non_causal_offset,
                                int sample_rate_hz,
                                int render_buffer_size,
                                float* binary_dyn_mem)
{
    assert(self != NULL);
    assert(config != NULL);

    (void)non_causal_offset;
    (void)sample_rate_hz;

    self->delay_headroom_blocks = config->delay_headroom_blocks;
    self->hysteresis_limit_1_blocks = config->delay_hysteresis_limit_1_blocks;
    self->hysteresis_limit_2_blocks = config->delay_hysteresis_limit_2_blocks;

    EchoPathDelayEstimator_Init(&self->delay_estimator, config,
                                render_buffer_size, binary_dyn_mem);

    self->has_delay = 0;
    memset(&self->delay, 0, sizeof(self->delay));

    self->has_delay_samples = 0;
    memset(&self->delay_samples, 0, sizeof(self->delay_samples));

    self->capture_call_counter = 0;
    self->delay_change_counter = 0;
    self->last_delay_estimate_quality = 0; /* kCoarse */
}

void RenderDelayController_Reset(RenderDelayController* self,
                                 int reset_delay_confidence)
{
    assert(self != NULL);

    self->has_delay = 0;
    self->has_delay_samples = 0;
    EchoPathDelayEstimator_Reset(&self->delay_estimator, reset_delay_confidence);
    self->delay_change_counter = 0;
    if (reset_delay_confidence) {
        self->last_delay_estimate_quality = 0; /* kCoarse */
    }
}

void RenderDelayController_LogRenderCall(RenderDelayController* self)
{
    assert(self != NULL);
    /* No-op: RenderDelayControllerImpl2 does not use SkewEstimator */
}

void RenderDelayController_SetAecHUsage(RenderDelayController* self,
                                        int size)
{
    assert(self != NULL);
    EchoPathDelayEstimator_SetAecHUsage(&self->delay_estimator, size);
}

void RenderDelayController_BufferRenderSpec(RenderDelayController* self,
                                            const float* far_spectrum,
                                            int spectrum_len)
{
    assert(self != NULL);
    EchoPathDelayEstimator_BufferRenderSpec(&self->delay_estimator,
                                            far_spectrum, spectrum_len);
}

void RenderDelayController_BufferRenderBlock(RenderDelayController* self,
                                             const float* far_block,
                                             int block_len)
{
    assert(self != NULL);
    EchoPathDelayEstimator_BufferRenderBlock(&self->delay_estimator,
                                             far_block, block_len);
}

int RenderDelayController_GetDelay(
    RenderDelayController* self,
    const DownsampledRenderBuffer* render_buffer,
    int render_delay_buffer_delay,
    int echo_remover_delay,
    int has_echo_remover_delay,
    const float* capture, int capture_len,
    int earphone_flag,
    int voip_mode_enable,
    int delay_default,
    int CastScreen,
    int matched_filter_enable_flag,
    int aec_low_compute_mode,
    DelayEstimate* out_delay)
{
    DelayEstimate delay_samples_est;
    int has_delay_samples_est;
    int use_hysteresis;

    assert(self != NULL);
    assert(capture_len == AEC3_BLOCK_SIZE);

    ++self->capture_call_counter;

    /* Estimate delay — pass capture directly (no delay_buf indirection) */
    has_delay_samples_est = EchoPathDelayEstimator_EstimateDelay(
        &self->delay_estimator,
        render_buffer,
        capture, AEC3_BLOCK_SIZE,
        earphone_flag, voip_mode_enable,
        delay_default,
        CastScreen,
        matched_filter_enable_flag,
        aec_low_compute_mode,
        &delay_samples_est);

    /* Overrule with echo remover delay if available */
    if (has_echo_remover_delay) {
        int total_delay = (render_delay_buffer_delay + echo_remover_delay) * AEC3_BLOCK_SIZE;
        delay_samples_est.quality = 1; /* kRefined */
        delay_samples_est.delay = total_delay;
        delay_samples_est.blocks_since_last_change = 0;
        delay_samples_est.blocks_since_last_update = 0;
        has_delay_samples_est = 1;
    }

    /* Update delay_samples tracking */
    if (has_delay_samples_est) {
        if (!self->has_delay_samples ||
            delay_samples_est.delay != self->delay_samples.delay) {
            self->delay_change_counter = 0;
        }
        if (self->has_delay_samples) {
            self->delay_samples.blocks_since_last_change =
                (self->delay_samples.delay == delay_samples_est.delay)
                    ? self->delay_samples.blocks_since_last_change + 1
                    : 0;
            self->delay_samples.blocks_since_last_update = 0;
            self->delay_samples.delay = delay_samples_est.delay;
            self->delay_samples.quality = delay_samples_est.quality;
        } else {
            self->delay_samples = delay_samples_est;
            self->has_delay_samples = 1;
        }
    } else {
        if (self->has_delay_samples) {
            ++self->delay_samples.blocks_since_last_change;
            ++self->delay_samples.blocks_since_last_update;
        }
    }

    if (self->delay_change_counter < 2 * AEC3_NUM_BLOCKS_PER_SECOND) {
        ++self->delay_change_counter;
    }

    /* Compute buffer delay */
    if (self->has_delay_samples) {
        int headroom;
        use_hysteresis =
            (self->last_delay_estimate_quality == 1) &&
            (self->delay_samples.quality == 1);

        headroom = self->delay_headroom_blocks;

        self->delay = ComputeBufferDelay(
            &self->delay, self->has_delay,
            headroom,
            use_hysteresis ? self->hysteresis_limit_1_blocks : 0,
            use_hysteresis ? self->hysteresis_limit_2_blocks : 0,
            &self->delay_samples);
        self->has_delay = 1;
        self->last_delay_estimate_quality = self->delay_samples.quality;
    }

    if (self->has_delay && out_delay != NULL) {
        *out_delay = self->delay;
    }

    return self->has_delay;
}

int RenderDelayController_HasClockdrift(const RenderDelayController* self)
{
    assert(self != NULL);
    return EchoPathDelayEstimator_GetClockdriftLevel(&self->delay_estimator)
           != CLOCKDRIFT_NONE;
}
