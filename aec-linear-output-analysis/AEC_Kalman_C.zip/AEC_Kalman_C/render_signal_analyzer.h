/*
 *  RenderSignalAnalyzer - Pure C Version
 *
 *  Analyzes render signal properties: narrow-band detection,
 *  strong peak identification, voice detection, and tone analysis.
 *
 *  Ported from WebRTC AEC3 C++ RenderSignalAnalyzer class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef RENDER_SIGNAL_ANALYZER_H_
#define RENDER_SIGNAL_ANALYZER_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "render_buffer.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * RenderSignalAnalyzer
 *
 * Detects narrow-band regions, strong spectral peaks, voice
 * presence, and non-voice tonal characteristics in the render
 * signal. Used by the echo remover to adapt suppression behavior.
 * ================================================================ */
typedef struct {
    int     strong_peak_freeze_duration;

    /* Narrow-band region counters (kFftLengthBy2 - 1 = 63 bins) */
    int     narrow_band_counters[AEC3_FFT_LENGTH_BY2 - 1];

    /* Strong narrow-band peak detection */
    int     narrow_peak_band;       /* Peak bin index, -1 if none */
    int     has_narrow_peak_band;
    int     narrow_peak_counter;

    /* Voice detection */
    int     voice_band_counter;

    /* Smoothed spectrum for tone detection (128-point) */
    float   X2_long[AEC3_FFT_LENGTH_BY2_PLUS1];

    /* Non-voice tone detection (128-point) */
    int     is_unvoice;
    int     trigger_counter;
    int     trigger_threshold;
    int     hold_counter;
    int     hold_duration;

    /* Non-voice tone detection (512-point) */
    int     is_unvoice_512fft;
    int     trigger_counter_512fft;
    int     trigger_threshold_512fft;
    int     hold_counter_512fft;
    int     hold_duration_512fft;
} RenderSignalAnalyzer;

/**
 * Initialize the render signal analyzer.
 *
 * @param self      Pointer to analyzer
 * @param config    AEC3 configuration
 */
void RenderSignalAnalyzer_Init(RenderSignalAnalyzer* self,
                               const Aec3Config* config);

/**
 * Update the analysis with the latest render buffer data.
 *
 * @param self              Pointer to analyzer
 * @param render_buffer     Render buffer
 * @param delay_partitions  Delay in partitions (-1 if not available)
 * @param has_delay         Whether delay_partitions is valid
 * @param render_noise      Render noise floor estimate (AEC3_FFT_LENGTH_BY2_PLUS1)
 */
void RenderSignalAnalyzer_Update(RenderSignalAnalyzer* self,
                                 const RenderBuffer* render_buffer,
                                 int delay_partitions,
                                 int has_delay,
                                 const float* render_noise);

/**
 * Update 512-point FFT tone analysis.
 *
 * @param self  Pointer to analyzer
 * @param X2    Power spectrum (AEC3_FFT_LENGTH_LONG_BY2_PLUS1 floats)
 */
void RenderSignalAnalyzer_Update512fft(RenderSignalAnalyzer* self,
                                       const float* X2);

/**
 * Check if the render signal has poor excitation (narrow-band).
 *
 * @param self  Pointer to analyzer
 * @return      1 if poor excitation detected, 0 otherwise
 */
int RenderSignalAnalyzer_PoorSignalExcitation(const RenderSignalAnalyzer* self);

/**
 * Check if the render signal is voice.
 *
 * @param self  Pointer to analyzer
 * @return      1 if voice detected, 0 otherwise
 */
int RenderSignalAnalyzer_VoiceSignal(const RenderSignalAnalyzer* self);

/**
 * Check if the render signal is non-voice (128-point analysis).
 */
int RenderSignalAnalyzer_IsUnVoiceSignal(const RenderSignalAnalyzer* self);

/**
 * Check if the render signal is non-voice (512-point analysis).
 */
int RenderSignalAnalyzer_IsUnVoiceSignal512fft(const RenderSignalAnalyzer* self);

/**
 * Zero the spectrum array around narrow-band signal regions.
 *
 * @param self  Pointer to analyzer
 * @param v     Spectrum array (AEC3_FFT_LENGTH_BY2_PLUS1 floats), modified in-place
 */
void RenderSignalAnalyzer_MaskRegionsAroundNarrowBands(
    const RenderSignalAnalyzer* self, float* v);

/**
 * Get the narrow peak band index.
 *
 * @param self          Pointer to analyzer
 * @param out_band      Output: peak band index
 * @return              1 if narrow peak exists, 0 otherwise
 */
int RenderSignalAnalyzer_NarrowPeakBand(const RenderSignalAnalyzer* self,
                                        int* out_band);

#ifdef __cplusplus
}
#endif

#endif /* RENDER_SIGNAL_ANALYZER_H_ */
