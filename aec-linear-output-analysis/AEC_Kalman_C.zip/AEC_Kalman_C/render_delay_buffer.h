/*
 *  RenderDelayBuffer - Pure C Version
 *
 *  Manages the render signal ring buffers (time-domain, frequency-domain,
 *  downsampled) and provides delay-aligned access for echo cancellation.
 *
 *  Ported from WebRTC AEC3 C++ RenderDelayBuffer class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef RENDER_DELAY_BUFFER_H_
#define RENDER_DELAY_BUFFER_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "aec3_buffer.h"
#include "aec3_fft.h"
#include "decimator.h"
#include "fft_data.h"
#include "render_buffer.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Buffering event codes */
#define RDB_EVENT_NONE              0
#define RDB_EVENT_RENDER_UNDERRUN   1
#define RDB_EVENT_RENDER_OVERRUN    2
#define RDB_EVENT_API_CALL_SKEW     3

/* ================================================================
 * RenderDelayBuffer - Render signal buffering with delay alignment
 *
 * Contains:
 *   - MatrixBuffer for time-domain blocks (multi-band)
 *   - VectorBuffer for power spectra
 *   - FftBuffer for FFT data
 *   - DownsampledRenderBuffer for matched filter delay estimation
 *   - Decimator for downsampling
 *   - RenderBuffer view for echo remover access
 * ================================================================ */
typedef struct {
    /* Configuration */
    Aec3Config          config;
    int                 num_bands;
    int                 down_sampling_factor;
    int                 sub_block_size;
    int                 buffer_headroom;

    /* Ring buffer storage - pre-allocated memory pointers */
    MatrixBuffer        blocks;
    VectorBuffer        spectra;

    /* Pre-allocated memory for ring buffers */
    float*              blocks_mem;     /* size * num_bands * AEC3_BLOCK_SIZE */
    float*              spectra_mem;    /* size * AEC3_LF_FFT_LENGTH_BY2_PLUS1 (PFDKF only) */
    FftDataPfdkf*       ffts2_mem;      /* size FftDataPfdkf objects */

    /* Typed FftBuffer pointer (owned by BlockProcessor; fft_buffer_128 removed) */
    FftBufferPfdkf*     fft_buffer_pfdkf;

    /* Delay state */
    int                 delay;          /* External delay in blocks */
    int                 has_delay;
    int                 internal_delay; /* Internal delay */
    int                 has_internal_delay;

    /* Echo remover buffer view */
    RenderBuffer        echo_remover_buffer;

    /* Downsampled render buffer for delay estimation */
    DownsampledRenderBuffer low_rate;
    float*              low_rate_mem;   /* Pre-allocated downsampled buffer */
    int                 low_rate_size;

    /* Decimator */
    Decimator           render_decimator;

    /* FFT engine */
    Aec3Fft             fft;

    /* Temporary downsampled render block */
    float               render_ds[AEC3_BLOCK_SIZE]; /* sub_block_size max */

    /* PFDKF history buffer: x_lf[AEC3_LF_FFT_DISTANCE] = 448 samples */
    float               x_lf[AEC3_LF_FFT_DISTANCE];
    Aec3Fft             fft_pfdkf;

    /* API call jitter tracking */
    int                 last_call_was_render;
    int                 num_api_calls_in_a_row;
    int                 max_observed_jitter;
    int                 capture_call_counter;
    int                 render_call_counter;

    /* Render activity detection */
    int                 render_activity;
    int                 render_activity_counter;

    /* External audio buffer delay */
    int                 external_audio_buffer_delay;
    int                 has_external_audio_buffer_delay;
    int                 external_delay_verified_after_reset;

    /* Buffer size (number of slots) */
    int                 buffer_size;

    /* Max allowed excess render blocks */
    int                 max_allowed_excess_render_blocks;

    /* Excess render detection (Impl2) */
    int                 min_latency_blocks;
    int                 excess_render_detection_counter;
} RenderDelayBuffer;

/**
 * Compute the delay estimator offset from config.
 */
int RenderDelayBuffer_DelayEstimatorOffset(const Aec3Config* config);

/**
 * Initialize the render delay buffer.
 *
 * All internal ring buffers are set up using the provided pre-allocated
 * memory regions. The caller must ensure sufficient memory is available.
 *
 * @param self              Pointer to RenderDelayBuffer
 * @param config            AEC3 configuration
 * @param num_bands         Number of frequency bands (1 for 16kHz, 3 for 48kHz)
 * @param render_buffer_size Ring buffer slot count (externally controlled)
 * @param blocks_mem        Pre-allocated memory for MatrixBuffer
 * @param spectra_mem   Pre-allocated memory for VectorBuffer (PFDKF only)
 * @param ffts2_mem     Pre-allocated memory for FftBufferPfdkf (PFDKF)
 * @param low_rate_mem  Pre-allocated memory for downsampled buffer
 * @param fft_buffer_pfdkf Pre-initialized FftBufferPfdkf instance
 */
void RenderDelayBuffer_Init(RenderDelayBuffer* self,
                            const Aec3Config* config,
                            int num_bands,
                            int render_buffer_size,
                            float* blocks_mem,
                            float* spectra_mem,
                            FftDataPfdkf* ffts2_mem,
                            float* low_rate_mem,
                            FftBufferPfdkf* fft_buffer_pfdkf);

/**
 * Reset the buffer alignment and delay state.
 */
void RenderDelayBuffer_Reset(RenderDelayBuffer* self);

/**
 * Set the maximum allowed excess render blocks.
 */
void RenderDelayBuffer_SetMaxAllowedExcessRenderBlocks(
    RenderDelayBuffer* self, int max_blocks);

/**
 * Insert a render block into the buffer.
 *
 * @param self          Pointer to RenderDelayBuffer
 * @param block         Render block: block[band][AEC3_BLOCK_SIZE]
 * @param num_bands     Number of bands in the block
 * @param pfdkf_enable  Whether PFDKF processing is enabled
 * @param aec_level     AEC processing level
 * @return              Buffering event code
 */
int RenderDelayBuffer_Insert(RenderDelayBuffer* self,
                             const float block[][AEC3_BLOCK_SIZE],
                             int num_bands,
                             int pfdkf_enable,
                             int aec_level);

/**
 * Prepare the buffer for capture processing.
 * Advances read indices and checks for underrun/skew.
 *
 * @param self  Pointer to RenderDelayBuffer
 * @return      Buffering event code
 */
int RenderDelayBuffer_PrepareCaptureProcessing(RenderDelayBuffer* self);

/**
 * Set the buffer delay.
 *
 * @param self          Pointer to RenderDelayBuffer
 * @param delay         Delay in blocks
 * @param delay_default Default delay value
 * @param aec_H_usage   AEC H usage parameter
 * @return              1 if delay changed, 0 otherwise
 */
int RenderDelayBuffer_SetDelay(RenderDelayBuffer* self,
                               int delay, int delay_default,
                               int aec_H_usage);

/**
 * Get the current external delay.
 */
int RenderDelayBuffer_Delay(const RenderDelayBuffer* self);

/**
 * Get the maximum allowed delay.
 */
int RenderDelayBuffer_MaxDelay(const RenderDelayBuffer* self);

/**
 * Get the RenderBuffer view for the echo remover.
 */
RenderBuffer* RenderDelayBuffer_GetRenderBuffer(RenderDelayBuffer* self);

/**
 * Get the downsampled render buffer for delay estimation.
 */
const DownsampledRenderBuffer* RenderDelayBuffer_GetDownsampledRenderBuffer(
    const RenderDelayBuffer* self);

/**
 * Check if the given delay is causal.
 */
int RenderDelayBuffer_CausalDelay(const RenderDelayBuffer* self, int delay);

/**
 * Provide an external estimate of the audio buffer delay.
 *
 * @param self      Pointer to RenderDelayBuffer
 * @param delay_ms  Delay in milliseconds
 */
void RenderDelayBuffer_SetAudioBufferDelay(RenderDelayBuffer* self,
                                           int delay_ms);

#ifdef __cplusplus
}
#endif

#endif /* RENDER_DELAY_BUFFER_H_ */
