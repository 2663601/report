/*
 *  RenderBuffer - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ render_buffer.cc
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "render_buffer.h"

#include <assert.h>
#include <string.h>

void RenderBuffer_Init(RenderBuffer* self,
                       MatrixBuffer* block_buf,
                       VectorBuffer* spec_buf)
{
    assert(self != NULL);
    assert(block_buf != NULL);
    assert(spec_buf != NULL);

    self->block_buffer    = block_buf;
    self->spectrum_buffer = spec_buf;
    self->fft_buffer_pfdkf = NULL;
    self->render_activity = 0;
}

const float* RenderBuffer_Block(const RenderBuffer* self,
                                int offset_blocks, int band)
{
    int position;
    assert(self != NULL);
    assert(self->block_buffer != NULL);

    position = MatrixBuffer_OffsetIndex(self->block_buffer,
                                        self->block_buffer->read,
                                        offset_blocks);
    return MatrixBuffer_GetSlot(self->block_buffer, position, band);
}

const float* RenderBuffer_Spectrum(const RenderBuffer* self,
                                   int offset_ffts)
{
    /* 128pt spectrum buffer removed — always return NULL */
    (void)self;
    (void)offset_ffts;
    return NULL;
}

const float* RenderBuffer_SpectrumPfdkf(const RenderBuffer* self,
                                        int offset_ffts)
{
    int position;
    assert(self != NULL);
    assert(self->spectrum_buffer != NULL);
    assert(self->spectrum_buffer->buffer_pfdkf != NULL);

    position = VectorBuffer_OffsetIndex(self->spectrum_buffer,
                                        self->spectrum_buffer->read,
                                        offset_ffts);
    return self->spectrum_buffer->buffer_pfdkf + position * self->spectrum_buffer->pfdkf_height;
}

int RenderBuffer_Position(const RenderBuffer* self)
{
    assert(self != NULL);
    assert(self->fft_buffer_pfdkf != NULL);
    return self->fft_buffer_pfdkf->read;
}

void RenderBuffer_SpectralSum(const RenderBuffer* self,
                              int num_spectra, float* X2)
{
    /* 128pt spectrum buffer removed — zero output */
    (void)self;
    (void)num_spectra;
    memset(X2, 0, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
}

void RenderBuffer_SpectralSums(const RenderBuffer* self,
                               int num_spectra_shorter,
                               int num_spectra_longer,
                               float* X2_shorter,
                               float* X2_longer)
{
    /* 128pt spectrum buffer removed — zero output */
    (void)self;
    (void)num_spectra_shorter;
    (void)num_spectra_longer;
    memset(X2_shorter, 0, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
    memset(X2_longer, 0, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
}

int RenderBuffer_GetRenderActivity(const RenderBuffer* self)
{
    assert(self != NULL);
    return self->render_activity;
}

void RenderBuffer_SetRenderActivity(RenderBuffer* self, int activity)
{
    assert(self != NULL);
    self->render_activity = activity;
}

int RenderBuffer_Headroom(const RenderBuffer* self)
{
    int headroom;
    assert(self != NULL);
    assert(self->fft_buffer_pfdkf != NULL);

    if (self->fft_buffer_pfdkf->write < self->fft_buffer_pfdkf->read) {
        headroom = self->fft_buffer_pfdkf->read - self->fft_buffer_pfdkf->write;
    } else {
        headroom = self->fft_buffer_pfdkf->size -
                   self->fft_buffer_pfdkf->write +
                   self->fft_buffer_pfdkf->read;
    }
    return headroom;
}

const VectorBuffer* RenderBuffer_GetSpectrumBuffer(const RenderBuffer* self)
{
    assert(self != NULL);
    return self->spectrum_buffer;
}

const MatrixBuffer* RenderBuffer_GetBlockBuffer(const RenderBuffer* self)
{
    assert(self != NULL);
    return self->block_buffer;
}

const FftDataPfdkf* RenderBuffer_GetFftBufferPfdkf(const RenderBuffer* self)
{
    assert(self != NULL);
    assert(self->fft_buffer_pfdkf != NULL);
    return self->fft_buffer_pfdkf->buffer;
}
