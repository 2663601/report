/*
 * AEC_Kalman module C interface - Pure C version
 * WebRTC AEC3 (Kalman) echo cancellation
 * Triggered by aec_delay_ms = -3
 *
 * Multi-band interface: matches AEC_webrtc calling convention.
 * BufferFarend: low-band only (160 samples @16kHz)
 * Process: multi-band input/output (num_bands x 160 samples)
 *          AEC on low-band, gain applied to high-bands
 */

#ifndef _YS_AEC_KALMAN_INTERFACE_H_
#define _YS_AEC_KALMAN_INTERFACE_H_

#include "aec3_config.h"

#ifdef __cplusplus
extern "C" {
#endif

int YS_AEC_Kalman_GetMemSize(void);

int YS_AEC_Kalman_Create(void* alloc_buf, void** handle,
                          int sample_rate, int frame_len, int nlp_level);

/* Buffer far-end reference signal (low-band only, 160 samples) */
int YS_AEC_Kalman_BufferFarend(void* handle, const float* far, int nrOfSamples);

/* Process multi-band near-end signal
 * nearend: array of float pointers, one per band [num_bands]
 * num_bands: number of frequency bands (1 @16kHz, 3 @48kHz)
 * out: array of float pointers, one per band [num_bands]
 * nrOfSamples: samples per band (160)
 */
int YS_AEC_Kalman_Process(void* handle,
                           const float* const* nearend,
                           int num_bands,
                           float* const* out,
                           int nrOfSamples);

int YS_AEC_Kalman_Destroy(void* handle);

/*
 * 设置外部固定延时并关闭内部延时估计模块(MatchedFilter+频谱互相关),
 * 用于延时固定的设备以节约计算量.
 *
 * delay_ms: 外部指定的远近端延时(毫秒), >=0 生效并关闭延时估计;
 *           <0 恢复自动延时估计(默认行为).
 */
int YS_AEC_Kalman_SetFixedDelay(void* handle, int delay_ms);

/* Get noise_gate_hold_counter from AEC Kalman internal state.
 * Returns >0 when AEC recently detected echo, 0 otherwise. */
int YS_AEC_Kalman_GetNoiseGateHoldCounter(void* handle);

/* Set AEC runtime config (noise gate params, etc.) */
int YS_AEC_Kalman_SetRuntimeConfig(void* handle, const AecRuntimeConfig* config);

#ifdef __cplusplus
}
#endif

#endif /* _YS_AEC_KALMAN_INTERFACE_H_ */
