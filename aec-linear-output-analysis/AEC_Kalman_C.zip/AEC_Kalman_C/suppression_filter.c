/*
 *  SuppressionFilter - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ SuppressionFilter class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point path retained.
 */

#include "suppression_filter.h"
#include <string.h>
#include <math.h>

void SuppressionFilter_Init(SuppressionFilter* self, int sample_rate_hz) {
    memset(self, 0, sizeof(SuppressionFilter));
    self->sample_rate_hz = sample_rate_hz;
    self->num_bands = Aec3_NumBandsForRate(sample_rate_hz);
    Aec3Fft_Init(&self->fft_512);
}

void SuppressionFilter_ApplyGain512(SuppressionFilter* self,
                                    const FftDataPfdkf* comfort_noise,
                                    const FftDataPfdkf* comfort_noise_high,
                                    const float* suppression_gain,
                                    float high_bands_gain,
                                    const FftDataPfdkf* E_lowest_band,
                                    float e[][AEC3_BLOCK_SIZE],
                                    int num_bands) {
    FftDataPfdkf E;
    float noise_gain[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float e_extended[AEC3_FFT_LENGTH_LONG];
    const float kIfftNorm = 2.0f / (float)AEC3_FFT_LENGTH_LONG;
    int k;
    double noise_max, noise_ratio, k_f;
    double noise_masker_rel, noise_masker_iml;

    /* Copy long FFT data and apply gain */
    FftDataPfdkf_Assign(&E, E_lowest_band);
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        E.relf[k] *= suppression_gain[k];
        E.imlf[k] *= suppression_gain[k];
    }

    /* Compute comfort noise gain */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        float g2 = suppression_gain[k] * suppression_gain[k];
        float ng = 1.0f - g2;
        noise_gain[k] = (ng > 0.0f) ? sqrtf(ng) : 0.0f;
    }

    /* Add comfort noise with frequency-dependent limiting */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        k_f = (double)k;
        if (k < 16) {
            noise_max = 1e4;
        } else if (k < 32) {
            noise_max = 1e3 + (32.0 - k_f) / 16.0 * (1e4 - 1e3);
        } else {
            noise_max = 1e3;
        }
        noise_ratio = 1.0 - k_f / (double)AEC3_FFT_LENGTH_LONG_BY2_PLUS1;

        noise_masker_rel = (double)comfort_noise->relf[k];
        if (noise_masker_rel > noise_max * noise_ratio * noise_ratio)
            noise_masker_rel = noise_max * noise_ratio * noise_ratio;
        if (noise_masker_rel < -noise_max * noise_ratio * noise_ratio)
            noise_masker_rel = -noise_max * noise_ratio * noise_ratio;

        noise_masker_iml = (double)comfort_noise->imlf[k];
        if (noise_masker_iml > noise_max * noise_ratio * noise_ratio)
            noise_masker_iml = noise_max * noise_ratio * noise_ratio;
        if (noise_masker_iml < -noise_max * noise_ratio * noise_ratio)
            noise_masker_iml = -noise_max * noise_ratio * noise_ratio;

        E.relf[k] += noise_gain[k] * (float)noise_masker_rel;
        E.imlf[k] += noise_gain[k] * (float)noise_masker_iml;
    }

    /* IFFT 512 and overlap-add */
    Aec3Fft_Ifft512_typed(&self->fft_512, &E, e_extended);

    {
        float sqrt_hanning_val;
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
            sqrt_hanning_val = sinf(3.14159265f * (float)k / (float)AEC3_FFT_LENGTH_LONG);
            float old_part = kIfftNorm * self->e_output_old_long[0][k] *
                             sinf(3.14159265f * (float)(k + AEC3_FFT_LENGTH_LONG_BY2) / (float)AEC3_FFT_LENGTH_LONG);
            float new_part = kIfftNorm * e_extended[k] * sqrt_hanning_val;
            float val = old_part + new_part;
            if (val < -32768.0f) val = -32768.0f;
            if (val > 32767.0f) val = 32767.0f;
            if (k < AEC3_BLOCK_SIZE) {
                e[0][k] = val;
            }
        }
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
            self->e_output_old_long[0][k] = e_extended[k + AEC3_FFT_LENGTH_LONG_BY2];
        }
    }

    /* Upper bands */
    if (num_bands > 1) {
        int b;
        for (b = 1; b < num_bands; b++) {
            for (k = 0; k < AEC3_BLOCK_SIZE; k++) {
                float val = e[b][k] * high_bands_gain;
                if (val < -32768.0f) val = -32768.0f;
                if (val > 32767.0f) val = 32767.0f;
                e[b][k] = val;
            }
        }
    }
}
