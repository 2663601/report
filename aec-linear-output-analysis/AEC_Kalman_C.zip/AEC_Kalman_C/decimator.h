/*
 *  Decimator - Pure C Version
 *
 *  Provides signal decimation (downsampling) with anti-aliasing
 *  and noise reduction filtering.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef DECIMATOR_H_
#define DECIMATOR_H_

#include "aec3_common.h"
#include "cascaded_biquad_filter.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int                     down_sampling_factor;
    CascadedBiQuadFilter    anti_aliasing_filter;
    CascadedBiQuadFilter    noise_reduction_filter;
} Decimator;

/* Initialize the decimator with the given downsampling factor (2, 4, or 8). */
void Decimator_Init(Decimator* self, int down_sampling_factor);

/*
 * Decimate a block of AEC3_BLOCK_SIZE samples.
 *
 * in:  input buffer of AEC3_BLOCK_SIZE samples
 * out: output buffer of AEC3_BLOCK_SIZE / down_sampling_factor samples
 */
void Decimator_Decimate(Decimator* self,
                        const float* in, float* out, int in_len);

#ifdef __cplusplus
}
#endif

#endif /* DECIMATOR_H_ */
