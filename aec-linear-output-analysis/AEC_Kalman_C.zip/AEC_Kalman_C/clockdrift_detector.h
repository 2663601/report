/*
 *  ClockdriftDetector - Pure C Version (Forwarding Header)
 *
 *  The ClockdriftDetector is fully implemented inside
 *  echo_path_delay_estimator.h / echo_path_delay_estimator.c.
 *
 *  This header provides a standalone include point so that modules
 *  needing only the clockdrift detector do not have to pull in the
 *  entire EchoPathDelayEstimator dependency tree.
 *
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef CLOCKDRIFT_DETECTOR_H_
#define CLOCKDRIFT_DETECTOR_H_

#include "echo_path_delay_estimator.h"

/*
 * The following types and functions are already declared in
 * echo_path_delay_estimator.h and implemented in
 * echo_path_delay_estimator.c:
 *
 *   Macros:
 *     CLOCKDRIFT_NONE         (0)
 *     CLOCKDRIFT_PROBABLE     (1)
 *     CLOCKDRIFT_VERIFIED     (2)
 *
 *   Type:
 *     ClockdriftDetector      (struct with delay_history, level,
 *                              stability_counter)
 *
 *   Functions:
 *     void ClockdriftDetector_Init(ClockdriftDetector* self);
 *     void ClockdriftDetector_Update(ClockdriftDetector* self,
 *                                    int delay_estimate);
 *
 * No additional declarations are needed here.
 */

#endif /* CLOCKDRIFT_DETECTOR_H_ */
