/*
 *  Subtractor - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ Subtractor class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *  128-point filter path removed — only PFDKF path retained.
 */

#include "subtractor.h"
#include "aec_state.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <assert.h>

/* ================================================================
 * NearendEnergyFix
 * ================================================================ */

void NearendEnergyFix_Init(NearendEnergyFix* self) {
    memset(self->ES.relf, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memset(self->ES.imlf, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memset(self->E2, 0, sizeof(self->E2));
    memset(self->S2, 0, sizeof(self->S2));
    memset(self->E2_fix, 0, sizeof(self->E2_fix));
    memset(self->E2_fix_suppress, 0, sizeof(self->E2_fix_suppress));
    memset(self->ES2, 0, sizeof(self->ES2));
    self->cohes = 0.0f;
}

void NearendEnergyFix_Update(NearendEnergyFix* self,
                              const SubtractorOutputFrequency* output) {
    const float smooth0 = 0.93f;
    const float smooth1 = 0.07f;
    int k;

    for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
        self->ES.relf[k] = smooth0 * self->ES.relf[k]
            + smooth1 * (output->E_out.relf[k] * output->S_out.relf[k]
                       + output->E_out.imlf[k] * output->S_out.imlf[k]);
        self->ES.imlf[k] = smooth0 * self->ES.imlf[k]
            + smooth1 * (output->E_out.relf[k] * output->S_out.imlf[k]
                       - output->E_out.imlf[k] * output->S_out.relf[k]);

        self->E2[k] = smooth0 * self->E2[k] + smooth1 * output->E2_out[k];
        self->S2[k] = smooth0 * self->S2[k] + smooth1 * output->S2_out[k];

        self->ES2[k] = self->ES.relf[k] * self->ES.relf[k]
                      + self->ES.imlf[k] * self->ES.imlf[k];

        self->cohes = sqrtf(self->ES2[k] / (self->E2[k] * self->S2[k] + 1e-10f));
        self->cohes = self->cohes < 1.0f ? self->cohes : 1.0f;

        self->E2_fix_suppress[k] = (1.0f - self->cohes) * output->E2_out[k];

        self->cohes = self->cohes < 0.5f ? self->cohes : 0.5f;
        self->E2_fix[k] = (1.0f - self->cohes) * output->E2_out[k];
    }
}

/* ================================================================
 * FilterMisadjustmentEstimator
 * ================================================================ */

void FilterMisadjustmentEstimator_Init(FilterMisadjustmentEstimator* self) {
    self->n_blocks = 4;
    self->n_blocks_acum = 0;
    self->e2_acum = 0.0f;
    self->y2_acum = 0.0f;
    self->inv_misadjustment = 0.0f;
    self->overhang = 0;
    self->E2_acum = 0.0f;
    self->Y2_acum = 0.0f;
}

void FilterMisadjustmentEstimator_Update(FilterMisadjustmentEstimator* self,
                                         const SubtractorOutput* output) {
    self->e2_acum += output->e2_main;
    self->y2_acum += output->y2;
    self->n_blocks_acum++;

    if (self->n_blocks_acum >= self->n_blocks) {
        if (self->y2_acum > 0.0f) {
            float inv = self->e2_acum / self->y2_acum;
            if (inv > self->inv_misadjustment) {
                self->inv_misadjustment = inv;
                self->overhang = 4;
            } else {
                if (self->overhang > 0) {
                    self->overhang--;
                } else {
                    self->inv_misadjustment *= 0.97f;
                }
            }
        }
        self->e2_acum = 0.0f;
        self->y2_acum = 0.0f;
        self->n_blocks_acum = 0;
    }
}

void FilterMisadjustmentEstimator_Reset(FilterMisadjustmentEstimator* self) {
    self->n_blocks_acum = 0;
    self->e2_acum = 0.0f;
    self->y2_acum = 0.0f;
    self->inv_misadjustment = 0.0f;
    self->overhang = 0;
}

int FilterMisadjustmentEstimator_IsAdjustmentNeeded(
        const FilterMisadjustmentEstimator* self) {
    return self->inv_misadjustment > 10.0f;
}

float FilterMisadjustmentEstimator_GetMisadjustment(
          const FilterMisadjustmentEstimator* self) {
    assert(self->inv_misadjustment > 0.0f);
    return 2.0f / sqrtf(self->inv_misadjustment);
}

void FilterMisadjustmentEstimator_UpdateFrequency(
         FilterMisadjustmentEstimator* self,
         const SubtractorOutputFrequency* output) {
    self->E2_acum += output->E2_accum;
    self->Y2_acum += output->Y2_accum;
    self->n_blocks_acum++;

    if (self->n_blocks_acum >= self->n_blocks) {
        if (self->y2_acum > self->n_blocks * 44015068.0f * AEC3_LF_FFT_LENGTH_BY2_PLUS1) {
            float update = self->E2_acum / self->Y2_acum;
            if (self->E2_acum > self->n_blocks * 4401506800.0f * AEC3_LF_FFT_LENGTH_BY2_PLUS1) {
                self->overhang = 4;
            } else {
                self->overhang = self->overhang > 1 ? self->overhang - 1 : 0;
            }

            if ((update < self->inv_misadjustment) || (self->overhang > 9)) {
                self->inv_misadjustment += 0.1f * (update - self->inv_misadjustment);
            }
        }
        self->E2_acum = 0.0f;
        self->Y2_acum = 0.0f;
        self->n_blocks_acum = 0;
    }
}

void FilterMisadjustmentEstimator_ResetFrequency(
         FilterMisadjustmentEstimator* self) {
    self->E2_acum = 0.0f;
    self->Y2_acum = 0.0f;
    self->n_blocks_acum = 0;
    self->inv_misadjustment = 0.0f;
    self->overhang = 0;
}

/* ================================================================
 * Helper: PredictionErrorPfdkf
 * ================================================================ */
static void PredictionErrorPfdkf(const FftDataPfdkf* S, const FftDataPfdkf* Y,
                                  FftDataPfdkf* E) {
    int i;
    for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; i++) {
        E->relf[i] = Y->relf[i] - S->relf[i];
        E->imlf[i] = Y->imlf[i] - S->imlf[i];
    }
}

/* ================================================================
 * Helper: AnalyzeErrorPfdkf
 * ================================================================ */
static void AnalyzeErrorPfdkf(SubtractorOutputFrequency* output,
                               AdaptiveFirFilter* filter) {
    int i;

    memcpy(output->E_out.relf, output->E.relf,
           sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memcpy(output->E_out.imlf, output->E.imlf,
           sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memcpy(output->S_out.relf, output->S.relf,
           sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memcpy(output->S_out.imlf, output->S.imlf,
           sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memcpy(output->E2_out, output->E2,
           sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);

    AdaptiveFirFilter_SetHPfUpdate(filter);

    for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; i++) {
        if (output->E2_speed[i] < output->E2[i]) {
            output->E_out.relf[i] = output->E_speed.relf[i];
            output->E_out.imlf[i] = output->E_speed.imlf[i];
            output->S_out.relf[i] = output->S_speed.relf[i];
            output->S_out.imlf[i] = output->S_speed.imlf[i];
            output->E2_out[i] = output->E2_speed[i];
            AdaptiveFirFilter_UpdateHPfupdate(filter, i);
        }
    }

    FftDataPfdkf_Spectrum(&output->S_out, output->S2_out);
    AdaptiveFirFilter_ComputeH2PfResponse(filter);

    output->E2_accum = 0.0f;
    output->Y2_accum = 0.0f;
    for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; i++) {
        output->E2_accum += output->E2_out[i];
        output->Y2_accum += output->Y2[i];
    }
}

/* ================================================================
 * Helper: ScaleFilterOutputFrequencyPfdkf
 * ================================================================ */
static void ScaleFilterOutputFrequencyPfdkf(
    FftDataPfdkf* Y, float factor,
    FftDataPfdkf* E, FftDataPfdkf* S,
    SubtractorOutputFrequency* output) {
    float factor2 = factor * factor;
    int i;
    for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; i++) {
        S->relf[i] *= factor;
        S->imlf[i] *= factor;
        E->relf[i] = Y->relf[i] - S->relf[i];
        E->imlf[i] = Y->imlf[i] - S->imlf[i];
        output->S2_out[i] *= factor2;
    }
    FftDataPfdkf_Spectrum(E, output->E2_out);
}

/* ================================================================
 * Helper: ComputeMetricsPfdkf
 * ================================================================ */
static void ComputeMetricsPfdkf(SubtractorOutputFrequency* output,
                                 const FftDataPfdkf* Y) {
    FftDataPfdkf_Spectrum(&output->E, output->E2);
    FftDataPfdkf_Spectrum(&output->E_speed, output->E2_speed);
    FftDataPfdkf_Spectrum(Y, output->Y2);
}

/* ================================================================
 * Subtractor_Init
 * ================================================================ */
void Subtractor_Init(Subtractor* self, const Aec3Config* config,
                     FftDataPfdkf* G_pfdkf_mem,
                     FftDataPfdkf* G_pfdkf_speed_mem,
                     float* H_error_pfdkf_mem,
                     FftDataPfdkf* H_pf_mem,
                     FftDataPfdkf* H_pf_speed_mem,
                     FftDataPfdkf* H_pf_update_mem,
                     float* H2_pf_update_mem,
                     int aec_H_usage) {
    MainFilterConfig main_cfg, main_initial_cfg;

    memset(self, 0, sizeof(Subtractor));
    self->config = *config;

    /* Assign externally allocated PFDKF memory for G_pfdkf/G_pfdkf_speed */
    self->G_pfdkf = G_pfdkf_mem;
    self->G_pfdkf_speed = G_pfdkf_speed_mem;
    self->max_pfdkf_partitions = aec_H_usage;

    Aec3Fft_Init(&self->fft_pfdkf);

    /* Initialize main filter with externally allocated PFDKF memory */
    AdaptiveFirFilter_Init(&self->main_filter,
                           config->filter_main_length_blocks,
                           config->filter_main_initial_length_blocks,
                           config->config_change_duration_blocks,
                           H_pf_mem, H_pf_speed_mem, H_pf_update_mem,
                           H2_pf_update_mem, aec_H_usage);

    /* Initialize main filter update gain */
    main_initial_cfg.length_blocks = config->filter_main_initial_length_blocks;
    main_initial_cfg.leakage_converged = config->filter_main_initial_leakage_converged;
    main_initial_cfg.leakage_diverged = config->filter_main_initial_leakage_diverged;
    main_initial_cfg.error_floor = config->filter_main_initial_error_floor;
    main_initial_cfg.error_ceil = config->filter_main_initial_error_ceil;
    main_initial_cfg.noise_gate = config->filter_main_initial_noise_gate;

    main_cfg.length_blocks = config->filter_main_length_blocks;
    main_cfg.leakage_converged = config->filter_main_leakage_converged;
    main_cfg.leakage_diverged = config->filter_main_leakage_diverged;
    main_cfg.error_floor = config->filter_main_error_floor;
    main_cfg.error_ceil = config->filter_main_error_ceil;
    main_cfg.noise_gate = config->filter_main_noise_gate;

    /* Pass external H_error_pfdkf memory to MainFilterUpdateGain */
    MainFilterUpdateGain_Init(&self->G_main, &main_initial_cfg,
                              config->config_change_duration_blocks,
                              &main_cfg,
                              H_error_pfdkf_mem, aec_H_usage);
    self->G_main.suppress_floor_coeff = config->suppress_floor_coeff;

    FilterMisadjustmentEstimator_Init(&self->filter_misadjustment_estimator);

    self->poor_shadow_filter_counter = 0;
    self->main_filter_last_selected_cache = 0;
    self->main_reset_hangover_blocks = 0;
    self->main_reset_shadow_hangover_blocks = 0;
    self->earphone_flag = 0;
    self->voip_flag = 0;
    self->aec_H_usage = 0;

    self->adaptation_during_saturation = 1;
    self->enable_misadjustment_estimator = 1;

    memset(self->y_old, 0, sizeof(self->y_old));
    memset(self->y_old_print, 0, sizeof(self->y_old_print));
    NearendEnergyFix_Init(&self->nearend_energy_fix);
}

/* ================================================================
 * Subtractor_ProcessPfdkf
 * ================================================================ */
void Subtractor_ProcessPfdkf(Subtractor* self,
                              const RenderBuffer* render_buffer,
                              const float* capture,
                              SubtractorOutputFrequency* output,
                              int update) {
    FftDataPfdkf* E       = &output->E;
    FftDataPfdkf* E_speed = &output->E_speed;
    FftDataPfdkf* S       = &output->S;
    FftDataPfdkf* S_speed = &output->S_speed;
    FftDataPfdkf* Y       = &output->Y;
    int i;

    if (update) {
        Aec3Fft_PaddedFftPfdkf_typed(&self->fft_pfdkf, capture, self->y_old, Y);
        memcpy(self->y_old_print, self->y_old,
               sizeof(float) * AEC3_LF_BLOCK_LENGTH);
    }

    memmove(self->y_old, self->y_old + AEC3_LF_BLOCK_LENGTH,
            sizeof(float) * AEC3_LF_FFT_DISTANCE2);
    memcpy(self->y_old + AEC3_LF_FFT_DISTANCE2, capture,
           sizeof(float) * AEC3_LF_BLOCK_LENGTH);

    if (update) {
        AdaptiveFirFilter_FilterPfdkf(&self->main_filter, render_buffer,
                                       S, S_speed);

        /* NaN check on filter output S */
        {
            static int filter_nan_logged = 0;
            if (!filter_nan_logged) {
                int kk, pp;
                for (pp = 0; pp < self->main_filter.pfdkf_partitions_count && !filter_nan_logged; pp++) {
                    for (kk = 0; kk < AEC3_LF_FFT_LENGTH_BY2_PLUS1 && !filter_nan_logged; kk++) {
                        if (!isfinite(self->main_filter.H_pf[pp].relf[kk]) ||
                            !isfinite(self->main_filter.H_pf[pp].imlf[kk])) {
                            fprintf(stderr, "[NaN] H_pf[%d] k=%d relf=%.6g imlf=%.6g\n",
                                pp, kk, self->main_filter.H_pf[pp].relf[kk],
                                self->main_filter.H_pf[pp].imlf[kk]);
                            filter_nan_logged = 1;
                        }
                    }
                }
                for (kk = 0; kk < AEC3_LF_FFT_LENGTH_BY2_PLUS1 && !filter_nan_logged; kk++) {
                    if (!isfinite(S->relf[kk]) || !isfinite(S->imlf[kk])) {
                        fprintf(stderr, "[NaN] S k=%d relf=%.6g imlf=%.6g (H_pf clean)\n",
                            kk, S->relf[kk], S->imlf[kk]);
                        filter_nan_logged = 1;
                    }
                }
            }
        }

        PredictionErrorPfdkf(S, Y, E);
        PredictionErrorPfdkf(S_speed, Y, E_speed);
        ComputeMetricsPfdkf(output, Y);
        AnalyzeErrorPfdkf(output, &self->main_filter);

        if (self->enable_misadjustment_estimator) {
            FilterMisadjustmentEstimator_UpdateFrequency(
                &self->filter_misadjustment_estimator, output);
            if (FilterMisadjustmentEstimator_IsAdjustmentNeeded(
                    &self->filter_misadjustment_estimator)) {
                float scale = FilterMisadjustmentEstimator_GetMisadjustment(
                                  &self->filter_misadjustment_estimator);
                AdaptiveFirFilter_ScaleFilterPfdkf(&self->main_filter, scale);
                ScaleFilterOutputFrequencyPfdkf(
                    Y, scale, &output->E_out, &output->S_out, output);
                FilterMisadjustmentEstimator_ResetFrequency(
                    &self->filter_misadjustment_estimator);
            }
        }

        NearendEnergyFix_Update(&self->nearend_energy_fix, output);
        MainFilterUpdateGain_ComputePfdkf(
            &self->G_main, render_buffer, output, &self->main_filter,
            self->G_pfdkf, self->G_pfdkf_speed,
            self->nearend_energy_fix.E2_fix,
            self->nearend_energy_fix.E2_fix_suppress,
            self->earphone_flag || self->voip_flag);

        PredictionErrorPfdkf(&output->E_out, Y, &output->S_out_tmp);
        FftDataPfdkf_Spectrum(&output->S_out_tmp, output->S2_out_tmp);
        for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; i++) {
            if (output->S2_out_tmp[i] > output->S2_out[i]) {
                output->S2_out[i] = output->S2_out_tmp[i];
                output->S_out.relf[i] = output->S_out_tmp.relf[i];
                output->S_out.imlf[i] = output->S_out_tmp.imlf[i];
            }
        }

        AdaptiveFirFilter_AdaptPfdkf(&self->main_filter, render_buffer,
                                      self->G_pfdkf, self->G_pfdkf_speed,
                                      self->main_filter.pfdkf_partitions_count);

        /* NaN check after adaptation */
        {
            static int sub_nan_logged = 0;
            if (!sub_nan_logged) {
                int kk;
                for (kk = 0; kk < AEC3_LF_FFT_LENGTH_BY2_PLUS1; kk++) {
                    if (!isfinite(output->E_out.relf[kk]) || !isfinite(output->E_out.imlf[kk])
                        || !isfinite(output->E2_out[kk])) {
                        fprintf(stderr, "[NaN] SubtractorPfdkf: k=%d E_out_re=%.6g E_out_im=%.6g E2_out=%.6g "
                            "Y_re=%.6g Y_im=%.6g S_re=%.6g S_im=%.6g "
                            "E_re=%.6g E_im=%.6g S_speed_re=%.6g\n",
                            kk, output->E_out.relf[kk], output->E_out.imlf[kk], output->E2_out[kk],
                            Y->relf[kk], Y->imlf[kk], S->relf[kk], S->imlf[kk],
                            E->relf[kk], E->imlf[kk], S_speed->relf[kk]);
                        sub_nan_logged = 1;
                        break;
                    }
                }
                if (!sub_nan_logged) {
                    int pp;
                    for (pp = 0; pp < self->main_filter.pfdkf_partitions_count && !sub_nan_logged; pp++) {
                        for (kk = 0; kk < AEC3_LF_FFT_LENGTH_BY2_PLUS1 && !sub_nan_logged; kk++) {
                            if (!isfinite(self->main_filter.H_pf[pp].relf[kk])) {
                                fprintf(stderr, "[NaN] SubtractorPfdkf H_pf[%d].relf[%d]=%.6g\n",
                                    pp, kk, self->main_filter.H_pf[pp].relf[kk]);
                                sub_nan_logged = 1;
                            }
                        }
                    }
                }
            }
        }
    }
}

/* ================================================================
 * Subtractor_HandleEchoPathChange
 * ================================================================ */
void Subtractor_HandleEchoPathChange(Subtractor* self,
                                     const EchoPathVariability* variability) {
    if (variability->delay_change != 0) {
        MainFilterConfig main_initial_cfg;

        AdaptiveFirFilter_HandleEchoPathChange(&self->main_filter);
        MainFilterUpdateGain_HandleEchoPathChange(&self->G_main, variability);

        main_initial_cfg.length_blocks = self->config.filter_main_initial_length_blocks;
        main_initial_cfg.leakage_converged = self->config.filter_main_initial_leakage_converged;
        main_initial_cfg.leakage_diverged = self->config.filter_main_initial_leakage_diverged;
        main_initial_cfg.error_floor = self->config.filter_main_initial_error_floor;
        main_initial_cfg.error_ceil = self->config.filter_main_initial_error_ceil;
        main_initial_cfg.noise_gate = self->config.filter_main_initial_noise_gate;
        MainFilterUpdateGain_SetConfig(&self->G_main, &main_initial_cfg, 1);
    }

    if (variability->gain_change) {
        MainFilterUpdateGain_HandleEchoPathChange(&self->G_main, variability);
    }
}

void Subtractor_SetEarphoneFlag(Subtractor* self, int flag) {
    self->earphone_flag = flag;
}

void Subtractor_SetVoipFlag(Subtractor* self, int flag) {
    self->voip_flag = flag;
}

void Subtractor_SetAecHUsage(Subtractor* self, int size) {
    int i;
    int clamped = size < self->max_pfdkf_partitions ? size : self->max_pfdkf_partitions;
    self->aec_H_usage = clamped;
    AdaptiveFirFilter_SetAecHUsage(&self->main_filter, size);
    MainFilterUpdateGain_SetAecHUsage(&self->G_main, size);

    for (i = 0; i < clamped; i++) {
        FftDataPfdkf_Clear(&self->G_pfdkf[i]);
        FftDataPfdkf_Clear(&self->G_pfdkf_speed[i]);
    }
}

int Subtractor_FilterLengthBlocks(const Subtractor* self) {
    return self->main_filter.current_size_partitions;
}
