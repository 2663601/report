/*
 *  ResidualEchoEstimator - Pure C Version
 *
 *  Estimates the residual echo power spectrum after linear cancellation.
 *  Ported from WebRTC AEC3 C++ ResidualEchoEstimator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef RESIDUAL_ECHO_ESTIMATOR_H_
#define RESIDUAL_ECHO_ESTIMATOR_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "render_buffer.h"
#include "reverb_model.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declaration - AecState is defined in aec_state.h */
struct AecState_;

typedef struct {
    Aec3Config  config;

    float   R2_old[AEC3_FFT_LENGTH_BY2_PLUS1];
    int     R2_hold_counter[AEC3_FFT_LENGTH_BY2_PLUS1];

    /* Render noise floor (128-point) */
    float   X2_noise_floor[AEC3_FFT_LENGTH_BY2_PLUS1];
    int     X2_noise_floor_counter[AEC3_FFT_LENGTH_BY2_PLUS1];

    /* Render noise floor (512-point) */
    float   X2_noise_floor_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    int     X2_noise_floor_long_counter[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    /* Smoothed spectra for noise estimation */
    float   X2_smoothed[AEC3_FFT_LENGTH_BY2_PLUS1];
    float   X2min[AEC3_FFT_LENGTH_BY2_PLUS1];
    float   X2tmp[AEC3_FFT_LENGTH_BY2_PLUS1];
    float   X2_smoothed_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   X2min_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   X2tmp_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    int     N2_counter;
    int     min_count;
    int     N2_counter_long;
    int     min_count_long;

    /* Reverb model (128-point, for legacy path) */
    ReverbModel echo_reverb;
    int     use_reverb_model;

    /* Reverb model (512-point, for PFDKF path) */
    ReverbModelLong echo_reverb_long;

    /* Configuration flags */
    int     soft_transparent_mode;
    int     override_estimated_echo_path_gain;

    /* Initial echo handling */
    int     initial_echo_potential_counter;
    int     echo_duration_counter;

    /* External delay tracking for initial echo potential (Fix 1.1) */
    int     has_external_delay_last;

    /* Energy tracking for PFDKF */
    float   capture_energy;
    float   filterout_energy;
    float   linearecho_energy;
    float   alpha;

    int     earphone_flag;
    int     voip_flag;
    int     enable_echo_reverb;

    /* Reverb tail detection: smoothed low-freq E2 energy for trend analysis */
    float   E2_lf_smooth;

    /* Last computed reverb debug values (for per-block dump alignment) */
    float   last_ne_weight;
    float   last_lf_ratio;
    float   last_flat_smooth;  /* smoothed spectral flatness for reverb tail detection */

    /* Instance state for reverb injection (formerly static locals) */
    float   lf_ratio_smooth;       /* replaces static s_lf_smooth */
    float   flat_smooth_state;     /* replaces static s_flat_smooth */

    /* Adaptive reverb injection gain */
    float   adaptive_reverb_gain;

    /* Diagnostic counter for reverb injection logging */
    int     reverb_diag_counter;
} ResidualEchoEstimator;

/**
 * Initialize the residual echo estimator.
 */
void ResidualEchoEstimator_Init(ResidualEchoEstimator* self,
                                const Aec3Config* config);

/**
 * Reset the estimator state.
 */
void ResidualEchoEstimator_Reset(ResidualEchoEstimator* self);

/**
 * Estimate residual echo power (128-point).
 *
 * @param self              Pointer to estimator
 * @param S2_linear         Linear echo estimate power spectrum (65 floats)
 * @param Y2                Capture power spectrum (65 floats)
 * @param E2                Error power spectrum (65 floats)
 * @param erle              ERLE estimate (65 floats)
 * @param usable_linear     Whether linear estimate is usable
 * @param saturated_echo    Whether echo is saturated
 * @param transparent_mode  Whether transparent mode is active
 * @param echo_path_gain    Estimated echo path gain
 * @param reverb_decay      Reverb decay factor
 * @param reverb_freq_resp  Reverb frequency response (65 floats)
 * @param filter_delay      Filter delay in blocks
 * @param filter_length     Filter length in blocks
 * @param render_buffer     Render buffer
 * @param R2                Output: residual echo power (65 floats)
 */
void ResidualEchoEstimator_Estimate(ResidualEchoEstimator* self,
                                    const float* S2_linear,
                                    const float* Y2,
                                    const float* E2,
                                    const float* erle,
                                    int usable_linear,
                                    int saturated_echo,
                                    int transparent_mode,
                                    float echo_path_gain,
                                    float reverb_decay,
                                    const float* reverb_freq_resp,
                                    int filter_delay,
                                    int filter_length,
                                    const RenderBuffer* render_buffer,
                                    float* R2);

/**
 * Estimate residual echo power (512-point, PFDKF mode).
 *
 * @param reverb_decay      Reverb decay factor (from ReverbDecayEstimator)
 * @param X2_reverb_tail    Render power spectrum at filter tail for reverb injection
 *                          (257 floats from RenderBuffer_SpectrumPfdkf, or NULL to skip)
 */
void ResidualEchoEstimator_Estimate512fftPfdkf(
    ResidualEchoEstimator* self,
    const float* S2_linear,
    const float* Y2,
    const float* E2,
    const float* X2Refer,
    const float* erle_long,
    const float* erle_long_greater,
    int saturated_echo_512fft,
    int earphone_flag,
    int voip_flag,
    int aec_level,
    int extra_echo_sup,
    int aec_low_compute_mode,
    int aec_H_usage,
    int has_external_delay,
    float reverb_decay,
    const float* X2_reverb_tail,
    const float* freq_response_tail_long,
    float* R2);

/**
 * Set earphone flag.
 */
void ResidualEchoEstimator_SetEarphoneFlag(ResidualEchoEstimator* self, int flag);

/**
 * Set voip flag.
 */
void ResidualEchoEstimator_SetVoipFlag(ResidualEchoEstimator* self, int flag);

/**
 * Set enable echo reverb flag.
 */
void ResidualEchoEstimator_SetEnableEchoReverb(ResidualEchoEstimator* self, int flag);

#ifdef __cplusplus
}
#endif

#endif /* RESIDUAL_ECHO_ESTIMATOR_H_ */
