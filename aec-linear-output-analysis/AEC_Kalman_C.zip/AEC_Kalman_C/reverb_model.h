/*
 *  ReverbModel - Pure C Version
 *
 *  Exponential reverberant echo model applied over power spectra.
 *  Ported from WebRTC AEC3 C++ ReverbModel class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef REVERB_MODEL_H_
#define REVERB_MODEL_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float   reverb[AEC3_FFT_LENGTH_BY2_PLUS1];
} ReverbModel;

/**
 * Initialize the reverb model.
 */
void ReverbModel_Init(ReverbModel* self);

/**
 * Reset the reverb model state.
 */
void ReverbModel_Reset(ReverbModel* self);

/**
 * Add reverb with no frequency shaping (uniform scaling).
 *
 * @param self                      Pointer to model
 * @param power_spectrum            Input power spectrum (65 floats)
 * @param power_spectrum_scaling    Uniform scaling factor
 * @param reverb_decay              Decay factor per block
 * @param reverb_power_spectrum     In/out: spectrum to add reverb to (65 floats)
 */
void ReverbModel_AddReverbNoFreqShaping(ReverbModel* self,
                                        const float* power_spectrum,
                                        float power_spectrum_scaling,
                                        float reverb_decay,
                                        float* reverb_power_spectrum);

/**
 * Add reverb with per-frequency shaping.
 *
 * @param self                      Pointer to model
 * @param power_spectrum            Input power spectrum (65 floats)
 * @param freq_response_tail        Per-frequency scaling (65 floats)
 * @param reverb_decay              Decay factor per block
 * @param reverb_power_spectrum     In/out: spectrum to add reverb to (65 floats)
 */
void ReverbModel_AddReverb(ReverbModel* self,
                           const float* power_spectrum,
                           const float* freq_response_tail,
                           float reverb_decay,
                           float* reverb_power_spectrum);

/**
 * Update reverb contributions without adding to output.
 */
void ReverbModel_UpdateNoFreqShaping(ReverbModel* self,
                                     const float* power_spectrum,
                                     float power_spectrum_scaling,
                                     float reverb_decay);

/**
 * Get the current reverb power spectrum.
 */
const float* ReverbModel_GetPowerSpectrum(const ReverbModel* self);

/* ================================================================
 * ReverbModelLong - 512-point FFT (257 bins) version
 *
 * Same exponential decay model as ReverbModel, but operates on
 * AEC3_FFT_LENGTH_LONG_BY2_PLUS1 (257) frequency bins for the
 * PFDKF 512-point processing path.
 * ================================================================ */
typedef struct {
    float   reverb[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
} ReverbModelLong;

void ReverbModelLong_Init(ReverbModelLong* self);
void ReverbModelLong_Reset(ReverbModelLong* self);

/**
 * Add reverb with uniform scaling (no frequency shaping).
 * All arrays are AEC3_FFT_LENGTH_LONG_BY2_PLUS1 (257) floats.
 */
void ReverbModelLong_AddReverbNoFreqShaping(ReverbModelLong* self,
                                            const float* power_spectrum,
                                            float power_spectrum_scaling,
                                            float reverb_decay,
                                            float* reverb_power_spectrum);

/**
 * Add reverb with per-frequency shaping (257 bins).
 *
 * @param self                      Pointer to model
 * @param power_spectrum            Input power spectrum (257 floats)
 * @param freq_response_tail        Per-frequency scaling (257 floats)
 * @param reverb_decay              Decay factor per block
 * @param reverb_power_spectrum     In/out: spectrum to add reverb to (257 floats)
 */
void ReverbModelLong_AddReverb(ReverbModelLong* self,
                               const float* power_spectrum,
                               const float* freq_response_tail,
                               float reverb_decay,
                               float* reverb_power_spectrum);

#ifdef __cplusplus
}
#endif

#endif /* REVERB_MODEL_H_ */
