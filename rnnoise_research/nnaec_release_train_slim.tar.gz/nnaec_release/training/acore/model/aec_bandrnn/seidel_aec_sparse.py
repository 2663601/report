#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SeidelAEC 的 **稀疏感知训练版** (block-sparse, 对标 rnnoise 稀疏做法)。

与原 seidel_aec.SeidelAEC 结构**完全一致**(fc_input + 2×GRU + dense0/1/2),
仅额外给两层 GRU 挂上 GRUSparsifier(4×8 块稀疏, 渐进调度到目标 density)。
推理结构不变: 稀疏只是把 GRU 权重里能量最小的 4×8 块置零, 便于后续
int8+block-sparse 导出(对齐 rnnoise rnn_16k.c 的 sparse_cgemv8x4 kernel)。

用法: toml 里 model.path 指向本类, 并给 sparse_* 参数。system 的
on_train_batch_end 钩子会检测 model.sparsify 并每步调用(零侵入原 seidel)。

稀疏参数来自权重分布分析(_weight_dist.py): 该稠密 ckpt 的 GRU 块能量分布
较平(砍50%丢26~33%能量), 故**从 50% density 起步**稀疏感知重训, 验证
PESQ/ERLE 不掉再往 66% 推。input/recurrent 都设 50%; recurrent 更密,
但统一 50% 便于导出, 后续可对 W_h* 单独放宽。
"""
import torch
import torch.nn as nn

from .seidel_aec import SeidelAEC

# sparsification 包在 training/acore/ 下; 相对本文件 (acore/model/aec_bandrnn/) 上两级
import sys, os
_ACORE = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _ACORE not in sys.path:
    sys.path.insert(0, _ACORE)
from sparsification import GRUSparsifier


class SeidelAECSparse(SeidelAEC):
    def __init__(self,
                 nbands=32, num_inputs=3,
                 fc_input_dim=128, gru_hidden=128, n_gru=2,
                 gru_dropout=0.2, dense_hidden=192,
                 # ---- 稀疏调度(对齐 rnnoise rnnoise16k.py 的量级, 按 band-aec 步数缩放) ----
                 sparse_density=0.5,          # 目标 density=0.5 → 50% 稀疏
                 sparse_block=(4, 8),         # 4×8 块(对齐 rnnoise sparse_cgemv8x4)
                 # 默认值仅占位, 实际由 toml 覆盖。方案A(稳定后稀疏)建议按"步/epoch"换算:
                 # start=开始ep×步每ep。如 ~16500步/ep → 60ep≈990000, 90ep≈1485000。
                 sparse_start=990000,         # 该步前不稀疏(让网络先充分收敛, ~60ep)
                 sparse_stop=1485000,         # 该步稀疏到满 density(~90ep, 30ep 渐进)
                 sparse_interval=100,
                 sparse_exponent=3,
                 sparse_keep_diagonal_recurrent=True,  # recurrent 保对角(rnnoise 惯例)
                 **kwargs):
        super().__init__(nbands=nbands, num_inputs=num_inputs,
                         fc_input_dim=fc_input_dim, gru_hidden=gru_hidden,
                         n_gru=n_gru, gru_dropout=gru_dropout,
                         dense_hidden=dense_hidden, **kwargs)
        self.sparse_density = sparse_density
        # 稀疏监控: 记录块尺寸与打印周期(供 _print_sparsity 用)。
        # sparse_log_every 可由 toml [model.args] 覆盖; 默认 2000 步一次(不频繁)。
        self._blk = tuple(sparse_block)
        self._sparse_log_every = int(kwargs.pop("sparse_log_every", 2000))
        self._sparse_step = 0

        bs = list(sparse_block)
        # 输入门 3 个 (W_ir/iz/in) + 循环门 3 个 (W_hr/hz/hn)
        kd = sparse_keep_diagonal_recurrent
        sparse_params = {
            'W_ir': (sparse_density, bs, False),
            'W_iz': (sparse_density, bs, False),
            'W_in': (sparse_density, bs, False),
            'W_hr': (sparse_density, bs, kd),
            'W_hz': (sparse_density, bs, kd),
            'W_hn': (sparse_density, bs, kd),
        }
        # keep_diagonal 要求方阵; gru_hidden==input 时 (fc=gru=128) 满足,
        # 但第 1 层 input W_i* 是 [hidden, fc], fc==hidden 才方; 这里 fc_input_dim==gru_hidden==128 OK。
        # 为稳妥, input 门一律 keep_diagonal=False(上面已设), 只有 recurrent 方阵才可 True。

        # nn.GRU(num_layers=2) 的两层权重是 weight_ih_l0/l1, weight_hh_l0/l1。
        # GRUSparsifier 只认 l0(weight_ih_l0/weight_hh_l0)。因此把每一层包成"只含该层
        # l0 视图"的代理无法直接做; 简单起见为每层各建一个单层 GRU 视图不现实。
        # 方案: 直接对 self.gru 的 l0 用 GRUSparsifier; 对 l1 另写一个代理对象。
        self.sparsifiers = []
        for layer in range(n_gru):
            proxy = _GRULayerProxy(self.gru, layer, gru_hidden, fc_input_dim if layer == 0 else gru_hidden)
            self.sparsifiers.append(
                GRUSparsifier([(proxy, sparse_params)],
                              sparse_start, sparse_stop, sparse_interval, sparse_exponent)
            )

    def sparsify(self, verbose=False):
        for sp in self.sparsifiers:
            sp.step(verbose=verbose)
        # ★ 稀疏进度监控(低频打印, 主要用于确认稀疏是否真正生效):
        #   每 self._sparse_log_every 步打印一次两层 GRU 的"实测 4x8 块全零率",
        #   这是稀疏是否生效的 ground truth(不是看调度参数, 而是看权重真被置零了)。
        #   step 前几步也强制打一次, 避免要等很久才知道配置对不对。
        self._sparse_step = getattr(self, "_sparse_step", 0) + 1
        every = getattr(self, "_sparse_log_every", 2000)
        if self._sparse_step <= 2 or self._sparse_step % every == 0:
            self._print_sparsity(self._sparse_step)

    def _print_sparsity(self, step):
        import torch as _t
        bs = getattr(self, "_blk", (4, 8))
        msgs = []
        for layer in range(self.n_gru):
            for wn in (f"weight_ih_l{layer}", f"weight_hh_l{layer}"):
                W = getattr(self.gru, wn).detach()
                r, c = W.shape
                rr, cc = (r // bs[0]) * bs[0], (c // bs[1]) * bs[1]
                Wb = W[:rr, :cc].reshape(rr // bs[0], bs[0], cc // bs[1], bs[1])
                blk_zero = (Wb.abs().amax(dim=(1, 3)) < 1e-12).float().mean().item()
                msgs.append(f"{wn}={blk_zero*100:.0f}%")
        print(f"I[sparse] step={step} 4x8块全零率: " + " ".join(msgs), flush=True)


class _GRULayerProxy:
    """把 nn.GRU 的第 layer 层(weight_ih_l{layer}/weight_hh_l{layer})伪装成
    GRUSparsifier 期望的 "单层 GRU" 接口(只需 .hidden_size / .weight_ih_l0 /
    .weight_hh_l0)。这样一个多层 GRU 的每层都能独立挂 sparsifier。"""
    def __init__(self, gru, layer, hidden_size, input_size):
        self._gru = gru
        self._layer = layer
        self.hidden_size = hidden_size
        self.input_size = input_size

    @property
    def weight_ih_l0(self):
        return getattr(self._gru, f"weight_ih_l{self._layer}")

    @property
    def weight_hh_l0(self):
        return getattr(self._gru, f"weight_hh_l{self._layer}")


if __name__ == "__main__":
    m = SeidelAECSparse(nbands=32, num_inputs=3)
    n = sum(p.numel() for p in m.parameters())
    print(f"SeidelAECSparse params={n} ({n/1e3:.1f}K)")
    feat = torch.randn(2, 50, 32 * 3)
    opt = torch.optim.Adam(m.parameters(), lr=1e-3)
    for step in range(6300):   # 跨过 sparse_start=6000
        g, h = m(feat)
        loss = g.mean()
        opt.zero_grad(); loss.backward(); opt.step()
        m.sparsify()
    # 检查两层 GRU 的实际稀疏度
    for layer in range(2):
        for wn in (f"weight_ih_l{layer}", f"weight_hh_l{layer}"):
            W = getattr(m.gru, wn)
            zero = (W.abs() < 1e-12).float().mean().item()
            print(f"  {wn}: zero frac = {zero*100:.1f}%")
