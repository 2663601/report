/*
 *  Matched Filter - Pure C Version
 *
 *  Produces recursively updated cross-correlation estimates for several
 *  signal shifts where the intra-shift spacing is uniform.
 *  Used for time-domain delay estimation in AEC3.
 *
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef MATCHED_FILTER_H_
#define MATCHED_FILTER_H_

#include "aec3_common.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * MatchedFilterLagEstimate - Lag estimate for one matched filter
 * ================================================================ */
typedef struct {
    float   accuracy;       /* Error reduction achieved by the filter */
    int     reliable;       /* Whether the estimate is reliable */
    int     lag;            /* Estimated lag in sub-block samples */
    int     updated;        /* Whether the filter was updated this block */
} MatchedFilterLagEstimate;

/* ================================================================
 * MatchedFilter - Multiple matched filters for delay estimation
 *
 * Each filter covers a different delay range. The filters are
 * updated using NLMS adaptation on the downsampled render/capture
 * signals. The peak of each filter indicates the estimated delay.
 * ================================================================ */
typedef struct {
    int     sub_block_size;             /* Downsampled block size */
    int     filter_intra_lag_shift;     /* Shift between consecutive filters */
    int     num_filters;                /* Number of matched filters */
    int     window_size;                /* Filter length per filter */

    /* Filter coefficients: num_filters x window_size */
    float   filters[AEC3_MAX_MATCHED_FILTERS][AEC3_MATCHED_FILTER_WINDOW_SIZE];
    int     filters_offsets[AEC3_MAX_MATCHED_FILTERS];
    MatchedFilterLagEstimate lag_estimates[AEC3_MAX_MATCHED_FILTERS];

    float   excitation_limit;           /* Minimum excitation threshold */
    float   smoothing;                  /* NLMS step size */
    float   matching_filter_threshold;  /* Reliability threshold */
} MatchedFilter;

/**
 * Initialize the matched filter.
 *
 * @param self                          Pointer to MatchedFilter
 * @param sub_block_size                Downsampled sub-block size
 * @param window_size_sub_blocks        Filter window in sub-blocks
 * @param num_filters                   Number of matched filters
 * @param alignment_shift_sub_blocks    Shift between filters in sub-blocks
 * @param excitation_limit              Minimum excitation level
 * @param smoothing                     NLMS adaptation step size
 * @param matching_filter_threshold     Reliability threshold
 */
void MatchedFilter_Init(MatchedFilter* self,
                        int sub_block_size,
                        int window_size_sub_blocks,
                        int num_filters,
                        int alignment_shift_sub_blocks,
                        float excitation_limit,
                        float smoothing,
                        float matching_filter_threshold);

/**
 * Update the matched filter with new capture data.
 *
 * @param self              Pointer to MatchedFilter
 * @param render_buffer     Downsampled render buffer (circular)
 * @param capture           Downsampled capture sub-block
 * @param capture_len       Length of capture (should equal sub_block_size)
 * @param delay_default     Default delay offset
 */
void MatchedFilter_Update(MatchedFilter* self,
                          const DownsampledRenderBuffer* render_buffer,
                          const float* capture, int capture_len,
                          int delay_default);

/**
 * Reset all matched filters and lag estimates.
 */
void MatchedFilter_Reset(MatchedFilter* self);

/**
 * Get the maximum filter lag across all filters.
 */
int MatchedFilter_GetMaxFilterLag(const MatchedFilter* self);

#ifdef __cplusplus
}
#endif

#endif /* MATCHED_FILTER_H_ */
