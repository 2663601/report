/*
 *  SuppressionGain - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ SuppressionGain class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point path retained.
 */

#include "suppression_gain.h"
#include "aec_state.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

/* ================================================================
 * Helper: Interpolate gain curve parameters across frequency (512-point)
 * ================================================================ */
static void InitGainCurve(float* enr_transparent, float* enr_suppress,
                          float* emr_transparent, int len,
                          float lf_enr_t, float lf_enr_s, float lf_emr_t,
                          float hf_enr_t, float hf_enr_s, float hf_emr_t,
                          int last_lf_band, int first_hf_band) {
    int k;
    for (k = 0; k < len; k++) {
        float a;
        if (k <= last_lf_band) {
            a = 0.0f;
        } else if (k < first_hf_band) {
            a = (float)(k - last_lf_band) / (float)(first_hf_band - last_lf_band);
        } else {
            a = 1.0f;
        }
        enr_transparent[k] = (1.0f - a) * lf_enr_t + a * hf_enr_t;
        enr_suppress[k]    = (1.0f - a) * lf_enr_s + a * hf_enr_s;
        emr_transparent[k] = (1.0f - a) * lf_emr_t + a * hf_emr_t;
    }
}

static void InitGainParameters512(GainParameters* p, const Aec3Config* cfg,
                                  int is_nearend) {
    /* 512-point long arrays: kLastLfBand=32, kFirstHfBand=128 */
    if (is_nearend) {
        p->max_inc_factor = cfg->suppressor_normal_tuning_512fft_max_inc_factor;
        p->max_dec_factor_lf = cfg->suppressor_normal_tuning_512fft_max_dec_factor_lf;
        /* Nearend uses nearend tuning params mapped to 512-point boundaries */
        InitGainCurve(p->enr_transparent_long, p->enr_suppress_long,
                      p->emr_transparent_long, AEC3_FFT_LENGTH_LONG_BY2_PLUS1,
                      cfg->suppressor_nearend_tuning_mask_lf_enr_transparent,
                      cfg->suppressor_nearend_tuning_mask_lf_enr_suppress,
                      cfg->suppressor_nearend_tuning_mask_lf_emr_transparent,
                      cfg->suppressor_nearend_tuning_mask_hf_enr_transparent,
                      cfg->suppressor_nearend_tuning_mask_hf_enr_suppress,
                      cfg->suppressor_nearend_tuning_mask_hf_emr_transparent,
                      32, 128);
    } else {
        p->max_inc_factor = cfg->suppressor_normal_tuning_512fft_max_inc_factor;
        p->max_dec_factor_lf = cfg->suppressor_normal_tuning_512fft_max_dec_factor_lf;
        InitGainCurve(p->enr_transparent_long, p->enr_suppress_long,
                      p->emr_transparent_long, AEC3_FFT_LENGTH_LONG_BY2_PLUS1,
                      cfg->suppressor_normal_tuning_512fft_mask_lf_enr_transparent,
                      cfg->suppressor_normal_tuning_512fft_mask_lf_enr_suppress,
                      cfg->suppressor_normal_tuning_512fft_mask_lf_emr_transparent,
                      cfg->suppressor_normal_tuning_512fft_mask_hf_enr_transparent,
                      cfg->suppressor_normal_tuning_512fft_mask_hf_enr_suppress,
                      cfg->suppressor_normal_tuning_512fft_mask_hf_emr_transparent,
                      32, 128);
    }
}

static void DominantNearendDetector_Init(DominantNearendDetector* d,
                                         const Aec3Config* cfg) {
    d->enr_threshold = cfg->suppressor_dominant_nearend_enr_threshold;
    d->enr_exit_threshold = cfg->suppressor_dominant_nearend_enr_exit_threshold;
    d->snr_threshold = cfg->suppressor_dominant_nearend_snr_threshold;
    d->hold_duration = cfg->suppressor_dominant_nearend_hold_duration;
    d->trigger_threshold = cfg->suppressor_dominant_nearend_trigger_threshold;
    d->use_during_initial_phase = cfg->suppressor_dominant_nearend_use_during_initial_phase;
    d->nearend_probability = 0.0f;
    d->render_ref_power = 0.0f;
    d->render_silent_frames = 0;
    d->nearend_state = 0;
    d->trigger_counter = 0;
    d->hold_counter = 0;
    d->echoend_state = 0;
    d->echoend_trigger_counter = 0;
    d->echoend_hold_counter = 0;
}

/* ================================================================
 * DominantNearendDetector_Update512fft (probability version)
 *
 * Adds a far-end activity gate on top of the C++ ENR-based detector.
 *
 * Core ENR decision (same as C++ UpdateLoop_512fft):
 *   enr = R2 / E2 over bins [1, 64)
 *   piecewise mapping to [0, 1]:
 *     enr ≤ 0.25 → 1.0
 *     enr ∈ (0.25, 2] → 0.1  (echo-dominated but filter active)
 *     enr ∈ (2, 10)  → linear ramp to 0
 *     enr ≥ 10  → 0
 *
 * Far-end silence gate (p_far, our addition):
 *   When render power drops ≥10 dB below its long-term reference AND
 *   E2 is well above noise, fire p_far. Gated by 60-frame hangover to
 *   skip the reverb tail (mic-side echo persists for RT60 after render
 *   stops).
 *
 * Asymmetric IIR smoothing, dual-gate early exit, initial-phase
 * handling: unchanged vs C++.
 *
 * Low-frequency window: bins [1, 64) ≈ 31~2000Hz.
 */
static void DominantNearendDetector_Update512fft(
    DominantNearendDetector* d,
    const float* nearend_spectrum,      /* E2  */
    const float* residual_echo_spectrum,/* R2  */
    const float* render_spectrum,       /* X2 (optional, NULL to disable gate) */
    const float* comfort_noise_spectrum,
    int initial_state,
    int echo_state) {
    int k;
    float ne_sum = 0.0f;
    float echo_sum = 0.0f;
    float noise_sum = 0.0f;
    float render_sum = 0.0f;
    float p_enr;
    float p_far = 0.0f;
    float p_inst;
    float alpha;

    (void)echo_state;  /* ignored: DtController disabled per project rule */

    for (k = 1; k < 64; k++) {
        ne_sum += nearend_spectrum[k];
        echo_sum += residual_echo_spectrum[k];
        noise_sum += comfort_noise_spectrum[k];
        if (render_spectrum) render_sum += render_spectrum[k];
    }

    /* Track long-term render reference power: slow update only when
     * render is active. Provides a baseline to normalize current render
     * power against. Uses IIR with τ ≈ 2 sec at 16ms/NLP cycle. */
    if (render_spectrum) {
        if (render_sum > d->render_ref_power) {
            d->render_ref_power += 0.008f * (render_sum - d->render_ref_power);
        } else {
            d->render_ref_power += 0.001f * (render_sum - d->render_ref_power);
        }

        /* Count consecutive "render silent" frames (below −10 dB of ref).
         * Using −10 dB (instead of −20 dB) widens the catchment so that
         * partial render pauses (between speech syllables) still count
         * as silence, increasing the chance p_far fires during long
         * nearend bursts. */
        if (d->render_ref_power > 1.0f &&
            render_sum < 0.1f * d->render_ref_power) {
            if (d->render_silent_frames < 1000) d->render_silent_frames++;
        } else {
            d->render_silent_frames = 0;
        }

        /* Far-end silence probability (p_far).
         *
         * KEY INSIGHT: render going silent does NOT mean mic is silent —
         * in high-reverb rooms the mic-side echo persists for RT60 (can
         * exceed 1 second) after render stops. Activating p_far
         * immediately would mis-label the reverb tail as nearend,
         * which is exactly what we observed in high_-10 validation.
         *
         * Hangover ≈ 60 frames × 16ms = 960ms, a conservative upper
         * bound that covers high-reverb RT60. Low-reverb rooms will
         * pay a small latency cost before p_far can fire, but that
         * only delays nearend ramp-up slightly and does not cause
         * false positives.
         *
         * Additional gate: require E2 well above noise (VAD) so
         * render-silent + near-silent frames are not tagged as nearend. */
        {
            const int kReverbTailHangoverFrames = 60;
            if (d->render_silent_frames > kReverbTailHangoverFrames &&
                d->render_ref_power > 1.0f &&
                ne_sum > 10.0f * noise_sum) {
                p_far = 1.0f;
            }
        }
    }

    /* ENR-based instantaneous probability.
     *
     * Mapping strategy: to replicate C++ hard-threshold behavior while
     * keeping a continuous output, we split the ENR axis into three
     * regions instead of a single log-linear ramp:
     *   enr ≤ enr_threshold (0.25) → p = 1.0
     *   enr in (enr_threshold, transition_high]  → p = 1.0
     *   enr in (transition_high, enr_exit)       → linear ramp to 0
     *   enr ≥ enr_exit_threshold (10)            → p = 0.0
     *
     * Rationale: the region enr ∈ [0.25, 2] corresponds to "linear
     * filter is working but echo still present" — NOT nearend. Mapping
     * this region to an intermediate probability (what the prior
     * log-linear did) causes false positives during ambiguous echo-only
     * segments. By extending the "echo" flat region toward enr=2, we
     * require clearer evidence before the probability starts rising. */
    if (!initial_state || d->use_during_initial_phase) {
        float enr = echo_sum / (ne_sum + 1.0f);
        const float transition_high = 2.0f;
        if (enr <= d->enr_threshold) {
            p_enr = 1.0f;
        } else if (enr >= d->enr_exit_threshold) {
            p_enr = 0.0f;
        } else if (enr <= transition_high) {
            /* Still in echo-dominated region; enr could be low simply
             * because the linear filter handled the echo. Not strong
             * evidence for nearend. Give a small but non-zero score so
             * the IIR can ease upward if this condition persists. */
            p_enr = 0.1f;
        } else {
            /* Real transition zone (2, 10): linear interpolation in log
             * domain to 0 at enr_exit. */
            float log_enr = logf(enr);
            float log_hi = logf(transition_high);
            float log_exit = logf(d->enr_exit_threshold);
            p_enr = 0.1f * (log_exit - log_enr) / (log_exit - log_hi);
            if (p_enr < 0.0f) p_enr = 0.0f;
            if (p_enr > 0.1f) p_enr = 0.1f;
        }
    } else {
        p_enr = 0.0f;
    }

    /* Fuse ENR evidence with far-end-silence gate.
     * Taking max keeps the strongest evidence: either ENR says nearend
     * directly, or far-end is provably quiet so anything in E2 is nearend.
     * Neither signal alone is sufficient in high-reverb scenes. */
    p_inst = p_enr > p_far ? p_enr : p_far;

    /* Asymmetric IIR smoothing. */
    if (p_inst > d->nearend_probability) {
        alpha = (d->trigger_threshold > 0)
                ? 1.0f / (float)d->trigger_threshold : 0.083f;
    } else {
        alpha = (d->hold_duration > 0)
                ? 1.0f / (float)d->hold_duration : 0.02f;
    }
    d->nearend_probability += alpha * (p_inst - d->nearend_probability);

    /* Early exit on strong echo (matches C++ dual-gate). */
    if (echo_sum > d->enr_exit_threshold * ne_sum &&
        echo_sum > d->snr_threshold * noise_sum) {
        d->nearend_probability = 0.0f;
    }

    if (d->nearend_probability < 0.0f) d->nearend_probability = 0.0f;
    if (d->nearend_probability > 1.0f) d->nearend_probability = 1.0f;

    /* Binary state with hysteresis. */
    if (!d->nearend_state) {
        if (d->nearend_probability >= 0.5f) d->nearend_state = 1;
    } else {
        if (d->nearend_probability < 0.3f) d->nearend_state = 0;
    }
}

/* ================================================================
 * SuppressionGain_Init
 * ================================================================ */
void SuppressionGain_Init(SuppressionGain* self, const Aec3Config* config,
                          int sample_rate_hz) {
    int k;
    memset(self, 0, sizeof(SuppressionGain));
    self->config = *config;
    self->sample_rate_hz = sample_rate_hz;
    self->state_change_duration_blocks = 250;
    self->one_by_state_change_duration_blocks = 1.0f / 250.0f;
    self->initial_state = 1;
    self->initial_state_change_counter = 0;
    self->low_render_average_power = 32768.0f * 32768.0f;
    self->avggain_m = 0.0f;
    self->aec_level = 2;
    self->earphone_flag = 0;
    self->voip_flag = 0;
    self->howl_supp = 1;

    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        self->last_gain_long[k] = 1.0f;
        self->last_nearend_long[k] = 0.0f;
        self->last_echo_long[k] = 0.0f;
    }

    InitGainParameters512(&self->nearend_params, config, 1);
    InitGainParameters512(&self->normal_params_512fft, config, 0);

    /* Earphone/voip 512fft params: LF boundary=128, HF boundary=192 */
    self->normal_params_512fft_earphone.max_inc_factor =
        config->suppressor_normal_tuning_512fft_earphone_max_inc_factor;
    self->normal_params_512fft_earphone.max_dec_factor_lf =
        config->suppressor_normal_tuning_512fft_earphone_max_dec_factor_lf;
    InitGainCurve(self->normal_params_512fft_earphone.enr_transparent_long,
                  self->normal_params_512fft_earphone.enr_suppress_long,
                  self->normal_params_512fft_earphone.emr_transparent_long,
                  AEC3_FFT_LENGTH_LONG_BY2_PLUS1,
                  config->suppressor_normal_tuning_512fft_earphone_mask_lf_enr_transparent,
                  config->suppressor_normal_tuning_512fft_earphone_mask_lf_enr_suppress,
                  config->suppressor_normal_tuning_512fft_earphone_mask_lf_emr_transparent,
                  config->suppressor_normal_tuning_512fft_earphone_mask_hf_enr_transparent,
                  config->suppressor_normal_tuning_512fft_earphone_mask_hf_enr_suppress,
                  config->suppressor_normal_tuning_512fft_earphone_mask_hf_emr_transparent,
                  128, 192);

    DominantNearendDetector_Init(&self->dominant_nearend_detector, config);
}

/* ================================================================
 * SuppressionGain_GetGain512 (512-point)
 *
 * Aligned with C++ LowerBandGain_512fft:
 *   - WeightEchoForAudibility
 *   - GetMinGain / GetMaxGain
 *   - GainToNoAudibleEcho (ENR uses nearend E2, EMR uses masker Y2)
 *   - ±8 bin frequency smoothing
 *   - Sqrt(gain) for amplitude-domain output
 * ================================================================ */

/* Helper: weight echo for audibility (matches C++ WeightEchoForAudibility_512fft) */
static void WeightEchoForAudibility512(const Aec3Config* cfg,
                                       const float* echo,
                                       float* weighted_echo,
                                       int len) {
    int k;
    float floor_power = cfg->echo_audibility_floor_power;

    struct { int begin; int end; float threshold; float normalizer; } bands[3];
    bands[0].begin = 0;  bands[0].end = 6;
    bands[0].threshold = floor_power * cfg->echo_audibility_audibility_threshold_lf;
    bands[0].normalizer = 1.0f / (bands[0].threshold - floor_power);
    bands[1].begin = 6;  bands[1].end = 14;
    bands[1].threshold = floor_power * cfg->echo_audibility_audibility_threshold_mf;
    bands[1].normalizer = 1.0f / (bands[1].threshold - floor_power);
    bands[2].begin = 14; bands[2].end = len;
    bands[2].threshold = floor_power * cfg->echo_audibility_audibility_threshold_hf;
    bands[2].normalizer = 1.0f / (bands[2].threshold - floor_power);

    for (int b = 0; b < 3; b++) {
        float thr = bands[b].threshold;
        float norm = bands[b].normalizer;
        for (k = bands[b].begin; k < bands[b].end; k++) {
            if (echo[k] < thr) {
                float tmp = (thr - echo[k]) * norm;
                float scale = 1.0f - tmp * tmp;
                weighted_echo[k] = echo[k] * (scale > 0.0f ? scale : 0.0f);
            } else {
                weighted_echo[k] = echo[k];
            }
        }
    }
}

/* AdjustGainForHighBand_512fft */
static void AdjustGainForHighBand_512fft(float* gain, float* avggain_m_state) {
    int k;
    float avggain_m = 0.0f;
    float decrement, factor_tmp;

    for (k = 0; k < 64; k++) {
        avggain_m += gain[k];
    }
    avggain_m /= 64.0f;

    *avggain_m_state = 0.6f * (*avggain_m_state) + 0.4f * avggain_m;

    decrement = (1.0f - *avggain_m_state) / 32.0f;
    factor_tmp = 1.0f;
    for (k = 65; k < 97; k++) {
        gain[k] *= factor_tmp;
        factor_tmp -= decrement;
    }

    for (k = 97; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        gain[k] *= factor_tmp;
    }
}

void SuppressionGain_GetGain512(SuppressionGain* self,
                                const float* E2,
                                const float* R2,
                                const float* S2_linear,
                                const float* Y2,
                                const struct AecState_* aec_state,
                                const float* render_spectrum,
                                const float* comfort_noise_spectrum,
                                float* gain_out,
                                float* high_bands_gain) {
    const GainParameters* p;
    float min_gain[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float max_gain[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float weighted_echo[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float gain_raw[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    int k;
    int saturated_echo = AecState_SaturatedEcho(aec_state);
    float floor_val = self->config.suppressor_floor_first_increase;
    float min_echo_power = self->config.echo_audibility_normal_render_limit;

    /* Update DominantNearendDetector BEFORE selecting tuning params.
     * Per user direction we ignore DtController echo_state and pass 0.
     *
     * Inputs:
     *   E2                   - error spectrum (linear filter output)
     *   R2                   - residual echo estimate (for ENR)
     *   render_spectrum (X2) - far-end spectrum (for p_far silence gate)
     *   comfort_noise        - noise floor (for dual-gate early exit) */
    DominantNearendDetector_Update512fft(
        &self->dominant_nearend_detector,
        E2, R2, render_spectrum, comfort_noise_spectrum,
        self->initial_state, 0);

    /* Debug dump: per-NLP-cycle nearend-state log, gated by
     * enable_vqe_dump existence.
     * Columns:
     *   frame ne_prob ne_state R2_lf E2_lf noise_sum
     *   Y2_lf S2_lf X2_lf render_ref silent_frames
     *   dt_ed2k dt_spec_cor dt_near_energy dt_echo_state
     * LF = bins [1, 64) ≈ 31~2000Hz.
     * DtController fields are from the previous NLP cycle (it runs
     * after GetGain512), so there is a 16ms lag. */
#ifdef _WIN32
    if (_access("enable_vqe_dump", 0) == 0)
#else
    if (access("enable_vqe_dump", 0) == 0)
#endif
    {
        static FILE* fp_ne_dump = NULL;
        static long long frame_idx = 0;
        if (!fp_ne_dump) {
            fp_ne_dump = fopen("dominant_nearend.log", "w");
            if (fp_ne_dump) {
                fprintf(fp_ne_dump,
                    "frame ne_prob ne_state R2_lf E2_lf noise_sum "
                    "Y2_lf S2_lf X2_lf render_ref silent_frames "
                    "dt_ed2k dt_spec_cor dt_near_energy dt_echo_state\n");
            }
        }
        if (fp_ne_dump) {
            float y2_lf = 0.f, s2_lf = 0.f, e2_lf = 0.f, r2_lf = 0.f, x2_lf = 0.f;
            float ne_sum = 0.f, noise_sum = 0.f;
            int j;
            for (j = 1; j < 64; j++) {
                ne_sum   += E2[j];
                noise_sum += comfort_noise_spectrum[j];
                y2_lf += Y2[j];
                s2_lf += S2_linear[j];
                e2_lf += E2[j];
                r2_lf += R2[j];
                x2_lf += render_spectrum ? render_spectrum[j] : 0.0f;
            }
            fprintf(fp_ne_dump,
                "%lld %.4f %d %.1f %.1f %.1f %.1f %.1f %.1f %.1f %d "
                "%.4f %.4f %.2f %d\n",
                frame_idx,
                self->dominant_nearend_detector.nearend_probability,
                self->dominant_nearend_detector.nearend_state,
                r2_lf, e2_lf, noise_sum,
                y2_lf, s2_lf, x2_lf,
                self->dominant_nearend_detector.render_ref_power,
                self->dominant_nearend_detector.render_silent_frames,
                aec_state->dt_controller.ed_ratio_2k,
                aec_state->dt_controller.spec_cor_de_512fft,
                aec_state->dt_controller.near_energy,
                aec_state->dt_controller.echo_state);
            frame_idx++;
        }
    }

    p = self->dominant_nearend_detector.nearend_state
        ? &self->nearend_params : &self->normal_params_512fft;

    /* 1. Weight echo for audibility */
    WeightEchoForAudibility512(&self->config, R2, weighted_echo,
                               AEC3_FFT_LENGTH_LONG_BY2_PLUS1);

    /* 2. Compute min gain */
    if (!saturated_echo) {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            min_gain[k] = weighted_echo[k] > 0.0f
                          ? min_echo_power / weighted_echo[k] : 1.0f;
            if (min_gain[k] > 1.0f) min_gain[k] = 1.0f;
            {
                float bound = self->last_gain_long[k] * 0.125f;
                if (min_gain[k] < bound) min_gain[k] = bound;
            }
        }
        for (k = 0; k < 12; k++) {
            if (self->last_nearend_long[k] > self->last_echo_long[k]) {
                float bound = self->last_gain_long[k] * p->max_dec_factor_lf;
                if (min_gain[k] < bound) min_gain[k] = bound;
                if (min_gain[k] > 1.0f) min_gain[k] = 1.0f;
            }
        }
    } else {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            min_gain[k] = 0.0f;
        }
    }

    /* 3. Compute max gain */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        max_gain[k] = self->last_gain_long[k] * 8.0f;
        if (max_gain[k] < floor_val) max_gain[k] = floor_val;
        if (max_gain[k] > 1.0f) max_gain[k] = 1.0f;
    }

    /* 4. GainToNoAudibleEcho */
    if (self->earphone_flag || self->voip_flag) {
        const GainParametersEarphone* pe = &self->normal_params_512fft_earphone;
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            float enr = weighted_echo[k] / (E2[k] + 1.0f);
            float emr = weighted_echo[k] / (comfort_noise_spectrum[k] + 1.0f);
            float g = 1.0f;
            if (enr > pe->enr_transparent_long[k] &&
                emr > pe->emr_transparent_long[k]) {
                g = (pe->enr_suppress_long[k] - enr) /
                    (pe->enr_suppress_long[k] - pe->enr_transparent_long[k]);
                {
                    float emr_bound = pe->emr_transparent_long[k] / emr;
                    if (g < emr_bound) g = emr_bound;
                }
            }
            if (g > max_gain[k]) g = max_gain[k];
            if (g < min_gain[k]) g = min_gain[k];
            gain_raw[k] = g;
        }
    } else {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            float enr = weighted_echo[k] / (E2[k] + 1.0f);
            float emr = weighted_echo[k] / (comfort_noise_spectrum[k] + 1.0f);
            float g = 1.0f;
            if (enr > p->enr_transparent_long[k] && emr > p->emr_transparent_long[k]) {
                g = (p->enr_suppress_long[k] - enr) /
                    (p->enr_suppress_long[k] - p->enr_transparent_long[k]);
                {
                    float emr_bound = p->emr_transparent_long[k] / emr;
                    if (g < emr_bound) g = emr_bound;
                }
            }
            if (g > max_gain[k]) g = max_gain[k];
            if (g < min_gain[k]) g = min_gain[k];
            gain_raw[k] = g;
        }
    }

    /* 5. Frequency smoothing: ±8 bin sliding average */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        int k_min = k - 8;
        int k_max = k + 8;
        float gain_mean = 0.0f;
        int j, count;
        if (k_min < 0) k_min = 0;
        if (k_max > AEC3_FFT_LENGTH_LONG_BY2_PLUS1)
            k_max = AEC3_FFT_LENGTH_LONG_BY2_PLUS1;
        count = k_max - k_min;
        for (j = k_min; j < k_max; j++) {
            gain_mean += gain_raw[j];
        }
        gain_out[k] = gain_mean / (float)count;
    }

    /* 5a. SuppressionGainLimit */
    {
        float gain_upper_bound = AecState_SuppressionGainLimit(aec_state);
        if (gain_upper_bound < 1.0f) {
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                if (gain_out[k] > gain_upper_bound)
                    gain_out[k] = gain_upper_bound;
            }
        }
    }

    /* 6. Update state */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        self->last_gain_long[k] = gain_out[k];
        self->last_nearend_long[k] = E2[k];
        self->last_echo_long[k] = weighted_echo[k];
    }

    /* 7. Sqrt gain */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        gain_out[k] = sqrtf(gain_out[k]);
    }

    /* 7a. AdjustGainForHighBand_512fft */
    if (!self->earphone_flag && !self->voip_flag) {
        AdjustGainForHighBand_512fft(gain_out, &self->avggain_m);
    }

    /* 7.5k-8k transition */
    if (!self->earphone_flag && !self->voip_flag) {
        int sup_start = (int)(AEC3_FFT_LENGTH_LONG_BY2_PLUS1 * 0.9375f);
        float avggain_local = 0.0f;
        for (k = 128; k < 224; k++) {
            avggain_local += gain_out[k];
        }
        avggain_local /= 96.0f;
        for (k = sup_start; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            gain_out[k] = avggain_local;
        }
    }

    /* 8. UpperBandsGain_512fft */
    {
        int start = AEC3_FFT_LENGTH_LONG_BY2 / 2;
        float gain_below_8_khz = 1.0f;
        float nearend_spectrum_sum = 0.0f;
        float filterout_spectrum_sum = 0.0f;
        float nearend_spectrum_mean;
        float filterout_ratio_local;
        float gain_mean_4_8_khz = 0.0f;
        int count = 0;

        for (k = start; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            if (gain_out[k] < gain_below_8_khz)
                gain_below_8_khz = gain_out[k];
        }

        for (k = start; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
            nearend_spectrum_sum += E2[k];
            filterout_spectrum_sum += Y2[k];
        }
        nearend_spectrum_mean = nearend_spectrum_sum / (float)(AEC3_FFT_LENGTH_LONG_BY2 - start);
        filterout_ratio_local = filterout_spectrum_sum / (nearend_spectrum_sum + 1e-6f);
        if (filterout_ratio_local > 1.0f) filterout_ratio_local = 1.0f;

        for (k = start; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
            if (E2[k] >= nearend_spectrum_mean) {
                gain_mean_4_8_khz += gain_out[k];
                count++;
            }
        }
        if (count > 0) {
            gain_mean_4_8_khz /= (float)count;
        }
        gain_mean_4_8_khz *= filterout_ratio_local;

        if (saturated_echo) {
            if (gain_below_8_khz > 0.001f) gain_below_8_khz = 0.001f;
            *high_bands_gain = gain_below_8_khz;
        } else if (self->aec_level == 2) {
            *high_bands_gain = gain_below_8_khz;
        } else {
            *high_bands_gain = gain_mean_4_8_khz * gain_mean_4_8_khz;
        }
    }
}

void SuppressionGain_SetInitialState(SuppressionGain* self, int state) {
    self->initial_state = state;
}

void SuppressionGain_SetEarphoneFlag(SuppressionGain* self, int flag) {
    self->earphone_flag = flag;
}

void SuppressionGain_SetVoipFlag(SuppressionGain* self, int flag) {
    self->voip_flag = flag;
}

void SuppressionGain_SetLevel(SuppressionGain* self, int level) {
    self->aec_level = level;
}
