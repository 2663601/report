/*
 *  AdaptiveFirFilter - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ AdaptiveFirFilter class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Frequency-domain adaptive FIR filter with main and PFDKF partitions.
 *  C99 compatible, no C++ keywords.
 */

#ifndef ADAPTIVE_FIR_FILTER_H_
#define ADAPTIVE_FIR_FILTER_H_

#include "aec3_common.h"
#include "fft_data.h"
#include "aec3_fft.h"
#include "aec3_buffer.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declarations for types used in function signatures */
struct RenderBuffer_;
typedef struct RenderBuffer_ RenderBuffer;

/* ================================================================
 * AdaptiveFirFilter - Frequency-domain adaptive FIR filter
 *
 * Contains main filter (H) and PFDKF filter (H_pf) coefficients
 * stored in frequency domain. Supports partition-based overlap-save
 * convolution and Kalman-style adaptation.
 * ================================================================ */
typedef struct {
    int             max_size_partitions;
    int             current_size_partitions;
    int             target_size_partitions;
    int             old_target_size_partitions;
    int             size_change_duration_blocks;
    float           one_by_size_change_duration_blocks;
    int             size_change_counter;

    int             partition_to_constrain;
    float           mse_H;
    float           mse_H_cache;
    float           mse_y;
    int             is_H_cache_set;
    int             aec_H_usage;

    /* PFDKF filter coefficients (externally allocated, sized by aec_H_usage) */
    FftDataPfdkf*   H_pf;
    FftDataPfdkf*   H_pf_speed;
    FftDataPfdkf*   H_pf_update;
    float*          H2_pf_update;       /* flat [partition * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + bin] */

    int             max_pfdkf_partitions;   /* pre-allocated partition count */
    int             pfdkf_partitions_count;
} AdaptiveFirFilter;

/* ================================================================
 * Initialization
 *
 * max_partitions:      maximum number of filter partitions
 * initial_partitions:  initial active partition count
 * size_change_duration: blocks over which size changes are smoothed
 * ================================================================ */
void AdaptiveFirFilter_Init(AdaptiveFirFilter* self,
                            int max_partitions,
                            int initial_partitions,
                            int size_change_duration,
                            FftDataPfdkf* H_pf_mem,
                            FftDataPfdkf* H_pf_speed_mem,
                            FftDataPfdkf* H_pf_update_mem,
                            float* H2_pf_update_mem,
                            int aec_H_usage);

/* ================================================================
 * Set PFDKF H usage count and clear PFDKF arrays
 * ================================================================ */
void AdaptiveFirFilter_SetAecHUsage(AdaptiveFirFilter* self, int size);

/* ================================================================
 * Scale PFDKF filter coefficients by a factor
 * ================================================================ */
void AdaptiveFirFilter_ScaleFilterPfdkf(AdaptiveFirFilter* self, float factor);

/* ================================================================
 * Copy H_pf to H_pf_update (snapshot for PFDKF)
 * ================================================================ */
void AdaptiveFirFilter_SetHPfUpdate(AdaptiveFirFilter* self);

/* ================================================================
 * Update H_pf_update at a specific frequency bin from H_pf_speed
 * ================================================================ */
void AdaptiveFirFilter_UpdateHPfupdate(AdaptiveFirFilter* self, int index);

/* ================================================================
 * Compute H2_pf_update from H_pf_update
 * ================================================================ */
void AdaptiveFirFilter_ComputeH2PfResponse(AdaptiveFirFilter* self);

/* ================================================================
 * FilterPfdkf: S = sum_j( H_pf_j * X_j ), S_speed = sum_j( H_pf_speed_j * X_j )
 *
 * PFDKF filter output using relf/imlf fields.
 * Convolves H_pf and H_pf_speed partitions with render buffer PFDKF FFT data.
 * Steps through the render buffer with AEC3_LF_BLOCK_SHIFT stride.
 *
 * render_buffer:  render buffer providing PFDKF FFT data
 * S:              output FftData for H_pf convolution (relf/imlf fields)
 * S_speed:        output FftData for H_pf_speed convolution (relf/imlf fields)
 * ================================================================ */
void AdaptiveFirFilter_FilterPfdkf(const AdaptiveFirFilter* self,
                                   const RenderBuffer* render_buffer,
                                   FftDataPfdkf* S,
                                   FftDataPfdkf* S_speed);

/* ================================================================
 * AdaptPfdkf: update H_pf and H_pf_speed using per-partition PFDKF gains
 *
 * First copies H_pf_update into H_pf and H_pf_speed (reset to snapshot),
 * then adapts: H_pf_j += G_j * conj(X_j), H_pf_speed_j += G_speed_j * conj(X_j)
 * Steps through the render buffer with AEC3_LF_BLOCK_SHIFT stride.
 *
 * render_buffer:  render buffer providing PFDKF FFT data
 * G:              per-partition gain array for H_pf (num_partitions elements)
 * G_speed:        per-partition gain array for H_pf_speed (num_partitions elements)
 * num_partitions: number of partitions to adapt
 * ================================================================ */
void AdaptiveFirFilter_AdaptPfdkf(AdaptiveFirFilter* self,
                                  const RenderBuffer* render_buffer,
                                  const FftDataPfdkf* G,
                                  const FftDataPfdkf* G_speed,
                                  int num_partitions);

/* ================================================================
 * Handle echo path change: reset PFDKF filter coefficients
 * ================================================================ */
void AdaptiveFirFilter_HandleEchoPathChange(AdaptiveFirFilter* self);

#ifdef __cplusplus
}
#endif

#endif /* ADAPTIVE_FIR_FILTER_H_ */
