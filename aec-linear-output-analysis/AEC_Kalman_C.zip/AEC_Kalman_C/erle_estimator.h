/*
 *  ErleEstimator - Pure C Version
 *
 *  Estimates the Echo Return Loss Enhancement (ERLE).
 *  Simplified pure C port: inlines subband and fullband ERLE estimation.
 *  Ported from WebRTC AEC3 C++ ErleEstimator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef ERLE_ESTIMATOR_H_
#define ERLE_ESTIMATOR_H_

#include "aec3_common.h"
#include "aec3_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * ErleEstimator
 *
 * Estimates ERLE per subband (512-point) and fullband.
 * 128-point arrays and functions have been removed as part of
 * memory optimization — only PFDKF 512-point path is retained.
 * ================================================================ */
typedef struct {
    int     startup_phase_length_blocks;
    int     blocks_since_reset;

    /* Subband ERLE (512-point FFT) */
    float   erle_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   erle_long_greater[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   erle_min_512fft;
    float   erle_max_l_512fft;
    float   erle_max_h_512fft;

    /* Accumulation spectra for 512fft ERLE (matches C++ accum_spectra_) */
    float   accum_Y2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   accum_E2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    int     accum_num_points_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    /* Fullband ERLE */
    float   fullband_erle_log2;
    int     fullband_hold_counter;

    /* Onset detection */
    int     onset_detection;
} ErleEstimator;

/**
 * Initialize the ERLE estimator.
 */
void ErleEstimator_Init(ErleEstimator* self,
                        int startup_phase_length_blocks,
                        const Aec3Config* config);

/**
 * Reset the ERLE estimator.
 * @param delay_change  If true, reset blocks_since_reset counter
 */
void ErleEstimator_Reset(ErleEstimator* self, int delay_change);

/**
 * Update ERLE with 512-point FFT spectra.
 */
void ErleEstimator_Update512fft(ErleEstimator* self,
                                const float* reverb_render_spectrum,
                                const float* capture_spectrum,
                                const float* subtractor_spectrum,
                                int converged_filter,
                                int onset_detection,
                                int use_update,
                                int under_suppression);

/**
 * Get the 512-point subband ERLE.
 */
const float* ErleEstimator_ErleLong(const ErleEstimator* self);

/**
 * Get the 512-point subband ERLE (greater variant).
 */
const float* ErleEstimator_ErleLongGreater(const ErleEstimator* self);

/**
 * Get the fullband ERLE in log2 units.
 */
float ErleEstimator_FullbandErleLog2(const ErleEstimator* self);

#ifdef __cplusplus
}
#endif

#endif /* ERLE_ESTIMATOR_H_ */
