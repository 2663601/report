#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
离线读盘版轻量 AEC Dataset
================================
配合 export_offline_aec.py 预先合成好的 int16 wav + manifest.json 使用。
__getitem__ 只做"读盘 + 可选轻量在线增广", 跳过在线合成链里最慢的
线性 AEC(AEC_16K_STFT_FS4) 和 RIR/非线性合成, 预计把数据侧单样本耗时从
几百 ms 降到 ~10ms, 整体训练 5~10x 提速(需实测)。

返回签名与 dset_train_on_opens_prev1_abg.Dataset.__getitem__ 完全一致:
  use_laec=True : (z, x, target, echo, y, vad)
  use_laec=False: (y, x, target, echo, vad)
(system_bandaec 解包顺序: z,x,target,echo,y,vad -> 用 z/y/x 做输入, target 监督)

★ 开关(online_augment):
  - False(默认): 纯读盘, 完全复现离线合成结果, 最快。
  - True        : 读盘后做轻量在线增广, 补偿"离线固定、每 epoch 不变"的多样性损失。
                  重活(RIR / 非线性 / 线性 AEC)已离线固定, 这里只做零成本级增广:
                    · 共享 EQ: 对 z/y/x 施加同一条 SevenBandParametricEQ(模拟设备频响漂移,
                      三路共享保证 z/y/x 相对关系不被破坏, target 不动);
                    · 麦克风路微噪: 给 y(和 z) 叠加极低电平高斯噪声(模拟残留底噪)。
                  增广强度/概率由 toml 的 [train_dataset.args.aug] 控制。
"""
import os
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import signal as _sps

sys.path.append("../")
from training.acore.datasets.base_dataset import BaseDataset


def expand_path(path):
    # 与 training.acore.utils.expand_path 等价; 内联以避免 import utils 时连带
    # 拉入 pytorch_lightning(本地读盘/合成无需 PL, 服务器训练才需要)。
    return os.path.abspath(os.path.expanduser(path))


# 手搓多频段 peaking EQ (不依赖 audiomentations, 便于本地验证 + 三路严格共享同一曲线)。
# 7 个对数分布的中心频率, 覆盖 16k 语音主要频段。
_EQ_CENTER_FREQS = np.array([120.0, 300.0, 600.0, 1200.0, 2400.0, 4000.0, 6500.0], dtype=np.float64)
_EQ_Q = 1.0  # 品质因数(带宽), 1.0 为中等宽度


def _peaking_biquad(f0, gain_db, Q, fs):
    """返回单个 peaking EQ 的 (b, a) 系数 (RBJ cookbook)。"""
    A = 10.0 ** (gain_db / 40.0)
    w0 = 2.0 * np.pi * f0 / fs
    alpha = np.sin(w0) / (2.0 * Q)
    cosw0 = np.cos(w0)
    b0 = 1.0 + alpha * A
    b1 = -2.0 * cosw0
    b2 = 1.0 - alpha * A
    a0 = 1.0 + alpha / A
    a1 = -2.0 * cosw0
    a2 = 1.0 - alpha / A
    b = np.array([b0, b1, b2]) / a0
    a = np.array([a0, a1, a2]) / a0
    return b, a


def _build_random_eq_sos(gains_db, fs):
    """把一组频段增益组成级联 SOS; gains_db 决定这条 EQ 曲线。"""
    sos = []
    for f0, g in zip(_EQ_CENTER_FREQS, gains_db):
        b, a = _peaking_biquad(f0, g, _EQ_Q, fs)
        sos.append(np.concatenate([b, a]))
    return np.asarray(sos, dtype=np.float64)


def _read_int16_wav(path, expect_len=None):
    """读 int16 wav -> float32 [-1,1]。"""
    data, _ = sf.read(path, dtype="int16", always_2d=False)
    y = (data.astype(np.float32)) / 32768.0
    if y.ndim > 1:
        y = y[:, 0]
    if expect_len is not None:
        if len(y) < expect_len:
            y = np.append(y, np.zeros(expect_len - len(y), dtype=np.float32))
        elif len(y) > expect_len:
            y = y[:expect_len]
    return y


class OfflineAECDataset(BaseDataset):
    def __init__(self,
                 manifest_path,
                 sr=16000,
                 online_augment=False,
                 dataset_limit=-1,
                 dataset_offset=0,
                 **kwargs):
        """
        manifest_path : export_offline_aec.py 产出的 manifest.json
        online_augment: 读盘后是否做轻量在线增广(见模块 docstring)
        dataset_limit : -1=全量; 否则截断到该数量(调试用)
        dataset_offset: 样本起始偏移
        kwargs["aug"] : 增广超参(可选), 字段:
            eq_p(默认0.5), eq_gain_db(默认12),
            mic_noise_p(默认0.3), mic_noise_db(默认-55)
        """
        super().__init__()
        self.sr = sr
        self.online_augment = bool(online_augment)
        self.eps = 1e-13

        mp = expand_path(manifest_path)
        with open(mp, "r") as f:
            meta = json.load(f)
        self.root = Path(mp).parent
        self.use_laec = meta.get("use_laec", True)
        self.has_echo = meta.get("has_echo", True)
        self.sub_sample_length = meta.get("sub_sample_length", 4)
        self.expect_len = int(self.sub_sample_length * self.sr)

        items = meta["items"]
        if dataset_offset:
            items = items[dataset_offset:]
        if dataset_limit is not None and dataset_limit >= 0:
            items = items[:dataset_limit]
        self.items = items
        self.length = len(self.items)

        # 轻量增广超参
        aug = kwargs.get("aug", {}) or {}
        self.eq_p = float(aug.get("eq_p", 0.5))
        self.eq_gain_db = float(aug.get("eq_gain_db", 6.0))   # 12→6: 7段级联防叠加爆值出nan
        self.mic_noise_p = float(aug.get("mic_noise_p", 0.3))
        self.mic_noise_db = float(aug.get("mic_noise_db", -55.0))

        print("I[offline]: manifest={}, count={}, use_laec={}, has_echo={}, online_augment={}".format(
            mp, self.length, self.use_laec, self.has_echo, self.online_augment))

    def __len__(self):
        return self.length

    def _apply_augment(self, z, x, y):
        """三路共享 EQ + 麦克风路微噪(z/y)。target 不动。

        稳态/数值保护(防 nan): 7 段 peaking EQ 级联最坏情况(多段高增益同频叠加)会把
        波形放大几十倍甚至产生 inf, 进 system 的 log_band_power/STFT 后出 nan。
        因此: ①增益收敛到较小范围(eq_gain_db 默认已降到 6); ②EQ 后对三路做统一幅度
        归一(保持 z/y/x 相对关系); ③isfinite 校验, 异常则整条回退到未增广。
        """
        # 共享 EQ: 掷一组随机频段增益 -> 组成一条曲线 -> 严格用同一条 SOS 作用 z/y/x,
        # 保持三路相对声学关系不被破坏(手搓 biquad, 不依赖 audiomentations)。
        if np.random.random() < self.eq_p:
            gains_db = np.random.uniform(-self.eq_gain_db, self.eq_gain_db,
                                         size=len(_EQ_CENTER_FREQS))
            sos = _build_random_eq_sos(gains_db, self.sr)
            yf = _sps.sosfilt(sos, y.astype(np.float64))
            xf = _sps.sosfilt(sos, x.astype(np.float64))
            zf = _sps.sosfilt(sos, z.astype(np.float64))
            # 异常保护: 任一路出现 inf/nan 就放弃本次 EQ(回退到原始三路)
            if (np.isfinite(yf).all() and np.isfinite(xf).all() and np.isfinite(zf).all()):
                # 统一幅度归一: 用三路共同的峰值缩放(保持相对关系), 把峰值压回 <=0.99
                peak = max(np.max(np.abs(yf)), np.max(np.abs(xf)), np.max(np.abs(zf)))
                if peak > 0.99:
                    g = 0.99 / (peak + self.eps)
                    yf = yf * g; xf = xf * g; zf = zf * g
                y = yf.astype(np.float32)
                x = xf.astype(np.float32)
                z = zf.astype(np.float32)

        # 麦克风路微噪: 给 y/z 叠加极低电平高斯噪声
        if np.random.random() < self.mic_noise_p:
            n = np.random.randn(len(y)).astype(np.float32)
            n /= (np.max(np.abs(n)) + self.eps)
            scale = 10 ** (self.mic_noise_db / 20)
            n = n * scale
            y = y + n
            z = z + n

        # 最终兜底: 任何一路非有限值一律清零为未增广输入不可得(已覆盖), 这里再 nan_to_num
        z = np.nan_to_num(z, nan=0.0, posinf=0.99, neginf=-0.99).astype(np.float32)
        x = np.nan_to_num(x, nan=0.0, posinf=0.99, neginf=-0.99).astype(np.float32)
        y = np.nan_to_num(y, nan=0.0, posinf=0.99, neginf=-0.99).astype(np.float32)
        return z, x, y

    def __getitem__(self, item):
        rec = self.items[item]
        el = self.expect_len

        x = _read_int16_wav(str(self.root / rec["x"]), el)
        target = _read_int16_wav(str(self.root / rec["target"]), el)
        y = _read_int16_wav(str(self.root / rec["y"]), el)
        if self.use_laec:
            z = _read_int16_wav(str(self.root / rec["z"]), el)
        else:
            z = y
        if self.has_echo and "echo" in rec:
            echo = _read_int16_wav(str(self.root / rec["echo"]), el)
        else:
            echo = np.zeros(el, dtype=np.float32)

        vad = np.load(str(self.root / rec["vad"])).astype(np.int64)

        if self.online_augment:
            z, x, y = self._apply_augment(z, x, y)

        if self.use_laec:
            return (z.astype("float32"), x.astype("float32"), target.astype("float32"),
                    echo.astype("float32"), y.astype("float32"), vad)
        return (y.astype("float32"), x.astype("float32"), target.astype("float32"),
                echo.astype("float32"), vad)
