/*
 *  AEC3 Configuration - Pure C Version
 *
 *  Ported from WebRTC AEC3 EchoCanceller3Config (echo_canceller3_config.h)
 *  and AECConfigParameter (echo_control.h).
 *
 *  All default values match the C++ version exactly.
 *  128-point main/shadow filter parameters removed — only PFDKF retained.
 *  C99 compatible, no C++ keywords.
 */

#ifndef AEC3_CONFIG_H_
#define AEC3_CONFIG_H_

#include "aec3_common.h"

/* ================================================================
 * Aec3Config - Static algorithm configuration
 *
 * Corresponds to EchoCanceller3Config in the C++ version.
 * Fields are flattened from the nested C++ struct hierarchy.
 * 128-point main/shadow filter params and suppressor_normal_tuning
 * have been removed as part of memory optimization.
 * ================================================================ */
typedef struct {

    /* ---- Delay estimation ---- */
    int     delay_default;                          /* 5 */
    int     delay_down_sampling_factor;             /* 4 */
    int     delay_num_filters;                      /* 5 */
    int     delay_api_call_jitter_blocks;           /* 26 */
    int     delay_min_echo_path_delay_blocks;       /* 0 */
    int     delay_headroom_blocks;                  /* 2 */
    int     delay_hysteresis_limit_1_blocks;        /* 1 */
    int     delay_hysteresis_limit_2_blocks;        /* 1 */
    int     delay_skew_hysteresis_blocks;           /* 3 */
    int     delay_fixed_capture_delay_samples;      /* 0 */
    float   delay_estimate_smoothing;               /* 0.7f */
    float   delay_candidate_detection_threshold;    /* 0.2f */
    int     delay_selection_thresholds_initial;     /* 5 */
    int     delay_selection_thresholds_converged;   /* 20 */

    /* ---- Main filter (retained for buffer sizing / filter analyzer) ---- */
    int     filter_main_length_blocks;              /* 13 */
    float   filter_main_leakage_converged;          /* 0.00005f */
    float   filter_main_leakage_diverged;           /* 0.05f */
    float   filter_main_error_floor;                /* 0.001f */
    float   filter_main_error_ceil;                 /* 2.f */
    float   filter_main_noise_gate;                 /* 20075344.f */

    /* ---- Main filter initial (retained for filter analyzer) ---- */
    int     filter_main_initial_length_blocks;      /* 12 */
    float   filter_main_initial_leakage_converged;  /* 0.005f */
    float   filter_main_initial_leakage_diverged;   /* 0.5f */
    float   filter_main_initial_error_floor;        /* 0.001f */
    float   filter_main_initial_error_ceil;         /* 2.f */
    float   filter_main_initial_noise_gate;         /* 20075344.f */

    /* ---- PFDKF filter ---- */
    int     pfdkf_num_block;                        /* 13 */
    int     pfdkf_shift_block;                      /* 3 */
    int     pfdkf_Hsize;                            /* 5 */
    float   pfdkf_error_floor;                      /* 0.003f */
    float   pfdkf_error_ceil;                       /* 20.f */
    float   pfdkf_noise_gate;                       /* 1543800.f */
    float   pfdkf_noise_gate2;                      /* 15438.f */

    /* ---- Filter state ---- */
    int     config_change_duration_blocks;          /* 250 */
    float   initial_state_seconds;                  /* 2.5f */
    int     conservative_initial_phase;             /* 0 (false) */
    int     enable_shadow_filter_output_usage;      /* 1 (true) */

    /* ---- ERLE ---- */
    float   erle_min;                               /* 1.f */
    float   erle_max_l;                             /* 30.f */
    float   erle_max_h;                             /* 10.f */
    float   erle_min_512fft;                        /* 1.f */
    float   erle_max_l_512fft;                      /* 4.f */
    float   erle_max_h_512fft;                      /* 1.5f */
    float   erle_max_512loop_l;                     /* 30.f */
    float   erle_max_512loop_h;                     /* 10.f */
    int     erle_onset_detection;                   /* 1 (true) */
    int     erle_num_sections;                      /* 1 */

    /* ---- Echo path strength ---- */
    float   ep_strength_lf;                         /* 1.f */
    float   ep_strength_mf;                         /* 1.f */
    float   ep_strength_hf;                         /* 1.f */
    float   ep_strength_default_len;                /* 0.83f */
    int     ep_strength_reverb_based_on_render;     /* 1 (true) */
    int     ep_strength_echo_can_saturate;          /* 1 (true) */
    int     ep_strength_bounded_erl;                /* 0 (false) */

    /* ---- Echo audibility ---- */
    float   echo_audibility_low_render_limit;       /* 256.f  (4*64) */
    float   echo_audibility_normal_render_limit;    /* 64.f */
    float   echo_audibility_floor_power;            /* 128.f  (2*64) */
    float   echo_audibility_audibility_threshold_lf;/* 12.f */
    float   echo_audibility_audibility_threshold_mf;/* 10.f */
    float   echo_audibility_audibility_threshold_hf;/* 8.f */
    int     echo_audibility_use_stationary_properties;          /* 0 (false) */
    int     echo_audibility_use_stationarity_properties_at_init;/* 0 (false) */

    /* ---- Render levels ---- */
    float   render_levels_active_render_limit;              /* 100.f */
    float   render_levels_poor_excitation_render_limit;     /* 150.f */
    float   render_levels_poor_excitation_render_limit_ds8; /* 20.f */

    /* ---- Echo removal control / gain rampup ---- */
    float   gain_rampup_initial_gain;               /* 0.0f */
    float   gain_rampup_first_non_zero_gain;        /* 0.001f */
    int     gain_rampup_non_zero_gain_blocks;       /* 187 */
    int     gain_rampup_full_gain_blocks;           /* 312 */
    int     echo_removal_has_clock_drift;           /* 0 (false) */
    int     echo_removal_linear_and_stable_echo_path; /* 0 (false) */

    /* ---- Echo model ---- */
    int     echo_model_noise_floor_hold;            /* 50 */
    float   echo_model_min_noise_floor_power;       /* 1638400.f */
    float   echo_model_stationary_gate_slope;       /* 10.f */
    float   echo_model_noise_gate_power;            /* 27509.42f */
    float   echo_model_noise_gate_slope;            /* 0.3f */
    int     echo_model_render_pre_window_size;      /* 1 */
    int     echo_model_render_post_window_size;     /* 1 */
    int     echo_model_render_pre_window_size_init; /* 10 */
    int     echo_model_render_post_window_size_init;/* 10 */
    float   echo_model_nonlinear_hold;              /* 1.f */
    float   echo_model_nonlinear_release;           /* 0.001f */

    /* ---- Suppressor ---- */
    int     suppressor_nearend_average_blocks;      /* 4 */

    /* normal_tuning_512fft.mask_lf */
    float   suppressor_normal_tuning_512fft_mask_lf_enr_transparent;  /* 0.3f */
    float   suppressor_normal_tuning_512fft_mask_lf_enr_suppress;     /* 0.4f */
    float   suppressor_normal_tuning_512fft_mask_lf_emr_transparent;  /* 0.3f */
    /* normal_tuning_512fft.mask_hf */
    float   suppressor_normal_tuning_512fft_mask_hf_enr_transparent;  /* 0.07f */
    float   suppressor_normal_tuning_512fft_mask_hf_enr_suppress;     /* 0.1f */
    float   suppressor_normal_tuning_512fft_mask_hf_emr_transparent;  /* 0.3f */
    float   suppressor_normal_tuning_512fft_max_inc_factor;           /* 2.0f */
    float   suppressor_normal_tuning_512fft_max_dec_factor_lf;        /* 0.25f */

    /* normal_tuning_512fft_earphone.mask_lf */
    float   suppressor_normal_tuning_512fft_earphone_mask_lf_enr_transparent;  /* 0.6f */
    float   suppressor_normal_tuning_512fft_earphone_mask_lf_enr_suppress;     /* 0.9f */
    float   suppressor_normal_tuning_512fft_earphone_mask_lf_emr_transparent;  /* 0.3f */
    /* normal_tuning_512fft_earphone.mask_hf */
    float   suppressor_normal_tuning_512fft_earphone_mask_hf_enr_transparent;  /* 0.2f */
    float   suppressor_normal_tuning_512fft_earphone_mask_hf_enr_suppress;     /* 0.5f */
    float   suppressor_normal_tuning_512fft_earphone_mask_hf_emr_transparent;  /* 0.3f */
    float   suppressor_normal_tuning_512fft_earphone_max_inc_factor;           /* 2.0f */
    float   suppressor_normal_tuning_512fft_earphone_max_dec_factor_lf;        /* 0.25f */

    /* echo_tuning.mask_lf */
    float   suppressor_echo_tuning_mask_lf_enr_transparent;     /* 0.00005f */
    float   suppressor_echo_tuning_mask_lf_enr_suppress;        /* 0.004f */
    float   suppressor_echo_tuning_mask_lf_emr_transparent;     /* 0.00005f */
    /* echo_tuning.mask_hf */
    float   suppressor_echo_tuning_mask_hf_enr_transparent;     /* 0.00007f */
    float   suppressor_echo_tuning_mask_hf_enr_suppress;        /* 0.001f */
    float   suppressor_echo_tuning_mask_hf_emr_transparent;     /* 0.00003f */
    float   suppressor_echo_tuning_max_inc_factor;              /* 1.0f */
    float   suppressor_echo_tuning_max_dec_factor_lf;           /* 0.125f */

    /* nearend_tuning.mask_lf */
    float   suppressor_nearend_tuning_mask_lf_enr_transparent;  /* 1.09f */
    float   suppressor_nearend_tuning_mask_lf_enr_suppress;     /* 1.1f */
    float   suppressor_nearend_tuning_mask_lf_emr_transparent;  /* 0.3f */
    /* nearend_tuning.mask_hf */
    float   suppressor_nearend_tuning_mask_hf_enr_transparent;  /* 0.1f */
    float   suppressor_nearend_tuning_mask_hf_enr_suppress;     /* 0.3f */
    float   suppressor_nearend_tuning_mask_hf_emr_transparent;  /* 0.3f */
    float   suppressor_nearend_tuning_max_inc_factor;           /* 2.0f */
    float   suppressor_nearend_tuning_max_dec_factor_lf;        /* 0.25f */

    /* dominant_nearend_detection */
    float   suppressor_dominant_nearend_enr_threshold;          /* 0.25f */
    float   suppressor_dominant_nearend_enr_exit_threshold;     /* 10.f */
    float   suppressor_dominant_nearend_snr_threshold;          /* 30.f */
    int     suppressor_dominant_nearend_hold_duration;          /* 50 */
    int     suppressor_dominant_nearend_trigger_threshold;      /* 12 */
    int     suppressor_dominant_nearend_use_during_initial_phase; /* 1 (true) */

    /* high_bands_suppression */
    float   suppressor_high_bands_enr_threshold;                /* 1.f */
    float   suppressor_high_bands_max_gain_during_echo;         /* 1.f */

    float   suppressor_floor_first_increase;                    /* 0.00001f */
    int     suppressor_enforce_transparent;                     /* 0 (false) */
    int     suppressor_enforce_empty_higher_bands;              /* 0 (false) */

    /* ---- Buffering ---- */
    int     buffering_use_new_render_buffering;                 /* 1 (true) */
    int     buffering_excess_render_detection_interval_blocks;  /* 250 */
    int     buffering_max_allowed_excess_render_blocks;         /* 8 */

    /* ---- PFDKF suppress floor tuning ---- */
    /* Range [0,1]. Scales the nearend-protection floor in PFDKF suppress_gain.
     * Lower = stronger echo suppression, weaker double-talk protection.
     * Default 1.0 (full protection). Recommended 0.8 for H=6 optimization. */
    float   suppress_floor_coeff;

    /* ---- Reverb suppression tuning (used when enable_echo_reverb=1) ---- */
    /* Range [0,1]. Controls reverb tail echo injection strength in R2 estimation.
     * Higher = more aggressive reverb suppression, but degrades double-talk.
     * Default 0.2. Recommended 0.5 for H=6 high-reverb optimization. */
    float   ep_strength_default_gain;
    float   reverb_decay_max;                       /* 0.95f: max decay rate estimate */
    int     reverb_fast_convergence_blocks;         /* 500: fast convergence phase duration */

} Aec3Config;


/* ================================================================
 * AecRuntimeConfig - Runtime-adjustable parameters
 *
 * Corresponds to AECConfigParameter in the C++ version (echo_control.h).
 * bool fields replaced with int (0/1).
 * ================================================================ */
typedef struct {
    int     aec_level;                      /* 1 */
    float   aec_nlp_level;                  /* 0.5f */
    int     aec_512fft_enable;              /* 1 (true) */
    int     matched_filter_enable;          /* 0 (false) */
    int     use_noise_gate_division;        /* 1 (true) */
    int     use_cache_filter;               /* 1 (true) */
    int     aec_dtcontrol_enable;           /* 1 (true) */
    int     highpass_enable_capture;        /* 1 (true) */
    int     highpass_enable_render;         /* 1 (true) */
    int     dtd_flag;                       /* 1 (true) */
    int     init_blocks;                    /* 1 */
    int     aec_H_usage;                    /* 20 */
    int     double_talk_count_max;          /* 30 */
    float   ed_ratio_2k_threshold;          /* 0.02f */
    int     howl_supp;                      /* 1 (true) */
    int     delay_default;                  /* 0 */
    int     apm_submodule_switch;           /* 1 (true) */
    int     render_started;                 /* 0 (false) */
    int     mute_flag;                      /* 0 (false) */
    float   nonlinear_level;                /* 0.f */
    int     CNG_level;                      /* -1 */
    int     audioMixing_flag;               /* 0 (false) */
    int     loopback_capture_mode;          /* 0 (false) */
    int     earphone_capture_mode;          /* 0 (false) */
    int     voip_mode_enable;               /* 0 (false) */
    int     voip_mode_proc_enable;          /* 0 (false) */
    int     initial_sup_flag;               /* 0 */
    int     external_audio_mixing;          /* 0 (false) */
    int     special_device_lowband_ext_gain_enable; /* 0 (false) */
    int     special_device_lowband_max_band;        /* 6 */
    float   special_device_lowband_min_power;       /* 6.f */
    float   special_device_lowband_ext_gain;        /* 16.f */
    int     voip_mode_enable_ver;           /* 0 */
    int     CastScreen;                     /* 0 (false) */
    int     weak_resecho_thd;               /* 10 */
    int     aec_delay_gcc_enable;           /* 0 (false) */
    int     aec_low_compute_mode;           /* 0 (false) */
    int     enable_echo_reverb;             /* 0 (false) */
    int     ExcludeNoiseFromEchoFlag;       /* 0 */
    int     extra_echo_sup;                 /* 0 (false) */
    int     builtin_aec_active_detect_enable; /* 0 (false) */

    /* Noise gate parameters (applied after DSE, before AGC in aec_kalman mode) */
    int     noise_gate_enable;              /* 0 (false) */
    int     noise_gate_threshold;           /* 200: peak amplitude threshold */
    float   noise_gate_setting_gain;        /* 0.1f: target gain when gating */
    float   noise_gate_gain_dec_factor;     /* 0.9f: smoothing factor for gain decrease */
    int     aec_noise_gate_enable;          /* 1: use AEC hold_counter to control gating */

    /* NLP implementation selection (spec: aec-kalman-speex-nlp)
     *   0: default AEC3 SuppressionGain_GetGain512 path (baseline)
     *   1: Speex-style NLP (ported from mdf.c ezviz_nonlinear_processing)
     * Only honored when aec_delay_ms == -3 (Kalman mode). Invalid values
     * fall back to 0. Settable at runtime via
     *   YS_VQE_SetConfig(h, YS_VQE_SET_AEC_NLP_MODE, &mode). */
    int     webrtc_aec_mode;
} AecRuntimeConfig;

/* ================================================================
 * Default value initialization functions
 * ================================================================ */

/**
 * Set all fields of Aec3Config to their default values.
 * Default values match EchoCanceller3Config in the C++ version exactly.
 */
void Aec3Config_SetDefaults(Aec3Config* config);

/**
 * Set all fields of AecRuntimeConfig to their default values.
 * Default values match AECConfigParameter as set in ys_aec_kalman.cpp.
 */
void AecRuntimeConfig_SetDefaults(AecRuntimeConfig* config);

#endif /* AEC3_CONFIG_H_ */
