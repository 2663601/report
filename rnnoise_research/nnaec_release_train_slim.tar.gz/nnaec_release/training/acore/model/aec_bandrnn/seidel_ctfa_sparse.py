#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SeidelCTFA 的 **稀疏感知训练版** (block-sparse, 对标 rnnoise / 复用 seidel_aec_sparse 做法)。

与 seidel_ctfa_aec.SeidelCTFA 结构**完全一致**(up_proj + cTFA门控 + fc_input + 时间GRU + farmod + dense),
仅给**主时间 GRU**(self.gru, 参数大头 ~63%)挂 4×8 块稀疏, 渐进调度到目标 density。
推理结构不变: 稀疏只是把时间 GRU 权重里能量最小的 4×8 块置零, 便于 int8+block-sparse 导出。

注意:
  - cTFA 的 ta_gru / fa_gru 很小(各几 K), 不稀疏(稀疏收益小、且可能伤门控精度)。
  - 稀疏逻辑/代理类与 seidel_aec_sparse 完全一致, 这里直接复用其 _GRULayerProxy 与
    GRUSparsifier 调度, 并带低频"4x8块全零率"打印(确认稀疏是否真生效)。

用法: toml 里 model.path 指向本类, 给 sparse_* 参数。system 的 on_train_batch_end 钩子
会检测 model.sparsify 并每步调用(零侵入, 普通 seidel/ctfa 无此方法)。
"""
import torch
import torch.nn as nn

from .seidel_ctfa_aec import SeidelCTFA
from .seidel_aec_sparse import _GRULayerProxy

import sys, os
_ACORE = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _ACORE not in sys.path:
    sys.path.insert(0, _ACORE)
from sparsification import GRUSparsifier


class SeidelCTFASparse(SeidelCTFA):
    def __init__(self,
                 nbands=64, num_inputs=3, ctfa_ch=16, fa_hidden=16,
                 fc_input_dim=128, gru_hidden=128, n_gru=2,
                 gru_dropout=0.2, dense_hidden=192,
                 use_ctfa=True, use_farmod_attn=True, farmod_bias_init=0.0,
                 # ---- 稀疏调度(与 seidel_aec_sparse 同口径) ----
                 sparse_density=0.5,
                 sparse_block=(4, 8),
                 sparse_start=0,
                 sparse_stop=62000,
                 sparse_interval=100,
                 sparse_exponent=3,
                 sparse_keep_diagonal_recurrent=True,
                 sparse_log_every=2000,
                 sparse_freeze_mask=False,
                 **kwargs):
        super().__init__(nbands=nbands, num_inputs=num_inputs, ctfa_ch=ctfa_ch,
                         fa_hidden=fa_hidden, fc_input_dim=fc_input_dim,
                         gru_hidden=gru_hidden, n_gru=n_gru, gru_dropout=gru_dropout,
                         dense_hidden=dense_hidden, use_ctfa=use_ctfa,
                         use_farmod_attn=use_farmod_attn, farmod_bias_init=farmod_bias_init,
                         **kwargs)
        self.sparse_density = sparse_density
        self._blk = tuple(sparse_block)
        self._sparse_log_every = int(sparse_log_every)
        self._sparse_step = 0
        self.sparse_freeze_mask = bool(sparse_freeze_mask)
        self._fixed_masks = {}
        self._mask_hooks = []

        bs = list(sparse_block)
        kd = sparse_keep_diagonal_recurrent
        sparse_params = {
            'W_ir': (sparse_density, bs, False),
            'W_iz': (sparse_density, bs, False),
            'W_in': (sparse_density, bs, False),
            'W_hr': (sparse_density, bs, kd),
            'W_hz': (sparse_density, bs, kd),
            'W_hn': (sparse_density, bs, kd),
        }
        # 只对主时间 GRU(self.gru)的每一层挂 sparsifier; cTFA 小 GRU 不动。
        self.sparsifiers = []
        for layer in range(n_gru):
            in_size = fc_input_dim if layer == 0 else gru_hidden
            proxy = _GRULayerProxy(self.gru, layer, gru_hidden, in_size)
            self.sparsifiers.append(
                GRUSparsifier([(proxy, sparse_params)],
                              sparse_start, sparse_stop, sparse_interval, sparse_exponent)
            )

    def _ensure_fixed_masks(self):
        """从 warm-start 权重的零位置提取固定 mask；首次前向时模型已加载 ckpt。"""
        if not self.sparse_freeze_mask or self._fixed_masks:
            return
        for layer in range(self.n_gru):
            for prefix in ("weight_ih", "weight_hh"):
                name = f"{prefix}_l{layer}"
                weight = getattr(self.gru, name)
                mask = (weight.detach() != 0).to(dtype=weight.dtype)
                self._fixed_masks[name] = mask
                weight.register_hook(lambda grad, n=name: grad * self._fixed_masks[n].to(grad.device))
        print("I[sparse-ctfa]: 已从 warm-start 权重提取并固定稀疏 mask", flush=True)

    def _apply_fixed_masks(self):
        if not self.sparse_freeze_mask:
            return
        self._ensure_fixed_masks()
        with torch.no_grad():
            for name, mask in self._fixed_masks.items():
                weight = getattr(self.gru, name)
                weight.mul_(mask.to(weight.device))

    def forward(self, feat, hidden=None):
        if self.sparse_freeze_mask:
            self._apply_fixed_masks()
        return super().forward(feat, hidden)

    def sparsify(self, verbose=False):
        if self.sparse_freeze_mask:
            self._apply_fixed_masks()
        else:
            for sp in self.sparsifiers:
                sp.step(verbose=verbose)
        self._sparse_step = getattr(self, "_sparse_step", 0) + 1
        every = getattr(self, "_sparse_log_every", 2000)
        if self._sparse_step <= 2 or self._sparse_step % every == 0:
            self._print_sparsity(self._sparse_step)

    def _print_sparsity(self, step):
        bs = self._blk
        msgs = []
        for layer in range(self.n_gru):
            for wn in (f"weight_ih_l{layer}", f"weight_hh_l{layer}"):
                W = getattr(self.gru, wn).detach()
                r, c = W.shape
                rr, cc = (r // bs[0]) * bs[0], (c // bs[1]) * bs[1]
                Wb = W[:rr, :cc].reshape(rr // bs[0], bs[0], cc // bs[1], bs[1])
                bz = (Wb.abs().amax(dim=(1, 3)) < 1e-12).float().mean().item()
                msgs.append(f"{wn}={bz*100:.0f}%")
        print(f"I[sparse-ctfa] step={step} 4x8块全零率: " + " ".join(msgs), flush=True)


if __name__ == "__main__":
    m = SeidelCTFASparse(nbands=64, sparse_start=2, sparse_stop=40,
                         sparse_interval=2, sparse_log_every=10)
    n = sum(p.numel() for p in m.parameters())
    print(f"SeidelCTFASparse params={n/1e3:.1f}K")
    feat = torch.randn(2, 30, 64 * 3)
    opt = torch.optim.Adam(m.parameters(), lr=1e-3)
    for step in range(60):
        g, h = m(feat)
        loss = g.mean()
        opt.zero_grad(); loss.backward(); opt.step()
        m.sparsify()
    print("期望末尾时间GRU块零率接近 50%(recurrent 略低)")
