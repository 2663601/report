/*
 *  WebrtcAecNlp - Pure C Port of Speex MDF NLP (Non-Linear Processor)
 *
 *  See webrtc_aec_nlp.h and spec design.md for full algorithm documentation.
 *  Ported from VQE/YS_SPEEX_AEC/mdf.c: ezviz_nonlinear_processing,
 *  ezviz_smoothed_psd, ezviz_overdrive_and_suppress.
 *
 *  Key adaptations from Speex 161-bin to Kalman 257-bin:
 *    - Smoothing coefficients: 0.84 / 0.16 (from Speex ptrGCoh)
 *    - sx floor: kMinFarendPSD = 40 (from Speex evz_kMinFarendPSD)
 *    - prefBand: [8, 55) = 47 bins covering 250~1687.5 Hz
 *    - weightCurve / overDriveCurve: closed-form resampled to 257 bins
 *    - NLP mode_idx = 1: kTargetSupp = -11.5, kNormalMinOverDrive = 2.0
 */

#include "webrtc_aec_nlp.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#include <io.h>
#define WEBRTC_AEC_ACCESS(p) _access((p), 0)
#else
#include <unistd.h>
#define WEBRTC_AEC_ACCESS(p) access((p), 0)
#endif

#ifndef M_PI_F
#define M_PI_F 3.14159265358979323846f
#endif

/* Speex NLP constants (mode_idx = 1, "normal" strength).
 * Speex original uses nlp_mode=2 with kTargetSupp=-18.4, min_overdrive=5.0
 * but that's for weak MDF linear filter. For PFDKF (strong linear filter),
 * we use mode_idx=0 (mild): kTargetSupp=-2.0, min_overdrive=1.0
 * This matches the Speex source: kTargetSupp[3] = { -2.f, -11.5f, -18.4f }
 * and kNormalMinOverDrive[3] = { 1.0f, 2.0f, 5.0f }
 */
static const float kTargetSupp         = -2.0f;   /* mode 0 = mild (Speex original) */
static const float kNormalMinOverDrive  =  1.0f;   /* mode 0 min overdrive */
static const float kMinFarendPSD       =  40.0f;

/* Smoothing coefficients from Speex ezviz_smoothed_psd (ptrGCoh) */
static const float kSmooth_old = 0.84f;
static const float kSmooth_new = 0.16f;

/* qsort comparator matching Speex CmpFloat */
static int SpeexCmpFloatAsc(const void* a, const void* b) {
    float fa = *(const float*)a;
    float fb = *(const float*)b;
    return (fa > fb) - (fa < fb);
}

/* ================================================================
 * WebrtcAecNlp_Init
 * ================================================================ */
void WebrtcAecNlp_Init(WebrtcAecNlpState* s) {
    int i;
    const int N = WEBRTC_AEC_BY2_PLUS1;  /* 257 */
    if (!s) return;
    memset(s, 0, sizeof(*s));

    /* Pre-compute Hann window (512 samples) */
    for (i = 0; i < WEBRTC_AEC_FFT_LEN; i++) {
        s->window[i] = 0.5f * (1.0f - cosf(2.0f * M_PI_F * (float)i /
                                           (float)(WEBRTC_AEC_FFT_LEN - 1)));
    }

    /* Pre-compute weightCurve (257 bins).
     * Speex formula: weightCurve[0]=0, weightCurve[i]=0.3*sqrt((i-1)/(N-2))+0.1
     * for i=1..N-1.  N_src=161, we use N=257 with same formula. */
    s->weightCurve[0] = 0.0f;
    for (i = 1; i < N; i++) {
        s->weightCurve[i] = 0.3f * sqrtf((float)(i - 1) / (float)(N - 2)) + 0.1f;
    }

    /* Pre-compute overDriveCurve (257 bins).
     * Speex formula: overDriveCurve[i] = sqrt(i/(N-1)) + 1.0, range [1.0, 2.0]
     * For PFDKF (strong linear filter), use sub-unity exponent (0.5~0.65) to
     * effectively take sqrt(hNl) instead of hNl, since cohde is naturally very
     * low (~0.1) after strong linear cancellation. This maps hNl=0.1 to G=0.32
     * instead of G=0.1, preserving more near-end signal. */
    for (i = 0; i < N; i++) {
        s->overDriveCurve[i] = 0.6f;  /* opt6: G = hNl^0.6, maps 0.1→0.25, 0.3→0.46 */
    }

    /* Initialize sd/se/sx to 1.0 to prevent numerical instability (Speex does same) */
    for (i = 0; i < N; i++) {
        s->sd[i] = 1.0f;
        s->sx[i] = 1.0f;
    }

    /* Speex default initial states */
    s->hNlFbLocalMin = 1.0f;
    s->hNlFbMin      = 1.0f;
    s->hNlXdAvgMin   = 1.0f;
    s->hNlNewMin     = 0;
    s->hNlMinCtr     = 0;
    s->overDrive     = kNormalMinOverDrive;
    s->overDriveSm   = kNormalMinOverDrive;
    s->stNearState   = 0;
    s->echoState     = 0;

    s->initialized    = 1;
    s->dump_frame_idx = 0;
    s->dump_fp        = NULL;
}

/* ================================================================
 * WebrtcAecNlp_Reset
 * ================================================================ */
void WebrtcAecNlp_Reset(WebrtcAecNlpState* s) {
    if (!s) return;
    void* fp = s->dump_fp;
    long long idx = s->dump_frame_idx;
    WebrtcAecNlp_Init(s);
    s->dump_fp = fp;
    s->dump_frame_idx = idx;
}

/* ================================================================
 * WebrtcAecNlp_Process — Full implementation (Wave 3, Steps A-J)
 * ================================================================ */
void WebrtcAecNlp_Process(
    WebrtcAecNlpState* s,
    const Aec3Fft* fft,
    const FftDataPfdkf* X_long,
    const FftDataPfdkf* Y_long,
    const FftDataPfdkf* E_long,
    const float* e_time,
    const float* d_time,
    float* G_long) {

    int i, k;
    FftDataPfdkf Dfw, Efw;
    float cohde[WEBRTC_AEC_BY2_PLUS1];
    float cohxd[WEBRTC_AEC_BY2_PLUS1];
    float hNl[WEBRTC_AEC_BY2_PLUS1];
    float hNlDeAvg, hNlXdAvg;
    float hNlFb, hNlFbLow;
    float hNlPref[WEBRTC_AEC_PREFBAND_SIZE];

    (void)Y_long;  /* reserved for future use */

    if (!s || !G_long) return;
    if (!s->initialized) WebrtcAecNlp_Init(s);

    /* ============================================================
     * Step A: Time-domain buffer update (shift + write)
     * dBuf/eBuf are 512 samples: [old 256 | new 256]
     * ============================================================ */
    memmove(s->dBuf, s->dBuf + WEBRTC_AEC_BY2, sizeof(float) * WEBRTC_AEC_BY2);
    memcpy(s->dBuf + WEBRTC_AEC_BY2, d_time, sizeof(float) * WEBRTC_AEC_BY2);

    memmove(s->eBuf, s->eBuf + WEBRTC_AEC_BY2, sizeof(float) * WEBRTC_AEC_BY2);
    memcpy(s->eBuf + WEBRTC_AEC_BY2, e_time, sizeof(float) * WEBRTC_AEC_BY2);

    /* ============================================================
     * Step B: Windowed FFT → Dfw (mic), Efw (error)
     * Xfw reuses X_long directly (already PaddedFft512'd in EchoRemover)
     * ============================================================ */
    for (i = 0; i < WEBRTC_AEC_FFT_LEN; i++) {
        s->dwBuf[i] = s->window[i] * s->dBuf[i];
        s->ewBuf[i] = s->window[i] * s->eBuf[i];
    }
    Aec3Fft_Fft512_typed(fft, s->dwBuf, &Dfw);
    Aec3Fft_Fft512_typed(fft, s->ewBuf, &Efw);

    /* ============================================================
     * Step C: Smoothed power spectra and cross-spectra
     * Coefficients: 0.84 / 0.16 (from Speex ptrGCoh)
     * sxd = d · conj(x) (matches Speex original)
     * ============================================================ */
    for (k = 0; k < WEBRTC_AEC_BY2_PLUS1; k++) {
        float dre = Dfw.relf[k], dim = Dfw.imlf[k];
        float ere = Efw.relf[k], eim = Efw.imlf[k];
        float xre = X_long->relf[k], xim = X_long->imlf[k];
        float x_pow = xre * xre + xim * xim;

        s->sd[k] = kSmooth_old * s->sd[k] + kSmooth_new * (dre * dre + dim * dim);
        s->se[k] = kSmooth_old * s->se[k] + kSmooth_new * (ere * ere + eim * eim);
        s->sx[k] = kSmooth_old * s->sx[k] + kSmooth_new * (x_pow > kMinFarendPSD ? x_pow : kMinFarendPSD);

        /* sde = d · conj(e) */
        s->sde[k][0] = kSmooth_old * s->sde[k][0] + kSmooth_new * (dre * ere + dim * eim);
        s->sde[k][1] = kSmooth_old * s->sde[k][1] + kSmooth_new * (dim * ere - dre * eim);

        /* sxd = d · conj(x) (Speex: dfw[0][i]*xfw[0][i] + dfw[1][i]*xfw[1][i]) */
        s->sxd[k][0] = kSmooth_old * s->sxd[k][0] + kSmooth_new * (dre * xre + dim * xim);
        s->sxd[k][1] = kSmooth_old * s->sxd[k][1] + kSmooth_new * (dim * xre - dre * xim);
    }

    /* ============================================================
     * Step D: Subband coherence
     * cohde = |sde|² / (sd · se)
     * cohxd = |sxd|² / (sx · sd)
     * ============================================================ */
    {
        /* Compute sdSum/seSum for dtState (Speex ezviz_smoothed_psd) */
        float sdSum = 0.0f, seSum = 0.0f;
        for (k = 0; k < WEBRTC_AEC_BY2_PLUS1; k++) {
            sdSum += s->sd[k];
            seSum += s->se[k];
        }

        /* Divergent filter safeguard (Speex: divergeState ? 1.05 : 1.0) * seSum > sdSum */
        s->divergeState = ((s->divergeState ? 1.05f : 1.0f) * seSum > sdSum) ? 1 : 0;

        /* Double/Single talk check (Speex thresholds: ST=10, DT=1.0) */
        s->dtState = 0;
        if (sdSum > 10.0f * seSum) {
            /* Single-talk (far-end only): filter working well */
            s->convergeState = 1;
        } else if (sdSum < 1.0f * seSum && !s->divergeState && s->convergeState) {
            /* Double-talk: near-end present */
            s->dtState = 1;
        }
    }

    for (k = 0; k < WEBRTC_AEC_BY2_PLUS1; k++) {
        float num_de = s->sde[k][0] * s->sde[k][0] + s->sde[k][1] * s->sde[k][1];
        cohde[k] = num_de / (s->sd[k] * s->se[k] + 1e-10f);

        float num_xd = s->sxd[k][0] * s->sxd[k][0] + s->sxd[k][1] * s->sxd[k][1];
        cohxd[k] = num_xd / (s->sx[k] * s->sd[k] + 1e-10f);
    }

    /* ============================================================
     * Step E: prefBand averages
     * ============================================================ */
    hNlDeAvg = 0.0f;
    hNlXdAvg = 0.0f;
    for (k = WEBRTC_AEC_MIN_PREFBAND; k < WEBRTC_AEC_MIN_PREFBAND + WEBRTC_AEC_PREFBAND_SIZE; k++) {
        hNlDeAvg += cohde[k];
        hNlXdAvg += cohxd[k];
    }
    hNlDeAvg /= (float)WEBRTC_AEC_PREFBAND_SIZE;
    hNlXdAvg /= (float)WEBRTC_AEC_PREFBAND_SIZE;
    hNlXdAvg = 1.0f - hNlXdAvg;

    /* ============================================================
     * Step F: Minimum tracking (hNlXdAvgMin)
     * ============================================================ */
    if ((hNlXdAvg < 0.75f || hNlDeAvg < 0.95f) && hNlXdAvg < s->hNlXdAvgMin) {
        s->hNlXdAvgMin = hNlXdAvg;
    }

    /* ============================================================
     * Step G: stNearState state machine
     * (Kept for logging/diagnostics but not used in gain calculation
     *  for opt6 configuration — flat overDriveCurve=0.6 for all frames)
     * ============================================================ */
    {
        s->hNlXdAvgLong = 0.995f * s->hNlXdAvgLong + 0.005f * hNlXdAvg;
        float xd_elevation = hNlXdAvg - s->hNlXdAvgLong;
        if (xd_elevation > 0.15f) {
            s->stNearState = 1;
        } else if (xd_elevation < 0.05f) {
            s->stNearState = 0;
        }
    }

    /* ============================================================
     * Step H: hNl construction + hNlFb order statistic
     * 4 branches: (hNlXdAvgMin==1) × (stNearState∈{0,1})
     *             (hNlXdAvgMin<1)  × (stNearState∈{0,1})
     * ============================================================ */
    if (s->hNlXdAvgMin == 1.0f) {
        s->echoState = 0;
        s->overDrive = kNormalMinOverDrive;
        if (s->stNearState == 1) {
            memcpy(hNl, cohde, sizeof(float) * WEBRTC_AEC_BY2_PLUS1);
            hNlFb = hNlDeAvg;
            hNlFbLow = hNlDeAvg;
        } else {
            for (k = 0; k < WEBRTC_AEC_BY2_PLUS1; k++) {
                hNl[k] = 1.0f - cohxd[k];
                if (hNl[k] < 0.0f) hNl[k] = 0.0f;
            }
            hNlFb = hNlXdAvg;
            hNlFbLow = hNlXdAvg;
        }
    } else {
        if (s->stNearState == 1) {
            s->echoState = 0;
            memcpy(hNl, cohde, sizeof(float) * WEBRTC_AEC_BY2_PLUS1);
            hNlFb = hNlDeAvg;
            hNlFbLow = hNlDeAvg;
        } else {
            s->echoState = 1;
            for (k = 0; k < WEBRTC_AEC_BY2_PLUS1; k++) {
                float a = cohde[k];
                float b = 1.0f - cohxd[k];
                hNl[k] = a < b ? a : b;
                if (hNl[k] < 0.0f) hNl[k] = 0.0f;
            }
            /* Order statistic on prefBand */
            memcpy(hNlPref, &hNl[WEBRTC_AEC_MIN_PREFBAND],
                   sizeof(float) * WEBRTC_AEC_PREFBAND_SIZE);
            qsort(hNlPref, WEBRTC_AEC_PREFBAND_SIZE, sizeof(float), SpeexCmpFloatAsc);
            hNlFb    = hNlPref[WEBRTC_AEC_HNLFB_IDX];
            hNlFbLow = hNlPref[WEBRTC_AEC_HNLFB_LOW_IDX];
        }
    }

    /* ============================================================
     * Step I: hNlFbLocalMin tracking + overdrive adaptation
     * ============================================================ */
    if (hNlFbLow < 0.6f && hNlFbLow < s->hNlFbLocalMin) {
        s->hNlFbLocalMin = hNlFbLow;
        s->hNlFbMin = hNlFbLow;
        s->hNlNewMin = 1;
        s->hNlMinCtr = 0;
    }
    /* Slow rise of local min (Speex: +0.0008/2 per frame) */
    s->hNlFbLocalMin += 0.0004f;
    if (s->hNlFbLocalMin > 1.0f) s->hNlFbLocalMin = 1.0f;
    s->hNlXdAvgMin += 0.0003f;
    if (s->hNlXdAvgMin > 1.0f) s->hNlXdAvgMin = 1.0f;

    if (s->hNlNewMin == 1) {
        s->hNlMinCtr++;
    }
    if (s->hNlMinCtr == 2) {
        s->hNlNewMin = 0;
        s->hNlMinCtr = 0;
        /* Compute overdrive from target suppression and hNlFbMin */
        float od = kTargetSupp / (logf(s->hNlFbMin + 1e-10f) + 1e-10f);
        if (od < kNormalMinOverDrive) od = kNormalMinOverDrive;
        s->overDrive = od;
    }

    /* Asymmetric IIR smoothing of overdrive (Speex: 0.99 fall / 0.9 rise) */
    if (s->overDrive < s->overDriveSm) {
        s->overDriveSm = 0.99f * s->overDriveSm + 0.01f * s->overDrive;
    } else {
        s->overDriveSm = 0.9f * s->overDriveSm + 0.1f * s->overDrive;
    }

    /* ============================================================
     * Step J: Apply overdrive to hNl → G_long
     * Continuous near-end modulation (no binary switching):
     *   base_exponent = 0.6 (opt6 baseline)
     *   ne_prob from hNlXdAvg elevation → modulate exponent down
     *   effective_exp = base * (1 - 0.5 * ne_prob)
     *   Range: [0.6, 0.3] depending on near-end probability
     *
     * This avoids the FPR problem of binary stNearState in high reverb:
     * even with moderate ne_prob (0.3-0.5 in high reverb noise), the
     * exponent only drops to 0.6*(1-0.5*0.4)=0.48, not catastrophically.
     * ============================================================ */
    {
        /* Compute continuous near-end probability from hNlXdAvg elevation */
        float xd_elevation = hNlXdAvg - s->hNlXdAvgLong;
        float ne_prob = (xd_elevation - 0.10f) / 0.30f;  /* [0.10, 0.40] → [0, 1] */
        if (ne_prob < 0.0f) ne_prob = 0.0f;
        if (ne_prob > 1.0f) ne_prob = 1.0f;

        /* Modulate exponent: 0.6 (echo) → 0.36 (strong near-end) */
        float eff_exp = 0.6f * (1.0f - 0.4f * ne_prob);

        for (k = 0; k < WEBRTC_AEC_BY2_PLUS1; k++) {
            float h = hNl[k];
            /* Weight subbands: if hNl > hNlFb, blend toward hNlFb */
            if (h > hNlFb) {
                h = s->weightCurve[k] * hNlFb + (1.0f - s->weightCurve[k]) * h;
            }
            /* Apply modulated exponent */
            float g = powf(h, eff_exp * s->overDriveSm);
            /* Clamp to [0, 1] */
            if (g < 0.0f) g = 0.0f;
            if (g > 1.0f) g = 1.0f;
            G_long[k] = g;
        }
    }

    /* ============================================================
     * Diagnostic dump (enable_vqe_dump gated)
     * ============================================================ */
    if (WEBRTC_AEC_ACCESS("enable_vqe_dump") == 0) {
        if (!s->dump_fp) {
            s->dump_fp = (void*)fopen("webrtc_aec_nlp.log", "w");
            if (s->dump_fp) {
                fprintf((FILE*)s->dump_fp,
                    "frame stNear echoState hNlDeAvg hNlXdAvg hNlFb "
                    "hNlFbMin overDrive overDriveSm\n");
            }
        }
        if (s->dump_fp) {
            fprintf((FILE*)s->dump_fp,
                "%lld %d %d %.4f %.4f %.4f %.4f %.4f %.4f\n",
                s->dump_frame_idx,
                s->stNearState, s->echoState,
                hNlDeAvg, hNlXdAvg, hNlFb,
                s->hNlFbMin, s->overDrive, s->overDriveSm);
        }
    }

    s->dump_frame_idx++;
}
