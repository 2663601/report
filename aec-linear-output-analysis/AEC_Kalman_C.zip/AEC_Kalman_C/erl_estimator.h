/*
 *  ErlEstimator - Pure C Version
 *
 *  Estimates the Echo Return Loss (ERL) based on signal spectra.
 *  Ported from WebRTC AEC3 C++ ErlEstimator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef ERL_ESTIMATOR_H_
#define ERL_ESTIMATOR_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * ErlEstimator
 *
 * Estimates the echo return loss per frequency bin using a
 * maximum-statistics approach. Also computes a broadband
 * time-domain ERL estimate.
 * ================================================================ */
typedef struct {
    int     startup_phase_length_blocks;
    float   erl[AEC3_FFT_LENGTH_BY2_PLUS1];
    int     hold_counters[AEC3_FFT_LENGTH_BY2_MINUS1];
    float   erl_time_domain;
    int     hold_counter_time_domain;
    int     blocks_since_reset;
} ErlEstimator;

/**
 * Initialize the ERL estimator.
 *
 * @param self                          Pointer to estimator
 * @param startup_phase_length_blocks   Number of blocks to skip at startup
 */
void ErlEstimator_Init(ErlEstimator* self, int startup_phase_length_blocks);

/**
 * Reset the ERL estimation (blocks_since_reset counter).
 */
void ErlEstimator_Reset(ErlEstimator* self);

/**
 * Update the ERL estimate with new spectral data.
 *
 * @param self              Pointer to estimator
 * @param converged_filter  Whether the adaptive filter has converged
 * @param render_spectrum   Render power spectrum (65 floats)
 * @param capture_spectrum  Capture power spectrum (65 floats)
 * @param use_erl_update    If true, skip update (external ERL used)
 */
void ErlEstimator_Update(ErlEstimator* self,
                         int converged_filter,
                         const float* render_spectrum,
                         const float* capture_spectrum,
                         int use_erl_update);

/**
 * Get the per-bin ERL estimate.
 */
const float* ErlEstimator_Erl(const ErlEstimator* self);

/**
 * Get the broadband time-domain ERL estimate.
 */
float ErlEstimator_ErlTimeDomain(const ErlEstimator* self);

#ifdef __cplusplus
}
#endif

#endif /* ERL_ESTIMATOR_H_ */
