/*
 *  ReverbDecayEstimator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ReverbDecayEstimator class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "reverb_decay_estimator.h"
#include <string.h>
#include <math.h>

static const int kEarlyReverbMinSizeBlocks = 3;

static float FastApproxLog2f(float x) {
    /* Simple log2 approximation */
    if (x <= 0.0f) return -30.0f;
    return (float)(log(x) / log(2.0));
}

static void LateReverbLinearRegressor_Reset(LateReverbLinearRegressor* self,
                                            int num_data_points) {
    self->nz = 0.0f;
    /* nn = N*(N*N-1)/12 */
    self->nn = (float)num_data_points *
               ((float)num_data_points * (float)num_data_points - 1.0f) / 12.0f;
    self->count = (num_data_points > 0) ?
                  -(float)num_data_points * 0.5f + 0.5f : 0.0f;
    self->N = num_data_points;
    self->n = 0;
}

static void LateReverbLinearRegressor_Accumulate(
    LateReverbLinearRegressor* self, float z) {
    self->nz += self->count * z;
    self->count += 1.0f;
    self->n++;
}

static int LateReverbLinearRegressor_EstimateAvailable(
    const LateReverbLinearRegressor* self) {
    return (self->n == self->N && self->N != 0);
}

static float LateReverbLinearRegressor_Estimate(
    LateReverbLinearRegressor* self) {
    if (self->nn == 0.0f) return 0.0f;
    return self->nz / self->nn;
}

static void EarlyReverbLengthEstimator_Init(EarlyReverbLengthEstimator* self,
                                            int max_blocks) {
    int max_sec = max_blocks - 6;  /* kBlocksPerSection = 6 */
    if (max_sec < 0) max_sec = 0;
    if (max_sec > EARLY_REVERB_MAX_SECTIONS) max_sec = EARLY_REVERB_MAX_SECTIONS;
    self->max_sections = max_sec;
    memset(self->numerators_smooth, 0, sizeof(float) * max_sec);
    memset(self->numerators, 0, sizeof(float) * max_sec);
    self->coefficients_counter = 0;
    self->block_counter = 0;
    self->n_sections = 0;
}

static void EarlyReverbLengthEstimator_Reset(EarlyReverbLengthEstimator* self) {
    self->coefficients_counter = 0;
    memset(self->numerators, 0, sizeof(float) * self->max_sections);
    self->block_counter = 0;
}

static int EarlyReverbLengthEstimator_Estimate(EarlyReverbLengthEstimator* self) {
    /* Simplified: return 0 (no early reverb detected) */
    (void)self;
    return 0;
}

static void ReverbDecayEstimator_ResetDecayEstimation(ReverbDecayEstimator* self) {
    EarlyReverbLengthEstimator_Reset(&self->early_reverb_estimator);
    LateReverbLinearRegressor_Reset(&self->late_reverb_estimator, 0);
    self->block_to_analyze = 0;
    self->estimation_region_candidate_size = 0;
    self->estimation_region_identified = 0;
    self->smoothing_constant = 0.0f;
    self->late_reverb_start = 0;
    self->late_reverb_end = 0;
}

void ReverbDecayEstimator_Init(ReverbDecayEstimator* self,
                               const Aec3Config* config) {
    memset(self, 0, sizeof(ReverbDecayEstimator));
    self->filter_length_blocks = config->filter_main_length_blocks;
    self->filter_length_coefficients =
        self->filter_length_blocks * AEC3_FFT_LENGTH_BY2;
    self->use_adaptive_echo_decay = (config->ep_strength_default_len < 0.0f);
    self->decay = fabsf(config->ep_strength_default_len);
    self->late_reverb_start = kEarlyReverbMinSizeBlocks;
    self->late_reverb_end = kEarlyReverbMinSizeBlocks;

    /* Adaptive convergence: two-phase smoothing rate */
    self->update_counter = 0;
    self->smoothing_rate_fast = 0.15f;
    self->smoothing_rate_slow = 0.05f;
    self->fast_convergence_blocks = config->reverb_fast_convergence_blocks;

    /* Mild decay */
    self->mild_decay_factor = 0.7f;
    self->mild_decay = self->decay * self->mild_decay_factor;

    EarlyReverbLengthEstimator_Init(&self->early_reverb_estimator,
                                    config->filter_main_length_blocks -
                                    kEarlyReverbMinSizeBlocks);
    memset(self->previous_gains, 0, sizeof(self->previous_gains));
}

void ReverbDecayEstimator_Update(ReverbDecayEstimator* self,
                                 const float* filter,
                                 int filter_len,
                                 float filter_quality,
                                 int has_filter_quality,
                                 int filter_delay_blocks,
                                 int usable_linear_filter,
                                 int stationary_signal) {
    int estimation_feasible;

    if (stationary_signal) return;

    estimation_feasible =
        (filter_delay_blocks <=
         self->filter_length_blocks - kEarlyReverbMinSizeBlocks - 1);
    estimation_feasible = estimation_feasible &&
        (filter_len == self->filter_length_coefficients);
    estimation_feasible = estimation_feasible && (filter_delay_blocks > 0);
    estimation_feasible = estimation_feasible && usable_linear_filter;

    if (!estimation_feasible) {
        ReverbDecayEstimator_ResetDecayEstimation(self);
        return;
    }

    if (!self->use_adaptive_echo_decay) return;

    /* Update smoothing constant from filter quality */
    if (has_filter_quality) {
        float new_smoothing = filter_quality * 0.2f;
        if (new_smoothing > self->smoothing_constant) {
            self->smoothing_constant = new_smoothing;
        }
    }
    if (self->smoothing_constant == 0.0f) return;

    /* Simplified: analyze filter blocks and estimate decay */
    if (self->block_to_analyze < self->filter_length_blocks) {
        self->block_to_analyze++;
    } else {
        /* Estimate decay from late reverb region */
        int peak_block = filter_delay_blocks;
        int start_block = peak_block + kEarlyReverbMinSizeBlocks;
        int end_block = self->filter_length_blocks - 1;

        if (end_block > start_block + 5) {
            /* Simple energy ratio decay estimation */
            float start_energy = 0.0f, end_energy = 0.0f;
            int k, start_idx, end_idx;

            start_idx = start_block * AEC3_FFT_LENGTH_BY2;
            end_idx = end_block * AEC3_FFT_LENGTH_BY2;

            for (k = 0; k < AEC3_FFT_LENGTH_BY2 && start_idx + k < filter_len; k++) {
                start_energy += filter[start_idx + k] * filter[start_idx + k];
            }
            for (k = 0; k < AEC3_FFT_LENGTH_BY2 && end_idx + k < filter_len; k++) {
                end_energy += filter[end_idx + k] * filter[end_idx + k];
            }

            start_energy /= AEC3_FFT_LENGTH_BY2;
            end_energy /= AEC3_FFT_LENGTH_BY2;

            if (start_energy > 4.0f * end_energy && start_energy > 1e-10f) {
                int num_blocks = end_block - start_block;
                float ratio = end_energy / (start_energy + 1e-10f);
                float new_decay;
                if (ratio > 0.0f && num_blocks > 0) {
                    new_decay = powf(ratio, 1.0f / (float)num_blocks);
                } else {
                    new_decay = self->decay;
                }
                if (new_decay > 0.95f) new_decay = 0.95f;
                if (new_decay < 0.02f) new_decay = 0.02f;
                new_decay = 0.97f * self->decay > new_decay ?
                            0.97f * self->decay : new_decay;
                self->decay += self->smoothing_constant * (new_decay - self->decay);
            }
        }

        self->block_to_analyze = start_block < self->filter_length_blocks ?
                                 start_block : self->filter_length_blocks;
        self->smoothing_constant = 0.0f;
    }
}

float ReverbDecayEstimator_Decay(const ReverbDecayEstimator* self) {
    return self->decay;
}
