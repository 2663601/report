/*
 *  Render Delay Controller - Pure C Version
 *
 *  Aligns the render and capture signals using delay estimation
 *  and buffer delay management. Coordinates the EchoPathDelayEstimator
 *  with hysteresis-based delay smoothing.
 *
 *  Based on WebRTC AEC3 RenderDelayControllerImpl2.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef RENDER_DELAY_CONTROLLER_H_
#define RENDER_DELAY_CONTROLLER_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "echo_path_delay_estimator.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * RenderDelayController - Main delay controller
 *
 * Manages delay estimation and buffer delay computation with
 * hysteresis to avoid frequent delay changes.
 * Based on RenderDelayControllerImpl2 (no skew/delay_buf).
 * ================================================================ */
typedef struct {
    int     delay_headroom_blocks;
    int     hysteresis_limit_1_blocks;
    int     hysteresis_limit_2_blocks;

    EchoPathDelayEstimator  delay_estimator;

    /* Current delay state */
    DelayEstimate   delay;
    int             has_delay;

    DelayEstimate   delay_samples;
    int             has_delay_samples;

    int             capture_call_counter;
    int             delay_change_counter;
    int             last_delay_estimate_quality;  /* 0=kCoarse, 1=kRefined */
} RenderDelayController;

/**
 * Compute the memory size needed for delay controller dynamic arrays.
 *
 * @param render_buffer_size    Ring buffer slot count
 * @return                      Required bytes
 */
int RenderDelayController_GetDynMemSize(int render_buffer_size);

/**
 * Initialize the render delay controller.
 *
 * @param self              Pointer to controller
 * @param config            AEC3 configuration
 * @param non_causal_offset Non-causal offset in blocks
 * @param sample_rate_hz    Sample rate
 * @param render_buffer_size Ring buffer slot count
 * @param binary_dyn_mem    Pre-allocated memory for binary estimator
 */
void RenderDelayController_Init(RenderDelayController* self,
                                const Aec3Config* config,
                                int non_causal_offset,
                                int sample_rate_hz,
                                int render_buffer_size,
                                float* binary_dyn_mem);

/**
 * Reset the controller.
 *
 * @param self                      Pointer to controller
 * @param reset_delay_confidence    If true, fully reset delay confidence
 */
void RenderDelayController_Reset(RenderDelayController* self,
                                 int reset_delay_confidence);

/**
 * Log a render call for skew estimation.
 */
void RenderDelayController_LogRenderCall(RenderDelayController* self);

/**
 * Get the delay estimate and compute buffer delay.
 *
 * @param self                          Pointer to controller
 * @param render_buffer                 Downsampled render buffer
 * @param render_delay_buffer_delay     Current render delay buffer delay
 * @param echo_remover_delay            Echo remover delay (-1 if none)
 * @param has_echo_remover_delay        Whether echo_remover_delay is valid
 * @param capture                       Capture block
 * @param capture_len                   Capture length
 * @param earphone_flag                 Earphone mode
 * @param voip_mode_enable              VoIP mode
 * @param delay_default                 Default delay
 * @param CastScreen                    Screen casting mode
 * @param matched_filter_enable_flag    Enable matched filter
 * @param aec_low_compute_mode          Low compute mode
 * @param out_delay                     Output: buffer delay estimate
 * @return                              1 if valid delay, 0 otherwise
 */
int RenderDelayController_GetDelay(
    RenderDelayController* self,
    const DownsampledRenderBuffer* render_buffer,
    int render_delay_buffer_delay,
    int echo_remover_delay,
    int has_echo_remover_delay,
    const float* capture, int capture_len,
    int earphone_flag,
    int voip_mode_enable,
    int delay_default,
    int CastScreen,
    int matched_filter_enable_flag,
    int aec_low_compute_mode,
    DelayEstimate* out_delay);

/**
 * Check if clockdrift has been detected.
 */
int RenderDelayController_HasClockdrift(const RenderDelayController* self);

/**
 * Buffer render spectrum for delay estimation.
 */
void RenderDelayController_BufferRenderSpec(RenderDelayController* self,
                                            const float* far_spectrum,
                                            int spectrum_len);

/**
 * Buffer render block for delay estimation.
 */
void RenderDelayController_BufferRenderBlock(RenderDelayController* self,
                                             const float* far_block,
                                             int block_len);

/**
 * Set aec_H_usage parameter.
 */
void RenderDelayController_SetAecHUsage(RenderDelayController* self,
                                        int size);

#ifdef __cplusplus
}
#endif

#endif /* RENDER_DELAY_CONTROLLER_H_ */
