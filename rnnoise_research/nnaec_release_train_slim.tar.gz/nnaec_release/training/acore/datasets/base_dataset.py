import torch
import random
from joblib import Parallel, delayed
from training.acore.acoustics.feature import load_wav
from tqdm import tqdm

class BaseDataset(torch.utils.data.Dataset):
    def __init__(self):
        super().__init__()

    @staticmethod
    def _offset_and_limit(dataset_list, offset, limit):
        dataset_list = dataset_list[offset:]
        if limit:
            dataset_list = dataset_list[:limit]
        return dataset_list

    @staticmethod
    def _random_select_from(dataset_list):
        return random.choice(dataset_list)

    @staticmethod
    def _preload_dataset(file_path_list, num_workers=12, remark=""):
        waveform_list = Parallel(n_jobs=num_workers)(
            delayed(load_wav)(f_path) for f_path in tqdm(file_path_list, desc=remark)
        )
        return list(zip(file_path_list, waveform_list))
