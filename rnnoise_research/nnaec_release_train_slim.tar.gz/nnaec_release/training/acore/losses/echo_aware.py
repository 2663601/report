import sys
import torch
import torch as th
import torch.nn as nn
import torch.nn.functional as tnf

sys.path.append("../../..")
import acore.acoustics.windows as windows

EPS = 1e-13


# noise aware loss
def mse(est, target):
    return tnf.mse_loss(est, target)


def mae(est, target):
    return tnf.l1_loss(est, target)


def compress_magphase(real, imag, alpha):
    compressed_mags = th.pow(real ** 2 + imag ** 2 + 1e-8, alpha * 0.5)
    phase = th.atan2(imag, real + 1e-8)
    real = compressed_mags * th.cos(phase)
    imag = compressed_mags * th.sin(phase)
    compressed_cspec = th.cat([real, imag], dim=1)
    return compressed_mags, compressed_cspec


def echo_weight(r_t, i_t, r_e, i_e):
    r_t_s = th.square(r_t)
    i_t_s = th.square(i_t)
    r_e_s = th.square(r_e)
    i_e_s = th.square(i_e)
    mag_s_2 = r_t_s + i_t_s
    mag_f_2 = r_e_s + i_e_s
    mag_weight = th.divide(mag_f_2, mag_f_2 + mag_s_2 + 1e-8) + 1
    return mag_weight


class nwloss(nn.Module):
    ''' noise aware loss.'''

    def __init__(self, nfft=512, window_size=512, hop_length=256, **kwargs):
        super().__init__()
        self.nfft, self.window_size, self.hop_length = nfft, window_size, hop_length
        self.window_func = kwargs["window"]
        self.beta = kwargs["beta"]

    def stft(self, x):
        x_stft = torch.stft(x, n_fft=self.nfft, hop_length=self.hop_length, center=False,
                            win_length=self.window_size, window=self.window_func.to(x.device), return_complex=True)
        return x_stft.real, x_stft.imag

    def forward(self, est, label, echo_s):
        """
         est: shape Batch x 2F x T.
         label, echo_s: Batch x Nsamples.
         echo_s:
         """
        if (echo_s.shape != label.shape) or (est.shape != label.shape):
            raise RuntimeError(
                f"Dimension mismatch when calculate loss, {est.shape} vs {label.shape} vs {echo_s.shape}")
        real_est, imag_est = self.stft(est)
        # real_est, imag_est = th.chunk(est, 2, dim=1)

        com_mags_est, com_cspec_est = compress_magphase(real_est, imag_est, 0.5)
        real_t, imag_t = self.stft(label)
        real_e, imag_e = self.stft(echo_s)
        # Reomve DC or not, You may uncomment this...
        # real_t[:, 0, :] = 0.0
        # imag_t[:, 0, :] = 0.0
        # real_e[:, 0, :] = 0.0
        # imag_e[:, 0, :] = 0.0
        com_mags_t, com_cspec_t = compress_magphase(real_t, imag_t, 0.5)
        mag_weight = echo_weight(real_t, imag_t, real_e, imag_e)
        loss_amp = th.mean(th.square(com_mags_est - com_mags_t) * mag_weight)
        loss_pha = mse(com_cspec_est, com_cspec_t)
        return (loss_amp + loss_pha) * self.beta


class nwloss_mae(nn.Module):
    ''' noise aware loss.'''

    def __init__(self, nfft=512, window_size=512, hop_length=256, **kwargs):
        super(nwloss_mae, self).__init__()
        self.nfft, self.window_size, self.hop_length = nfft, window_size, hop_length
        self.window_func = kwargs["window"]
        self.beta = kwargs["beta"]

    def stft(self, x):
        x_stft = torch.stft(x, n_fft=self.nfft, hop_length=self.hop_length, center=False,
                            win_length=self.window_size, window=self.window_func.to(x.device), return_complex=True)
        return x_stft.real, x_stft.imag

    def forward(self, est, label, echo_s):
        """
         est: shape Batch x 2F x T.
         label, echo_s: Batch x Nsamples.
         echo_s:
         """
        if (echo_s.shape != label.shape) or (est.shape != label.shape):
            raise RuntimeError(
                f"Dimension mismatch when calculate loss, {est.shape} vs {label.shape} vs {echo_s.shape}")
        real_est, imag_est = self.stft(est)
        # real_est, imag_est = th.chunk(est, 2, dim=1)

        com_mags_est, com_cspec_est = compress_magphase(real_est, imag_est, 0.5)
        real_t, imag_t = self.stft(label)
        real_e, imag_e = self.stft(echo_s)

        com_mags_t, com_cspec_t = compress_magphase(real_t, imag_t, 0.5)
        mag_weight = echo_weight(real_t, imag_t, real_e, imag_e)
        loss_amp = th.mean(th.abs(com_mags_est - com_mags_t) * mag_weight)
        loss_pha = mae(com_cspec_est, com_cspec_t)
        return (loss_amp + loss_pha) * self.beta

if __name__ == '__main__':
    window_size = 512
    winfunc = torch.ones(window_size)
    # loss_func =  nwloss(nfft=window_size, window_size=window_size, hop_length=window_size // 2, window=winfunc,
    #                      beta=100)
    loss_func = nwloss_mae(nfft=window_size, window_size=window_size, hop_length=window_size // 2, window=winfunc,
                                 beta=200)
    # est= torch.randn(2, 257*2, 100)
    ests = torch.randn(1, 32000)
    label = torch.randn(1, 32000)
    noise = torch.randn(1, 32000)
    # x_stft = torch.stft(ests, n_fft=window_size, hop_length=window_size//2, center=False,
    #                     win_length=window_size, window=winfunc.to(ests.device), return_complex=True)
    # print(x_stft.shape)
    loss = loss_func(ests, label, noise)
    print(loss)
