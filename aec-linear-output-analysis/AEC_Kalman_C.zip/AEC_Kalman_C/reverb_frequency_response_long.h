/*
 *  ReverbFrequencyResponseLong - Pure C Version
 *
 *  257-bin reverb frequency response estimator for 512-point FFT path.
 *  Extracts per-frequency reverb tail gain from PFDKF H2 partitions.
 *
 *  Based on the 65-bin ReverbFrequencyResponse pattern,
 *  adapted for the 512-point PFDKF path (257 bins).
 */

#ifndef REVERB_FREQUENCY_RESPONSE_LONG_H_
#define REVERB_FREQUENCY_RESPONSE_LONG_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float   tail_response_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];  /* 257 floats */
    float   average_decay_long;
    int     update_counter;
} ReverbFrequencyResponseLong;

/**
 * Initialize the long reverb frequency response estimator.
 */
void ReverbFrequencyResponseLong_Init(ReverbFrequencyResponseLong* self);

/**
 * Update the frequency response estimate from PFDKF H2 partitions.
 *
 * @param self                      Pointer to estimator
 * @param H2_pf_update              Flat array [partition * 257 + bin]
 * @param num_partitions            Number of partitions
 * @param filter_delay_blocks       Filter delay in blocks
 * @param linear_filter_quality     Quality estimate
 * @param has_quality               Whether quality is valid
 * @param stationary_block          Whether current block is stationary
 */
void ReverbFrequencyResponseLong_Update(
    ReverbFrequencyResponseLong* self,
    const float* H2_pf_update,
    int num_partitions,
    int filter_delay_blocks,
    float linear_filter_quality,
    int has_quality,
    int stationary_block);

/**
 * Get the estimated reverb frequency response (257 floats).
 */
const float* ReverbFrequencyResponseLong_GetResponse(
    const ReverbFrequencyResponseLong* self);

#ifdef __cplusplus
}
#endif

#endif /* REVERB_FREQUENCY_RESPONSE_LONG_H_ */
