/*
 *  ReverbFrequencyResponseLong - Pure C Version
 *
 *  257-bin reverb frequency response estimator for 512-point FFT path.
 *  Extracts per-frequency reverb tail gain from PFDKF H2 partitions.
 *
 *  Based on the 65-bin ReverbFrequencyResponse pattern,
 *  adapted for the 512-point PFDKF path (257 bins).
 */

#include "reverb_frequency_response_long.h"
#include <string.h>

void ReverbFrequencyResponseLong_Init(ReverbFrequencyResponseLong* self) {
    memset(self->tail_response_long, 0, sizeof(self->tail_response_long));
    self->average_decay_long = 0.0f;
    self->update_counter = 0;
}

void ReverbFrequencyResponseLong_Update(
    ReverbFrequencyResponseLong* self,
    const float* H2_pf_update,
    int num_partitions,
    int filter_delay_blocks,
    float linear_filter_quality,
    int has_quality,
    int stationary_block) {

    int k, direct_part, tail_start, p;
    float direct_energy, tail_energy, average_decay_new, smoothing;
    int tail_count;

    /* Gate check: skip if stationary or no quality */
    if (stationary_block || !has_quality) return;

    /* Need at least 3 partitions for meaningful estimation */
    if (num_partitions < 3) return;

    /* Compute partition indices */
    direct_part = filter_delay_blocks;
    if (direct_part < 0) direct_part = 0;
    if (direct_part > num_partitions - 1) direct_part = num_partitions - 1;

    /* Use the upper half of partitions (excluding direct) as "tail" region.
     * For short filters (e.g. 6 partitions), using only the last partition
     * gives an extremely low energy ratio because the filter has already
     * attenuated most energy. Instead, average the upper half to get a
     * more representative tail energy estimate.
     *
     * Example: 6 partitions, direct=0
     *   tail_start = max(1, 6/2) = 3  → average partitions 3,4,5
     * Example: 13 partitions, direct=0
     *   tail_start = max(1, 13/2) = 6  → average partitions 6..12
     */
    tail_start = num_partitions / 2;
    if (tail_start <= direct_part) tail_start = direct_part + 1;
    if (tail_start >= num_partitions) tail_start = num_partitions - 1;
    tail_count = num_partitions - tail_start;
    if (tail_count < 1) tail_count = 1;

    /* Compute energies (skip DC bin k=0) */
    direct_energy = 0.0f;
    tail_energy = 0.0f;
    for (k = 1; k <= AEC3_FFT_LENGTH_LONG_BY2; k++) {
        direct_energy += H2_pf_update[direct_part * AEC3_FFT_LENGTH_LONG_BY2_PLUS1 + k];
    }
    /* Average tail energy across multiple partitions */
    for (p = tail_start; p < num_partitions; p++) {
        for (k = 1; k <= AEC3_FFT_LENGTH_LONG_BY2; k++) {
            tail_energy += H2_pf_update[p * AEC3_FFT_LENGTH_LONG_BY2_PLUS1 + k];
        }
    }
    tail_energy /= (float)tail_count;

    /* Skip if direct energy too small (avoid division by zero) */
    if (direct_energy < 1e-10f) return;

    /* Compute average decay ratio */
    average_decay_new = tail_energy / direct_energy;

    /* Clamp to 1.0 if tail > direct (estimation error) */
    if (average_decay_new > 1.0f) average_decay_new = 1.0f;

    /* Apply a minimum floor to prevent near-zero estimates.
     * Even in low-reverb environments, the tail/direct ratio should not
     * be below ~0.01 for the reverb injection to have any effect. */
    if (average_decay_new < 0.01f) average_decay_new = 0.01f;

    /* IIR smoothing */
    smoothing = 0.2f * linear_filter_quality;
    self->average_decay_long += smoothing * (average_decay_new - self->average_decay_long);

    /* Compute per-bin tail response using averaged tail spectrum */
    {
        float tail_spectrum[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
        /* Average the per-bin tail spectrum across tail partitions */
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            tail_spectrum[k] = 0.0f;
        }
        for (p = tail_start; p < num_partitions; p++) {
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                tail_spectrum[k] += H2_pf_update[p * AEC3_FFT_LENGTH_LONG_BY2_PLUS1 + k];
            }
        }
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            tail_spectrum[k] /= (float)tail_count;
        }

        /* Blend: use direct spectrum shape scaled by average_decay_long,
         * but also incorporate actual tail spectrum shape.
         * blend = 0.5 * (direct_shape * decay + tail_actual)
         * This preserves frequency-dependent reverb characteristics. */
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            float direct_based = H2_pf_update[direct_part * AEC3_FFT_LENGTH_LONG_BY2_PLUS1 + k]
                                 * self->average_decay_long;
            float tail_actual = tail_spectrum[k];
            self->tail_response_long[k] = 0.5f * (direct_based + tail_actual);
        }
    }

    /* Neighbor smoothing: for k in [1, 255], replace if neighbor avg > current */
    for (k = 1; k <= AEC3_FFT_LENGTH_LONG_BY2_MINUS1; k++) {
        float avg_neighbour = 0.5f * (self->tail_response_long[k - 1] +
                                       self->tail_response_long[k + 1]);
        if (avg_neighbour > self->tail_response_long[k]) {
            self->tail_response_long[k] = avg_neighbour;
        }
    }

    /* Increment update counter */
    self->update_counter++;
}

const float* ReverbFrequencyResponseLong_GetResponse(
    const ReverbFrequencyResponseLong* self) {
    return self->tail_response_long;
}
