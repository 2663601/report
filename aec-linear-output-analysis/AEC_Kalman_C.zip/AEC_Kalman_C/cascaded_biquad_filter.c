/*
 *  Cascaded Biquad Filter - Pure C Version
 *
 *  Applies a cascade of biquad (second-order IIR) filters.
 *  Direct Form 1 implementation.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#include "cascaded_biquad_filter.h"
#include <string.h>
#include <assert.h>

/* ----------------------------------------------------------------
 * Internal: apply a single biquad stage (Direct Form 1)
 * x and y may alias (in-place processing).
 * ---------------------------------------------------------------- */
static void ApplyBiQuad(const float* x, float* y, int len,
                        BiQuadState* bq) {
    const float* c_b = bq->coefficients.b;
    const float* c_a = bq->coefficients.a;
    float* m_x = bq->x;
    float* m_y = bq->y;
    int k;

    for (k = 0; k < len; ++k) {
        float tmp = x[k];
        y[k] = c_b[0] * tmp + c_b[1] * m_x[0] + c_b[2] * m_x[1]
             - c_a[0] * m_y[0] - c_a[1] * m_y[1];
        m_x[1] = m_x[0];
        m_x[0] = tmp;
        m_y[1] = m_y[0];
        m_y[0] = y[k];
    }
}

/* ----------------------------------------------------------------
 * Compute biquad coefficients from zero-pole-gain parameters.
 * Matches the C++ BiQuad(BiQuadParam) constructor.
 * ---------------------------------------------------------------- */
static void ComputeCoefficients(const BiQuadParam* param,
                                BiQuadCoefficients* coeffs) {
    float z_r = param->zero_re;
    float z_i = param->zero_im;
    float p_r = param->pole_re;
    float p_i = param->pole_im;
    float gain = param->gain;

    if (param->mirror_zero) {
        /* Zeros at z_r and -z_r (z_i must be 0) */
        coeffs->b[0] = gain * 1.0f;
        coeffs->b[1] = 0.0f;
        coeffs->b[2] = gain * -(z_r * z_r);
    } else {
        /* Zeros at (z_r + z_i*i) and (z_r - z_i*i) */
        coeffs->b[0] = gain * 1.0f;
        coeffs->b[1] = gain * -2.0f * z_r;
        coeffs->b[2] = gain * (z_r * z_r + z_i * z_i);
    }

    /* Poles at (p_r + p_i*i) and (p_r - p_i*i) */
    coeffs->a[0] = -2.0f * p_r;
    coeffs->a[1] = p_r * p_r + p_i * p_i;
}

/* ----------------------------------------------------------------
 * Public API
 * ---------------------------------------------------------------- */

void CascadedBiQuad_InitFromParams(CascadedBiQuadFilter* self,
                                   const BiQuadParam* params,
                                   int num_stages) {
    int i;
    assert(self != NULL);
    assert(num_stages >= 0 && num_stages <= BIQUAD_MAX_STAGES);

    self->num_stages = num_stages;
    memset(self->stages, 0, sizeof(self->stages));

    for (i = 0; i < num_stages; ++i) {
        ComputeCoefficients(&params[i], &self->stages[i].coefficients);
        self->stages[i].x[0] = self->stages[i].x[1] = 0.0f;
        self->stages[i].y[0] = self->stages[i].y[1] = 0.0f;
    }
}

void CascadedBiQuad_InitFromCoeffs(CascadedBiQuadFilter* self,
                                   const BiQuadCoefficients* coeffs,
                                   int num_stages) {
    int i;
    assert(self != NULL);
    assert(num_stages >= 0 && num_stages <= BIQUAD_MAX_STAGES);

    self->num_stages = num_stages;
    memset(self->stages, 0, sizeof(self->stages));

    for (i = 0; i < num_stages; ++i) {
        self->stages[i].coefficients = *coeffs;
        self->stages[i].x[0] = self->stages[i].x[1] = 0.0f;
        self->stages[i].y[0] = self->stages[i].y[1] = 0.0f;
    }
}

void CascadedBiQuad_InitPassThrough(CascadedBiQuadFilter* self) {
    assert(self != NULL);
    self->num_stages = 0;
    memset(self->stages, 0, sizeof(self->stages));
}

void CascadedBiQuad_Process(CascadedBiQuadFilter* self,
                            const float* x, float* y, int len) {
    assert(self != NULL);

    if (self->num_stages > 0) {
        /* First stage: x -> y */
        ApplyBiQuad(x, y, len, &self->stages[0]);
        /* Subsequent stages: y -> y (in-place) */
        {
            int k;
            for (k = 1; k < self->num_stages; ++k) {
                ApplyBiQuad(y, y, len, &self->stages[k]);
            }
        }
    } else {
        /* Pass-through: copy input to output */
        memcpy(y, x, sizeof(float) * (size_t)len);
    }
}

void CascadedBiQuad_ProcessInPlace(CascadedBiQuadFilter* self,
                                   float* y, int len) {
    int k;
    assert(self != NULL);

    for (k = 0; k < self->num_stages; ++k) {
        ApplyBiQuad(y, y, len, &self->stages[k]);
    }
}

void CascadedBiQuad_Reset(CascadedBiQuadFilter* self) {
    int i;
    assert(self != NULL);

    for (i = 0; i < self->num_stages; ++i) {
        self->stages[i].x[0] = self->stages[i].x[1] = 0.0f;
        self->stages[i].y[0] = self->stages[i].y[1] = 0.0f;
    }
}
