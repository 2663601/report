/*
 *  ResidualEchoEstimator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ResidualEchoEstimator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "residual_echo_estimator.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#ifdef _WIN32
#include <io.h>
#define ACCESS_F(p) _access((p), 0)
#else
#include <unistd.h>
#define ACCESS_F(p) access((p), 0)
#endif

static void RenderNoisePower(ResidualEchoEstimator* self,
                             const RenderBuffer* render_buffer) {
    const float* X2 = RenderBuffer_Spectrum(render_buffer, 0);
    int k;
    if (!X2) return;

    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        if (self->X2_noise_floor_counter[k] > 0) {
            self->X2_noise_floor_counter[k]--;
        } else {
            if (X2[k] < self->X2_noise_floor[k]) {
                self->X2_noise_floor[k] = X2[k];
            } else {
                self->X2_noise_floor[k] *= 1.002f;
            }
            self->X2_noise_floor_counter[k] = self->config.echo_model_noise_floor_hold;
        }
    }
}

static void RenderNoisePower512fft(ResidualEchoEstimator* self,
                                   const float* X2Refer) {
    int k;
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        if (self->X2_noise_floor_long_counter[k] > 0) {
            self->X2_noise_floor_long_counter[k]--;
        } else {
            if (X2Refer[k] < self->X2_noise_floor_long[k]) {
                self->X2_noise_floor_long[k] = X2Refer[k];
            } else {
                self->X2_noise_floor_long[k] *= 1.002f;
            }
            self->X2_noise_floor_long_counter[k] =
                self->config.echo_model_noise_floor_hold;
        }
    }
}

void ResidualEchoEstimator_Init(ResidualEchoEstimator* self,
                                const Aec3Config* config) {
    int k;
    memset(self, 0, sizeof(ResidualEchoEstimator));
    self->config = *config;
    self->soft_transparent_mode = 1;
    self->override_estimated_echo_path_gain = 1;
    self->enable_echo_reverb = 1;
    self->initial_echo_potential_counter = 30;
    self->has_external_delay_last = 0;
    self->alpha = 0.3f;

    ReverbModel_Init(&self->echo_reverb);
    self->use_reverb_model = config->ep_strength_reverb_based_on_render;

    ReverbModelLong_Init(&self->echo_reverb_long);

    /* Initialize smoothed state (formerly static locals) */
    self->lf_ratio_smooth = 0.0f;
    self->flat_smooth_state = 0.0f;
    self->adaptive_reverb_gain = 0.0f;

    ResidualEchoEstimator_Reset(self);
}

void ResidualEchoEstimator_Reset(ResidualEchoEstimator* self) {
    int k;
    ReverbModel_Reset(&self->echo_reverb);
    ReverbModelLong_Reset(&self->echo_reverb_long);

    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        self->X2_noise_floor_counter[k] = self->config.echo_model_noise_floor_hold;
        self->X2_noise_floor[k] = self->config.echo_model_min_noise_floor_power;
        self->R2_old[k] = 0.0f;
        self->R2_hold_counter[k] = 0;
        self->X2_smoothed[k] = 0.0f;
        self->X2min[k] = 0.0f;
        self->X2tmp[k] = 0.0f;
    }
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        self->X2_noise_floor_long_counter[k] = self->config.echo_model_noise_floor_hold;
        self->X2_noise_floor_long[k] = self->config.echo_model_min_noise_floor_power;
        self->X2_smoothed_long[k] = 0.0f;
        self->X2min_long[k] = 0.0f;
        self->X2tmp_long[k] = 0.0f;
    }
    self->N2_counter = 0;
    self->min_count = 0;
    self->N2_counter_long = 0;
    self->min_count_long = 0;
    self->capture_energy = 0.0f;
    self->filterout_energy = 0.0f;
    self->linearecho_energy = 0.0f;
}

void ResidualEchoEstimator_Estimate(ResidualEchoEstimator* self,
                                    const float* S2_linear,
                                    const float* Y2,
                                    const float* E2,
                                    const float* erle,
                                    int usable_linear,
                                    int saturated_echo,
                                    int transparent_mode,
                                    float echo_path_gain,
                                    float reverb_decay,
                                    const float* reverb_freq_resp,
                                    int filter_delay,
                                    int filter_length,
                                    const RenderBuffer* render_buffer,
                                    float* R2) {
    int k;

    RenderNoisePower(self, render_buffer);

    if (usable_linear) {
        /* Linear estimate: R2 = S2_linear / erle */
        for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
            self->R2_hold_counter[k] = 10;
            if (erle[k] > 0.0f) {
                R2[k] = S2_linear[k] / erle[k];
            } else {
                R2[k] = S2_linear[k];
            }
        }

        if (saturated_echo) {
            memcpy(R2, Y2, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
        }

        /* Add reverb contribution */
        if (self->enable_echo_reverb && self->use_reverb_model) {
            const float* render_spec =
                RenderBuffer_Spectrum(render_buffer, filter_length + 1);
            if (render_spec && reverb_freq_resp) {
                ReverbModel_AddReverb(&self->echo_reverb,
                                      render_spec, reverb_freq_resp,
                                      reverb_decay, R2);
            }
        }
    } else {
        /* Non-linear estimate */
        float gain2 = echo_path_gain * echo_path_gain;
        const float* X2;
        float X2_buf[AEC3_FFT_LENGTH_BY2_PLUS1];

        if (transparent_mode && self->soft_transparent_mode) {
            gain2 = 0.01f * 0.01f;
        }

        /* Get render spectrum around delay */
        RenderBuffer_SpectralSum(render_buffer, 3, X2_buf);
        X2 = X2_buf;

        /* Subtract noise floor */
        for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
            float x2 = X2[k] - self->config.echo_model_stationary_gate_slope *
                        self->X2_noise_floor[k];
            if (x2 < 0.0f) x2 = 0.0f;
            R2[k] = x2 * gain2;
        }

        if (saturated_echo) {
            memcpy(R2, Y2, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
        }

        /* Add reverb */
        if (!(transparent_mode && self->soft_transparent_mode)) {
            if (self->use_reverb_model) {
                const float* render_spec =
                    RenderBuffer_Spectrum(render_buffer, filter_delay + 1);
                if (render_spec) {
                    ReverbModel_AddReverbNoFreqShaping(&self->echo_reverb,
                        render_spec, gain2, reverb_decay, R2);
                }
            }
        }
    }

    /* Handle transparent mode */
    if (!self->soft_transparent_mode && transparent_mode) {
        memset(R2, 0, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
        memset(self->R2_old, 0, sizeof(self->R2_old));
    }

    memcpy(self->R2_old, R2, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
}

void ResidualEchoEstimator_Estimate512fftPfdkf(
    ResidualEchoEstimator* self,
    const float* S2_linear,
    const float* Y2,
    const float* E2,
    const float* X2Refer,
    const float* erle_long,
    const float* erle_long_greater,
    int saturated_echo_512fft,
    int earphone_flag,
    int voip_flag,
    int aec_level,
    int extra_echo_sup,
    int aec_low_compute_mode,
    int aec_H_usage,
    int has_external_delay,
    float reverb_decay,
    const float* X2_reverb_tail,
    const float* freq_response_tail_long,
    float* R2) {
    int k;
    float capture_energy = 0.0f, filterout_energy = 0.0f;
    float filterout_ratio;
    float erle_mean = 0.0f;
    float erle_greater_avg[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    (void)aec_level;

    RenderNoisePower512fft(self, X2Refer);

    /* Fix 1.1: Initial echo potential counter logic (matches C++ Estimate_512fft_pfdkf) */
    {
        double X2_sum = 0.0;
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            X2_sum += X2Refer[k];
        }
        X2_sum /= (double)AEC3_FFT_LENGTH_LONG_BY2_PLUS1;
        X2_sum /= 1000.0;
        if (X2_sum > 30000.0) X2_sum = 30000.0;
        if (X2_sum > 200.0 && self->initial_echo_potential_counter > 0) {
            self->initial_echo_potential_counter--;
            if (!has_external_delay) {
                self->echo_duration_counter = 25;  /* potential delay 400ms */
            } else if (!self->has_external_delay_last) {
                self->echo_duration_counter = 5;   /* 80ms */
            }
        }
        self->has_external_delay_last = has_external_delay;
    }

    /* Compute erle_mean (matches C++) */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        erle_mean += erle_long[k];
    }
    erle_mean /= (float)AEC3_FFT_LENGTH_LONG_BY2_PLUS1;

    /* Compute erle_greater_avg: ±2 bin smoothing of erle_long_greater (matches C++) */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        int k_min = k - 2;
        int k_max = k + 2;
        float avg = 0.0f;
        int j;
        if (k_min < 0) k_min = 0;
        if (k_max > AEC3_FFT_LENGTH_LONG_BY2 - 1) k_max = AEC3_FFT_LENGTH_LONG_BY2 - 1;
        for (j = k_min; j <= k_max; j++) {
            avg += erle_long_greater[j];
        }
        erle_greater_avg[k] = avg / (float)(k_max - k_min + 1);
    }

    /* Compute energy tracking (Fix 1.6: add linearecho_energy) */
    {
        float linearecho_energy = 0.0f;
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            capture_energy += Y2[k];
            filterout_energy += E2[k];
            linearecho_energy += S2_linear[k];
        }
        self->capture_energy += self->alpha * (capture_energy - self->capture_energy);
        self->filterout_energy += self->alpha * (filterout_energy - self->filterout_energy);
        self->linearecho_energy += self->alpha * (linearecho_energy - self->linearecho_energy);
    }
    filterout_ratio = self->filterout_energy / (self->capture_energy + 1e-6f);
    if (filterout_ratio > 1.0f) filterout_ratio = 1.0f;

    /* Handle initial echo potential */
    if (self->echo_duration_counter > 0 && !earphone_flag && !voip_flag) {
        memcpy(R2, Y2, sizeof(float) * AEC3_FFT_LENGTH_LONG_BY2_PLUS1);
        self->echo_duration_counter--;
        return;
    }

    /* Linear estimate: R2 = S2_linear / erle_long */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        if (erle_long[k] > 0.0f) {
            R2[k] = S2_linear[k] / erle_long[k];
        } else {
            R2[k] = S2_linear[k];
        }
    }

    /* Apply adjustments based on filterout_ratio and flags (matches C++) */
    if (aec_low_compute_mode) {
        if (earphone_flag || voip_flag) {
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                float factor;
                if (extra_echo_sup || voip_flag) {
                    factor = erle_greater_avg[k] * erle_greater_avg[k];
                } else {
                    factor = erle_greater_avg[k];
                }
                R2[k] *= factor;
                if (filterout_ratio < 0.2f) R2[k] *= 4.0f;
                if (filterout_ratio < 0.1f) R2[k] *= 4.0f;
            }
        } else {
            if (filterout_ratio > 0.05f) {
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    float factor;
                    if (extra_echo_sup) {
                        factor = sqrtf(erle_greater_avg[k]);
                        if (k > 64) factor = erle_greater_avg[k];
                    } else {
                        factor = 0.5f * sqrtf(erle_greater_avg[k]);
                        if (factor > 5.0f) factor = 5.0f;
                        if (factor < 0.0f) factor = 0.0f;
                    }
                    R2[k] *= factor;
                }
            } else {
                float factor = 0.75f / (filterout_ratio + 1e-6f);
                if (!extra_echo_sup) {
                    factor /= 3.0f;
                    if (factor > 30.0f) factor = 30.0f;
                }
                if (factor > 100.0f) factor = 100.0f;
                if (factor < 0.0f) factor = 0.0f;
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    R2[k] *= factor;
                }
            }
        }
    } else {
        if (earphone_flag || voip_flag) {
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                if (filterout_ratio >= 0.4f) {
                    /* Match C++: protect near-end when erle is low */
                    if (erle_long[k] <= 2.0f || erle_mean < 3.0f) {
                        R2[k] *= 0.005f;
                    } else {
                        R2[k] *= 0.5f;
                    }
                } else if (filterout_ratio >= 0.1f) {
                    R2[k] *= 0.5f;
                }
                if (filterout_ratio < 0.1f) R2[k] *= 2.0f;
                if (filterout_ratio < 0.01f) R2[k] *= 5.0f;
            }
        } else {
            if (filterout_ratio < 0.5f) {
                for (k = 128; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    /* Match C++: only amplify when erle >= 5 */
                    if (erle_long[k] >= 5.0f) {
                        R2[k] *= 2.0f;
                    }
                }
            }
            if (filterout_ratio < 0.02f) {
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    R2[k] *= 2.0f;
                }
            }
            if (filterout_ratio < 0.01f) {
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    R2[k] *= 4.0f;
                }
            }
        }
    }

    /* Add reverb contribution (512-point)
     *
     * Two-factor control for reverb injection strength:
     *
     * Factor 1: ne_weight = E2_lf / (E2_lf + S2_lf)  [0~500Hz]
     *   Near-end proportion — speech F0 (85~300Hz) concentrates here.
     *   High means near-end active, reduce reverb.
     *
     * Factor 2: lf_ratio = E2_lf / (E2_total + eps)
     *   Low-freq energy proportion of total E2.
     *   Reverb tail has low lf_ratio (energy in mid/high freq).
     *   Near-end speech has high lf_ratio (F0 in low freq).
     *
     * Both factors are smoothed with IIR (alpha=0.15) to reduce frame-level
     * noise. Thresholds derived from actual PCM analysis:
     *   Echo single-talk: ne_smooth ~0.3, lf_smooth ~0.3
     *   Double-talk:      ne_smooth ~0.77, lf_smooth ~0.5
     *
     * Factor 3: spectral flatness of E2
     *   Reverb tail has flat spectrum (flatness ~0.17, diffuse reflections).
     *   Speech has harmonic structure (flatness ~0.03, sharp peaks).
     *   High flatness + high ne_smooth -> reverb tail, not double-talk.
     *   Computed as geometric_mean / arithmetic_mean of E2 spectrum.
     *
     * 512fft @16kHz: 31.25Hz/bin, bins 1~16 = 31~500Hz */
    self->reverb_diag_counter++;
    if (self->enable_echo_reverb && self->use_reverb_model &&
        reverb_decay > 0.0f && X2_reverb_tail != NULL &&
        freq_response_tail_long != NULL) {
        /* Per-frequency reverb injection with LF SNR adaptive scaling */
        float clamped_tail[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
        float R2_before_sum = 0.0f;
        float R2_after_sum = 0.0f;
        float reverb_contrib_sum = 0.0f;
        float X2_tail_sum = 0.0f;
        float freq_resp_sum = 0.0f;
        float reverb_state_sum = 0.0f;
        float E2_sum = 0.0f, Y2_sum = 0.0f, S2_sum = 0.0f;
        int i;

        /* Step 1: Compute E2 low-freq SNR for near-end detection.
         * E2 bins 1~9 = 31~281Hz (<300Hz).
         * Near-end speech has F0 energy here → high LF SNR.
         * Echo-only has low LF energy → low LF SNR.
         * Use asymmetric noise floor tracker on LF energy. */
        {
            float e2_lf_sum = 0.0f;
            float e2_lf_amp, snr_db, reverb_lf_scale;
            for (i = 1; i <= 9; i++) {
                e2_lf_sum += E2[i];
            }
            e2_lf_amp = sqrtf(e2_lf_sum);

            /* Update LF noise floor: fast fall, slow rise */
            if (e2_lf_amp < self->E2_lf_smooth || self->E2_lf_smooth < 1.0f) {
                self->E2_lf_smooth = e2_lf_amp;
            } else {
                self->E2_lf_smooth *= 1.002f;
            }

            /* Compute LF SNR in dB */
            snr_db = 0.0f;
            if (self->E2_lf_smooth > 1.0f && e2_lf_amp > 1.0f) {
                snr_db = 20.0f * log10f(e2_lf_amp / self->E2_lf_smooth);
            }
            if (snr_db < 0.0f) snr_db = 0.0f;

            /* Map SNR to reverb injection scale: negative correlation.
             * Uses squared-exponential for gentle slope at low SNR,
             * steep drop at high SNR:
             *   scale = exp(-(snr_db / tau)^2)
             *
             * tau=15:
             *   0 dB  → 1.00
             *   5 dB  → 0.89
             *  10 dB  → 0.64
             *  12 dB  → 0.53
             *  15 dB  → 0.37
             *  20 dB  → 0.17
             *  25 dB  → 0.06
             *  30 dB  → 0.02 */
            {
                const float tau = 15.0f;
                float x = snr_db / tau;
                reverb_lf_scale = 1;
            }

            /* Apply: clamped_tail scaled by ep_strength_default_gain × LF SNR scale */
            for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; i++) {
                clamped_tail[i] = freq_response_tail_long[i] > 0.0f
                                  ? freq_response_tail_long[i] : 0.0f;
                clamped_tail[i] *= self->config.ep_strength_default_gain * reverb_lf_scale;
                R2_before_sum += R2[i];
                X2_tail_sum += X2_reverb_tail[i];
                freq_resp_sum += clamped_tail[i];
                E2_sum += E2[i];
                Y2_sum += Y2[i];
                S2_sum += S2_linear[i];
            }
        }
        /* Capture reverb IIR state before injection */
        for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; i++) {
            reverb_state_sum += self->echo_reverb_long.reverb[i];
        }
        ReverbModelLong_AddReverb(
            &self->echo_reverb_long,
            X2_reverb_tail, clamped_tail,
            reverb_decay, R2);
        for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; i++) {
            R2_after_sum += R2[i];
        }
        reverb_contrib_sum = R2_after_sum - R2_before_sum;

        /* Diagnostic: disabled — enable by changing #if 0 to #if 1 */
#if 0
        if (self->reverb_diag_counter % 10 == 0) {
            float ratio = (R2_before_sum > 1e-10f)
                          ? reverb_contrib_sum / R2_before_sum : 0.0f;
            float erle_actual = (E2_sum > 1e-10f) ? Y2_sum / E2_sum : 0.0f;
            fprintf(stderr, "[ReverbDiag] frm=%d decay=%.4f fo_ratio=%.4f erle_act=%.1f "
                    "Y2=%.0f S2=%.0f E2=%.0f R2_base=%.0f "
                    "X2_tail=%.0f freq_avg=%.8f reverb_st=%.0f reverb_add=%.0f "
                    "R2_total=%.0f ratio=%.4f erle_mean=%.2f\n",
                    self->reverb_diag_counter, reverb_decay, filterout_ratio,
                    erle_actual,
                    Y2_sum, S2_sum, E2_sum, R2_before_sum,
                    X2_tail_sum,
                    freq_resp_sum / AEC3_FFT_LENGTH_LONG_BY2_PLUS1,
                    reverb_state_sum, reverb_contrib_sum,
                    R2_after_sum, ratio, erle_mean);
        }
#endif
    } else {
        /* Diagnostic: disabled */
#if 0
        if (self->reverb_diag_counter % 10 == 0) {
            fprintf(stderr, "[ReverbDiag] frm=%d SKIPPED: enable=%d use_model=%d decay=%.4f "
                    "X2_tail=%s freq_resp=%s\n",
                    self->reverb_diag_counter,
                    self->enable_echo_reverb, self->use_reverb_model,
                    reverb_decay,
                    X2_reverb_tail ? "yes" : "NULL",
                    freq_response_tail_long ? "yes" : "NULL");
        }
#endif
    }

    /* Saturated echo handling */
    if (saturated_echo_512fft && aec_H_usage == 5) {
        memcpy(R2, Y2, sizeof(float) * AEC3_FFT_LENGTH_LONG_BY2_PLUS1);
    }
}

void ResidualEchoEstimator_SetEarphoneFlag(ResidualEchoEstimator* self, int flag) {
    self->earphone_flag = flag;
}

void ResidualEchoEstimator_SetVoipFlag(ResidualEchoEstimator* self, int flag) {
    self->voip_flag = flag;
}

void ResidualEchoEstimator_SetEnableEchoReverb(ResidualEchoEstimator* self, int flag) {
    self->enable_echo_reverb = flag;
}
