#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
'''
@File   ：windows.py
@Author ：LiPingping
@Date   ：05/05/22 下午4:29 
@Desc   : Classic dsp window func utils.
'''

import torch

def roothanning(window_size):
    '''Sqrt root hanning window.'''
    # fft_window = np.hanning(window_size + 2)[1:-1] ** 0.5
    win = torch.sqrt(torch.hann_window(window_size + 2, periodic=False)[1:-1])
    return win

def ones(window_size):
    '''Ones window.'''
    win = torch.ones(window_size)
    return win


if __name__ == '__main__':
    import numpy as np

    win = np.sqrt(np.hanning(256))
    tmp = torch.hann_window(256, periodic=False) ** 0.5  # periodic must be False
    print(len(win), win)
    print(len(tmp), tmp)

    # # fft_window = np.hanning(256 + 2)[1:-1] ** 0.5
    # fft_window = np.hanning(256 + 2)[1:-1] ** 0.5
    # test = torch.hann_window(256 + 2, periodic=False)[1:-1] ** 0.5
    # print(len(fft_window), fft_window)
    # print(len(test), test)


    fft_window = np.hanning(512 + 2)[1:-1] ** 0.5
    test = torch.hann_window(512 + 2, periodic=False)[1:-1] ** 0.5
    # print(len(fft_window), fft_window)
    # print(len(test), test)
    w1 = fft_window[:len(fft_window)//2]
    w2 = fft_window[len(fft_window)//2:]
    print(w1**2+w2**2)

    # w1 = test[:len(test)//2]
    # w2 = test[len(test)//2:]
    # print(w1*w1+w2)
