/*
 *  ReverbFrequencyResponse - Pure C Version
 *
 *  Estimates the frequency response of the reverberant echo.
 *  Ported from WebRTC AEC3 C++ ReverbFrequencyResponse class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef REVERB_FREQUENCY_RESPONSE_H_
#define REVERB_FREQUENCY_RESPONSE_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float   tail_response[AEC3_FFT_LENGTH_BY2_PLUS1];
    float   average_decay;
    int     enable_smooth_updates;
} ReverbFrequencyResponse;

/**
 * Initialize the reverb frequency response estimator.
 */
void ReverbFrequencyResponse_Init(ReverbFrequencyResponse* self);

/**
 * Update the frequency response estimate.
 *
 * @param self                      Pointer to estimator
 * @param H2                        Filter frequency response [partitions][65]
 * @param num_partitions            Number of partitions
 * @param filter_delay_blocks       Filter delay in blocks
 * @param linear_filter_quality     Quality estimate (negative if unavailable)
 * @param has_quality               Whether quality is valid
 * @param stationary_block          Whether current block is stationary
 */
void ReverbFrequencyResponse_Update(ReverbFrequencyResponse* self,
                                    const float (*H2)[AEC3_FFT_LENGTH_BY2_PLUS1],
                                    int num_partitions,
                                    int filter_delay_blocks,
                                    float linear_filter_quality,
                                    int has_quality,
                                    int stationary_block);

/**
 * Get the estimated reverb frequency response.
 */
const float* ReverbFrequencyResponse_GetResponse(
    const ReverbFrequencyResponse* self);

#ifdef __cplusplus
}
#endif

#endif /* REVERB_FREQUENCY_RESPONSE_H_ */
