/*
 *  EchoRemover - Pure C Version
 *
 *  Coordinates the echo removal pipeline: subtractor, suppression gain,
 *  comfort noise, suppression filter, and AEC state.
 *  Ported from WebRTC AEC3 C++ EchoRemover class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords.
 */

#ifndef ECHO_REMOVER_H_
#define ECHO_REMOVER_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "aec3_fft.h"
#include "subtractor.h"
#include "suppression_gain.h"
#include "comfort_noise_generator.h"
#include "suppression_filter.h"
#include "aec_state.h"
#include "render_signal_analyzer.h"
#include "residual_echo_estimator.h"
#include "webrtc_aec_nlp.h"
#include "subtractor_output.h"
#include "render_buffer.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * EchoRemover
 * ================================================================ */
typedef struct {
    Aec3Config              config;
    Aec3Fft                 fft_512;
    int                     sample_rate_hz;

    Subtractor              subtractor;
    SuppressionGain         suppression_gain;
    ComfortNoiseGenerator   cng;
    SuppressionFilter       suppression_filter;
    AecState                aec_state;
    RenderSignalAnalyzer    render_signal_analyzer;
    ResidualEchoEstimator   residual_echo_estimator;
    WebrtcAecNlpState           webrtc_aec_nlp;  /* Optional WebRTC AEC-style NLP (webrtc_aec_mode=1) */

    /* Long (512-point) work buffers */
    float   E2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   Y2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   R2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   S2_linear_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   G_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    FftDataPfdkf comfort_noise;
    FftDataPfdkf comfort_noise_high;

    int     block_counter;
    int     gain_change_hangover;
    int     linear_filter_output_last_selected;
    float   accelerate;
    float   near_activity;
    int     music_flag;
    int     echo_process_enable;

    /* Runtime config */
    int     aec_CNG_level;
    int     use_cache_filter;
    int     use_noise_gate_division;
    int     initial_sup_flag;
    int     frame_cnt;
    int     echo_possible;

    /* 512fft PFDKF state variables */
    float   d_long[AEC3_FFT_LENGTH_BY2 * 8];                       /* 8-block capture history (512 samples) */
    float   x_long[AEC3_FFT_LENGTH_LONG_BY2];                      /* 4-block render data (256 samples) */
    float   x_long_old[AEC3_FFT_LENGTH_LONG_BY2];                  /* x_long previous frame (for PaddedFft512) */
    float   out_buffer[AEC3_MAX_BANDS][AEC3_FFT_LENGTH_BY2 * 3];   /* 3-block NLP output buffer */
    float   hband_in[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE * 4];         /* 4-block upper band input buffer for NLP cycle */
    int     suppress_cnt;                                           /* 4-block cycle counter */
    float   aec_nlp_level;                                          /* NLP gain level */
    float   S2_avg;                                                 /* smoothed linear echo power mean */
    float   echo_sup_factor;                                        /* echo suppression factor */
    float   high_bands_gain;                                        /* gain for upper bands (from suppression_gain) */
    float   hband_delay_buf[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE * 4];  /* 256-sample swap delay buffer for upper bands (matches C++ e_output_old_long_) */
    SubtractorOutputFrequency subtractor_output_frequency;          /* PFDKF frequency-domain output */

    /* Runtime config (propagated from EchoCanceller3) */
    AecRuntimeConfig rt_config;
} EchoRemover;

/**
 * Initialize the echo remover.
 */
void EchoRemover_Init(EchoRemover* self, const Aec3Config* config,
                      int sample_rate_hz,
                      FftDataPfdkf* H_pf_mem,
                      FftDataPfdkf* H_pf_speed_mem,
                      FftDataPfdkf* H_pf_update_mem,
                      float* H2_pf_update_mem,
                      FftDataPfdkf* G_pfdkf_mem,
                      FftDataPfdkf* G_pfdkf_speed_mem,
                      float* H_error_pfdkf_mem,
                      int aec_H_usage);

/**
 * Process one capture block through the 512fft PFDKF echo remover.
 *
 * Implements the 4-block NLP cycle: full NLP pipeline when suppress_cnt >= 4,
 * buffered output when suppress_cnt is 1/2/3.
 *
 * @param self                      Pointer to echo remover
 * @param echo_path_variability     Echo path change description
 * @param capture_signal_saturation Whether capture is saturated
 * @param apm_submodule_switch      Submodule switch flag
 * @param external_delay            External delay estimate (NULL if none)
 * @param has_external_delay        Whether external_delay is valid
 * @param render_buffer             Render buffer
 * @param capture                   Capture block [num_bands][AEC3_BLOCK_SIZE]
 * @param num_bands                 Number of bands
 * @param echo_process_enable       Whether echo processing is enabled
 */
void EchoRemover_ProcessCapture_512fft_Pfdkf(
    EchoRemover* self,
    EchoPathVariability echo_path_variability,
    int capture_signal_saturation,
    int apm_submodule_switch,
    const DelayEstimate* external_delay,
    int has_external_delay,
    RenderBuffer* render_buffer,
    float capture[][AEC3_BLOCK_SIZE],
    int num_bands,
    int echo_process_enable);

/**
 * Set near-end activity level.
 */
void EchoRemover_SetNearActivity(EchoRemover* self, float near_activity);

/**
 * Set music flag.
 */
void EchoRemover_SetMusicFlag(EchoRemover* self, int music_flag);

/**
 * Get echo state.
 */
int EchoRemover_GetEchoState(const EchoRemover* self);

#ifdef __cplusplus
}
#endif

#endif /* ECHO_REMOVER_H_ */
