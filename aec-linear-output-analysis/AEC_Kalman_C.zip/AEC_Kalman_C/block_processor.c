/*
 *  BlockProcessor - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ BlockProcessor class.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#include "block_processor.h"
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdint.h>

/* ================================================================
 * Module-level profiling (enabled by AEC3_PROFILE_MODULES define)
 * ================================================================ */
#ifdef AEC3_PROFILE_MODULES
#ifdef _WIN32
#include <windows.h>
static double _prof_get_us(void) {
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER cnt;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&cnt);
    return (double)cnt.QuadPart / (double)freq.QuadPart * 1e6;
}
#else
#include <time.h>
static double _prof_get_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e6 + ts.tv_nsec / 1e3;
}
#endif

typedef struct {
    double delay_est_sum;
    double render_buf_sum;
    double echo_remover_sum;
    double subtractor_sum;
    double nlp_sum;
    double total_sum;
    int    count;
} ProfileAccum;

static ProfileAccum s_prof = {0};

/* Expose subtractor/NLP split timing from echo_remover */
extern double g_prof_subtractor_us;
extern double g_prof_nlp_us;

void BlockProcessor_PrintProfile(void) {
    if (s_prof.count > 0) {
        int n = s_prof.count;
        printf("\n===== AEC_Kalman_C Module Profile (%d blocks) =====\n", n);
        printf("  %-25s %8.1f us/block  %5.1f%%\n", "RenderDelayBuffer",
               s_prof.render_buf_sum / n, s_prof.render_buf_sum / s_prof.total_sum * 100);
        printf("  %-25s %8.1f us/block  %5.1f%%\n", "DelayEstimation",
               s_prof.delay_est_sum / n, s_prof.delay_est_sum / s_prof.total_sum * 100);
        printf("  %-25s %8.1f us/block  %5.1f%%\n", "Subtractor(PFDKF)",
               s_prof.subtractor_sum / n, s_prof.subtractor_sum / s_prof.total_sum * 100);
        printf("  %-25s %8.1f us/block  %5.1f%%\n", "NLP(512fft)",
               s_prof.nlp_sum / n, s_prof.nlp_sum / s_prof.total_sum * 100);
        printf("  %-25s %8.1f us/block  %5.1f%%\n", "EchoRemover(total)",
               s_prof.echo_remover_sum / n, s_prof.echo_remover_sum / s_prof.total_sum * 100);
        printf("  %-25s %8.1f us/block  %5.1f%%\n", "Other(overhead)",
               (s_prof.total_sum - s_prof.render_buf_sum - s_prof.delay_est_sum - s_prof.echo_remover_sum) / n,
               (s_prof.total_sum - s_prof.render_buf_sum - s_prof.delay_est_sum - s_prof.echo_remover_sum) / s_prof.total_sum * 100);
        printf("  %-25s %8.1f us/block\n", "TOTAL",
               s_prof.total_sum / n);
        printf("===================================================\n");
    }
}
#endif /* AEC3_PROFILE_MODULES */

/* Delay estimate dump file (4ms per block, 64 samples @16kHz) */
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif
static FILE* s_delay_fp = NULL;
static int   s_delay_file_opened = 0;

static void delay_dump_write(int delay_blocks) {
    if (access("enable_vqe_dump", 0) != 0) return;
    int i;
    int16_t delay_ms;
    if (!s_delay_fp && !s_delay_file_opened) {
        s_delay_fp = fopen("delay_estimate.pcm", "wb");
        s_delay_file_opened = 1;
    }
    if (s_delay_fp) {
        delay_ms = (int16_t)(delay_blocks * 4);
        for (i = 0; i < AEC3_BLOCK_SIZE; i++) {
            fwrite(&delay_ms, sizeof(int16_t), 1, s_delay_fp);
        }
    }
}

void BlockProcessor_CloseDelayDump(void) {
    if (s_delay_fp) {
        fclose(s_delay_fp);
        s_delay_fp = NULL;
        s_delay_file_opened = 0;
    }
}

/* ================================================================
 * BlockProcessor_Init
 * ================================================================ */
void BlockProcessor_Init(BlockProcessor* self, const Aec3Config* config,
                         int sample_rate_hz, int render_buffer_size,
                         float* blocks_mem, float* spectra_mem,
                         FftDataPfdkf* ffts2_mem,
                         float* low_rate_mem, int low_rate_size,
                         float* binary_dyn_mem,
                         FftDataPfdkf* H_pf_mem,
                         FftDataPfdkf* H_pf_speed_mem,
                         FftDataPfdkf* H_pf_update_mem,
                         float* H2_pf_update_mem,
                         FftDataPfdkf* G_pfdkf_mem,
                         FftDataPfdkf* G_pfdkf_speed_mem,
                         float* H_error_pfdkf_mem,
                         int aec_H_usage) {
    int num_bands;
    int buf_size = render_buffer_size;

    self->render_buffer_size = buf_size;
    self->blocks_mem = blocks_mem;
    self->spectra_mem = spectra_mem;
    self->ffts2_mem = ffts2_mem;
    self->low_rate_mem = low_rate_mem;
    self->low_rate_size = low_rate_size;
    self->binary_dyn_mem = binary_dyn_mem;

    memset(blocks_mem, 0, sizeof(float) * (size_t)buf_size * AEC3_MAX_BANDS * AEC3_BLOCK_SIZE);
    memset(spectra_mem, 0, sizeof(float) * (size_t)buf_size * AEC3_LF_FFT_LENGTH_BY2_PLUS1);  /* PFDKF only (128pt removed) */
    memset(ffts2_mem, 0, sizeof(FftDataPfdkf) * (size_t)buf_size);
    memset(low_rate_mem, 0, sizeof(float) * (size_t)low_rate_size);

    self->config = *config;
    self->sample_rate_hz = sample_rate_hz;
    num_bands = Aec3_NumBandsForRate(sample_rate_hz);
    self->num_bands = num_bands;

    /* Initialize typed FftBuffer instance (fft_buffer_128 removed) */
    FftBufferPfdkf_Init(&self->fft_buffer_pfdkf, self->ffts2_mem, buf_size);

    /* Initialize render delay buffer with pre-allocated memory */
    RenderDelayBuffer_Init(&self->render_delay_buffer, config, num_bands,
                           buf_size,
                           self->blocks_mem, self->spectra_mem,
                           self->ffts2_mem, self->low_rate_mem,
                           &self->fft_buffer_pfdkf);

    /* Initialize render delay controller */
    {
        int non_causal_offset = RenderDelayBuffer_DelayEstimatorOffset(config);
        RenderDelayController_Init(&self->render_delay_controller, config,
                                   non_causal_offset, sample_rate_hz,
                                   buf_size, binary_dyn_mem);
    }

    /* Initialize echo remover */
    EchoRemover_Init(&self->echo_remover, config, sample_rate_hz,
                     H_pf_mem, H_pf_speed_mem, H_pf_update_mem,
                     H2_pf_update_mem, G_pfdkf_mem, G_pfdkf_speed_mem,
                     H_error_pfdkf_mem, aec_H_usage);

    self->capture_properly_started = 0;
    self->render_properly_started = 0;
    self->render_event = RDB_EVENT_NONE;
    self->capture_call_counter = 0;
    self->has_estimated_delay = 0;
    memset(&self->estimated_delay, 0, sizeof(DelayEstimate));
    self->aec_512fft_enable = 0;
    self->matched_filter_enable_flag = 1;  /* enabled by default like C++ */
    self->voip_mode_enable = 0;
    self->delay_default = 0;
    self->CastScreen = 0;
    self->aec_low_compute_mode = 0;
    self->earphone_capture_mode_flag = 0;
    self->fixed_delay_blocks = -1;  /* 默认自动延时估计 */
}

/* ================================================================
 * BlockProcessor_BufferRender
 * ================================================================ */
void BlockProcessor_BufferRender(BlockProcessor* self,
                                 const float render_block[][AEC3_BLOCK_SIZE],
                                 int num_bands) {
    self->render_event = RenderDelayBuffer_Insert(&self->render_delay_buffer,
                                                   render_block, num_bands,
                                                   1, 1);

    /* Feed render block to delay estimator for binary spectral correlation
     * via RenderDelayController (aligned with C++ version which calls
     * delay_controller_->BufferRenderBlock) */
    RenderDelayController_BufferRenderBlock(
        &self->render_delay_controller,
        render_block[0], AEC3_BLOCK_SIZE);

    self->render_properly_started = 1;
    RenderDelayController_LogRenderCall(&self->render_delay_controller);
}

/* ================================================================
 * BlockProcessor_ProcessCapture
 * ================================================================ */
void BlockProcessor_ProcessCapture(BlockProcessor* self,
                                   int echo_path_gain_change,
                                   int capture_signal_saturation,
                                   int apm_submodule_switch,
                                   float capture_block[][AEC3_BLOCK_SIZE],
                                   int num_bands,
                                   int echo_process_enable,
                                   int earphone_flag,
                                   int adm_mute) {
    EchoPathVariability echo_path_variability;
    DelayEstimate delay_out;
    int has_delay;
    int buffer_event;
#ifdef AEC3_PROFILE_MODULES
    double t_total_start, t0, t1;
    t_total_start = _prof_get_us();
#endif

    self->capture_call_counter++;

    if (self->render_properly_started) {
        if (!self->capture_properly_started) {
            self->capture_properly_started = 1;
            RenderDelayBuffer_Reset(&self->render_delay_buffer);
            RenderDelayController_Reset(&self->render_delay_controller, 1);
        }
    } else {
        return;
    }

    echo_path_variability.gain_change = echo_path_gain_change;
    echo_path_variability.delay_change = 0;  /* kNone */
    echo_path_variability.clock_drift = 0;

    /* Handle render buffer overrun from previous Insert call */
    if (self->render_event == RDB_EVENT_RENDER_OVERRUN &&
        self->render_properly_started) {
        echo_path_variability.delay_change = 3;  /* kBufferFlush */
        RenderDelayController_Reset(&self->render_delay_controller, 1);
    }
    /* Impl2: clear render_event immediately after overrun check */
    self->render_event = RDB_EVENT_NONE;

    /* Prepare capture processing — use local variable (Impl2 pattern) */
#ifdef AEC3_PROFILE_MODULES
    t0 = _prof_get_us();
#endif
    buffer_event = RenderDelayBuffer_PrepareCaptureProcessing(
                       &self->render_delay_buffer);
#ifdef AEC3_PROFILE_MODULES
    t1 = _prof_get_us();
    s_prof.render_buf_sum += (t1 - t0);
#endif

    /* Impl2: on underrun, only do lightweight delay_controller Reset(false) */
    if (buffer_event == RDB_EVENT_RENDER_UNDERRUN) {
        RenderDelayController_Reset(&self->render_delay_controller, 0);
    }
    /* Impl2: no ApiCallSkew handling */

    /* Get delay estimate */
#ifdef AEC3_PROFILE_MODULES
    t0 = _prof_get_us();
#endif

    if (self->fixed_delay_blocks >= 0) {
        /* 固定延时模式: 跳过延时估计(MatchedFilter+频谱互相关), 直接设置延时 */
        has_delay = 0;
        if (!self->has_estimated_delay) {
            /* 首次: 用固定延时初始化 */
            delay_out.delay = self->fixed_delay_blocks;
            delay_out.quality = 2;  /* kRefined */
            has_delay = 1;
        }
        /* 后续帧不再更新延时, 保持首次设置的值 */
    } else {
        has_delay = RenderDelayController_GetDelay(
            &self->render_delay_controller,
            RenderDelayBuffer_GetDownsampledRenderBuffer(&self->render_delay_buffer),
            RenderDelayBuffer_Delay(&self->render_delay_buffer),
            -1, 0,  /* no echo remover delay */
            capture_block[0], AEC3_BLOCK_SIZE,
            self->earphone_capture_mode_flag,
            self->voip_mode_enable,
            self->delay_default,
            self->CastScreen,
            self->matched_filter_enable_flag,
            self->aec_low_compute_mode,
            &delay_out);
    }

    if (has_delay) {
#ifdef AEC3_PROFILE_MODULES
        t1 = _prof_get_us();
        s_prof.delay_est_sum += (t1 - t0);
#endif
        self->estimated_delay = delay_out;
        self->has_estimated_delay = 1;

        delay_dump_write(delay_out.delay);

        /* Impl2: no CausalDelay check, directly SetDelay with actual params */
        {
            int delay_changed = RenderDelayBuffer_SetDelay(
                &self->render_delay_buffer, delay_out.delay,
                self->delay_default, 0);
            if (delay_changed) {
                echo_path_variability.delay_change = 1;  /* kNewDetectedDelay */
            }
        }
    } else {
#ifdef AEC3_PROFILE_MODULES
        t1 = _prof_get_us();
        s_prof.delay_est_sum += (t1 - t0);
#endif
        int prev_delay = self->has_estimated_delay ? self->estimated_delay.delay : 0;
        delay_dump_write(prev_delay);
    }

    echo_path_variability.clock_drift =
        RenderDelayController_HasClockdrift(&self->render_delay_controller);

    /* Run echo remover — always use 512fft PFDKF path */
    if (echo_process_enable) {
#ifdef AEC3_PROFILE_MODULES
        t0 = _prof_get_us();
        g_prof_subtractor_us = 0;
        g_prof_nlp_us = 0;
#endif
        EchoRemover_ProcessCapture_512fft_Pfdkf(
            &self->echo_remover,
            echo_path_variability,
            capture_signal_saturation,
            apm_submodule_switch,
            self->has_estimated_delay ? &self->estimated_delay : NULL,
            self->has_estimated_delay,
            RenderDelayBuffer_GetRenderBuffer(&self->render_delay_buffer),
            capture_block, num_bands,
            echo_process_enable);
#ifdef AEC3_PROFILE_MODULES
        t1 = _prof_get_us();
        s_prof.echo_remover_sum += (t1 - t0);
        s_prof.subtractor_sum += g_prof_subtractor_us;
        s_prof.nlp_sum += g_prof_nlp_us;
#endif
    }
#ifdef AEC3_PROFILE_MODULES
    s_prof.total_sum += (_prof_get_us() - t_total_start);
    s_prof.count++;
#endif
}
/* ================================================================
 * BlockProcessor_SetAudioBufferDelay
 * ================================================================ */
void BlockProcessor_SetAudioBufferDelay(BlockProcessor* self, int delay_ms) {
    RenderDelayBuffer_SetAudioBufferDelay(&self->render_delay_buffer, delay_ms);
}

/* ================================================================
 * BlockProcessor_SetFixedDelay
 * ================================================================ */
void BlockProcessor_SetFixedDelay(BlockProcessor* self, int fixed_delay_blocks) {
    self->fixed_delay_blocks = fixed_delay_blocks;
}
