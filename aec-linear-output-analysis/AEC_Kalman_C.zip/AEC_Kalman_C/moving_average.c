/*
 *  Moving Average - Pure C Version
 *
 *  Fixed-window moving average computation for spectral smoothing.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "moving_average.h"
#include <string.h>
#include <assert.h>

void MovingAverage_Init(MovingAverage* self, int num_elem, int mem_len) {
    assert(self != NULL);
    assert(num_elem > 0 && num_elem <= MOVING_AVG_MAX_ELEM);
    assert(mem_len > 0 && mem_len <= MOVING_AVG_MAX_MEM_LEN);

    self->num_elem = num_elem;
    self->num_elem_long = 257;  /* AEC3_FFT_LENGTH_LONG_BY2_PLUS1 */
    self->mem_len = mem_len - 1;  /* store mem_len-1 previous frames */
    self->scaling = 1.0f / (float)mem_len;
    self->mem_index = 0;

    memset(self->memory, 0, sizeof(self->memory));
    memset(self->memory_long, 0, sizeof(self->memory_long));
}

void MovingAverage_Average(MovingAverage* self,
                           const float* input, float* output) {
    int i, m;
    int ne = self->num_elem;

    assert(self != NULL);

    /* Start with current input */
    memcpy(output, input, sizeof(float) * (size_t)ne);

    /* Sum all previous frames stored in memory */
    for (m = 0; m < self->mem_len; ++m) {
        const float* mem_ptr = self->memory + m * ne;
        for (i = 0; i < ne; ++i) {
            output[i] += mem_ptr[i];
        }
    }

    /* Scale by 1/total_window_length */
    for (i = 0; i < ne; ++i) {
        output[i] *= self->scaling;
    }

    /* Update memory with current input */
    if (self->mem_len > 0) {
        memcpy(self->memory + self->mem_index * ne,
               input, sizeof(float) * (size_t)ne);
        self->mem_index = (self->mem_index + 1) % self->mem_len;
    }
}

void MovingAverage_Average512(MovingAverage* self,
                              const float* input, float* output) {
    int i, m;
    int ne = self->num_elem_long;  /* 257 */

    assert(self != NULL);

    /* Start with current input */
    memcpy(output, input, sizeof(float) * (size_t)ne);

    /* Sum all previous frames stored in memory_long */
    for (m = 0; m < self->mem_len; ++m) {
        const float* mem_ptr = self->memory_long + m * ne;
        for (i = 0; i < ne; ++i) {
            output[i] += mem_ptr[i];
        }
    }

    /* Scale */
    for (i = 0; i < ne; ++i) {
        output[i] *= self->scaling;
    }

    /* Update memory_long with current input */
    if (self->mem_len > 0) {
        memcpy(self->memory_long + self->mem_index * ne,
               input, sizeof(float) * (size_t)ne);
        self->mem_index = (self->mem_index + 1) % self->mem_len;
    }
}
