/*
 *  BlockProcessor - Pure C Version
 *
 *  Block-level scheduler: coordinates RenderDelayBuffer,
 *  RenderDelayController, and EchoRemover for 64-sample blocks.
 *  Ported from WebRTC AEC3 C++ BlockProcessor class.
 *  Original copyright (c) 2016 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords.
 */

#ifndef BLOCK_PROCESSOR_H_
#define BLOCK_PROCESSOR_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "render_delay_buffer.h"
#include "render_delay_controller.h"
#include "echo_remover.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * BlockProcessor
 *
 * Manages the block-level processing pipeline:
 *   1. BufferRender: inserts render blocks into RenderDelayBuffer
 *   2. ProcessCapture: aligns render/capture via delay controller,
 *      then passes to EchoRemover for echo cancellation
 * ================================================================ */
typedef struct {
    Aec3Config              config;
    int                     sample_rate_hz;
    int                     num_bands;

    RenderDelayBuffer       render_delay_buffer;
    RenderDelayController   render_delay_controller;
    EchoRemover             echo_remover;

    int     capture_properly_started;
    int     render_properly_started;
    int     render_event;           /* RDB_EVENT_* code */
    int     capture_call_counter;

    /* Delay estimate state */
    DelayEstimate   estimated_delay;
    int             has_estimated_delay;

    /* 512fft PFDKF enable flag (0=use 128-point path, 1=use 512fft PFDKF path) */
    int             aec_512fft_enable;

    /* Render buffer size (dynamically configurable, default AEC3_RENDER_BUFFER_SIZE) */
    int             render_buffer_size;

    /* Pre-allocated memory for render delay buffer ring buffers (pointer-based) */
    float*          blocks_mem;     /* render_buffer_size * num_bands * AEC3_BLOCK_SIZE */
    float*          spectra_mem;    /* render_buffer_size * 257 (PFDKF only) */
    FftDataPfdkf*   ffts2_mem;      /* render_buffer_size * FftDataPfdkf */

    /* Typed FftBuffer instance for PFDKF (fft_buffer_128 removed) */
    FftBufferPfdkf  fft_buffer_pfdkf;
    float*          low_rate_mem;       /* downsampled render buffer (dynamic size) */
    int             low_rate_size;      /* actual lr_size from config */
    float*          binary_dyn_mem;     /* binary delay estimator dynamic arrays */

    /* Delay estimation control flags (aligned with C++ BlockProcessorImpl2) */
    int             matched_filter_enable_flag;
    int             voip_mode_enable;
    int             delay_default;
    int             CastScreen;
    int             aec_low_compute_mode;
    int             earphone_capture_mode_flag;

    /* 固定延时模式: >=0 表示使用外部指定延时(blocks), <0 表示自动延时估计 */
    int             fixed_delay_blocks;
} BlockProcessor;

/**
 * Initialize the block processor.
 *
 * @param self              Pointer to block processor
 * @param config            AEC3 configuration
 * @param sample_rate_hz    Sample rate in Hz
 * @param render_buffer_size Ring buffer slot count (0 = use default AEC3_RENDER_BUFFER_SIZE)
 * @param blocks_mem        Pre-allocated memory for time-domain ring buffer
 * @param spectra_mem       Pre-allocated memory for spectrum ring buffer (PFDKF only)
 * @param ffts2_mem         Pre-allocated memory for PFDKF FFT ring buffer
 * @param low_rate_mem      Pre-allocated memory for downsampled render buffer
 * @param low_rate_size     Size of downsampled render buffer (from config)
 * @param binary_dyn_mem    Pre-allocated memory for binary delay estimator
 */
void BlockProcessor_Init(BlockProcessor* self, const Aec3Config* config,
                         int sample_rate_hz, int render_buffer_size,
                         float* blocks_mem, float* spectra_mem,
                         FftDataPfdkf* ffts2_mem,
                         float* low_rate_mem, int low_rate_size,
                         float* binary_dyn_mem,
                         FftDataPfdkf* H_pf_mem,
                         FftDataPfdkf* H_pf_speed_mem,
                         FftDataPfdkf* H_pf_update_mem,
                         float* H2_pf_update_mem,
                         FftDataPfdkf* G_pfdkf_mem,
                         FftDataPfdkf* G_pfdkf_speed_mem,
                         float* H_error_pfdkf_mem,
                         int aec_H_usage);

/**
 * Buffer a render block.
 *
 * @param self          Pointer to block processor
 * @param render_block  Render block [num_bands][AEC3_BLOCK_SIZE]
 * @param num_bands     Number of frequency bands
 */
void BlockProcessor_BufferRender(BlockProcessor* self,
                                 const float render_block[][AEC3_BLOCK_SIZE],
                                 int num_bands);

/**
 * Process a capture block.
 *
 * @param self                      Pointer to block processor
 * @param echo_path_gain_change     Whether echo path gain changed
 * @param capture_signal_saturation Whether capture is saturated
 * @param apm_submodule_switch      Submodule switch flag
 * @param capture_block             Capture block [num_bands][AEC3_BLOCK_SIZE] (modified in-place)
 * @param num_bands                 Number of frequency bands
 * @param echo_process_enable       Whether echo processing is enabled
 * @param earphone_flag             Earphone mode flag
 * @param adm_mute                  ADM mute flag
 */
void BlockProcessor_ProcessCapture(BlockProcessor* self,
                                   int echo_path_gain_change,
                                   int capture_signal_saturation,
                                   int apm_submodule_switch,
                                   float capture_block[][AEC3_BLOCK_SIZE],
                                   int num_bands,
                                   int echo_process_enable,
                                   int earphone_flag,
                                   int adm_mute);

/**
 * Set the audio buffer delay from external source.
 *
 * @param self      Pointer to block processor
 * @param delay_ms  Delay in milliseconds
 */
void BlockProcessor_SetAudioBufferDelay(BlockProcessor* self, int delay_ms);

/**
 * Set fixed delay mode: skip internal delay estimation to save computation.
 *
 * @param self              Pointer to block processor
 * @param fixed_delay_blocks  >=0: use fixed delay (in blocks, 1 block ≈ 4ms);
 *                            <0: restore automatic delay estimation (default)
 */
void BlockProcessor_SetFixedDelay(BlockProcessor* self, int fixed_delay_blocks);

/**
 * Close the delay estimate dump file.
 */
void BlockProcessor_CloseDelayDump(void);

#ifdef AEC3_PROFILE_MODULES
void BlockProcessor_PrintProfile(void);
#endif

#ifdef __cplusplus
}
#endif

#endif /* BLOCK_PROCESSOR_H_ */
