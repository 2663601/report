/*
 *  EchoAudibility - Pure C Version
 *
 *  Estimates echo audibility based on render signal stationarity.
 *  Simplified pure C port from WebRTC AEC3 C++ EchoAudibility class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef ECHO_AUDIBILITY_H_
#define ECHO_AUDIBILITY_H_

#include "aec3_common.h"
#include "render_buffer.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * StationarityEstimator (simplified inline)
 *
 * Tracks per-band stationarity of the render signal using a
 * noise floor estimator and hangover counters.
 * ================================================================ */
typedef struct {
    float   noise_spectrum[AEC3_FFT_LENGTH_BY2_PLUS1];
    int     noise_block_counter;
    int     hangovers[AEC3_FFT_LENGTH_BY2_PLUS1];
    int     stationarity_flags[AEC3_FFT_LENGTH_BY2_PLUS1];
} StationarityEstimator;

/* ================================================================
 * EchoAudibility
 * ================================================================ */
typedef struct {
    int     use_render_stationarity_at_init;
    int     render_spectrum_write_prev;
    int     has_render_spectrum_write_prev;
    int     render_block_write_prev;
    int     non_zero_render_seen;

    StationarityEstimator render_stationarity;
} EchoAudibility;

/**
 * Initialize the echo audibility estimator.
 */
void EchoAudibility_Init(EchoAudibility* self,
                         int use_render_stationarity_at_init);

/**
 * Reset the echo audibility state.
 */
void EchoAudibility_Reset(EchoAudibility* self);

/**
 * Update the echo audibility with new render data.
 *
 * @param self                              Pointer to estimator
 * @param render_buffer                     Render buffer
 * @param render_reverb_contribution_spectrum  Reverb contribution (65 floats)
 * @param delay_blocks                      Current delay in blocks
 * @param external_delay_seen               Whether external delay has been seen
 */
void EchoAudibility_Update(EchoAudibility* self,
                           const RenderBuffer* render_buffer,
                           const float* render_reverb_contribution_spectrum,
                           int delay_blocks,
                           int external_delay_seen);

/**
 * Get the residual echo scaling per band.
 *
 * @param self                          Pointer to estimator
 * @param filter_has_had_time_to_converge  Whether filter has converged
 * @param residual_scaling              Output array (65 floats)
 */
void EchoAudibility_GetResidualEchoScaling(const EchoAudibility* self,
                                           int filter_has_had_time_to_converge,
                                           float* residual_scaling);

/**
 * Returns whether the current render block is stationary.
 */
int EchoAudibility_IsBlockStationary(const EchoAudibility* self);

#ifdef __cplusplus
}
#endif

#endif /* ECHO_AUDIBILITY_H_ */
