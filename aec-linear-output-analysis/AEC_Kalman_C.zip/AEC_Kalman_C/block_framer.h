/*
 *  Block Framer - Pure C Version
 *
 *  Converts 64-sample processing blocks back into 80-sample sub-frames.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#ifndef BLOCK_FRAMER_H_
#define BLOCK_FRAMER_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float   buffer[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE];
    int     buffer_count;   /* number of samples currently in buffer per band */
    int     num_bands;
} BlockFramer;

/* Initialize the block framer, clearing internal buffer. */
void BlockFramer_Init(BlockFramer* self, int num_bands);

/*
 * Insert a 64-sample block into the internal buffer (no output produced).
 * Used when buffering blocks before a sub-frame can be formed.
 *
 * block: input block, shape [num_bands][AEC3_BLOCK_SIZE]
 */
void BlockFramer_InsertBlock(BlockFramer* self,
                             const float block[][AEC3_BLOCK_SIZE],
                             int num_bands);

/*
 * Insert a 64-sample block and extract an 80-sample sub-frame.
 *
 * block:     input block, shape [num_bands][AEC3_BLOCK_SIZE]
 * sub_frame: output sub-frame, shape [num_bands][AEC3_SUB_FRAME_LENGTH]
 */
void BlockFramer_InsertBlockAndExtractSubFrame(
    BlockFramer* self,
    const float block[][AEC3_BLOCK_SIZE],
    float sub_frame[][AEC3_SUB_FRAME_LENGTH],
    int num_bands);

#ifdef __cplusplus
}
#endif

#endif /* BLOCK_FRAMER_H_ */
