/*
 *  AdaptiveFirFilter - Pure C Implementation
 *
 *  Ported from WebRTC AEC3 C++ AdaptiveFirFilter class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords. Generic (non-SIMD) implementation.
 *  128-point filter code removed — only PFDKF path retained.
 */

#include "adaptive_fir_filter.h"
#include "render_buffer.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <assert.h>

/* ================================================================
 * Internal helpers
 * ================================================================ */

static int min_int(int a, int b) {
    return (a < b) ? a : b;
}

/* ================================================================
 * UpdateFrequencyResponsePfdkf: H2[k*257+i] = H[k].relf[i]^2 + H[k].imlf[i]^2
 * H2 is a flat array with linear addressing [k * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + i]
 * ================================================================ */
static void UpdateFrequencyResponsePfdkf(
    const FftDataPfdkf* H,
    int num_partitions,
    float* H2)
{
    int k, i;
    for (k = 0; k < num_partitions; ++k) {
        float* H2_k = &H2[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1];
        for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
            H2_k[i] = H[k].relf[i] * H[k].relf[i] +
                       H[k].imlf[i] * H[k].imlf[i];
        }
    }
}

/* ================================================================
 * Public API Implementation
 * ================================================================ */

void AdaptiveFirFilter_Init(AdaptiveFirFilter* self,
                            int max_partitions,
                            int initial_partitions,
                            int size_change_duration,
                            FftDataPfdkf* H_pf_mem,
                            FftDataPfdkf* H_pf_speed_mem,
                            FftDataPfdkf* H_pf_update_mem,
                            float* H2_pf_update_mem,
                            int aec_H_usage)
{
    int k;
    assert(self != NULL);
    assert(max_partitions >= initial_partitions);
    assert(max_partitions <= AEC3_MAX_FILTER_PARTITIONS);
    assert(size_change_duration > 0);
    assert(H_pf_mem != NULL);
    assert(H_pf_speed_mem != NULL);
    assert(H_pf_update_mem != NULL);
    assert(H2_pf_update_mem != NULL);
    assert(aec_H_usage > 0);

    memset(self, 0, sizeof(AdaptiveFirFilter));

    self->max_size_partitions = max_partitions;
    self->current_size_partitions = initial_partitions;
    self->target_size_partitions = initial_partitions;
    self->old_target_size_partitions = initial_partitions;
    self->size_change_duration_blocks = size_change_duration;
    self->one_by_size_change_duration_blocks = 1.0f / (float)size_change_duration;
    self->size_change_counter = 0;

    self->partition_to_constrain = 0;
    self->mse_H = 0.0f;
    self->mse_H_cache = 0.0f;
    self->mse_y = 0.0f;
    self->is_H_cache_set = 0;
    self->aec_H_usage = aec_H_usage;

    /* Assign externally allocated PFDKF memory */
    self->H_pf = H_pf_mem;
    self->H_pf_speed = H_pf_speed_mem;
    self->H_pf_update = H_pf_update_mem;
    self->H2_pf_update = H2_pf_update_mem;
    self->max_pfdkf_partitions = aec_H_usage;

    /* Clear PFDKF arrays up to aec_H_usage */
    for (k = 0; k < aec_H_usage; ++k) {
        FftDataPfdkf_Clear(&self->H_pf[k]);
        FftDataPfdkf_Clear(&self->H_pf_speed[k]);
        FftDataPfdkf_Clear(&self->H_pf_update[k]);
        memset(&self->H2_pf_update[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1], 0,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    }
    self->pfdkf_partitions_count = 0;
}

void AdaptiveFirFilter_SetAecHUsage(AdaptiveFirFilter* self, int size)
{
    int k;
    assert(self != NULL);

    self->aec_H_usage = size;
    self->pfdkf_partitions_count = min_int(size, self->max_pfdkf_partitions);

    for (k = 0; k < self->pfdkf_partitions_count; ++k) {
        FftDataPfdkf_Clear(&self->H_pf[k]);
        FftDataPfdkf_Clear(&self->H_pf_speed[k]);
        FftDataPfdkf_Clear(&self->H_pf_update[k]);
        memset(&self->H2_pf_update[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1], 0,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    }
}

void AdaptiveFirFilter_HandleEchoPathChange(AdaptiveFirFilter* self)
{
    int k;
    assert(self != NULL);

    /* Reset PFDKF filter coefficients */
    for (k = 0; k < self->pfdkf_partitions_count; ++k) {
        FftDataPfdkf_Clear(&self->H_pf[k]);
        FftDataPfdkf_Clear(&self->H_pf_speed[k]);
        FftDataPfdkf_Clear(&self->H_pf_update[k]);
        memset(&self->H2_pf_update[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1], 0,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    }

    self->mse_H = 0.0f;
    self->mse_H_cache = 0.0f;
    self->mse_y = 0.0f;
}

void AdaptiveFirFilter_ScaleFilterPfdkf(AdaptiveFirFilter* self, float factor)
{
    int k, i;
    float factor2 = factor * factor;
    assert(self != NULL);

    for (k = 0; k < self->pfdkf_partitions_count; ++k) {
        for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
            self->H_pf[k].relf[i] *= factor;
            self->H_pf[k].imlf[i] *= factor;
        }
        for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
            self->H_pf_speed[k].relf[i] *= factor;
            self->H_pf_speed[k].imlf[i] *= factor;
        }
        for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
            self->H_pf_update[k].relf[i] *= factor;
            self->H_pf_update[k].imlf[i] *= factor;
        }
        {
            float* H2_k = &self->H2_pf_update[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1];
            for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
                H2_k[i] *= factor2;
            }
        }
    }
}

void AdaptiveFirFilter_SetHPfUpdate(AdaptiveFirFilter* self)
{
    int k;
    assert(self != NULL);
    for (k = 0; k < self->pfdkf_partitions_count; ++k) {
        memcpy(self->H_pf_update[k].relf, self->H_pf[k].relf,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
        memcpy(self->H_pf_update[k].imlf, self->H_pf[k].imlf,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    }
}

void AdaptiveFirFilter_UpdateHPfupdate(AdaptiveFirFilter* self, int index)
{
    int k;
    assert(self != NULL);
    assert(index >= 0 && index < AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    for (k = 0; k < self->pfdkf_partitions_count; ++k) {
        self->H_pf_update[k].relf[index] = self->H_pf_speed[k].relf[index];
        self->H_pf_update[k].imlf[index] = self->H_pf_speed[k].imlf[index];
    }
}

void AdaptiveFirFilter_ComputeH2PfResponse(AdaptiveFirFilter* self)
{
    assert(self != NULL);
    UpdateFrequencyResponsePfdkf(self->H_pf_update,
                                 self->pfdkf_partitions_count,
                                 self->H2_pf_update);
}


/* ================================================================
 * ApplyFilterPfdkf: S = sum_j( X_j * H_j ) using SoA layout
 *
 * PFDKF variant. Steps through the render buffer
 * with AEC3_LF_BLOCK_SHIFT stride instead of 1.
 * Hot path: uses SoA relf_buf/imlf_buf for cache-friendly access.
 * ================================================================ */
static void ApplyFilterPfdkf(const FftBufferPfdkf* fft_buf,
                             int position,
                             int fft_buf_size,
                             const FftDataPfdkf* H,
                             int num_partitions,
                             int aec_H_usage,
                             FftDataPfdkf* S)
{
    int j, k, index;
    int H_size;

    memset(S->relf, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memset(S->imlf, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);

    H_size = num_partitions < (int)aec_H_usage ? num_partitions : (int)aec_H_usage;
    index = position;

    for (j = 0; j < H_size; ++j) {
        /* SoA access: get relf/imlf pointers for this slot */
        const float* X_relf;
        const float* X_imlf;
        FftBufferPfdkf_GetSlot(fft_buf, index, &X_relf, &X_imlf);

        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            S->relf[k] += X_relf[k] * H[j].relf[k] - X_imlf[k] * H[j].imlf[k];
            S->imlf[k] += X_relf[k] * H[j].imlf[k] + X_imlf[k] * H[j].relf[k];
        }
        index = index + AEC3_LF_BLOCK_SHIFT;
        index = index < fft_buf_size ? index : index % fft_buf_size;
    }
}

/* ================================================================
 * AdaptPartitionsPfdkfImpl: H_pf_j += G_j * conj(X_j) using SoA render buf
 *
 * Per-partition adaptation in PFDKF domain.
 * Steps through the render buffer with AEC3_LF_BLOCK_SHIFT stride.
 * Hot path: uses SoA relf_buf/imlf_buf for cache-friendly access.
 * ================================================================ */
static void AdaptPartitionsPfdkfImpl(const FftBufferPfdkf* fft_buf,
                                     int position,
                                     int fft_buf_size,
                                     const FftDataPfdkf* G,
                                     FftDataPfdkf* H_pf,
                                     int num_partitions,
                                     int aec_H_usage)
{
    int i, k, index;
    int H_size;

    H_size = num_partitions < (int)aec_H_usage ? num_partitions : (int)aec_H_usage;
    index = position;

    for (i = 0; i < H_size; ++i) {
        const float* X_relf;
        const float* X_imlf;
        FftBufferPfdkf_GetSlot(fft_buf, index, &X_relf, &X_imlf);

        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            H_pf[i].relf[k] += X_relf[k] * G[i].relf[k] + X_imlf[k] * G[i].imlf[k];
            H_pf[i].imlf[k] += X_relf[k] * G[i].imlf[k] - X_imlf[k] * G[i].relf[k];
        }
        index = index + AEC3_LF_BLOCK_SHIFT;
        index = index < fft_buf_size ? index : index % fft_buf_size;
    }
}

/* ================================================================
 * FilterPfdkf: convolve H_pf and H_pf_speed with render PFDKF data
 * ================================================================ */
void AdaptiveFirFilter_FilterPfdkf(const AdaptiveFirFilter* self,
                                   const RenderBuffer* render_buffer,
                                   FftDataPfdkf* S,
                                   FftDataPfdkf* S_speed)
{
    const FftBufferPfdkf* fft_buf;
    int position;
    int fft_buf_size;

    assert(self != NULL);
    assert(render_buffer != NULL);
    assert(S != NULL);
    assert(S_speed != NULL);

    fft_buf = render_buffer->fft_buffer_pfdkf;
    position = render_buffer->fft_buffer_pfdkf->read;
    fft_buf_size = render_buffer->fft_buffer_pfdkf->size;

    ApplyFilterPfdkf(fft_buf, position, fft_buf_size,
                     self->H_pf, self->pfdkf_partitions_count,
                     self->aec_H_usage, S);

    ApplyFilterPfdkf(fft_buf, position, fft_buf_size,
                     self->H_pf_speed, self->pfdkf_partitions_count,
                     self->aec_H_usage, S_speed);
}

/* ================================================================
 * AdaptPfdkf: update H_pf and H_pf_speed using per-partition gains
 *
 * First resets H_pf and H_pf_speed from H_pf_update snapshot,
 * then adapts both using the provided gain vectors.
 * ================================================================ */
void AdaptiveFirFilter_AdaptPfdkf(AdaptiveFirFilter* self,
                                  const RenderBuffer* render_buffer,
                                  const FftDataPfdkf* G,
                                  const FftDataPfdkf* G_speed,
                                  int num_partitions)
{
    const FftBufferPfdkf* fft_buf;
    int position;
    int fft_buf_size;
    int i;

    assert(self != NULL);
    assert(render_buffer != NULL);
    assert(G != NULL);
    assert(G_speed != NULL);

    /* Reset H_pf and H_pf_speed from H_pf_update snapshot (AssignPfdkf) */
    for (i = 0; i < self->pfdkf_partitions_count; ++i) {
        memcpy(self->H_pf[i].relf, self->H_pf_update[i].relf,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
        memcpy(self->H_pf[i].imlf, self->H_pf_update[i].imlf,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
        memcpy(self->H_pf_speed[i].relf, self->H_pf_update[i].relf,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
        memcpy(self->H_pf_speed[i].imlf, self->H_pf_update[i].imlf,
               sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    }

    fft_buf = render_buffer->fft_buffer_pfdkf;
    position = render_buffer->fft_buffer_pfdkf->read;
    fft_buf_size = render_buffer->fft_buffer_pfdkf->size;

    /* Adapt H_pf using G */
    AdaptPartitionsPfdkfImpl(fft_buf, position, fft_buf_size,
                             G, self->H_pf,
                             self->pfdkf_partitions_count,
                             self->aec_H_usage);

    /* Adapt H_pf_speed using G_speed */
    AdaptPartitionsPfdkfImpl(fft_buf, position, fft_buf_size,
                             G_speed, self->H_pf_speed,
                             self->pfdkf_partitions_count,
                             self->aec_H_usage);
}
