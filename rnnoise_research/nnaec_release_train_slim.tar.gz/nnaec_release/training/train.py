#! /usr/bin/env python3
# -*- coding:utf-8 -*-
# Author:   LiPingping
# Time:     2021/11/09
# Desc:     Main training scripts.
import os
import sys
import json
import toml
import torch
import argparse
import multiprocessing
from pathlib import Path

from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import ReduceLROnPlateau

from pytorch_lightning import Trainer
from pytorch_lightning.loggers import CSVLogger, TensorBoardLogger
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping, ModelSummary

sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..")))
import acore.optimizer as optimizer_class
from acore.utils import prepare_utils, initialize_module


# torch.set_float32_matmul_precision('medium')

def main(conf):
    # 产物目录带启动时间戳, 避免同名实验/重跑互相覆盖或混在一个文件夹。
    # 结构: ../exp/{save_dir}/{tag}_{YYYYmmdd-HHMMSS}/checkpoints/
    import time
    run_stamp = time.strftime("%Y%m%d-%H%M%S")
    exp_dir = Path("../exp") / conf["meta"]["save_dir"] / f"{conf['meta']['tag']}_{run_stamp}"
    exp_dir.mkdir(parents=True, exist_ok=True)
    print(f"I: 本次训练产物目录 = {exp_dir}")

    # 存一份本次运行的关键配置快照(run_info.txt), 方便回溯"这批 ckpt 用什么配置训的"。
    try:
        with open(exp_dir / "run_info.txt", "w") as f:
            f.write(f"run_stamp: {run_stamp}\n")
            f.write(f"tag: {conf['meta']['tag']}\n")
            f.write(f"loss: {conf.get('loss_function', {}).get('path', '?')}\n")
            # 过滤掉 prepare_utils 注入的 window 张量(避免打印一大串浮点)
            _la = {k: v for k, v in conf.get('loss_function', {}).get('args', {}).items()
                   if k not in ("window", "window_type")}
            f.write(f"loss_args: {_la}\n")
            f.write(f"optimizer: {conf.get('optimizer', {})}\n")
            f.write(f"model: {conf.get('model', {}).get('path', '?')}\n")
            f.write(f"model_args: {conf.get('model', {}).get('args', {})}\n")
            f.write(f"train_dataset: {conf.get('train_dataset', {}).get('path', '?')}\n")
            f.write(f"train_dataset_args: {conf.get('train_dataset', {}).get('args', {})}\n")
            f.write(f"trainer_args: {conf.get('trainer', {}).get('args', {})}\n")
    except Exception as e:
        print("W: 写 run_info.txt 失败(不影响训练):", e)

    # Datasets preparation.
    datasets = initialize_module(conf["train_dataset"]["path"], args=conf["train_dataset"]["args"])
    validate_size = int(len(datasets) * conf["validation_dataset"]["args"]["split_ratio"])
    train_size = len(datasets) - validate_size
    print("D: training&dev dataset size = （{}，{}).".format(train_size, validate_size))
    # 固定 split 种子, 保证 train/val 划分可复现
    _split_gen = torch.Generator().manual_seed(int(conf.get("meta", {}).get("seed", 0)))
    train_dataset, vali_dataset = torch.utils.data.random_split(
        datasets, [train_size, validate_size], generator=_split_gen)

    # ★ 验证集不走数据增广(online_augment): 增广是训练期随机扰动, 混进 val 会让 val_loss
    #   每 epoch 不可比, 且增广的数值风险(如 EQ 爆值)会污染验证。做法: 若数据集支持
    #   online_augment, 另建一个"关增广"的同类实例, 用同一套 split 索引取 val 子集,
    #   与 train 子集严格不重叠。不支持该属性的数据集(如在线合成 Dataset)保持原行为。
    if getattr(datasets, "online_augment", False):
        import copy as _copy
        val_base = initialize_module(conf["train_dataset"]["path"],
                                     args={**conf["train_dataset"]["args"], "online_augment": False})
        vali_dataset = torch.utils.data.Subset(val_base, list(vali_dataset.indices))
        print("I: 验证集使用关增广的独立数据集实例(online_augment=False)。")

    train_dataloader = DataLoader(dataset=train_dataset, **conf["train_dataset"]["dataloader"])
    valid_dataloader = DataLoader(dataset=vali_dataset, **conf["validation_dataset"]["dataloader"])

    # Model Init.
    model = initialize_module(conf["model"]["path"], args=conf["model"]["args"])

    # ★ 可选 warm-start: 从已训练 ckpt/pth 加载 model.* 权重做微调/迁移(优化器/epoch 从头)。
    #   配置: [trainer].init_ckpt = "../exp/.../xxx.ckpt"; 留空或不写=从头训练(原行为)。
    #   用 strict=False 容忍 system buffer 差异; 务必看打印的 missing/unexpected 数:
    #   结构不匹配(如 band64 ckpt 灌 band32 模型)会大面积 missing, 等于没加载。
    #   与完整 resume(resume_ckpt)的区别: warm-start 只灌权重, 不恢复优化器/epoch/lr。
    init_ckpt = conf.get("trainer", {}).get("init_ckpt", "")
    if init_ckpt:
        print(f"I: warm-start 加载预训练权重: {init_ckpt}")
        _ck = torch.load(init_ckpt, map_location="cpu")
        _sd = _ck.get("state_dict", _ck) if isinstance(_ck, dict) else _ck
        _model_sd = {k.replace("model.", "", 1): v for k, v in _sd.items()
                     if k.startswith("model.")}
        if not _model_sd:  # ckpt 可能直接就是裸 model state_dict(无 model. 前缀)
            _model_sd = _sd
        _missing, _unexpected = model.load_state_dict(_model_sd, strict=False)
        print(f"I: warm-start done. missing={len(_missing)}, unexpected={len(_unexpected)}")
        if len(_missing) > 0:
            print(f"   W: missing keys(前10): {list(_missing)[:10]}")
            print("   W: missing 多说明结构不匹配, 请确认 ckpt 与当前 model 结构一致。")

    # Optimizer & Scheduler
    optimizer = getattr(optimizer_class, conf["optimizer"]["name"])(params=model.parameters(),
                                                                    **conf["optimizer"]["args"])
    scheduler = ReduceLROnPlateau(optimizer=optimizer, **conf["trainer"]["scheduler"])

    # Loss function.
    loss_function = initialize_module(conf["loss_function"]["path"], args=conf["loss_function"]["args"])
    # loss_function = getattr(loss, conf["loss_function"]["name"])(**conf["loss_function"]["args"])

    # Callbacks
    modelsummary = ModelSummary(max_depth=3)
    earlystop = EarlyStopping(**conf["trainer"]["earlystop"])
    checkpoint = ModelCheckpoint(dirpath=exp_dir / "checkpoints/", **conf["trainer"]["checkpoint"])

    # Logger
    # csvlogger = CSVLogger(exp_dir/ "logs/csv", name=conf["meta"]["tag"])
    logger = TensorBoardLogger(exp_dir / "logs", name=conf["meta"]["tag"])

    # Trainer configs.
    system_args = dict({"model": model, "optimizer": optimizer, "loss_func": loss_function,
                        "train_loader": train_dataloader, "val_loader": valid_dataloader,
                        "scheduler": scheduler, "monitor": "val_loss", "config": None, }, **conf["system"]["args"], **conf["model"]["args"])
    system = initialize_module(conf["system"]["path"], args=system_args)

    trainer = Trainer(callbacks=[checkpoint, earlystop, modelsummary], logger=[logger], **conf["trainer"]["args"])

    # ★ 可选完整 resume(断点续训): 恢复权重+优化器+lr+epoch 计数, 从上次中断处接着训。
    #   配置: [trainer].resume_ckpt = "../exp/.../xxx.ckpt"; 留空或不写=正常训练(原行为)。
    #   与 warm-start(init_ckpt)的区别: resume 要求配置/结构一致, 且 max_epochs 需比原来大才有意义;
    #   warm-start 只灌权重做微调。二者一般二选一(同时配时 resume 的优化器状态会覆盖 warm-start)。
    resume_ckpt = conf.get("trainer", {}).get("resume_ckpt", "")
    if resume_ckpt:
        print(f"I: 完整 resume 断点续训: {resume_ckpt}")
    trainer.fit(system, ckpt_path=resume_ckpt if resume_ckpt else None)

    # Save results & best models.
    best_k = {k: v.item() for k, v in checkpoint.best_k_models.items()}
    with open(exp_dir / "best_k_models.json", "w") as f:
        json.dump(best_k, f, indent=0)
    print("I: The best checkpoint to save: {}".format(checkpoint.best_model_path))
    state_dict = torch.load(checkpoint.best_model_path)
    # 只取属于 model.* 的权重; system 的 buffer(window/loss_func.window/erb.B/erb.Bt)不属于 model,
    # 用 strict=False 忽略这些多余 key, 避免 "Unexpected key(s)" 报错。
    model_sd = {k.replace("model.", "", 1): v
                for k, v in state_dict["state_dict"].items() if k.startswith("model.")}
    system.model.load_state_dict(state_dict=model_sd, strict=False)
    system.model.cpu()
    torch.save(state_dict, exp_dir / "best_model.pth")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Speech Algorithm")
    parser.add_argument("-C", "--configuration", required=False,
                        default="conf/aes16k/aesfs16_240829_baselinerf_bpbgcl2m_300hdev2slim_dsebeta.toml",
                        type=str, help="Configuration (*.toml).")
    parser.add_argument("-D", "-d", "--devices", type=list, default=[2],
                        help="The device of GPUs you are using for training.")
    # parser.add_argument("-R", "--resume", action="store_true", help="Resume the experiment from frozen checkpoint.")

    args = parser.parse_args()
    conf = toml.load(args.configuration)

    conf["meta"]["tag"] = Path(args.configuration).stem
    # conf["meta"]["gpus"] = list(map(int, args.devices))
    # print("D:  device selected: ", conf["meta"]["gpus"])
    # conf["trainer"]["args"]["resume"] = args.resume
    conf["trainer"]["args"]["devices"] = list(map(int, args.devices))
    conf["train_dataset"]["dataloader"]["batch_size"] *= len(conf["trainer"]["args"]["devices"])
    conf["validation_dataset"]["dataloader"]["batch_size"] = conf["train_dataset"]["dataloader"]["batch_size"]

    print("I: toml config({})".format(conf))

    num_cpus = multiprocessing.cpu_count()
    print("I: the number of cpu cores: {}".format(num_cpus))

    prepare_utils(conf)
    main(conf)
