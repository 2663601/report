/*
 *  EchoRemover - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ EchoRemover class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *  128-point processing path removed — only 512fft PFDKF path retained.
 */

#include "echo_remover.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

/* ================================================================
 * Module profiling globals (written here, read by block_processor.c)
 * ================================================================ */
#ifdef AEC3_PROFILE_MODULES
#ifdef _WIN32
#include <windows.h>
static double _er_prof_get_us(void) {
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER cnt;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&cnt);
    return (double)cnt.QuadPart / (double)freq.QuadPart * 1e6;
}
#else
#include <time.h>
static double _er_prof_get_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e6 + ts.tv_nsec / 1e3;
}
#endif
double g_prof_subtractor_us = 0;
double g_prof_nlp_us = 0;
#endif /* AEC3_PROFILE_MODULES */

/* ================================================================
 * EchoRemover_Init
 * ================================================================ */
void EchoRemover_Init(EchoRemover* self, const Aec3Config* config,
                      int sample_rate_hz,
                      FftDataPfdkf* H_pf_mem,
                      FftDataPfdkf* H_pf_speed_mem,
                      FftDataPfdkf* H_pf_update_mem,
                      float* H2_pf_update_mem,
                      FftDataPfdkf* G_pfdkf_mem,
                      FftDataPfdkf* G_pfdkf_speed_mem,
                      float* H_error_pfdkf_mem,
                      int aec_H_usage) {
    memset(self, 0, sizeof(EchoRemover));
    self->config = *config;
    self->sample_rate_hz = sample_rate_hz;

    Aec3Fft_Init(&self->fft_512);

    Subtractor_Init(&self->subtractor, config,
                    G_pfdkf_mem, G_pfdkf_speed_mem,
                    H_error_pfdkf_mem,
                    H_pf_mem, H_pf_speed_mem, H_pf_update_mem,
                    H2_pf_update_mem, aec_H_usage);
    SuppressionGain_Init(&self->suppression_gain, config, sample_rate_hz);
    CNG_Init(&self->cng);
    SuppressionFilter_Init(&self->suppression_filter, sample_rate_hz);
    AecState_Init(&self->aec_state, config);
    RenderSignalAnalyzer_Init(&self->render_signal_analyzer, config);
    ResidualEchoEstimator_Init(&self->residual_echo_estimator, config);
    WebrtcAecNlp_Init(&self->webrtc_aec_nlp);

    self->block_counter = 0;
    self->gain_change_hangover = 0;
    self->linear_filter_output_last_selected = 1;
    self->accelerate = 1.0f;
    self->near_activity = 1.0f;
    self->music_flag = 0;
    self->echo_process_enable = 1;
    self->aec_CNG_level = 0;
    self->use_cache_filter = 1;
    self->use_noise_gate_division = 0;
    self->initial_sup_flag = 1;
    self->frame_cnt = 1;
    self->echo_possible = 0;

    /* 512fft PFDKF state initialization */
    memset(self->d_long, 0, sizeof(self->d_long));
    memset(self->x_long, 0, sizeof(self->x_long));
    memset(self->x_long_old, 0, sizeof(self->x_long_old));
    memset(self->out_buffer, 0, sizeof(self->out_buffer));
    self->suppress_cnt = 0;
    self->aec_nlp_level = 1.0f;
    self->S2_avg = 0.0f;
    self->echo_sup_factor = 0.0f;
    self->high_bands_gain = 1.0f;
    memset(&self->subtractor_output_frequency, 0, sizeof(self->subtractor_output_frequency));

    /* Runtime config defaults */
    AecRuntimeConfig_SetDefaults(&self->rt_config);
}

/* ================================================================
 * EchoRemover_ProcessCapture_512fft_Pfdkf
 *
 * 4-block NLP cycle using PFDKF 512-point FFT processing.
 * Full NLP when suppress_cnt >= 4, buffered output otherwise.
 * Uses FftDataPfdkf (relf/imlf) for all 512-point temporaries.
 * ================================================================ */
void EchoRemover_ProcessCapture_512fft_Pfdkf(
    EchoRemover* self,
    EchoPathVariability echo_path_variability,
    int capture_signal_saturation,
    int apm_submodule_switch,
    const DelayEstimate* external_delay,
    int has_external_delay,
    RenderBuffer* render_buffer,
    float capture[][AEC3_BLOCK_SIZE],
    int num_bands,
    int echo_process_enable) {

    float* y0 = capture[0];
    int k, i;
    FftDataPfdkf Y_long, E_long, S_long;
    FftDataPfdkf X_long;
    float high_bands_gain;

    (void)apm_submodule_switch;
    (void)external_delay;

    self->block_counter++;

    /* Dump delay-aligned render and raw capture to PCM files */
    if (access("enable_vqe_dump", 0) == 0)
    {
        static FILE* fp_render_aligned = NULL;
        static FILE* fp_capture_raw = NULL;
        if (!fp_render_aligned) {
            fp_render_aligned = fopen("render_aligned.pcm", "wb");
            fp_capture_raw = fopen("capture_raw.pcm", "wb");
        }
        if (fp_render_aligned) {
            const float* r0 = RenderBuffer_Block(render_buffer, 0, 0);
            int16_t tmp16[AEC3_BLOCK_SIZE];
            for (i = 0; i < AEC3_BLOCK_SIZE; i++) {
                float v = r0[i];
                if (v > 32767.f) v = 32767.f;
                if (v < -32768.f) v = -32768.f;
                tmp16[i] = (int16_t)v;
            }
            fwrite(tmp16, sizeof(int16_t), AEC3_BLOCK_SIZE, fp_render_aligned);
        }
        if (fp_capture_raw) {
            int16_t tmp16[AEC3_BLOCK_SIZE];
            for (i = 0; i < AEC3_BLOCK_SIZE; i++) {
                float v = y0[i];
                if (v > 32767.f) v = 32767.f;
                if (v < -32768.f) v = -32768.f;
                tmp16[i] = (int16_t)v;
            }
            fwrite(tmp16, sizeof(int16_t), AEC3_BLOCK_SIZE, fp_capture_raw);
        }
    }

    /* Handle echo path changes */
    if (echo_path_variability.gain_change || echo_path_variability.delay_change ||
        echo_path_variability.clock_drift) {
        if (echo_path_variability.gain_change) {
            if (self->gain_change_hangover == 0) {
                self->gain_change_hangover = 3;
            } else {
                echo_path_variability.gain_change = 0;
            }
        }
        Subtractor_HandleEchoPathChange(&self->subtractor, &echo_path_variability);
        AecState_HandleEchoPathChange(&self->aec_state, &echo_path_variability);
        if (echo_path_variability.delay_change != 0) {
            SuppressionGain_SetInitialState(&self->suppression_gain, 1);
        }
    }
    if (self->gain_change_hangover > 0) {
        self->gain_change_hangover--;
    }

    /* Analyze render signal (128-point, needed for subtractor) */
    RenderSignalAnalyzer_Update(&self->render_signal_analyzer,
                                render_buffer,
                                AecState_FilterDelayBlocks(&self->aec_state),
                                AecState_FilterDelayBlocks(&self->aec_state) >= 0,
                                self->residual_echo_estimator.X2_noise_floor);

    /* Append capture[0] to d_long tail */
    for (i = 0; i < AEC3_BLOCK_SIZE; i++) {
        self->d_long[AEC3_FFT_LENGTH_BY2 * 7 + i] = y0[i];
    }

    /* Save upper band input for 4-block NLP cycle */
    {
        int b, hb_offset;
        hb_offset = self->suppress_cnt * AEC3_BLOCK_SIZE;
        for (b = 1; b < num_bands; b++) {
            memcpy(&self->hband_in[b][hb_offset], capture[b],
                   AEC3_BLOCK_SIZE * sizeof(float));
        }
    }

    self->suppress_cnt++;

    if (self->suppress_cnt >= 4) {
        /* ============================================================
         * Full NLP cycle
         * ============================================================ */
        const float* render_block0;
        const float* render_block1;
        const float* render_block2;
        const float* render_block3;
        float y_long_buf[AEC3_FFT_LENGTH_LONG_BY2];
        float capture_out[AEC3_FFT_LENGTH_LONG_BY2];

        /* 1. Run PFDKF subtractor with update=1 */
#ifdef AEC3_PROFILE_MODULES
        { double _st = _er_prof_get_us();
#endif
        Subtractor_ProcessPfdkf(&self->subtractor, render_buffer,
                                y0, &self->subtractor_output_frequency, 1);
#ifdef AEC3_PROFILE_MODULES
        g_prof_subtractor_us += (_er_prof_get_us() - _st); }
#endif

        /* 2. Assemble 4 render blocks into x_long */
        render_block0 = RenderBuffer_Block(render_buffer, 0, 0);
        render_block1 = RenderBuffer_Block(render_buffer, -1, 0);
        render_block2 = RenderBuffer_Block(render_buffer, -2, 0);
        render_block3 = RenderBuffer_Block(render_buffer, -3, 0);
        for (i = 0; i < AEC3_FFT_LENGTH_BY2; i++) {
            self->x_long[i + AEC3_FFT_LENGTH_BY2 * 0] = render_block3[i];
            self->x_long[i + AEC3_FFT_LENGTH_BY2 * 1] = render_block2[i];
            self->x_long[i + AEC3_FFT_LENGTH_BY2 * 2] = render_block1[i];
            self->x_long[i + AEC3_FFT_LENGTH_BY2 * 3] = render_block0[i];
        }

        /* 3. Copy subtractor output to FftDataPfdkf temporaries (relf/imlf) */
        FftDataPfdkf_Clear(&Y_long);
        FftDataPfdkf_Clear(&E_long);
        FftDataPfdkf_Clear(&S_long);
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            Y_long.relf[k] = self->subtractor_output_frequency.Y.relf[k];
            Y_long.imlf[k] = self->subtractor_output_frequency.Y.imlf[k];
            E_long.relf[k] = self->subtractor_output_frequency.E_out.relf[k];
            E_long.imlf[k] = self->subtractor_output_frequency.E_out.imlf[k];
            S_long.relf[k] = self->subtractor_output_frequency.S_out.relf[k];
            S_long.imlf[k] = self->subtractor_output_frequency.S_out.imlf[k];
        }

        /* 4. Execute PaddedFft512 on x_long to get X_long */
        Aec3Fft_PaddedFft512_typed(&self->fft_512, self->x_long,
                              self->x_long_old, AEC3_WINDOW_SQRT_HANNING,
                              &X_long);
        memcpy(self->x_long_old, self->x_long,
               AEC3_FFT_LENGTH_LONG_BY2 * sizeof(float));

        /* 5. Copy power spectra from subtractor_output_frequency */
        memcpy(self->S2_linear_long,
               self->subtractor_output_frequency.S2_out,
               AEC3_FFT_LENGTH_LONG_BY2_PLUS1 * sizeof(float));
        memcpy(self->Y2_long,
               self->subtractor_output_frequency.Y2,
               AEC3_FFT_LENGTH_LONG_BY2_PLUS1 * sizeof(float));
        memcpy(self->E2_long,
               self->subtractor_output_frequency.E2_out,
               AEC3_FFT_LENGTH_LONG_BY2_PLUS1 * sizeof(float));

        /* 6. Compute X2_long power spectrum from X_long */
#ifdef AEC3_PROFILE_MODULES
        { double _nlp_st = _er_prof_get_us();
#endif
        {
            float X2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
            SubtractorOutput dummy_sub_output;

            memset(&dummy_sub_output, 0, sizeof(dummy_sub_output));

            FftDataPfdkf_Spectrum(&X_long, X2_long);

            /* 7. Update render signal analyzer (512fft) */
            RenderSignalAnalyzer_Update512fft(&self->render_signal_analyzer, X2_long);

            /* 8. Update ERLE */
            AecState_UpdateErle(&self->aec_state, &dummy_sub_output,
                                self->E2_long, self->Y2_long, X2_long);

            /* 9. Update echo saturation */
            AecState_UpdateEchoSaturation(&self->aec_state,
                                          capture_signal_saturation,
                                          self->S2_linear_long,
                                          self->E2_long, self->Y2_long);

            /* 9a. Update reverb decay from PFDKF filter H2 */
            if (self->rt_config.enable_echo_reverb) {
                AecState_UpdateReverbDecayPfdkf(
                    &self->aec_state,
                    self->subtractor.main_filter.H2_pf_update,
                    self->subtractor.main_filter.pfdkf_partitions_count);
            }

            /* 9b. Update reverb frequency response (257-bin) from PFDKF H2 */
            if (self->rt_config.enable_echo_reverb) {
                ReverbFrequencyResponseLong_Update(
                    &self->aec_state.reverb_model_estimator.reverb_freq_resp_long,
                    self->subtractor.main_filter.H2_pf_update,
                    self->subtractor.main_filter.pfdkf_partitions_count,
                    AecState_FilterDelayBlocks(&self->aec_state),
                    1.0f,  /* linear_filter_quality: PFDKF always active */
                    1,     /* has_quality: always available in PFDKF path */
                    EchoAudibility_IsBlockStationary(
                        &self->aec_state.echo_audibility));
            }

            /* 10. Estimate residual echo (512fft PFDKF) */
            {
                /* decay is stored as per-partition (each partition = AEC3_LF_BLOCK_SHIFT blocks).
                 * IIR reverb model runs per-NLP-cycle (4 blocks).
                 * Convert: decay_nlp = decay_partition ^ (4 / AEC3_LF_BLOCK_SHIFT) */
                float decay_per_partition = AecState_ReverbDecay(&self->aec_state);
                float reverb_decay = powf(decay_per_partition,
                                          4.0f / (float)AEC3_LF_BLOCK_SHIFT);
                int filter_tail_offset = self->subtractor.aec_H_usage *
                                         AEC3_LF_BLOCK_SHIFT + 1;
                const float* X2_reverb_tail =
                    (self->rt_config.enable_echo_reverb && reverb_decay > 0.0f)
                    ? RenderBuffer_SpectrumPfdkf(render_buffer, filter_tail_offset)
                    : NULL;
                const float* freq_response_tail_long =
                    (self->rt_config.enable_echo_reverb)
                    ? ReverbFrequencyResponseLong_GetResponse(
                          &self->aec_state.reverb_model_estimator.reverb_freq_resp_long)
                    : NULL;

                /* Sync enable_echo_reverb to ResidualEchoEstimator */
                self->residual_echo_estimator.enable_echo_reverb =
                    self->rt_config.enable_echo_reverb;

                ResidualEchoEstimator_Estimate512fftPfdkf(
                    &self->residual_echo_estimator,
                    self->S2_linear_long, self->Y2_long, self->E2_long,
                    X2_long,
                    AecState_ErleLong(&self->aec_state),
                    AecState_ErleLongGreater(&self->aec_state),
                    AecState_SaturatedEcho512fft(&self->aec_state),
                    self->rt_config.earphone_capture_mode,
                    self->rt_config.voip_mode_proc_enable,
                    self->rt_config.aec_level,
                    self->rt_config.extra_echo_sup,
                    0,  /* always 0: keep normal R2 behavior regardless of low_compute_mode */
                    self->subtractor.aec_H_usage,
                    has_external_delay,
                    reverb_decay,
                    X2_reverb_tail,
                    freq_response_tail_long,
                    self->R2_long);
            }

            /* 11. Compute comfort noise (512fft) */
            CNG_Compute512(&self->cng, &self->aec_state,
                           self->Y2_long,
                           &self->comfort_noise, &self->comfort_noise_high,
                           0, self->near_activity, self->music_flag);

            /* 12. Bounded nearend: clamp E2 to Y2 */
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                if (self->E2_long[k] > self->Y2_long[k]) {
                    self->E2_long[k] = self->Y2_long[k];
                }
            }

            /* 13. Compute suppression gain (512fft).
             *
             * Two code paths selected by rt_config.webrtc_aec_mode
             * (spec: aec-kalman-speex-nlp):
             *   0: AEC3 SuppressionGain_GetGain512 (baseline, preserves scoring)
             *   1: Speex-style WebrtcAecNlp_Process (coherence + overdrive NLP)
             *
             * Speex path needs time-domain e/d for windowed FFT:
             *   - e_time_256: IFFT(E_long), using EchoRemover::fft_512
             *   - d_time_256: last 256 samples of d_long (current NLP cycle mic)
             * Xfw reuses X_long (already PaddedFft512'd above).
             */
            if (self->rt_config.webrtc_aec_mode == 1) {
                float e_time_256[AEC3_FFT_LENGTH_LONG_BY2];
                float d_time_256[AEC3_FFT_LENGTH_LONG_BY2];
                float e_extended[AEC3_FFT_LENGTH_LONG];
                float gain_min = 1.0f;

                /* d_time = d_long's most recent 256 samples (= last 4 blocks) */
                for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2; i++) {
                    d_time_256[i] = self->d_long[AEC3_FFT_LENGTH_BY2 * 4 + i];
                }

                /* IFFT(E_long) → 512 samples, take first 256 as current e_time */
                Aec3Fft_Ifft512_typed(&self->fft_512, &E_long, e_extended);
                memcpy(e_time_256, e_extended,
                       sizeof(float) * AEC3_FFT_LENGTH_LONG_BY2);

                WebrtcAecNlp_Process(&self->webrtc_aec_nlp, &self->fft_512,
                                 &X_long, &Y_long, &E_long,
                                 e_time_256, d_time_256,
                                 self->G_long);

                /* high_bands_gain: min of G_long[128..256] (approximates
                 * AEC3 UpperBandsGain_512fft's "gain_below_8_khz") */
                for (k = AEC3_FFT_LENGTH_LONG_BY2 / 2;
                     k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    if (self->G_long[k] < gain_min) gain_min = self->G_long[k];
                }
                high_bands_gain = gain_min;
            } else {
                SuppressionGain_GetGain512(&self->suppression_gain,
                                           self->E2_long, self->R2_long,
                                           self->S2_linear_long, self->Y2_long,
                                           &self->aec_state,
                                           X2_long,
                                           CNG_NoiseSpectrumLong(&self->cng),
                                           self->G_long, &high_bands_gain);
            }

            /* 14. Apply dt_controller suppression gain */
            {
                FftDataPfdkf Y_fft_long_nlp;
                float Y2_fft_long_nlp[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
                const float* suppress_gain;
                float gain_mean = 0.0f;
                float S2_avg_local = 0.0f;

                /* Build NLP-applied FftDataPfdkf for dt_controller */
                FftDataPfdkf_Assign(&Y_fft_long_nlp, &E_long);
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    Y_fft_long_nlp.relf[k] *= self->G_long[k];
                    Y_fft_long_nlp.imlf[k] *= self->G_long[k];
                }
                FftDataPfdkf_Spectrum(&Y_fft_long_nlp, Y2_fft_long_nlp);

                DtController_Update512fft(&self->aec_state.dt_controller,
                                          &Y_long, &E_long, &S_long,
                                          &Y_fft_long_nlp, &X_long,
                                          self->G_long,
                                          CNG_NoiseSpectrumLong(&self->cng),
                                          self->rt_config.aec_level,
                                          0);  /* always 0: keep normal DT behavior regardless of low_compute_mode */

                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    gain_mean += self->G_long[k];
                }
                gain_mean /= AEC3_FFT_LENGTH_LONG_BY2_PLUS1;

                for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; i++) {
                    S2_avg_local += sqrtf(self->S2_linear_long[i]);
                }
                S2_avg_local /= AEC3_FFT_LENGTH_LONG_BY2_PLUS1;
                self->S2_avg = self->S2_avg * 0.85f + S2_avg_local * 0.15f;
                if (self->S2_avg < 1500.0f) {
                    if (self->aec_nlp_level > 0.0f) {
                        self->aec_nlp_level -= 0.1f;
                        if (self->aec_nlp_level < 0.0f)
                            self->aec_nlp_level = 0.0f;
                    }
                } else {
                    self->aec_nlp_level = 1.0f;
                }

                if (self->rt_config.aec_nlp_level >= 0.0f &&
                    self->rt_config.aec_nlp_level <= 1.0f) {
                    self->aec_nlp_level = self->rt_config.aec_nlp_level;
                }

                suppress_gain = DtController_GetSupGainl(
                    &self->aec_state.dt_controller);
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    float sg = suppress_gain[k] * self->aec_nlp_level
                               + (1.0f - self->aec_nlp_level);
                    self->G_long[k] = self->G_long[k] * self->aec_nlp_level
                                      + (1.0f - self->aec_nlp_level);
                    self->G_long[k] *= sg;
                }
                high_bands_gain *= suppress_gain[AEC3_FFT_LENGTH_LONG_BY2];
            }

            /* Store final high_bands_gain for external multi-band use */
            self->high_bands_gain = high_bands_gain;

            /* 15. Zero out high-band comfort noise */
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                self->comfort_noise_high.relf[k] = 0.0f;
                self->comfort_noise_high.imlf[k] = 0.0f;
            }
            if (self->rt_config.CNG_level == -1) {
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    self->comfort_noise.relf[k] = 0.0f;
                    self->comfort_noise.imlf[k] = 0.0f;
                }
            }

            /* 16. Assemble long-window capture from d_long */
            for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2; i++) {
                y_long_buf[i] = self->d_long[i];
            }

            /* 17. Apply suppression filter (512fft) — overlap-add */
            {
                FftDataPfdkf E_sup;
                float noise_gain_arr[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
                float e_extended[AEC3_FFT_LENGTH_LONG];

                /* Build E_sup from E_long (FftDataPfdkf) */
                FftDataPfdkf_Clear(&E_sup);
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    E_sup.relf[k] = E_long.relf[k] * self->G_long[k];
                    E_sup.imlf[k] = E_long.imlf[k] * self->G_long[k];
                }

                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    float g2 = self->G_long[k] * self->G_long[k];
                    float ng = 1.0f - g2;
                    noise_gain_arr[k] = (ng > 0.0f) ? sqrtf(ng) : 0.0f;
                }

                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    E_sup.relf[k] += noise_gain_arr[k] * self->comfort_noise.relf[k];
                    E_sup.imlf[k] += noise_gain_arr[k] * self->comfort_noise.imlf[k];
                }

                Aec3Fft_Ifft512_typed(&self->suppression_filter.fft_512,
                                &E_sup, e_extended);

                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
                    float win_new = sinf(3.14159265f * (float)k / (float)AEC3_FFT_LENGTH_LONG);
                    float win_old = sinf(3.14159265f * (float)(k + AEC3_FFT_LENGTH_LONG_BY2) / (float)AEC3_FFT_LENGTH_LONG);
                    float val = self->suppression_filter.e_output_old_long[0][k] * win_old
                              + e_extended[k] * win_new;
                    if (val < -32768.0f) val = -32768.0f;
                    if (val > 32767.0f) val = 32767.0f;
                    capture_out[k] = val;
                }
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
                    self->suppression_filter.e_output_old_long[0][k] =
                        e_extended[k + AEC3_FFT_LENGTH_LONG_BY2];
                }
            }

            /* 18. Write first AEC3_BLOCK_SIZE samples to capture[0] */
            memcpy(capture[0], capture_out,
                   AEC3_BLOCK_SIZE * sizeof(float));

            memcpy(self->out_buffer[0],
                   capture_out + AEC3_BLOCK_SIZE,
                   AEC3_BLOCK_SIZE * 3 * sizeof(float));

            /* Handle upper bands: apply high_bands_gain + 256-sample swap delay
             * (matches C++ e_output_old_long_ swap in suppression_filter.cc)
             *
             * The 512-point overlap-add on band 0 introduces ~256 samples of
             * group delay.  Without compensating, the high bands arrive 256
             * samples (16 ms @16 kHz) earlier than band 0.
             *
             * Fix: swap current 4-block high-band output with the previous
             * cycle's buffered data (hband_delay_buf), so the high bands are
             * delayed by exactly one NLP cycle (4 blocks = 256 samples).
             */
            {
                int b;
                float tmp[AEC3_BLOCK_SIZE * 4];
                for (b = 1; b < num_bands; b++) {
                    /* Apply gain to all 4 blocks of hband_in -> tmp */
                    for (i = 0; i < AEC3_BLOCK_SIZE * 4; i++) {
                        float val = self->hband_in[b][i] * high_bands_gain;
                        if (val < -32768.0f) val = -32768.0f;
                        if (val > 32767.0f) val = 32767.0f;
                        tmp[i] = val;
                    }

                    /* Output previous cycle's delayed data */
                    /* Block 0 -> capture[b] */
                    memcpy(capture[b], self->hband_delay_buf[b],
                           AEC3_BLOCK_SIZE * sizeof(float));
                    /* Blocks 1,2,3 -> out_buffer[b] */
                    memcpy(self->out_buffer[b],
                           self->hband_delay_buf[b] + AEC3_BLOCK_SIZE,
                           AEC3_BLOCK_SIZE * 3 * sizeof(float));

                    /* Store current cycle's data for next cycle */
                    memcpy(self->hband_delay_buf[b], tmp,
                           AEC3_BLOCK_SIZE * 4 * sizeof(float));
                }
            }
        }

        /* Reset suppress_cnt */
#ifdef AEC3_PROFILE_MODULES
        g_prof_nlp_us += (_er_prof_get_us() - _nlp_st); }
#endif
        self->suppress_cnt = 0;

    } else {
        /* ============================================================
         * Intermediate blocks (suppress_cnt == 1, 2, or 3)
         * ============================================================ */
        int offset;

#ifdef AEC3_PROFILE_MODULES
        { double _st = _er_prof_get_us();
#endif
        Subtractor_ProcessPfdkf(&self->subtractor, render_buffer,
                                y0, &self->subtractor_output_frequency,
                                !self->rt_config.aec_low_compute_mode);
#ifdef AEC3_PROFILE_MODULES
        g_prof_subtractor_us += (_er_prof_get_us() - _st); }
#endif

        offset = (self->suppress_cnt - 1) * AEC3_BLOCK_SIZE;
        memcpy(capture[0], &self->out_buffer[0][offset],
               AEC3_BLOCK_SIZE * sizeof(float));

        {
            int b;
            for (b = 1; b < num_bands; b++) {
                memcpy(capture[b], &self->out_buffer[b][offset],
                       AEC3_BLOCK_SIZE * sizeof(float));
            }
        }
    }

    /* Every call: dump reverb debug PCM (per-block, aligned with input) */
    if (access("enable_vqe_dump", 0) == 0) {
        static FILE* fp_reverb_dump = NULL;

        if (!fp_reverb_dump) {
            fp_reverb_dump = fopen("reverb_debug.pcm", "wb");
        }
        if (fp_reverb_dump) {
            int16_t rd_samples[2];
            float nw = self->residual_echo_estimator.last_ne_weight * 32767.0f;
            float lr = self->residual_echo_estimator.last_lf_ratio * 32767.0f;
            int ri;
            if (nw > 32767.0f) nw = 32767.0f;
            if (lr > 32767.0f) lr = 32767.0f;
            rd_samples[0] = (int16_t)nw;
            rd_samples[1] = (int16_t)lr;
            for (ri = 0; ri < AEC3_BLOCK_SIZE; ri++) {
                fwrite(rd_samples, sizeof(int16_t), 2, fp_reverb_dump);
            }
        }
    }

    /* Every call end: shift d_long */
    memmove(self->d_long, self->d_long + AEC3_FFT_LENGTH_BY2,
            AEC3_FFT_LENGTH_BY2 * 7 * sizeof(float));
}

void EchoRemover_SetNearActivity(EchoRemover* self, float near_activity) {
    self->near_activity = near_activity;
}

void EchoRemover_SetMusicFlag(EchoRemover* self, int music_flag) {
    self->music_flag = music_flag;
}

int EchoRemover_GetEchoState(const EchoRemover* self) {
    return AecState_GetEchoState(&self->aec_state);
}
