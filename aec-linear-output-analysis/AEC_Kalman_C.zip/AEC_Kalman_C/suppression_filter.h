/*
 *  SuppressionFilter - Pure C Version
 *
 *  Applies frequency-domain suppression gain and overlap-add synthesis.
 *  Ported from WebRTC AEC3 C++ SuppressionFilter class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point path retained.
 *  C99 compatible, no C++ keywords.
 */

#ifndef SUPPRESSION_FILTER_H_
#define SUPPRESSION_FILTER_H_

#include "aec3_common.h"
#include "aec3_fft.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * SuppressionFilter
 *
 * Applies the suppression gain in the frequency domain, adds
 * comfort noise, and performs overlap-add synthesis to produce
 * the time-domain output. Only 512-point path retained.
 * ================================================================ */
typedef struct {
    int         sample_rate_hz;
    Aec3Fft     fft_512;

    /* Overlap-add buffers for 512-point (per band) */
    float       e_output_old_long[AEC3_MAX_BANDS][AEC3_FFT_LENGTH_LONG_BY2];

    int         num_bands;
} SuppressionFilter;

/**
 * Initialize the suppression filter.
 */
void SuppressionFilter_Init(SuppressionFilter* self, int sample_rate_hz);

/**
 * Apply suppression gain (512-point) with comfort noise and overlap-add.
 *
 * @param self                  Pointer to suppression filter
 * @param comfort_noise         Lower band comfort noise (FftData, rel/iml)
 * @param comfort_noise_high    Upper band comfort noise (FftData, rel/iml)
 * @param suppression_gain      Suppression gain (257 floats)
 * @param high_bands_gain       Gain for upper bands
 * @param E_lowest_band         Error signal in frequency domain (FftData, rel/iml)
 * @param e                     Output: time-domain signal [num_bands][AEC3_BLOCK_SIZE]
 * @param num_bands             Number of bands
 */
void SuppressionFilter_ApplyGain512(SuppressionFilter* self,
                                    const FftDataPfdkf* comfort_noise,
                                    const FftDataPfdkf* comfort_noise_high,
                                    const float* suppression_gain,
                                    float high_bands_gain,
                                    const FftDataPfdkf* E_lowest_band,
                                    float e[][AEC3_BLOCK_SIZE],
                                    int num_bands);

#ifdef __cplusplus
}
#endif

#endif /* SUPPRESSION_FILTER_H_ */
