/*
 *  AecState - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ AecState class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "aec_state.h"
#include <string.h>
#include <math.h>
#include <stdio.h>

/* ================================================================
 * InitialState helpers
 * ================================================================ */
static void InitialState_Init(AecState* self) {
    self->initial_state_active = 1;
    self->initial_transition_triggered = 0;
    self->initial_strong_render_blocks = 0;
}

static void InitialState_Update(AecState* self,
                                int active_render,
                                int saturated_capture) {
    if (!self->initial_state_active) return;

    if (active_render && !saturated_capture) {
        self->initial_strong_render_blocks++;
    }

    /* Transition after initial_state_seconds worth of strong render */
    {
        int threshold = (int)(self->initial_state_seconds *
                              AEC3_NUM_BLOCKS_PER_SECOND);
        if ((int)self->initial_strong_render_blocks >= threshold) {
            self->initial_transition_triggered = 1;
            self->initial_state_active = 0;
        }
    }
}

/* ================================================================
 * FilterDelay helpers
 * ================================================================ */
static void FilterDelay_Init(AecState* self) {
    self->external_delay_reported = 0;
    self->filter_delay_blocks = 0;
    self->delay_headroom_blocks = self->config.delay_headroom_blocks;
    memset(&self->external_delay, 0, sizeof(DelayEstimate));
    self->has_external_delay = 0;
}

static void FilterDelay_Update(AecState* self,
                               const DelayEstimate* external_delay,
                               int has_external_delay) {
    if (has_external_delay) {
        self->external_delay = *external_delay;
        self->has_external_delay = 1;
        self->external_delay_reported = 1;
    }

    /* Use filter analyzer delay */
    self->filter_delay_blocks = FilterAnalyzer_DelayBlocks(&self->filter_analyzer);
}

/* ================================================================
 * TransparentMode helpers
 * ================================================================ */
static void TransparentMode_Init(AecState* self) {
    self->transparency_activated = 0;
    self->transparent_capture_block_counter = 0;
    self->transparent_active_blocks_since_sane = 0;
    self->transparent_sane_filter_observed = 0;
    self->transparent_non_converged_seq = 0;
    self->transparent_diverged_seq = 0;
    self->transparent_num_converged = 0;
    self->transparent_strong_render_blocks = 0;
}

static void TransparentMode_Update(AecState* self,
                                   int consistent_filter,
                                   int converged_filter,
                                   int diverged_filter,
                                   int active_render,
                                   int saturated_capture) {
    (void)saturated_capture;
    self->transparent_capture_block_counter++;

    if (converged_filter) {
        self->transparent_num_converged++;
        self->transparent_non_converged_seq = 0;
    } else {
        self->transparent_non_converged_seq++;
    }

    if (diverged_filter) {
        self->transparent_diverged_seq++;
    } else {
        self->transparent_diverged_seq = 0;
    }

    if (consistent_filter) {
        self->transparent_sane_filter_observed = 1;
        self->transparent_active_blocks_since_sane = 0;
    } else if (active_render) {
        self->transparent_active_blocks_since_sane++;
    }

    /* Activate transparency if filter never converges */
    if (self->transparent_capture_block_counter > 10 * AEC3_NUM_BLOCKS_PER_SECOND &&
        self->transparent_num_converged == 0 &&
        !self->transparent_sane_filter_observed) {
        self->transparency_activated = 1;
    } else {
        self->transparency_activated = 0;
    }
}

/* ================================================================
 * FilteringQualityAnalyzer helpers
 * ================================================================ */
static void FilterQuality_Init(AecState* self) {
    self->usable_linear_estimate = 0;
    self->filter_update_blocks_since_reset = 0;
    self->filter_update_blocks_since_start = 0;
    self->convergence_seen = 0;
}

static void FilterQuality_Update(AecState* self,
                                 int active_render,
                                 int transparent_mode,
                                 int saturated_capture,
                                 int consistent_estimate,
                                 int has_external_delay,
                                 int converged_filter,
                                 int over_suppression) {
    (void)over_suppression;

    if (active_render && !saturated_capture) {
        self->filter_update_blocks_since_reset++;
        self->filter_update_blocks_since_start++;
    }

    if (converged_filter) {
        self->convergence_seen = 1;
    }

    /* Linear filter is usable if:
     * - External delay has been reported
     * - Filter has had time to converge
     * - Not in transparent mode */
    if (transparent_mode) {
        self->usable_linear_estimate = 0;
    } else if (has_external_delay &&
               self->filter_update_blocks_since_reset > 2 * AEC3_NUM_BLOCKS_PER_SECOND) {
        if (consistent_estimate || self->convergence_seen) {
            self->usable_linear_estimate = 1;
        }
    }
}

/* ================================================================
 * SaturationDetector helpers
 * ================================================================ */
static void SaturationDetector_Init(AecState* self) {
    self->saturated_echo = 0;
    self->saturated_echo_dt_counter = 0;
}

static void SaturationDetector_Update(AecState* self,
                                      const float* x,
                                      int saturated_capture,
                                      int usable_linear,
                                      const SubtractorOutput* output,
                                      float echo_path_gain) {
    (void)x; (void)echo_path_gain;

    if (!usable_linear) {
        /* Check if render is strong and capture is saturated */
        if (saturated_capture && output->s2_main > 100.0f * AEC3_BLOCK_SIZE) {
            self->saturated_echo = 1;
            self->saturated_echo_dt_counter = 10;
        }
    } else {
        self->saturated_echo = 0;
    }

    if (self->saturated_echo_dt_counter > 0) {
        self->saturated_echo_dt_counter--;
        if (self->saturated_echo_dt_counter == 0) {
            self->saturated_echo = 0;
        }
    }
}

static void SaturationDetector_Update512fft(AecState* self,
                                            int capture_signal_saturation,
                                            const float* S2_linear,
                                            const float* E2,
                                            const float* Y2) {
    int k;
    float s2_sum = 0.0f, y2_sum = 0.0f;
    (void)E2;

    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        s2_sum += S2_linear[k];
        y2_sum += Y2[k];
    }

    if (capture_signal_saturation && s2_sum > 0.5f * y2_sum) {
        self->saturated_echo = 1;
        self->saturated_echo_dt_counter = 10;
    }

    if (self->saturated_echo_dt_counter > 0) {
        self->saturated_echo_dt_counter--;
        if (self->saturated_echo_dt_counter == 0) {
            self->saturated_echo = 0;
        }
    }
}

/* ================================================================
 * AecState main implementation
 * ================================================================ */

void AecState_Init(AecState* self, const Aec3Config* config) {
    memset(self, 0, sizeof(AecState));
    self->config = *config;
    self->initial_state_seconds = config->initial_state_seconds;
    self->conservative_initial_phase = config->conservative_initial_phase;

    InitialState_Init(self);
    FilterDelay_Init(self);
    TransparentMode_Init(self);
    FilterQuality_Init(self);
    SaturationDetector_Init(self);

    ErlEstimator_Init(&self->erl_estimator,
                      (int)(config->initial_state_seconds *
                            AEC3_NUM_BLOCKS_PER_SECOND));
    ErleEstimator_Init(&self->erle_estimator,
                       (int)(config->initial_state_seconds *
                             AEC3_NUM_BLOCKS_PER_SECOND),
                       config);
    FilterAnalyzer_Init(&self->filter_analyzer, config);
    SubtractorOutputAnalyzer_Init(&self->subtractor_output_analyzer);
    EchoAudibility_Init(&self->echo_audibility,
                        config->echo_audibility_use_stationarity_properties_at_init);
    SuppressionGainUpperLimiter_Init(&self->suppression_gain_limiter, config);
    ReverbModelEstimator_Init(&self->reverb_model_estimator, config);
    DtController_Init(&self->dt_controller);

    self->double_talk_probability = 0.0f;
}

void AecState_Update(AecState* self,
                     const DelayEstimate* external_delay,
                     int has_external_delay,
                     const float (*H2)[AEC3_FFT_LENGTH_BY2_PLUS1],
                     int H2_partitions,
                     const float* h, int h_len,
                     const RenderBuffer* render_buffer,
                     const float* E2_main,
                     const float* Y2,
                     FftData128* Y_fft,
                     FftData128* E_fft,
                     FftData128* S_fft,
                     const float* y,
                     const float* e,
                     const SubtractorOutput* subtractor_output,
                     float nonlinear_level,
                     int audioMixing_flag,
                     int dtd_flag,
                     int earphone_flag,
                     int submodule_flag) {
    int active_render;
    int converged, diverged;
    const float* render_spectrum = NULL;

    /* Update subtractor output analysis */
    SubtractorOutputAnalyzer_Update(&self->subtractor_output_analyzer,
                                    subtractor_output);
    converged = SubtractorOutputAnalyzer_ConvergedFilter(
        &self->subtractor_output_analyzer);
    diverged = SubtractorOutputAnalyzer_DivergedFilter(
        &self->subtractor_output_analyzer);

    /* Update filter analyzer */
    FilterAnalyzer_Update(&self->filter_analyzer, h, h_len, render_buffer);

    /* Update delay state */
    FilterDelay_Update(self, external_delay, has_external_delay);

    /* Check render activity
     * Note: 128-point RenderBuffer_Spectrum was removed (returns NULL).
     * Use RenderBuffer_GetRenderActivity which is set by render_delay_buffer
     * via DetectActiveRender on the time-domain render block. */
    active_render = RenderBuffer_GetRenderActivity(render_buffer);

    if (active_render) {
        self->blocks_with_active_render++;
    }

    /* Track strong render blocks (not saturated) */
    if (active_render && !self->capture_signal_saturation) {
        self->strong_not_saturated_render_blocks++;
    }

    /* Update initial state */
    InitialState_Update(self, active_render, self->capture_signal_saturation);

    /* Update transparent mode */
    TransparentMode_Update(self,
        FilterAnalyzer_Consistent(&self->filter_analyzer),
        converged, diverged,
        active_render, self->capture_signal_saturation);

    /* Update filtering quality */
    FilterQuality_Update(self, active_render,
        self->transparency_activated,
        self->capture_signal_saturation,
        FilterAnalyzer_Consistent(&self->filter_analyzer),
        self->has_external_delay,
        converged, 0);

    /* Update saturation detector */
    {
        const float* x_block = RenderBuffer_Block(render_buffer, 0, 0);
        if (x_block) {
            SaturationDetector_Update(self, x_block,
                self->capture_signal_saturation,
                self->usable_linear_estimate,
                subtractor_output,
                FilterAnalyzer_Gain(&self->filter_analyzer));
        }
    }

    /* Update ERL estimator */
    ErlEstimator_Update(&self->erl_estimator,
                        converged,
                        render_spectrum ? render_spectrum : E2_main,
                        Y2,
                        0);

    /* 128-point ERLE update removed — only 512fft path retained */

    /* Update echo audibility */
    {
        const float* reverb_resp =
            ReverbModelEstimator_GetReverbFrequencyResponse(
                &self->reverb_model_estimator);
        EchoAudibility_Update(&self->echo_audibility,
                              render_buffer, reverb_resp,
                              self->filter_delay_blocks,
                              self->external_delay_reported);
    }

    /* Update reverb model estimator */
    ReverbModelEstimator_Update(&self->reverb_model_estimator,
        h, h_len, H2, H2_partitions,
        -1.0f, 0,  /* no quality estimate */
        self->filter_delay_blocks,
        self->usable_linear_estimate,
        EchoAudibility_IsBlockStationary(&self->echo_audibility));

    /* Update suppression gain limiter */
    SuppressionGainUpperLimiter_Update(&self->suppression_gain_limiter,
        active_render, self->transparency_activated);

    /* Update DT controller */
    if (Y_fft && E_fft && S_fft && y && e) {
        const float* x_block = RenderBuffer_Block(render_buffer, 0, 0);
        if (x_block) {
            FftData128 X_fft;
            /* 128pt FFT buffer removed — X_fft stays zero-initialized.
             * AecState_Update is not called in PFDKF path, but must still compile. */
            memset(&X_fft, 0, sizeof(FftData128));

            DtController_Update(&self->dt_controller,
                Y_fft, E_fft, S_fft, &X_fft,
                y, e,
                subtractor_output->s_main, x_block,
                nonlinear_level,
                audioMixing_flag, dtd_flag,
                submodule_flag, earphone_flag,
                ErlEstimator_ErlTimeDomain(&self->erl_estimator),
                self->erl_time_domain_diff,
                0);
        }
    }

    /* Update ERL time domain diff */
    {
        float erl_td = ErlEstimator_ErlTimeDomain(&self->erl_estimator);
        self->erl_time_domain_diff = erl_td;
    }

    /* Update double talk probability */
    self->double_talk_probability =
        DtController_GetDoubleTalkProbability(&self->dt_controller);
}

void AecState_UpdateErle(AecState* self,
                         const SubtractorOutput* subtractor_output,
                         const float* E2_long,
                         const float* Y2_long,
                         const float* X2_long) {
    /* Match C++ Update_erle_pfdkf: always pass converged=1 for PFDKF path.
     * C++ version hardcodes converged_filter=1 in Update_erle_pfdkf(),
     * not relying on SubtractorOutputAnalyzer which tracks 128-point path. */
    (void)subtractor_output;

    ErleEstimator_Update512fft(&self->erle_estimator,
                               X2_long, Y2_long, E2_long,
                               1, 1, 0, 0);
}

void AecState_UpdateEchoSaturation(AecState* self,
                                   int capture_signal_saturation,
                                   const float* S2_linear,
                                   const float* E2,
                                   const float* Y2) {
    SaturationDetector_Update512fft(self, capture_signal_saturation,
                                    S2_linear, E2, Y2);
}

void AecState_HandleEchoPathChange(AecState* self,
                                   const EchoPathVariability* variability) {
    if (variability->gain_change || variability->delay_change) {
        FilterAnalyzer_Reset(&self->filter_analyzer);
        ErlEstimator_Reset(&self->erl_estimator);
        ErleEstimator_Reset(&self->erle_estimator, variability->delay_change);
        SubtractorOutputAnalyzer_HandleEchoPathChange(
            &self->subtractor_output_analyzer);
        SuppressionGainUpperLimiter_Reset(&self->suppression_gain_limiter);

        /* Reset filtering quality */
        self->usable_linear_estimate = 0;
        self->filter_update_blocks_since_reset = 0;
        self->convergence_seen = 0;
    }
}

/* ================================================================
 * Accessor functions
 * ================================================================ */

int AecState_UsableLinearEstimate(const AecState* self) {
    return self->usable_linear_estimate;
}

int AecState_UseLinearFilterOutput(const AecState* self) {
    return self->usable_linear_estimate;
}

float AecState_EchoPathGain(const AecState* self) {
    return FilterAnalyzer_Gain(&self->filter_analyzer);
}

int AecState_FilterDelayBlocks(const AecState* self) {
    return self->filter_delay_blocks;
}

int AecState_ActiveRender(const AecState* self) {
    return self->blocks_with_active_render > 200;
}

int AecState_TransparentMode(const AecState* self) {
    return self->transparency_activated;
}

int AecState_SaturatedEcho(const AecState* self) {
    return self->saturated_echo;
}

int AecState_SaturatedEcho512fft(const AecState* self) {
    return self->saturated_echo;
}

int AecState_SaturatedCapture(const AecState* self) {
    return self->capture_signal_saturation;
}

void AecState_UpdateCaptureSaturation(AecState* self, int saturation) {
    self->capture_signal_saturation = saturation;
}

float AecState_ReverbDecay(const AecState* self) {
    return ReverbModelEstimator_ReverbDecay(&self->reverb_model_estimator);
}

const float* AecState_GetReverbFrequencyResponse(const AecState* self) {
    return ReverbModelEstimator_GetReverbFrequencyResponse(
        &self->reverb_model_estimator);
}

float AecState_SuppressionGainLimit(const AecState* self) {
    return SuppressionGainUpperLimiter_Limit(&self->suppression_gain_limiter);
}

int AecState_IsSuppressionGainLimitActive(const AecState* self) {
    return SuppressionGainUpperLimiter_IsActive(&self->suppression_gain_limiter);
}

int AecState_TransitionTriggered(const AecState* self) {
    return self->initial_transition_triggered;
}

const float* AecState_Erl(const AecState* self) {
    return ErlEstimator_Erl(&self->erl_estimator);
}

float AecState_ErlTimeDomain(const AecState* self) {
    return ErlEstimator_ErlTimeDomain(&self->erl_estimator);
}

float AecState_ErlTimeDomainDiff(const AecState* self) {
    return self->erl_time_domain_diff;
}

const float* AecState_ErleLong(const AecState* self) {
    return ErleEstimator_ErleLong(&self->erle_estimator);
}

const float* AecState_ErleLongGreater(const AecState* self) {
    return ErleEstimator_ErleLongGreater(&self->erle_estimator);
}

int AecState_FilterLengthBlocks(const AecState* self) {
    return FilterAnalyzer_FilterLengthBlocks(&self->filter_analyzer);
}

int AecState_UseStationaryProperties(const AecState* self) {
    return self->config.echo_audibility_use_stationary_properties;
}

void AecState_GetResidualEchoScaling(const AecState* self, float* scaling) {
    int converged = (self->filter_update_blocks_since_start >
                     5 * AEC3_NUM_BLOCKS_PER_SECOND);
    EchoAudibility_GetResidualEchoScaling(&self->echo_audibility,
                                          converged, scaling);
}

float AecState_GetDoubleTalkProbability(const AecState* self) {
    return self->double_talk_probability;
}

int AecState_GetEchoState(const AecState* self) {
    return DtController_GetEchoState(&self->dt_controller);
}

const ControlOperation* AecState_GetOperations(const AecState* self) {
    return DtController_GetOperations(&self->dt_controller);
}

float AecState_AccelerateRate(AecState* self) {
    return DtController_AccelerateRate(&self->dt_controller);
}

/* ================================================================
 * AecState_UpdateReverbDecayPfdkf
 *
 * Estimate reverb decay from PFDKF filter H2 frequency response.
 * Uses centered linear regression on log2(partition energy) for
 * robust decay estimation.
 *
 * H2_pf_update layout: [partition * 257 + bin]
 * Each partition spans AEC3_LF_BLOCK_SHIFT (3) blocks in time.
 * ================================================================ */

/* Fast approximate log2 for positive floats */
static float FastApproxLog2f_pfdkf(float x) {
    if (x <= 0.0f) return -30.0f;
    return (float)(log(x) / log(2.0));
}

#define BLOCKS_PER_SECTION 3

static const float kEarlyReverbTiltUpper = 0.13750352f;  /* log2(1.1) */
static const float kEarlyReverbTiltLower = -0.32192809f; /* log2(0.8) */

/* Segmented tilt analysis to find late reverb start partition */
static int EarlyReverbLengthEstimator_Estimate_pfdkf(
    const float* partition_energies,
    int num_partitions,
    int peak_partition) {
    int start = peak_partition + 1;
    int best_start = start;
    int sec_start, sec_end, n, i;
    float sum_n, sum_z, sum_nz, sum_nn, tilt;

    if (start >= num_partitions - 1) return start;

    /* Scan sections from start */
    for (sec_start = start; sec_start + BLOCKS_PER_SECTION <= num_partitions; sec_start += BLOCKS_PER_SECTION) {
        sec_end = sec_start + BLOCKS_PER_SECTION;
        if (sec_end > num_partitions) sec_end = num_partitions;
        n = sec_end - sec_start;
        if (n < 2) break;

        /* Linear regression on log2(energy) within section */
        sum_n = 0.0f; sum_z = 0.0f; sum_nz = 0.0f; sum_nn = 0.0f;
        for (i = 0; i < n; i++) {
            float z = FastApproxLog2f_pfdkf(partition_energies[sec_start + i]);
            float ni = (float)i - (float)(n - 1) * 0.5f;
            sum_nz += ni * z;
            sum_nn += ni * ni;
        }
        tilt = (sum_nn > 0.0f) ? sum_nz / sum_nn : 0.0f;

        /* Early reverb: energy not decaying or decaying too fast */
        if (tilt > kEarlyReverbTiltUpper || tilt < kEarlyReverbTiltLower) {
            best_start = sec_end;
        } else {
            break;  /* Found late reverb region */
        }
    }

    if (best_start >= num_partitions - 1) best_start = start;
    return best_start;
}

void AecState_UpdateReverbDecayPfdkf(AecState* self,
                                     const float* H2_pf_update,
                                     int num_partitions) {
    const int bins = AEC3_LF_FFT_LENGTH_BY2_PLUS1;  /* 257 */
    ReverbDecayEstimator* rde = &self->reverb_model_estimator.reverb_decay_estimator;
    float partition_energies[AEC3_MAX_FILTER_PARTITIONS];
    float direct_energy;
    int k, p, start_part, end_part, count;
    float sum_nz, sum_nn, slope, new_decay, smooth_rate;

    /* On first call, set initial decay to 0.5 for adaptive estimation.
     * The static config uses ep_strength_default_len=0.83 (non-adaptive),
     * but when enable_echo_reverb=1 we want adaptive decay starting from 0.5.
     * This function is only called when enable_echo_reverb=1. */
    if (rde->update_counter == 0) {
        rde->decay = 0.5f;
        rde->mild_decay = rde->decay * rde->mild_decay_factor;
    }

    if (num_partitions < 2 || H2_pf_update == NULL) return;

    /* Compute per-partition energies (skip DC bin) */
    for (p = 0; p < num_partitions; p++) {
        float energy = 0.0f;
        for (k = 1; k < bins; k++) {
            energy += H2_pf_update[p * bins + k];
        }
        partition_energies[p] = energy;
    }

    /* Find the peak partition (direct path) — may not be partition 0
     * due to filter delay alignment */
    {
        int peak_part = 0;
        float peak_energy = partition_energies[0];
        for (p = 1; p < num_partitions; p++) {
            if (partition_energies[p] > peak_energy) {
                peak_energy = partition_energies[p];
                peak_part = p;
            }
        }
        direct_energy = peak_energy;

        /* Need at least 2 partitions after peak for decay estimation */
        if (direct_energy < 1e-6f || peak_part >= num_partitions - 2) {
            return;
        }

        /* Estimate decay from partitions after peak */
        start_part = peak_part + 1;

        /* Skip early reflections: use tilt analysis to find where late
         * reverb (smooth exponential decay) begins.  Only apply when
         * enough partitions remain so the regression still has ≥ 2 points. */
        {
            int late_start = EarlyReverbLengthEstimator_Estimate_pfdkf(
                                 partition_energies, num_partitions, peak_part);
            if (late_start > start_part &&
                late_start <= num_partitions - 2) {
                start_part = late_start;
            }
            /* Debug: disabled — enable by changing #if 0 to #if 1 */
#if 0
            if (rde->update_counter < 10 || rde->update_counter % 100 == 0) {
                fprintf(stderr, "[EarlyReverb] cnt=%d peak=%d late_start=%d start_part=%d npart=%d "
                        "E=[%.1f %.1f %.1f %.1f %.1f %.1f]\n",
                        rde->update_counter, peak_part, late_start, start_part, num_partitions,
                        num_partitions > 0 ? partition_energies[0] : 0,
                        num_partitions > 1 ? partition_energies[1] : 0,
                        num_partitions > 2 ? partition_energies[2] : 0,
                        num_partitions > 3 ? partition_energies[3] : 0,
                        num_partitions > 4 ? partition_energies[4] : 0,
                        num_partitions > 5 ? partition_energies[5] : 0);
            }
#endif
        }
    }

    /* For short filters (< 4 partitions after peak), use simple two-point decay */
    end_part = num_partitions - 1;
    count = end_part - start_part + 1;
    if (count < 2) return;

    if (count == 2) {
        /* Simple ratio-based decay for very short tail */
        float tail_energy = partition_energies[end_part];
        float ratio;
        if (tail_energy >= direct_energy || tail_energy < 1e-15f) return;
        ratio = tail_energy / direct_energy;
        {
            /* Per-partition decay: ratio spans (end_part - start_part + 1) partitions */
            int num_partitions_span = end_part - start_part + 1;
            if (num_partitions_span < 1) return;
            new_decay = powf(ratio, 1.0f / (float)num_partitions_span);
        }
    } else {
        /* Standard path: centered linear regression on log2(partition_energy) */
        sum_nz = 0.0f;
        sum_nn = 0.0f;
        {
            float center = (float)(count - 1) * 0.5f;
            for (p = start_part; p <= end_part; p++) {
                float z = FastApproxLog2f_pfdkf(partition_energies[p]);
                float ni = (float)(p - start_part) - center;
                sum_nz += ni * z;
                sum_nn += ni * ni;
            }
        }
        if (sum_nn == 0.0f) return;
        slope = sum_nz / sum_nn;

        /* Convert slope to per-partition decay.
         * slope is log2(energy) change per partition.
         * Stored as per-partition; converted to per-NLP-cycle at use site. */
        new_decay = powf(2.0f, slope);

        /* Debug: disabled */
#if 0
        if (rde->update_counter < 10 || rde->update_counter % 100 == 0) {
            fprintf(stderr, "[DecayReg] cnt=%d start=%d end=%d count=%d slope=%.4f "
                    "new_decay=%.4f cur_decay=%.4f\n",
                    rde->update_counter, start_part, end_part, count,
                    slope, new_decay, rde->decay);
        }
#endif
    }

    /* Clamp to valid range */
    if (new_decay > self->config.reverb_decay_max) new_decay = self->config.reverb_decay_max;
    if (new_decay < 0.02f) new_decay = 0.02f;

    /* Descent protection: don't drop more than 5% per update */
    if (new_decay < 0.95f * rde->decay) new_decay = 0.95f * rde->decay;

    /* Two-phase adaptive smoothing */
    if (rde->update_counter < rde->fast_convergence_blocks) {
        smooth_rate = rde->smoothing_rate_fast;
    } else {
        smooth_rate = rde->smoothing_rate_slow;
    }
    rde->decay += smooth_rate * (new_decay - rde->decay);

    /* Debug: disabled */
#if 0
    if (rde->update_counter < 10 || rde->update_counter % 100 == 0) {
        fprintf(stderr, "[DecayFinal] cnt=%d new=%.4f smoothed=%.4f addr=%p\n",
                rde->update_counter, new_decay, rde->decay, (void*)&rde->decay);
    }
#endif

    rde->update_counter++;

    /* Sync mild_decay */
    rde->mild_decay = rde->decay * rde->mild_decay_factor;
}
