/*
 *  Matched Filter Lag Aggregator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ matched_filter_lag_aggregator.cc
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Histogram-based aggregation of delay estimates from multiple
 *  matched filters and binary delay estimator.
 */

#include "matched_filter_lag_aggregator.h"

#include <string.h>
#include <assert.h>
#include <stdio.h>

/* ================================================================
 * Helper: find index of maximum element in int array
 * ================================================================ */
static int FindMaxElementIndex(const int* arr, int size)
{
    int max_idx = 0;
    int max_val = arr[0];
    int i;
    for (i = 1; i < size; ++i) {
        if (arr[i] > max_val) {
            max_val = arr[i];
            max_idx = i;
        }
    }
    return max_idx;
}

/* ================================================================
 * Public API
 * ================================================================ */

void MatchedFilterLagAggregator_Init(MatchedFilterLagAggregator* self,
                                     int max_filter_lag,
                                     const DelaySelectionThresholds* thresholds)
{
    assert(self != NULL);
    assert(thresholds != NULL);
    assert(max_filter_lag + 1 <= MF_LAG_AGGREGATOR_MAX_HISTOGRAM);
    assert(thresholds->initial <= thresholds->converged);

    self->histogram_size = max_filter_lag + 1;
    memset(self->histogram, 0, sizeof(self->histogram));
    memset(self->histogram_data, 0, sizeof(self->histogram_data));
    self->histogram_data_index = 0;
    self->significant_candidate_found = 0;
    self->candidate_last = -1;  /* Fix: use -1 to indicate no previous candidate */
    self->delay_stable = 0;

    self->thresholds.initial = thresholds->initial;
    self->thresholds.converged = thresholds->converged;

    self->aec_H_usage = 5;
}

void MatchedFilterLagAggregator_Reset(MatchedFilterLagAggregator* self,
                                      int hard_reset)
{
    assert(self != NULL);

    memset(self->histogram, 0, sizeof(int) * self->histogram_size);
    memset(self->histogram_data, 0, sizeof(self->histogram_data));
    self->histogram_data_index = 0;

    if (hard_reset) {
        self->significant_candidate_found = 0;
        self->candidate_last = -1;  /* Fix: reset to invalid */
    }
}

void MatchedFilterLagAggregator_SetAecHUsage(MatchedFilterLagAggregator* self,
                                             int size)
{
    assert(self != NULL);
    self->aec_H_usage = size;
}

int MatchedFilterLagAggregator_Aggregate(
    MatchedFilterLagAggregator* self,
    const MatchedFilterLagEstimate* lag_estimates, int num_estimates,
    int delay_estimate,
    int earphone_flag,
    int voip_mode_enable,
    DelayEstimate* out_delay)
{
    float best_accuracy = 0.0f;
    int best_lag_estimate_index = -1;
    int k;
    int lag_data, delay_data;
    int delay_interval;
    int candidate;
    int thresholds_initial, thresholds_converged;
    int history_mod;

    assert(self != NULL);
    assert(out_delay != NULL);

    (void)earphone_flag; /* Used in C++ but not affecting logic here */

    /* Choose the strongest reliable lag estimate */
    for (k = 0; k < num_estimates; ++k) {
        if (lag_estimates[k].updated && lag_estimates[k].reliable) {
            if (lag_estimates[k].accuracy > best_accuracy) {
                best_accuracy = lag_estimates[k].accuracy;
                best_lag_estimate_index = k;
            }
        }
    }

    if (best_lag_estimate_index != -1 || delay_estimate > 0) {
        /* Decrement old histogram entry */
        assert(self->histogram_data[self->histogram_data_index] >= 0);
        assert(self->histogram_data[self->histogram_data_index] < self->histogram_size);
        --self->histogram[self->histogram_data[self->histogram_data_index]];

        lag_data = 0;
        delay_data = 0;
        if (best_lag_estimate_index != -1) {
            lag_data = lag_estimates[best_lag_estimate_index].lag;
        }
        if (delay_estimate > 0) {
            delay_data = (delay_estimate << AEC3_BLOCK_SIZE_LOG2) / 4;
        }

        delay_interval = 1;
        if (self->aec_H_usage > 5) {
            delay_interval = 160;  /* 10 blocks, 40ms */
        }

        if (best_lag_estimate_index != -1) {
            /* If both estimates available and close, prefer binary */
            if (delay_estimate > 0 && delay_data > 0) {
                if ((lag_data + 96) > delay_data && lag_data < (delay_data + 96)) {
                    lag_data = delay_data;
                }
            }
            self->histogram_data[self->histogram_data_index] =
                (lag_data / delay_interval) * delay_interval;
        } else {
            self->histogram_data[self->histogram_data_index] =
                (delay_data / delay_interval) * delay_interval;
        }

        /* Clamp to valid range */
        if (self->histogram_data[self->histogram_data_index] >= self->histogram_size) {
            self->histogram_data[self->histogram_data_index] = self->histogram_size - 1;
        }
        if (self->histogram_data[self->histogram_data_index] < 0) {
            self->histogram_data[self->histogram_data_index] = 0;
        }

        /* Increment new histogram entry */
        ++self->histogram[self->histogram_data[self->histogram_data_index]];

        /* Advance circular history index */
        history_mod = 250;
        self->histogram_data_index =
            (self->histogram_data_index + 1) % history_mod;

        /* Find histogram peak */
        candidate = FindMaxElementIndex(self->histogram, self->histogram_size);

        /*
         * Hysteresis: if the new candidate is exactly one delay_interval
         * above the previous candidate, keep the previous one to avoid
         * unnecessary delay jumps.
         * Fix: only apply when candidate_last is valid (>= 0).
         */
        if (self->aec_H_usage > 5 && self->candidate_last >= 0) {
            if (self->candidate_last == candidate - delay_interval) {
                candidate = self->candidate_last;
            }
        }

        /* Apply thresholds */
        thresholds_initial = self->thresholds.initial;
        thresholds_converged = self->thresholds.converged;
        if (voip_mode_enable) {
            thresholds_initial = 25;
            thresholds_converged = 40;
        }

        self->significant_candidate_found =
            self->significant_candidate_found ||
            (self->histogram[candidate] > thresholds_converged);

        if (self->histogram[candidate] > thresholds_converged ||
            (self->histogram[candidate] > thresholds_initial &&
             !self->significant_candidate_found)) {
            self->candidate_last = candidate;
            out_delay->quality = self->significant_candidate_found ? 1 : 0;
            out_delay->delay = candidate;
            out_delay->blocks_since_last_change = 0;
            out_delay->blocks_since_last_update = 0;
            return 1;
        }
    }

    return 0;
}

int MatchedFilterLagAggregator_AggregateBinary(
    MatchedFilterLagAggregator* self,
    int delay_estimate,
    int voip_mode_enable,
    DelayEstimate* out_delay)
{
    int delay_data;
    int delay_interval;
    int candidate;
    int thresholds_initial, thresholds_converged;
    int history_mod;

    assert(self != NULL);
    assert(out_delay != NULL);

    if (delay_estimate <= 0) {
        return 0;
    }

    /* Decrement old histogram entry */
    assert(self->histogram_data[self->histogram_data_index] >= 0);
    assert(self->histogram_data[self->histogram_data_index] < self->histogram_size);
    --self->histogram[self->histogram_data[self->histogram_data_index]];

    delay_data = (delay_estimate << AEC3_BLOCK_SIZE_LOG2) / 4;

    delay_interval = 1;
    if (self->aec_H_usage > 5) {
        delay_interval = 160;
    }

    self->histogram_data[self->histogram_data_index] =
        (delay_data / delay_interval) * delay_interval;

    /* Clamp to valid range */
    if (self->histogram_data[self->histogram_data_index] >= self->histogram_size) {
        self->histogram_data[self->histogram_data_index] = self->histogram_size - 1;
    }
    if (self->histogram_data[self->histogram_data_index] < 0) {
        self->histogram_data[self->histogram_data_index] = 0;
    }

    ++self->histogram[self->histogram_data[self->histogram_data_index]];

    history_mod = 250;
    self->histogram_data_index =
        (self->histogram_data_index + 1) % history_mod;

    /* Find histogram peak */
    candidate = FindMaxElementIndex(self->histogram, self->histogram_size);

    /*
     * Hysteresis: if the new candidate is exactly one delay_interval
     * above the previous candidate, keep the previous one.
     * Fix: only apply when candidate_last is valid (>= 0).
     * Previously candidate_last was initialized to 0, which caused
     * the first valid candidate at delay_interval (160) to be
     * incorrectly rolled back to 0 (since 0 == 160 - 160).
     */
    if (self->aec_H_usage > 5 && self->candidate_last >= 0) {
        if (self->candidate_last == candidate - delay_interval) {
            candidate = self->candidate_last;
        }
    }

    thresholds_initial = self->thresholds.initial;
    thresholds_converged = self->thresholds.converged;
    if (voip_mode_enable) {
        thresholds_initial = 25;
        thresholds_converged = 40;
    }

    self->significant_candidate_found =
        self->significant_candidate_found ||
        (self->histogram[candidate] > thresholds_converged);

    if (self->histogram[candidate] > thresholds_converged ||
        (self->histogram[candidate] > thresholds_initial &&
         !self->significant_candidate_found)) {
        self->candidate_last = candidate;
        out_delay->quality = self->significant_candidate_found ? 1 : 0;
        out_delay->delay = candidate;
        out_delay->blocks_since_last_change = 0;
        out_delay->blocks_since_last_update = 0;
        return 1;
    }

    return 0;
}
