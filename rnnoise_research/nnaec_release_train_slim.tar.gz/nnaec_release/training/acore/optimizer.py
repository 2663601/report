#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
'''
@File   ：optimizer.py
@Author ：LiPingping
@Date   ：23/08/22 下午7:01 
@Desc   : Optimizer Class.
'''

import torch

# optimizer = torch.optim.Adam(
#     params=model.parameters(),
#     lr=conf["optimizer"]["lr"],
#     betas=(conf["optimizer"]["beta1"], conf["optimizer"]["beta2"])
# )

# optimizer = torch.optim.AdamW(
#     params=model.parameters(),
#     lr=conf["optimizer"]["lr"]
# )

adam = torch.optim.Adam
adamw = torch.optim.AdamW

