/*
 *  WebrtcAecNlp - Pure C Port of Speex MDF NLP (Non-Linear Processor)
 *
 *  Ported from Speex/ezviz_echo MDF module (YS_SPEEX_AEC/mdf.c:
 *  ezviz_nonlinear_processing).  Adapted to the AEC_Kalman PFDKF path:
 *    - Speex original: 160-sample partition, 320-point FFT, 161 bins
 *    - This port:      256-sample NLP cycle, 512-point FFT, 257 bins
 *
 *  Input at each NLP cycle (16 ms @ 16 kHz):
 *    - X_long: render FFT (already computed in EchoRemover via
 *              Aec3Fft_PaddedFft512_typed on the 4-block render window)
 *    - Y_long: mic FFT (subtractor output frequency)
 *    - E_long: error FFT after PFDKF linear filter
 *    - e_time[256]: time-domain error (obtained by IFFT(E_long) at call
 *                   site, so WebrtcAecNlp does not re-run IFFT internally)
 *    - d_time[256]: time-domain mic (taken from EchoRemover::d_long)
 *
 *  Output:
 *    - G_long[257]: per-bin amplitude gain in [0, 1]
 *
 *  Spec: .kiro/specs/aec-kalman-speex-nlp/design.md (section 4-5).
 */
#ifndef WEBRTC_AEC_H_
#define WEBRTC_AEC_H_

#include "aec3_common.h"
#include "aec3_fft.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 512-point FFT convenience aliases */
#define WEBRTC_AEC_BY2        AEC3_FFT_LENGTH_LONG_BY2        /* 256 */
#define WEBRTC_AEC_BY2_PLUS1  AEC3_FFT_LENGTH_LONG_BY2_PLUS1  /* 257 */
#define WEBRTC_AEC_FFT_LEN    AEC3_FFT_LENGTH_LONG            /* 512 */

/* Frequency-aligned prefBand covering Speex's 250~1700 Hz range.
 * Kalman PFDKF resolution = 16000/512 = 31.25 Hz/bin
 *   MIN_PREFBAND = 250 / 31.25 = 8
 *   PREFBAND_SIZE: 47 bins → end bin 54 (1687.5 Hz, the last bin ≤ 1700)
 *   Loop range: [8, 55)
 *
 * Order-statistic indices (matches Speex: floor(0.75*(N-1)), floor(0.5*(N-1)))
 *   HNLFB_IDX     = floor(0.75 * 46) = 34
 *   HNLFB_LOW_IDX = floor(0.50 * 46) = 23
 */
#define WEBRTC_AEC_MIN_PREFBAND    8
#define WEBRTC_AEC_PREFBAND_SIZE   47
#define WEBRTC_AEC_HNLFB_IDX       34
#define WEBRTC_AEC_HNLFB_LOW_IDX   23

typedef struct {
    /* Time-domain buffers (512 samples: old 256 | new 256), windowed copies */
    float dBuf[WEBRTC_AEC_FFT_LEN];
    float eBuf[WEBRTC_AEC_FFT_LEN];
    float dwBuf[WEBRTC_AEC_FFT_LEN];
    float ewBuf[WEBRTC_AEC_FFT_LEN];

    /* Smoothed power spectra and cross-spectra (aligned with Speex sd/se/sx/sde/sxd) */
    float sd[WEBRTC_AEC_BY2_PLUS1];
    float se[WEBRTC_AEC_BY2_PLUS1];
    float sx[WEBRTC_AEC_BY2_PLUS1];
    float sde[WEBRTC_AEC_BY2_PLUS1][2];  /* [0]=real, [1]=imag */
    float sxd[WEBRTC_AEC_BY2_PLUS1][2];

    /* Adaptive overdrive state */
    float hNlFbLocalMin;
    float hNlFbMin;
    float hNlXdAvgMin;
    int   hNlNewMin;
    int   hNlMinCtr;
    float overDrive;
    float overDriveSm;

    /* Near-end / echo state machine */
    int   stNearState;
    int   echoState;

    /* Double-talk / divergence state (from Speex ezviz_smoothed_psd) */
    int   dtState;        /* 1 = double-talk detected (sdSum < seSum) */
    int   divergeState;   /* 1 = filter diverged (seSum > sdSum) */
    int   convergeState;  /* 1 = filter has converged at least once */

    /* Coherence-based double-talk detection (internal) */
    float hNlDeAvgLong;   /* Long-term smoothed hNlDeAvg (τ≈2s) */
    float hNlXdAvgLong;   /* Long-term smoothed hNlXdAvg (τ≈2s) */

    /* Pre-computed Hann window (length = WEBRTC_AEC_FFT_LEN) */
    float window[WEBRTC_AEC_FFT_LEN];

    /* Pre-computed weightCurve and overDriveCurve resampled to 257 bins
     * using Speex's closed-form formulae (see webrtc_aec_nlp.c for derivation):
     *   weightCurve   = 0 at bin 0, else 0.3*sqrt((k-1)/(N-2)) + 0.1
     *   overDriveCurve = sqrt(k/(N-1)) + 1
     * N = WEBRTC_AEC_BY2_PLUS1 = 257 */
    float weightCurve[WEBRTC_AEC_BY2_PLUS1];
    float overDriveCurve[WEBRTC_AEC_BY2_PLUS1];

    /* Lazy-init flag: first Process call triggers Init */
    int   initialized;

    /* Diagnostic dump state (enable_vqe_dump gated) */
    long long dump_frame_idx;
    void*     dump_fp;  /* FILE*, NULL until first dump write */
} WebrtcAecNlpState;

/**
 * Initialize the Speex NLP state.
 * Zeros all buffers, pre-computes Hann window, sets hNlFbLocalMin/
 * hNlFbMin/hNlXdAvgMin/overDrive/overDriveSm = 1.0f.
 */
void WebrtcAecNlp_Init(WebrtcAecNlpState* s);

/**
 * Reset (equivalent to Init).
 */
void WebrtcAecNlp_Reset(WebrtcAecNlpState* s);

/**
 * Run one NLP cycle (= 256 samples = 16 ms @ 16 kHz).
 *
 * @param s           State (must be Init'd or lazy-init triggered on first call)
 * @param fft         FFT context (shared with EchoRemover::fft_512)
 * @param X_long      Render FFT (read-only, already delay-aligned)
 * @param Y_long      Mic FFT (unused by pure NLP but kept for future extensions)
 * @param E_long      Error FFT after linear filter
 * @param e_time      256 samples of time-domain error
 * @param d_time      256 samples of time-domain mic
 * @param G_long      Output: 257 per-bin amplitude gains in [0, 1]
 */
void WebrtcAecNlp_Process(
    WebrtcAecNlpState* s,
    const Aec3Fft* fft,
    const FftDataPfdkf* X_long,
    const FftDataPfdkf* Y_long,
    const FftDataPfdkf* E_long,
    const float* e_time,
    const float* d_time,
    float* G_long);

#ifdef __cplusplus
}
#endif

#endif /* WEBRTC_AEC_H_ */
