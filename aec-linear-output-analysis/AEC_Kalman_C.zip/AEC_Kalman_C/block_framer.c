/*
 *  Block Framer - Pure C Version
 *
 *  Converts 64-sample processing blocks back into 80-sample sub-frames.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#include "block_framer.h"
#include <string.h>
#include <assert.h>

void BlockFramer_Init(BlockFramer* self, int num_bands) {
    assert(self != NULL);
    assert(num_bands > 0 && num_bands <= AEC3_MAX_BANDS);
    memset(self->buffer, 0, sizeof(self->buffer));
    self->buffer_count = AEC3_BLOCK_SIZE;  /* Start full to avoid read-overrun on first InsertBlockAndExtractSubFrame */
    self->num_bands = num_bands;
}

void BlockFramer_InsertBlock(BlockFramer* self,
                             const float block[][AEC3_BLOCK_SIZE],
                             int num_bands) {
    int i;
    assert(self != NULL);
    assert(num_bands == self->num_bands);
    assert(self->buffer_count == 0);

    for (i = 0; i < num_bands; ++i) {
        memcpy(self->buffer[i], block[i],
               sizeof(float) * AEC3_BLOCK_SIZE);
    }
    self->buffer_count = AEC3_BLOCK_SIZE;
}

void BlockFramer_InsertBlockAndExtractSubFrame(
    BlockFramer* self,
    const float block[][AEC3_BLOCK_SIZE],
    float sub_frame[][AEC3_SUB_FRAME_LENGTH],
    int num_bands) {
    int i;
    int samples_to_frame;

    assert(self != NULL);
    if (self == NULL) return;
    assert(num_bands == self->num_bands);
    assert(self->buffer_count <= AEC3_BLOCK_SIZE);

    /*
     * The sub-frame (80 samples) is formed by:
     *   1. buffer_count samples from the internal buffer
     *   2. (80 - buffer_count) samples from the new block
     * The remaining block samples go into the buffer.
     */
    samples_to_frame = AEC3_SUB_FRAME_LENGTH - self->buffer_count;

    for (i = 0; i < num_bands; ++i) {
        /* Copy buffered samples to the beginning of the sub-frame */
        if (self->buffer_count > 0) {
            memcpy(sub_frame[i], self->buffer[i],
                   sizeof(float) * (size_t)self->buffer_count);
        }
        /* Fill the rest from the new block */
        memcpy(sub_frame[i] + self->buffer_count, block[i],
               sizeof(float) * (size_t)samples_to_frame);

        /* Store remaining block samples in the buffer */
        {
            int remaining = AEC3_BLOCK_SIZE - samples_to_frame;
            if (remaining > 0) {
                memcpy(self->buffer[i], block[i] + samples_to_frame,
                       sizeof(float) * (size_t)remaining);
            }
            /* Only update buffer_count once (same for all bands) */
            if (i == num_bands - 1) {
                self->buffer_count = remaining;
            }
        }
    }
}
