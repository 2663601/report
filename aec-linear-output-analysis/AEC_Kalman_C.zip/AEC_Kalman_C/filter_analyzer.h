/*
 *  FilterAnalyzer - Pure C Version
 *
 *  Analyzes properties of the adaptive filter: delay, gain, consistency.
 *  Ported from WebRTC AEC3 C++ FilterAnalyzer class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef FILTER_ANALYZER_H_
#define FILTER_ANALYZER_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "render_buffer.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * ConsistentFilterDetector (inlined)
 * ================================================================ */
typedef struct {
    int     significant_peak;
    float   filter_floor_accum;
    float   filter_secondary_peak;
    int     filter_floor_low_limit;
    int     filter_floor_high_limit;
    float   active_render_threshold;
    int     consistent_estimate_counter;
    int     consistent_delay_reference;
} ConsistentFilterDetector;

/* ================================================================
 * FilterRegion
 * ================================================================ */
typedef struct {
    int     start_sample;
    int     end_sample;
} FilterRegion;

/* ================================================================
 * FilterAnalyzer
 * ================================================================ */
typedef struct {
    int     use_preprocessed_filter;
    int     bounded_erl;
    float   default_gain;
    int     use_incremental_analysis;

    float   h_highpass[AEC3_MAX_FILTER_TIME_DOMAIN];
    int     h_highpass_len;

    int     delay_blocks;
    int     blocks_since_reset;
    int     consistent_estimate;
    float   gain;
    int     peak_index;
    int     filter_length_blocks;

    FilterRegion region;
    ConsistentFilterDetector consistent_filter_detector;
} FilterAnalyzer;

/**
 * Initialize the filter analyzer.
 */
void FilterAnalyzer_Init(FilterAnalyzer* self, const Aec3Config* config);

/**
 * Reset the filter analyzer state.
 */
void FilterAnalyzer_Reset(FilterAnalyzer* self);

/**
 * Update the analysis with new filter data.
 *
 * @param self                  Pointer to analyzer
 * @param filter_time_domain    Time-domain filter coefficients
 * @param filter_len            Length of filter array
 * @param render_buffer         Render buffer for consistency check
 */
void FilterAnalyzer_Update(FilterAnalyzer* self,
                           const float* filter_time_domain,
                           int filter_len,
                           const RenderBuffer* render_buffer);

/**
 * Get the filter delay in blocks.
 */
int FilterAnalyzer_DelayBlocks(const FilterAnalyzer* self);

/**
 * Get whether the filter estimate is consistent.
 */
int FilterAnalyzer_Consistent(const FilterAnalyzer* self);

/**
 * Get the estimated filter gain.
 */
float FilterAnalyzer_Gain(const FilterAnalyzer* self);

/**
 * Get the filter length in blocks.
 */
int FilterAnalyzer_FilterLengthBlocks(const FilterAnalyzer* self);

/**
 * Get the preprocessed (highpass) filter.
 */
const float* FilterAnalyzer_GetAdjustedFilter(const FilterAnalyzer* self);

#ifdef __cplusplus
}
#endif

#endif /* FILTER_ANALYZER_H_ */
