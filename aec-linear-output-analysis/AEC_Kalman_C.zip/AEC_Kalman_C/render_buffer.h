/*
 *  RenderBuffer - Pure C Version
 *
 *  Provides a view into the render data ring buffers for the echo remover.
 *  Wraps MatrixBuffer (time-domain blocks), VectorBuffer (power spectra),
 *  and FftBuffer (frequency-domain data).
 *
 *  Ported from WebRTC AEC3 C++ RenderBuffer class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef RENDER_BUFFER_H_
#define RENDER_BUFFER_H_

#include "aec3_common.h"
#include "aec3_buffer.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * RenderBuffer - Read-only view into render ring buffers
 *
 * Does not own the underlying buffers; merely holds pointers
 * to the MatrixBuffer, VectorBuffer, and FftBuffer instances
 * managed by RenderDelayBuffer.
 * ================================================================ */
typedef struct RenderBuffer_ {
    MatrixBuffer*   block_buffer;       /* Time-domain block ring buffer */
    VectorBuffer*   spectrum_buffer;    /* Power spectrum ring buffer */
    FftBufferPfdkf* fft_buffer_pfdkf;   /* PFDKF typed FFT ring buffer */
    int             render_activity;    /* Recent render signal activity flag */
} RenderBuffer;

/**
 * Initialize a RenderBuffer with pointers to the underlying ring buffers.
 *
 * @param self      Pointer to RenderBuffer
 * @param block_buf MatrixBuffer for time-domain blocks
 * @param spec_buf  VectorBuffer for power spectra
 */
void RenderBuffer_Init(RenderBuffer* self,
                       MatrixBuffer* block_buf,
                       VectorBuffer* spec_buf);

/**
 * Get a pointer to a time-domain block at the given offset and band.
 *
 * @param self              Pointer to RenderBuffer
 * @param offset_blocks     Offset from current read position
 * @param band              Band index (0..num_bands-1)
 * @return                  Pointer to AEC3_BLOCK_SIZE floats
 */
const float* RenderBuffer_Block(const RenderBuffer* self,
                                int offset_blocks, int band);

/**
 * Get a pointer to the power spectrum at the given offset.
 *
 * @param self          Pointer to RenderBuffer
 * @param offset_ffts   Offset from current read position
 * @return              Pointer to AEC3_FFT_LENGTH_BY2_PLUS1 floats
 */
const float* RenderBuffer_Spectrum(const RenderBuffer* self,
                                   int offset_ffts);

/**
 * Get a pointer to the PFDKF power spectrum at the given offset.
 *
 * @param self          Pointer to RenderBuffer
 * @param offset_ffts   Offset from current read position
 * @return              Pointer to spectrum floats (from buffer_pfdkf)
 */
const float* RenderBuffer_SpectrumPfdkf(const RenderBuffer* self,
                                        int offset_ffts);

/**
 * Get the current read position in the circular FFT buffer.
 *
 * @param self  Pointer to RenderBuffer
 * @return      Current read index
 */
int RenderBuffer_Position(const RenderBuffer* self);

/**
 * Compute the sum of power spectra over num_spectra consecutive entries.
 *
 * @param self          Pointer to RenderBuffer
 * @param num_spectra   Number of spectra to sum
 * @param X2            Output array of AEC3_FFT_LENGTH_BY2_PLUS1 floats
 */
void RenderBuffer_SpectralSum(const RenderBuffer* self,
                              int num_spectra, float* X2);

/**
 * Compute two spectral sums: a shorter and a longer window.
 *
 * @param self                  Pointer to RenderBuffer
 * @param num_spectra_shorter   Number of spectra for shorter sum
 * @param num_spectra_longer    Number of spectra for longer sum
 * @param X2_shorter            Output shorter sum (AEC3_FFT_LENGTH_BY2_PLUS1)
 * @param X2_longer             Output longer sum (AEC3_FFT_LENGTH_BY2_PLUS1)
 */
void RenderBuffer_SpectralSums(const RenderBuffer* self,
                               int num_spectra_shorter,
                               int num_spectra_longer,
                               float* X2_shorter,
                               float* X2_longer);

/**
 * Get the render activity flag.
 */
int RenderBuffer_GetRenderActivity(const RenderBuffer* self);

/**
 * Set the render activity flag.
 */
void RenderBuffer_SetRenderActivity(RenderBuffer* self, int activity);

/**
 * Get the headroom between write and read positions in the FFT buffer.
 *
 * @param self  Pointer to RenderBuffer
 * @return      Number of unread slots
 */
int RenderBuffer_Headroom(const RenderBuffer* self);

/**
 * Get a const pointer to the spectrum buffer.
 */
const VectorBuffer* RenderBuffer_GetSpectrumBuffer(const RenderBuffer* self);

/**
 * Get a const pointer to the block buffer.
 */
const MatrixBuffer* RenderBuffer_GetBlockBuffer(const RenderBuffer* self);

/**
 * Get a pointer to the typed PFDKF FFT buffer array.
 *
 * @param self  Pointer to RenderBuffer
 * @return      Pointer to the FftDataPfdkf array
 */
const FftDataPfdkf* RenderBuffer_GetFftBufferPfdkf(const RenderBuffer* self);

#ifdef __cplusplus
}
#endif

#endif /* RENDER_BUFFER_H_ */
