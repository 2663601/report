/*
 *  AEC3 Configuration - Default Values Implementation
 *
 *  All default values are taken directly from the C++ sources:
 *    - EchoCanceller3Config (aec3_source/api/echo_canceller3_config.h)
 *    - AECConfigParameter   (VQE/AEC_Kalman/ys_aec_kalman.cpp)
 *
 *  128-point main/shadow filter parameters removed — only PFDKF retained.
 *  C99 compatible.
 */

#include "aec3_config.h"
#include <string.h>  /* memset */

void Aec3Config_SetDefaults(Aec3Config* config)
{
    if (!config) return;
    memset(config, 0, sizeof(Aec3Config));

    /* ---- Delay estimation ---- */
    config->delay_default                        = 5;
    config->delay_down_sampling_factor           = 4;
    config->delay_num_filters                    = 5;
    config->delay_api_call_jitter_blocks         = 26;
    config->delay_min_echo_path_delay_blocks     = 0;
    config->delay_headroom_blocks                = 2;
    config->delay_hysteresis_limit_1_blocks      = 1;
    config->delay_hysteresis_limit_2_blocks      = 1;
    config->delay_skew_hysteresis_blocks         = 3;
    config->delay_fixed_capture_delay_samples    = 0;
    config->delay_estimate_smoothing             = 0.7f;
    config->delay_candidate_detection_threshold  = 0.2f;
    config->delay_selection_thresholds_initial   = 5;
    config->delay_selection_thresholds_converged = 20;

    /* ---- PFDKF ---- */
    config->pfdkf_num_block     = 13;

    /* ---- Main filter (retained for buffer sizing / filter analyzer) ---- */
    config->filter_main_length_blocks       = 13;
    config->filter_main_leakage_converged   = 0.00005f;
    config->filter_main_leakage_diverged    = 0.05f;
    config->filter_main_error_floor         = 0.001f;
    config->filter_main_error_ceil          = 2.f;
    config->filter_main_noise_gate          = 20075344.f;

    /* ---- Main filter initial (retained for filter analyzer) ---- */
    config->filter_main_initial_length_blocks       = 12;
    config->filter_main_initial_leakage_converged   = 0.005f;
    config->filter_main_initial_leakage_diverged    = 0.5f;
    config->filter_main_initial_error_floor         = 0.001f;
    config->filter_main_initial_error_ceil          = 2.f;
    config->filter_main_initial_noise_gate          = 20075344.f;
    config->pfdkf_shift_block   = 3;
    config->pfdkf_Hsize         = 5;
    config->pfdkf_error_floor   = 0.003f;
    config->pfdkf_error_ceil    = 20.f;
    config->pfdkf_noise_gate    = 1543800.f;
    config->pfdkf_noise_gate2   = 15438.f;

    /* ---- Filter state ---- */
    config->config_change_duration_blocks           = 250;
    config->initial_state_seconds                   = 2.5f;
    config->conservative_initial_phase              = 0;
    config->enable_shadow_filter_output_usage       = 1;

    /* ---- ERLE ---- */
    config->erle_min            = 1.f;
    config->erle_max_l          = 30.f;
    config->erle_max_h          = 10.f;
    config->erle_min_512fft     = 1.f;
    config->erle_max_l_512fft   = 4.f;
    config->erle_max_h_512fft   = 1.5f;
    config->erle_max_512loop_l  = 30.f;
    config->erle_max_512loop_h  = 10.f;
    config->erle_onset_detection = 1;
    config->erle_num_sections   = 1;

    /* ---- Echo path strength ---- */
    config->ep_strength_lf                      = 1.f;
    config->ep_strength_mf                      = 1.f;
    config->ep_strength_hf                      = 1.f;
    config->ep_strength_default_len             = 0.83f;
    config->ep_strength_reverb_based_on_render  = 1;
    config->ep_strength_echo_can_saturate       = 1;
    config->ep_strength_bounded_erl             = 0;

    /* ---- Echo audibility ---- */
    config->echo_audibility_low_render_limit                    = 256.f;
    config->echo_audibility_normal_render_limit                 = 64.f;
    config->echo_audibility_floor_power                         = 128.f;
    config->echo_audibility_audibility_threshold_lf             = 12.f;
    config->echo_audibility_audibility_threshold_mf             = 10.f;
    config->echo_audibility_audibility_threshold_hf             = 8.f;
    config->echo_audibility_use_stationary_properties           = 0;
    config->echo_audibility_use_stationarity_properties_at_init = 0;

    /* ---- Render levels ---- */
    config->render_levels_active_render_limit              = 100.f;
    config->render_levels_poor_excitation_render_limit     = 150.f;
    config->render_levels_poor_excitation_render_limit_ds8 = 20.f;

    /* ---- Echo removal control / gain rampup ---- */
    config->gain_rampup_initial_gain            = 0.0f;
    config->gain_rampup_first_non_zero_gain     = 0.001f;
    config->gain_rampup_non_zero_gain_blocks    = 187;
    config->gain_rampup_full_gain_blocks        = 312;
    config->echo_removal_has_clock_drift        = 0;
    config->echo_removal_linear_and_stable_echo_path = 0;

    /* ---- Echo model ---- */
    config->echo_model_noise_floor_hold             = 50;
    config->echo_model_min_noise_floor_power        = 1638400.f;
    config->echo_model_stationary_gate_slope        = 10.f;
    config->echo_model_noise_gate_power             = 27509.42f;
    config->echo_model_noise_gate_slope             = 0.3f;
    config->echo_model_render_pre_window_size       = 1;
    config->echo_model_render_post_window_size      = 1;
    config->echo_model_render_pre_window_size_init  = 10;
    config->echo_model_render_post_window_size_init = 10;
    config->echo_model_nonlinear_hold               = 1.f;
    config->echo_model_nonlinear_release            = 0.001f;

    /* ---- Suppressor ---- */
    config->suppressor_nearend_average_blocks = 4;

    /* normal_tuning_512fft */
    config->suppressor_normal_tuning_512fft_mask_lf_enr_transparent  = 0.3f;
    config->suppressor_normal_tuning_512fft_mask_lf_enr_suppress     = 0.4f;
    config->suppressor_normal_tuning_512fft_mask_lf_emr_transparent  = 0.3f;
    config->suppressor_normal_tuning_512fft_mask_hf_enr_transparent  = 0.07f;
    config->suppressor_normal_tuning_512fft_mask_hf_enr_suppress     = 0.1f;
    config->suppressor_normal_tuning_512fft_mask_hf_emr_transparent  = 0.3f;
    config->suppressor_normal_tuning_512fft_max_inc_factor           = 2.0f;
    config->suppressor_normal_tuning_512fft_max_dec_factor_lf        = 0.25f;

    /* normal_tuning_512fft_earphone */
    config->suppressor_normal_tuning_512fft_earphone_mask_lf_enr_transparent  = 0.6f;
    config->suppressor_normal_tuning_512fft_earphone_mask_lf_enr_suppress     = 0.9f;
    config->suppressor_normal_tuning_512fft_earphone_mask_lf_emr_transparent  = 0.3f;
    config->suppressor_normal_tuning_512fft_earphone_mask_hf_enr_transparent  = 0.2f;
    config->suppressor_normal_tuning_512fft_earphone_mask_hf_enr_suppress     = 0.5f;
    config->suppressor_normal_tuning_512fft_earphone_mask_hf_emr_transparent  = 0.3f;
    config->suppressor_normal_tuning_512fft_earphone_max_inc_factor           = 2.0f;
    config->suppressor_normal_tuning_512fft_earphone_max_dec_factor_lf        = 0.25f;

    /* echo_tuning */
    config->suppressor_echo_tuning_mask_lf_enr_transparent  = 0.00005f;
    config->suppressor_echo_tuning_mask_lf_enr_suppress     = 0.004f;
    config->suppressor_echo_tuning_mask_lf_emr_transparent  = 0.00005f;
    config->suppressor_echo_tuning_mask_hf_enr_transparent  = 0.00007f;
    config->suppressor_echo_tuning_mask_hf_enr_suppress     = 0.001f;
    config->suppressor_echo_tuning_mask_hf_emr_transparent  = 0.00003f;
    config->suppressor_echo_tuning_max_inc_factor           = 1.0f;
    config->suppressor_echo_tuning_max_dec_factor_lf        = 0.125f;

    /* nearend_tuning */
    config->suppressor_nearend_tuning_mask_lf_enr_transparent  = 1.09f;
    config->suppressor_nearend_tuning_mask_lf_enr_suppress     = 1.1f;
    config->suppressor_nearend_tuning_mask_lf_emr_transparent  = 0.3f;
    config->suppressor_nearend_tuning_mask_hf_enr_transparent  = 0.1f;
    config->suppressor_nearend_tuning_mask_hf_enr_suppress     = 0.3f;
    config->suppressor_nearend_tuning_mask_hf_emr_transparent  = 0.3f;
    config->suppressor_nearend_tuning_max_inc_factor           = 2.0f;
    config->suppressor_nearend_tuning_max_dec_factor_lf        = 0.25f;

    /* dominant_nearend_detection */
    config->suppressor_dominant_nearend_enr_threshold           = 0.25f;
    config->suppressor_dominant_nearend_enr_exit_threshold      = 10.f;
    config->suppressor_dominant_nearend_snr_threshold           = 30.f;
    config->suppressor_dominant_nearend_hold_duration           = 50;
    config->suppressor_dominant_nearend_trigger_threshold       = 12;
    config->suppressor_dominant_nearend_use_during_initial_phase = 1;

    /* high_bands_suppression */
    config->suppressor_high_bands_enr_threshold         = 1.f;
    config->suppressor_high_bands_max_gain_during_echo  = 1.f;

    config->suppressor_floor_first_increase         = 0.00001f;
    config->suppressor_enforce_transparent          = 0;
    config->suppressor_enforce_empty_higher_bands   = 0;

    /* ---- Buffering ---- */
    config->buffering_use_new_render_buffering                = 1;
    config->buffering_excess_render_detection_interval_blocks = 250;
    config->buffering_max_allowed_excess_render_blocks        = 8;

    /* ---- PFDKF suppress floor tuning ----
     * suppress_floor_coeff: suppress_gain floor scaling factor.
     * Range [0, 1]. Lower = stronger echo suppression, weaker DT protection.
     * Used in PFDKF: suppress_floor_k = combined^2 * coeff.
     * 0.0 = no nearend protection floor (strongest echo suppression)
     * 1.0 = full nearend protection (default, best DT preservation)
     * Recommended: 0.8 for H=6 optimization */
    config->suppress_floor_coeff                = 1.0f;

    /* ---- Reverb suppression tuning (used when enable_echo_reverb=1) ----
     * ep_strength_default_gain: reverb tail echo injection gain.
     * Range [0, 1]. Higher = more aggressive reverb suppression.
     * Used in ResidualEchoEstimator: freq_response_tail * gain.
     * 0.0 = no reverb injection (low ERLE in high reverb)
     * 0.5 = strong reverb estimation (+15dB ERLE, slight DT cost)
     * 1.0 = maximum (highest ERLE, severe DT degradation)
     * Recommended: 0.2 (default), 0.5 (H=6 high-reverb) */
    config->ep_strength_default_gain            = 0.2f;
    config->reverb_decay_max                    = 0.95f;
    config->reverb_fast_convergence_blocks      = 500;
}

void AecRuntimeConfig_SetDefaults(AecRuntimeConfig* config)
{
    if (!config) return;
    memset(config, 0, sizeof(AecRuntimeConfig));

    config->aec_level                           = 1;
    config->aec_nlp_level                       = 1.0f;
    config->aec_512fft_enable                   = 1;
    config->matched_filter_enable               = 0;
    config->use_noise_gate_division             = 1;
    config->use_cache_filter                    = 1;
    config->aec_dtcontrol_enable                = 0;
    config->highpass_enable_capture              = 1;
    config->highpass_enable_render               = 1;
    config->dtd_flag                            = 1;
    config->init_blocks                         = 1;
    config->aec_H_usage                         = 30;
    config->double_talk_count_max               = 30;
    config->ed_ratio_2k_threshold               = 0.02f;
    config->howl_supp                           = 1;
    config->delay_default                       = 0;
    config->apm_submodule_switch                = 1;
    config->render_started                      = 0;
    config->mute_flag                           = 0;
    config->nonlinear_level                     = 0.f;
    config->CNG_level                           = -1;
    config->audioMixing_flag                    = 0;
    config->loopback_capture_mode               = 0;
    config->earphone_capture_mode               = 0;
    config->voip_mode_enable                    = 0;
    config->voip_mode_proc_enable               = 0;
    config->initial_sup_flag                    = 0;
    config->external_audio_mixing               = 0;
    config->special_device_lowband_ext_gain_enable = 0;
    config->special_device_lowband_max_band     = 6;
    config->special_device_lowband_min_power    = 6.f;
    config->special_device_lowband_ext_gain     = 16.f;
    config->voip_mode_enable_ver                = 0;
    config->CastScreen                          = 0;
    config->weak_resecho_thd                    = 10;
    config->aec_delay_gcc_enable                = 0;
    config->aec_low_compute_mode                = 1;
    config->enable_echo_reverb                  = 0;
    config->ExcludeNoiseFromEchoFlag            = 0;
    config->extra_echo_sup                      = 1;
    config->builtin_aec_active_detect_enable    = 0;

    /* Noise gate defaults */
    config->noise_gate_enable                   = 1;
    config->noise_gate_threshold                = 200;
    config->noise_gate_setting_gain             = 0.1f;
    config->noise_gate_gain_dec_factor          = 0.9f;
    config->aec_noise_gate_enable               = 0;

    /* NLP implementation: default to AEC3 path to preserve baseline scoring */
    config->webrtc_aec_mode                            = 0;
}
