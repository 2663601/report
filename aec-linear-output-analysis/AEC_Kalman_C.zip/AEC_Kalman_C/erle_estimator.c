/*
 *  ErleEstimator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ErleEstimator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point PFDKF path retained.
 */

#include "erle_estimator.h"
#include <string.h>
#include <math.h>
#include <stdio.h>

void ErleEstimator_Init(ErleEstimator* self,
                        int startup_phase_length_blocks,
                        const Aec3Config* config) {
    int i;
    memset(self, 0, sizeof(ErleEstimator));
    self->startup_phase_length_blocks = startup_phase_length_blocks;
    self->blocks_since_reset = 0;

    self->erle_min_512fft = config->erle_min_512fft;
    self->erle_max_l_512fft = config->erle_max_l_512fft;
    self->erle_max_h_512fft = config->erle_max_h_512fft;
    self->onset_detection = config->erle_onset_detection;

    for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; i++) {
        self->erle_long[i] = self->erle_min_512fft;
        self->erle_long_greater[i] = self->erle_min_512fft;
        self->accum_Y2_long[i] = 0.0f;
        self->accum_E2_long[i] = 0.0f;
        self->accum_num_points_long[i] = 0;
    }
    self->fullband_erle_log2 = 0.0f;
    self->fullband_hold_counter = 0;
}

void ErleEstimator_Reset(ErleEstimator* self, int delay_change) {
    int i;

    /* Reset fullband */
    self->fullband_erle_log2 = 0.0f;
    self->fullband_hold_counter = 0;

    if (delay_change) {
        self->blocks_since_reset = 0;
    }
}

void ErleEstimator_Update512fft(ErleEstimator* self,
                                const float* X2_reverb,
                                const float* Y2,
                                const float* E2,
                                int converged_filter,
                                int onset_detection,
                                int use_update,
                                int under_suppression) {
    int k;
    static const float kX2BandEnergyThreshold = 500.0f;
    static const int kPointsToAccumulate = 1;
    static const float kAccumAlpha = 0.15f;
    static const float kErleAlpha = 0.3f;

    self->blocks_since_reset++;
    if (self->blocks_since_reset < self->startup_phase_length_blocks) {
        return;
    }

    if (!converged_filter) {
        goto finish;
    }

    /* Step 1: UpdateAccumulatedSpectra_512fft */
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        if (X2_reverb[k] > kX2BandEnergyThreshold) {
            float alpha = kAccumAlpha;
            if (self->accum_num_points_long[k] == kPointsToAccumulate ||
                use_update == 0) {
                self->accum_Y2_long[k] = 0.0f;
                self->accum_E2_long[k] = 0.0f;
                self->accum_num_points_long[k] = 0;
            }
            self->accum_Y2_long[k] += alpha * (Y2[k] - self->accum_Y2_long[k]);
            self->accum_E2_long[k] += alpha * (E2[k] - self->accum_E2_long[k]);
            self->accum_num_points_long[k]++;
        }
    }

    /* Step 2: UpdateBands_512fft */
    for (k = 1; k < AEC3_FFT_LENGTH_LONG_BY2; k++) {
        if (self->accum_num_points_long[k] == kPointsToAccumulate &&
            self->accum_E2_long[k] > 0.0f) {
            float new_erle = self->accum_Y2_long[k] / self->accum_E2_long[k];

            /* erle_long: clamp to [min, 10.0] */
            {
                float updated = self->erle_long[k] + kErleAlpha * (new_erle - self->erle_long[k]);
                if (updated < self->erle_min_512fft) updated = self->erle_min_512fft;
                if (updated > 10.0f) updated = 10.0f;
                self->erle_long[k] = updated;
            }

            /* erle_long_greater: clamp to [min, 100.0] */
            {
                float updated = self->erle_long_greater[k] + kErleAlpha * (new_erle - self->erle_long_greater[k]);
                if (updated < self->erle_min_512fft) updated = self->erle_min_512fft;
                if (updated > 100.0f) updated = 100.0f;
                self->erle_long_greater[k] = updated;
            }
        }
    }

finish:
    self->erle_long[0] = self->erle_long[1];
    self->erle_long[AEC3_FFT_LENGTH_LONG_BY2] = self->erle_long[AEC3_FFT_LENGTH_LONG_BY2 - 1];
    self->erle_long_greater[0] = self->erle_long_greater[1];
    self->erle_long_greater[AEC3_FFT_LENGTH_LONG_BY2] =
        self->erle_long_greater[AEC3_FFT_LENGTH_LONG_BY2 - 1];
}

const float* ErleEstimator_ErleLong(const ErleEstimator* self) {
    return self->erle_long;
}

const float* ErleEstimator_ErleLongGreater(const ErleEstimator* self) {
    return self->erle_long_greater;
}

float ErleEstimator_FullbandErleLog2(const ErleEstimator* self) {
    return self->fullband_erle_log2;
}
