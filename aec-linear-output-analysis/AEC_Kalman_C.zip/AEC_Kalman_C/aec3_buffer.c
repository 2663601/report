/*
 *  AEC3 Ring Buffers - Pure C Implementation
 *
 *  Ported from WebRTC AEC3 C++ VectorBuffer, MatrixBuffer, FftBuffer.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "aec3_buffer.h"
#include <string.h>  /* memset */

/* ================================================================
 * VectorBuffer
 * ================================================================ */

void VectorBuffer_Init(VectorBuffer* self, float* mem, int size, int height, int pfdkf_height) {
    self->size   = size;
    self->height = height;
    self->pfdkf_height = pfdkf_height;
    /* 128pt buffer removed — only PFDKF buffer is allocated */
    self->buffer = NULL;
    self->buffer_pfdkf = mem;
    self->write  = 0;
    self->read   = 0;
    memset(self->buffer_pfdkf, 0, (size_t)size * (size_t)pfdkf_height * sizeof(float));
}

int VectorBuffer_OffsetIndex(const VectorBuffer* self, int index, int offset) {
    return (self->size + index + offset) % self->size;
}

void VectorBuffer_IncWriteIndex(VectorBuffer* self) {
    self->write = (self->write < self->size - 1) ? self->write + 1 : 0;
}

void VectorBuffer_DecWriteIndex(VectorBuffer* self) {
    self->write = (self->write > 0) ? self->write - 1 : self->size - 1;
}

/* ================================================================
 * MatrixBuffer
 * ================================================================ */

void MatrixBuffer_Init(MatrixBuffer* self, float* mem,
                       int size, int height, int width) {
    self->size   = size;
    self->height = height;
    self->width  = width;
    self->buffer = mem;
    self->write  = 0;
    self->read   = 0;
    memset(self->buffer, 0,
           (size_t)size * (size_t)height * (size_t)width * sizeof(float));
}

float* MatrixBuffer_GetSlot(const MatrixBuffer* self, int index, int band) {
    return self->buffer + ((size_t)index * self->height + band) * self->width;
}

int MatrixBuffer_OffsetIndex(const MatrixBuffer* self, int index, int offset) {
    return (self->size + index + offset) % self->size;
}

void MatrixBuffer_IncWriteIndex(MatrixBuffer* self) {
    self->write = (self->write < self->size - 1) ? self->write + 1 : 0;
}

void MatrixBuffer_DecWriteIndex(MatrixBuffer* self) {
    self->write = (self->write > 0) ? self->write - 1 : self->size - 1;
}

/* ================================================================
 * Additional read index manipulation functions
 * ================================================================ */

void MatrixBuffer_IncReadIndex(MatrixBuffer* self) {
    self->read = (self->read < self->size - 1) ? self->read + 1 : 0;
}

void MatrixBuffer_DecReadIndex(MatrixBuffer* self) {
    self->read = (self->read > 0) ? self->read - 1 : self->size - 1;
}

void VectorBuffer_IncReadIndex(VectorBuffer* self) {
    self->read = (self->read < self->size - 1) ? self->read + 1 : 0;
}

void VectorBuffer_DecReadIndex(VectorBuffer* self) {
    self->read = (self->read > 0) ? self->read - 1 : self->size - 1;
}

/* ================================================================
 * FftBuffer128
 * ================================================================ */

void FftBuffer128_Init(FftBuffer128* self, FftData128* mem, int size) {
    int i;
    self->size   = size;
    self->buffer = mem;
    self->write  = 0;
    self->read   = 0;
    for (i = 0; i < size; ++i) {
        FftData128_Clear(&self->buffer[i]);
    }
}

int FftBuffer128_OffsetIndex(const FftBuffer128* self, int index, int offset) {
    return (self->size + index + offset) % self->size;
}

void FftBuffer128_IncWriteIndex(FftBuffer128* self) {
    self->write = (self->write < self->size - 1) ? self->write + 1 : 0;
}

void FftBuffer128_DecWriteIndex(FftBuffer128* self) {
    self->write = (self->write > 0) ? self->write - 1 : self->size - 1;
}

void FftBuffer128_IncReadIndex(FftBuffer128* self) {
    self->read = (self->read < self->size - 1) ? self->read + 1 : 0;
}

void FftBuffer128_DecReadIndex(FftBuffer128* self) {
    self->read = (self->read > 0) ? self->read - 1 : self->size - 1;
}

/* ================================================================
 * FftBufferPfdkf
 * ================================================================ */

void FftBufferPfdkf_Init(FftBufferPfdkf* self, FftDataPfdkf* mem, int size) {
    /* SoA layout: reinterpret the raw memory as two contiguous float arrays.
     * Total memory = size * sizeof(FftDataPfdkf) = size * 2056 bytes
     * = size * 514 floats = enough for relf[size*257] + imlf[size*257] */
    float* raw = (float*)mem;
    self->size     = size;
    self->buffer   = mem;  /* keep AoS alias for cold-path compat */
    self->relf_buf = raw;
    self->imlf_buf = raw + (size_t)size * AEC3_LF_FFT_LENGTH_BY2_PLUS1;
    self->write    = 0;
    self->read     = 0;
    memset(self->relf_buf, 0, (size_t)size * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * sizeof(float));
    memset(self->imlf_buf, 0, (size_t)size * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * sizeof(float));
}

int FftBufferPfdkf_OffsetIndex(const FftBufferPfdkf* self, int index, int offset) {
    return (self->size + index + offset) % self->size;
}

void FftBufferPfdkf_IncWriteIndex(FftBufferPfdkf* self) {
    self->write = (self->write < self->size - 1) ? self->write + 1 : 0;
}

void FftBufferPfdkf_DecWriteIndex(FftBufferPfdkf* self) {
    self->write = (self->write > 0) ? self->write - 1 : self->size - 1;
}

void FftBufferPfdkf_IncReadIndex(FftBufferPfdkf* self) {
    self->read = (self->read < self->size - 1) ? self->read + 1 : 0;
}

void FftBufferPfdkf_DecReadIndex(FftBufferPfdkf* self) {
    self->read = (self->read > 0) ? self->read - 1 : self->size - 1;
}
