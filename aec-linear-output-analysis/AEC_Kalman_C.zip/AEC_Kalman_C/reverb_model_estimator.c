/*
 *  ReverbModelEstimator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ReverbModelEstimator class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "reverb_model_estimator.h"

void ReverbModelEstimator_Init(ReverbModelEstimator* self,
                               const Aec3Config* config) {
    ReverbDecayEstimator_Init(&self->reverb_decay_estimator, config);
    ReverbFrequencyResponse_Init(&self->reverb_frequency_response);
    ReverbFrequencyResponseLong_Init(&self->reverb_freq_resp_long);
}

void ReverbModelEstimator_Update(ReverbModelEstimator* self,
                                 const float* impulse_response,
                                 int impulse_response_len,
                                 const float (*H2)[AEC3_FFT_LENGTH_BY2_PLUS1],
                                 int num_partitions,
                                 float linear_filter_quality,
                                 int has_quality,
                                 int filter_delay_blocks,
                                 int usable_linear_estimate,
                                 int stationary_block) {
    /* Update frequency response estimate */
    ReverbFrequencyResponse_Update(&self->reverb_frequency_response,
                                   H2, num_partitions,
                                   filter_delay_blocks,
                                   linear_filter_quality,
                                   has_quality,
                                   stationary_block);

    /* Update decay estimate */
    ReverbDecayEstimator_Update(&self->reverb_decay_estimator,
                                impulse_response, impulse_response_len,
                                linear_filter_quality, has_quality,
                                filter_delay_blocks,
                                usable_linear_estimate,
                                stationary_block);
}

float ReverbModelEstimator_ReverbDecay(const ReverbModelEstimator* self) {
    return ReverbDecayEstimator_Decay(&self->reverb_decay_estimator);
}

const float* ReverbModelEstimator_GetReverbFrequencyResponse(
    const ReverbModelEstimator* self) {
    return ReverbFrequencyResponse_GetResponse(&self->reverb_frequency_response);
}
