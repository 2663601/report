/*
 *  RenderDelayBuffer - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ render_delay_buffer.cc
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "render_delay_buffer.h"

#include <assert.h>
#include <math.h>
#include <string.h>

/* ================================================================
 * Internal helpers
 * ================================================================ */

static int LowRateBufferOffset(const Aec3Config* config)
{
    return RenderDelayBuffer_DelayEstimatorOffset(config) >> 1;
}

/* Advance write indices for all render buffers */
static void IncreaseWriteIndices(int sub_block_size,
                                 MatrixBuffer* blocks,
                                 VectorBuffer* spectra,
                                 DownsampledRenderBuffer* low_rate,
                                 FftBufferPfdkf* fft_buf_pfdkf)
{
    /* Move low_rate write index backward by sub_block_size */
    low_rate->write -= sub_block_size;
    if (low_rate->write < 0) {
        low_rate->write += low_rate->size;
    }

    MatrixBuffer_IncWriteIndex(blocks);
    VectorBuffer_DecWriteIndex(spectra);
    if (fft_buf_pfdkf) FftBufferPfdkf_DecWriteIndex(fft_buf_pfdkf);
}

/* Advance low_rate read indices only (Impl2::IncrementLowRateReadIndices) */
static void IncreaseLowRateReadIndices(int sub_block_size,
                                       DownsampledRenderBuffer* low_rate)
{
    low_rate->read -= sub_block_size;
    if (low_rate->read < 0) {
        low_rate->read += low_rate->size;
    }
}

/* Advance block/spectra/fft read indices only (Impl2::IncrementReadIndices) */
static void IncreaseBlockReadIndices(MatrixBuffer* blocks,
                                     VectorBuffer* spectra,
                                     FftBufferPfdkf* fft_buf_pfdkf)
{
    if (blocks->read != blocks->write) {
        MatrixBuffer_IncReadIndex(blocks);
        VectorBuffer_DecReadIndex(spectra);
        if (fft_buf_pfdkf) FftBufferPfdkf_DecReadIndex(fft_buf_pfdkf);
    }
}

/* Check for render buffer overrun */
static int RenderOverrun(const MatrixBuffer* b,
                         const DownsampledRenderBuffer* l)
{
    return (l->read == l->write) || (b->read == b->write);
}

/* Check for render buffer underrun (Impl2: only checks low_rate) */
static int RenderUnderrun(const DownsampledRenderBuffer* l)
{
    return (l->read == l->write);
}

/* Compute latency in the downsampled buffer */
static int BufferLatency(const DownsampledRenderBuffer* l)
{
    return (l->size + l->read - l->write) % l->size;
}

/* Check for API call skew */
static int ApiCallSkew(const DownsampledRenderBuffer* low_rate,
                       int sub_block_size,
                       int low_rate_buffer_offset_sub_blocks)
{
    int latency = BufferLatency(low_rate);
    int expected = low_rate_buffer_offset_sub_blocks * sub_block_size;
    int skew = abs(expected - latency);
    return skew >= expected;
}

/* Map external delay to internal delay */
static int MapExternalDelayToInternalDelay(const RenderDelayBuffer* self,
                                           int external_delay_blocks)
{
    int latency = BufferLatency(&self->low_rate);
    int latency_blocks;
    assert(self->sub_block_size > 0);
    latency_blocks = latency / self->sub_block_size;
    return latency_blocks + external_delay_blocks -
           RenderDelayBuffer_DelayEstimatorOffset(&self->config);
}

/* Map internal delay to external delay */
static int MapInternalDelayToExternalDelay(const RenderDelayBuffer* self)
{
    /* RenderDelayBufferImpl2::ComputeDelay — no DelayEstimatorOffset */
    int latency = BufferLatency(&self->low_rate);
    int latency_blocks = latency / self->sub_block_size;
    int internal_delay;

    if (self->spectra.read >= self->spectra.write) {
        internal_delay = self->spectra.read - self->spectra.write;
    } else {
        internal_delay = self->spectra.size +
                         self->spectra.read - self->spectra.write;
    }

    return internal_delay - latency_blocks;
}

/* Apply delay to buffer read indices */
static void ApplyDelay(RenderDelayBuffer* self, int delay)
{
    self->blocks.read = MatrixBuffer_OffsetIndex(&self->blocks,
                                                  self->blocks.write, -delay);
    self->spectra.read = VectorBuffer_OffsetIndex(&self->spectra,
                                                   self->spectra.write, delay);
    if (self->fft_buffer_pfdkf)
        self->fft_buffer_pfdkf->read = FftBufferPfdkf_OffsetIndex(self->fft_buffer_pfdkf,
                                                                     self->fft_buffer_pfdkf->write, delay);
}

/* Insert a block into the ring buffers (time-domain, FFT, spectrum, downsampled) */
static void InsertBlock(RenderDelayBuffer* self,
                        const float block[][AEC3_BLOCK_SIZE],
                        int num_bands,
                        int previous_write)
{
    int k, i;
    float* dst;
    int ds_len;

    /* Copy time-domain block into MatrixBuffer */
    for (k = 0; k < num_bands; ++k) {
        dst = MatrixBuffer_GetSlot(&self->blocks, self->blocks.write, k);
        memcpy(dst, block[k], sizeof(float) * AEC3_BLOCK_SIZE);
    }

    /* Decimate band 0 for downsampled buffer */
    ds_len = self->sub_block_size;
    Decimator_Decimate(&self->render_decimator,
                       block[0], self->render_ds, AEC3_BLOCK_SIZE);

    /* Copy decimated data into low_rate buffer (reversed order) */
    for (i = 0; i < ds_len; ++i) {
        int idx = (self->low_rate.write + i) % self->low_rate.size;
        self->low_rate.buffer[idx] = self->render_ds[ds_len - 1 - i];
    }

    /* Compute padded FFT: previous_block[0] + current_block[0] -> FFT128 -> FftData128 */
    /* NOTE: 128pt FFT and fft_buffer_128 completely removed — using fft_buffer_pfdkf for index sync */

    /* 128pt power spectrum write removed — spectra.buffer is NULL */

    /* ---- PFDKF 512-point FFT ---- */
    {
        FftDataPfdkf fft_tmp;  /* temporary AoS for FFT output */
        Aec3Fft_PaddedFftPfdkf_typed(&self->fft_pfdkf, block[0], self->x_lf,
                                &fft_tmp);

        /* Write to SoA ring buffer */
        FftBufferPfdkf_WriteSlot(self->fft_buffer_pfdkf,
                                 self->fft_buffer_pfdkf->write, &fft_tmp);

        /* Compute PFDKF power spectrum from the temporary */
        {
            float* spec_pfdkf_dst = self->spectra.buffer_pfdkf +
                                    self->spectra.write * self->spectra.pfdkf_height;
            FftDataPfdkf_Spectrum(&fft_tmp, spec_pfdkf_dst);
        }

        /* Shift x_lf */
        memmove(self->x_lf, self->x_lf + AEC3_LF_BLOCK_LENGTH,
                (AEC3_LF_FFT_DISTANCE - AEC3_LF_BLOCK_LENGTH) * sizeof(float));
        memcpy(self->x_lf + (AEC3_LF_FFT_DISTANCE - AEC3_LF_BLOCK_LENGTH),
               block[0], AEC3_LF_BLOCK_LENGTH * sizeof(float));
    }
}

/* Detect active render signal */
static int DetectActiveRender(const RenderDelayBuffer* self,
                              const float* x, int len)
{
    float energy = 0.0f;
    float threshold;
    int i;

    for (i = 0; i < len; ++i) {
        energy += x[i] * x[i];
    }

    threshold = self->config.render_levels_active_render_limit *
                self->config.render_levels_active_render_limit *
                (float)AEC3_FFT_LENGTH_BY2;

    return energy > threshold;
}

/* Detect excess render blocks (Impl2::DetectExcessRenderBlocks) */
static int DetectExcessRenderBlocks(RenderDelayBuffer* self)
{
    int excess_render_detected = 0;
    int latency_blocks = BufferLatency(&self->low_rate) / self->sub_block_size;

    /* Track minimum latency */
    if (latency_blocks < self->min_latency_blocks) {
        self->min_latency_blocks = latency_blocks;
    }

    /* After processing a configurable number of blocks, check minimum latency */
    if (++self->excess_render_detection_counter >=
        self->config.buffering_excess_render_detection_interval_blocks) {
        /* If minimum latency exceeds threshold, too many render blocks */
        excess_render_detected =
            self->min_latency_blocks > self->max_allowed_excess_render_blocks;
        /* Reset counter and let minimum latency be current latency */
        self->min_latency_blocks = latency_blocks;
        self->excess_render_detection_counter = 0;
    }

    return excess_render_detected;
}

/* ================================================================
 * Public API
 * ================================================================ */

int RenderDelayBuffer_DelayEstimatorOffset(const Aec3Config* config)
{
    return config->delay_api_call_jitter_blocks * 2;
}

void RenderDelayBuffer_Init(RenderDelayBuffer* self,
                            const Aec3Config* config,
                            int num_bands,
                            int render_buffer_size,
                            float* blocks_mem,
                            float* spectra_mem,
                            FftDataPfdkf* ffts2_mem,
                            float* low_rate_mem,
                            FftBufferPfdkf* fft_buffer_pfdkf)
{
    int buf_size;

    assert(self != NULL);
    assert(config != NULL);
    assert(render_buffer_size > 0);

    self->config = *config;
    self->num_bands = num_bands;
    self->down_sampling_factor = config->delay_down_sampling_factor;
    self->sub_block_size = (self->down_sampling_factor > 0)
        ? AEC3_BLOCK_SIZE / self->down_sampling_factor
        : AEC3_BLOCK_SIZE;
    self->buffer_headroom = config->filter_main_length_blocks;

    /* Compute buffer size: use externally provided render_buffer_size as buf_size directly */
    buf_size = render_buffer_size;
    self->buffer_size = buf_size;

    /* Initialize ring buffers with pre-allocated memory */
    self->blocks_mem = blocks_mem;
    MatrixBuffer_Init(&self->blocks, blocks_mem,
                      buf_size, num_bands, AEC3_BLOCK_SIZE);

    self->spectra_mem = spectra_mem;
    VectorBuffer_Init(&self->spectra, spectra_mem,
                      buf_size, AEC3_FFT_LENGTH_BY2_PLUS1,
                      AEC3_LF_FFT_LENGTH_BY2_PLUS1);

    /* fft_buffer_128 removed — only PFDKF buffer retained */
    self->ffts2_mem = ffts2_mem;
    FftBufferPfdkf_Init(fft_buffer_pfdkf, ffts2_mem, buf_size);
    self->fft_buffer_pfdkf = fft_buffer_pfdkf;

    /* Initialize echo remover buffer view */
    RenderBuffer_Init(&self->echo_remover_buffer,
                      &self->blocks, &self->spectra);
    /* Set typed buffer pointer on the render buffer (fft_buffer_128 removed) */
    self->echo_remover_buffer.fft_buffer_pfdkf = fft_buffer_pfdkf;

    /* Initialize downsampled render buffer */
    {
        int lr_size = Aec3_GetDownSampledBufferSize(
            self->down_sampling_factor, config->delay_num_filters);
        self->low_rate_mem = low_rate_mem;
        self->low_rate_size = lr_size;
        self->low_rate.buffer = low_rate_mem;
        self->low_rate.size = lr_size;
        self->low_rate.write = 0;
        self->low_rate.read = 0;
        memset(low_rate_mem, 0, sizeof(float) * (size_t)lr_size);
    }

    /* Initialize decimator */
    Decimator_Init(&self->render_decimator, self->down_sampling_factor);

    /* Initialize FFT */
    Aec3Fft_Init(&self->fft);
    Aec3Fft_Init(&self->fft_pfdkf);

    /* Initialize state */
    memset(self->render_ds, 0, sizeof(self->render_ds));
    memset(self->x_lf, 0, sizeof(self->x_lf));
    self->last_call_was_render = 0;
    self->num_api_calls_in_a_row = 1;
    self->max_observed_jitter = 1;
    self->capture_call_counter = 0;
    self->render_call_counter = 0;
    self->render_activity = 0;
    self->render_activity_counter = 0;
    self->has_external_audio_buffer_delay = 0;
    self->external_audio_buffer_delay = 0;
    self->external_delay_verified_after_reset = 0;
    self->max_allowed_excess_render_blocks = 8;
    self->min_latency_blocks = 0;
    self->excess_render_detection_counter = 0;

    /* Set initial delay */
    self->delay = config->delay_default;
    self->has_delay = 1;
    self->has_internal_delay = 0;

    RenderDelayBuffer_Reset(self);
}

void RenderDelayBuffer_Reset(RenderDelayBuffer* self)
{
    assert(self != NULL);

    self->last_call_was_render = 0;
    self->num_api_calls_in_a_row = 1;
    self->min_latency_blocks = 0;
    self->excess_render_detection_counter = 0;

    /* Pre-fill low rate buffer with minimal headroom.
     * RenderDelayBufferImpl2 only offsets by 1 sub_block_size.
     * (The large LowRateBufferOffset belongs to RenderDelayBufferImpl variant 1.) */
    self->low_rate.read = (self->low_rate.write + self->sub_block_size) %
                          self->low_rate.size;

    if (self->has_external_audio_buffer_delay) {
        int headroom = 2;  /* default headroom */
        int external_delay_to_set = 1;  /* Impl2: minimum delay is 1 */
        int max_delay;

        if (self->external_audio_buffer_delay <= headroom) {
            external_delay_to_set = 1;
        } else {
            external_delay_to_set = self->external_audio_buffer_delay - headroom;
        }

        max_delay = RenderDelayBuffer_MaxDelay(self);
        if (external_delay_to_set > max_delay) {
            external_delay_to_set = max_delay;
        }

        self->internal_delay = external_delay_to_set;
        self->has_internal_delay = 1;
        ApplyDelay(self, self->internal_delay);
        self->delay = MapInternalDelayToExternalDelay(self);
        self->has_delay = 1;
        self->external_delay_verified_after_reset = 0;
    } else {
        /* Apply default delay */
        ApplyDelay(self, self->config.delay_default);
        self->has_delay = 0;
        self->has_internal_delay = 0;
    }
}

void RenderDelayBuffer_SetMaxAllowedExcessRenderBlocks(
    RenderDelayBuffer* self, int max_blocks)
{
    assert(self != NULL);
    if (max_blocks >= 4 && max_blocks <= 8) {
        self->max_allowed_excess_render_blocks = max_blocks;
    }
}

int RenderDelayBuffer_Insert(RenderDelayBuffer* self,
                             const float block[][AEC3_BLOCK_SIZE],
                             int num_bands,
                             int pfdkf_enable,
                             int aec_level)
{
    int previous_write;
    int event;

    assert(self != NULL);

    ++self->render_call_counter;

    if (self->has_delay) {
        if (!self->last_call_was_render) {
            self->last_call_was_render = 1;
            self->num_api_calls_in_a_row = 1;
        } else {
            ++self->num_api_calls_in_a_row;
            if (self->num_api_calls_in_a_row > self->max_observed_jitter) {
                self->max_observed_jitter = self->num_api_calls_in_a_row;
            }
        }
    }

    /* Save previous write position */
    previous_write = self->blocks.write;

    /* Advance write indices */
    IncreaseWriteIndices(self->sub_block_size,
                         &self->blocks, &self->spectra,
                         &self->low_rate,
                         self->fft_buffer_pfdkf);

    /* Check for overrun */
    event = RenderOverrun(&self->blocks, &self->low_rate)
            ? RDB_EVENT_RENDER_OVERRUN
            : RDB_EVENT_NONE;

    /* Detect render activity */
    if (!self->render_activity) {
        if (DetectActiveRender(self, block[0], AEC3_BLOCK_SIZE)) {
            self->render_activity_counter += 1;
        }
        self->render_activity = (self->render_activity_counter >= 20);
    }

    /* Insert the block */
    InsertBlock(self, block, num_bands, previous_write);

    if (event != RDB_EVENT_NONE) {
        RenderDelayBuffer_Reset(self);
    }

    return event;
}

int RenderDelayBuffer_PrepareCaptureProcessing(RenderDelayBuffer* self)
{
    int event = RDB_EVENT_NONE;

    assert(self != NULL);

    ++self->capture_call_counter;

    if (self->has_delay) {
        if (self->last_call_was_render) {
            self->last_call_was_render = 0;
            self->num_api_calls_in_a_row = 1;
        } else {
            ++self->num_api_calls_in_a_row;
            if (self->num_api_calls_in_a_row > self->max_observed_jitter) {
                self->max_observed_jitter = self->num_api_calls_in_a_row;
            }
        }
    }

    /* Impl2: detect excess render blocks first */
    if (DetectExcessRenderBlocks(self)) {
        RenderDelayBuffer_Reset(self);
        event = RDB_EVENT_RENDER_OVERRUN;
    } else if (RenderUnderrun(&self->low_rate)) {
        /* Impl2: on underrun, only advance block read indices (not low_rate),
         * reduce delay by 1, and report underrun */
        IncreaseBlockReadIndices(&self->blocks, &self->spectra,
                                 self->fft_buffer_pfdkf);
        if (self->has_delay && self->delay > 0) {
            self->delay = self->delay - 1;
        }
        event = RDB_EVENT_RENDER_UNDERRUN;
    } else {
        /* Impl2: first advance low_rate, then advance blocks/spectra/ffts */
        IncreaseLowRateReadIndices(self->sub_block_size, &self->low_rate);
        IncreaseBlockReadIndices(&self->blocks, &self->spectra,
                                 self->fft_buffer_pfdkf);
    }

    /* Impl2 does not Reset on underrun (only on overrun via Insert) */

    RenderBuffer_SetRenderActivity(&self->echo_remover_buffer,
                                   self->render_activity);
    if (self->render_activity) {
        self->render_activity_counter = 0;
        self->render_activity = 0;
    }

    return event;
}

int RenderDelayBuffer_SetDelay(RenderDelayBuffer* self,
                               int delay, int delay_default,
                               int aec_H_usage)
{
    int total_delay;
    int max_delay;

    assert(self != NULL);

    (void)aec_H_usage;

    if (!self->external_delay_verified_after_reset &&
        self->has_external_audio_buffer_delay && self->has_delay) {
        self->external_delay_verified_after_reset = 1;
    }

    if (self->has_delay && self->delay == delay) {
        return 0;
    }

    self->delay = delay;
    self->has_delay = 1;

    /* MapDelayToTotalDelay: latency_blocks + external_delay (Impl2) */
    {
        int latency = BufferLatency(&self->low_rate);
        int latency_blocks = latency / self->sub_block_size;
        total_delay = latency_blocks + delay;
    }

    max_delay = (int)RenderDelayBuffer_MaxDelay(self);
    if (total_delay < 0) total_delay = 0;
    if (total_delay > max_delay) total_delay = max_delay;

    /* Add delay_default offset (Impl2: total_delay += delay_default/4) */
    total_delay += delay_default / 4;

    self->internal_delay = total_delay;
    self->has_internal_delay = 1;

    ApplyDelay(self, total_delay);
    return 1;
}

int RenderDelayBuffer_Delay(const RenderDelayBuffer* self)
{
    assert(self != NULL);
    return MapInternalDelayToExternalDelay(self);
}

int RenderDelayBuffer_MaxDelay(const RenderDelayBuffer* self)
{
    assert(self != NULL);
    return self->buffer_size - 1 - self->buffer_headroom;
}

RenderBuffer* RenderDelayBuffer_GetRenderBuffer(RenderDelayBuffer* self)
{
    assert(self != NULL);
    return &self->echo_remover_buffer;
}

const DownsampledRenderBuffer* RenderDelayBuffer_GetDownsampledRenderBuffer(
    const RenderDelayBuffer* self)
{
    assert(self != NULL);
    return &self->low_rate;
}

int RenderDelayBuffer_CausalDelay(const RenderDelayBuffer* self, int delay)
{
    assert(self != NULL);
    /* RenderDelayBufferImpl2: always returns true (no causal check) */
    (void)delay;
    return 1;
}

void RenderDelayBuffer_SetAudioBufferDelay(RenderDelayBuffer* self,
                                           int delay_ms)
{
    assert(self != NULL);

    /* Impl2: delay_ms >> ((num_bands == 1) ? 1 : 2)
     * C version is always single-band (16kHz), so divide by 2 */
    self->external_audio_buffer_delay = delay_ms >> 1;
    self->has_external_audio_buffer_delay = 1;
}
