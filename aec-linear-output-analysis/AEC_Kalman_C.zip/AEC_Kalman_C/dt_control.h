/*
 *  DtController - Pure C Version
 *
 *  Double-talk control: coherence-based echo state detection,
 *  suppression gain control, and double-talk detection.
 *  Ported from WebRTC AEC3 C++ DtController class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef DT_CONTROL_H_
#define DT_CONTROL_H_

#include "aec3_common.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * ControlOperation - Flags controlling AEC behavior
 * ================================================================ */
typedef struct {
    int     AccelerateAdaptive;
    int     StopAdaptive;
    int     StopNLP;
    int     StopFiltering;
    int     OverSuppress;
    int     ExOverSuppress;
    int     UnderSuppress;
    int     NearMaintain;
    int     ERLEUpdate;
    int     StopERLUpdate;
    int     StopNearAdjust;
    int     UseWeinerGain[3];
} ControlOperation;

/* ================================================================
 * DtController (optimized)
 *
 * Removed unused arrays: cohxdl, cohdyl, coheyl, res_echo_estimatel,
 *   sx2_512fft (never read), se2_512fft (replaced by scalar seSum),
 *   sy2_512fft (identical to sd2_512fft).
 * Replaced cohdel[257] (echo_sup_dt storage) with scalar echo_sup_dt_scalar.
 * Removed unused fields: over_estimate, weak_echo, seg_weak_echo,
 *   capture_noise_floor.
 * Savings: ~8.3 KB memory, ~34% fewer loops per frame.
 * ================================================================ */
typedef struct {
    /* Power spectra (512-point) — only sd2 and se2_nlp needed */
    float   sd2_512fft[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   se2_nlp_512fft[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    /* 512fft echo state detection */
    float   near_energy;
    float   capture_energy;
    float   spec_cor_de_512fft;
    float   spec_cor_de_last[3];
    float   ed_ratio_2k;
    float   ed_ratio_2k_smooth;
    float   ed_ratio_8k_smooth;
    float   gain_bigthan090_count_last;
    int     near_exist_count_512fft;

    /* Suppression gains (512-point) */
    float   echo_sup_gainl[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    /* echo_sup_dt scalar (was per-bin cohdel[], all bins updated identically) */
    float   echo_sup_dt_scalar;

    /* Echo state */
    int     echo_state;
    int     near_state;
    int     dt_state;
    float   accelerate;
    float   double_talk_probability;

    /* Counters */
    int     double_talk_count;
    int     double_talk_count_max;
    int     echo_state_count;
    int     echo_exist_count;
    int     near_exist_count;
    int     frame_cnt;

    /* Configuration */
    float   nonlinear_level;
    int     audioMixing_flag;
    int     dtd_flag;
    int     submodule_flag;
    int     earphone_flag;
    int     voip_flag;
    int     aec_dtcontrol_enable;
    float   ed_ratio_2k_threshold;
    int     ExcludeNoiseFromEchoFlag;

    /* Filter divergence state */
    int     filter_divergence_state;

    /* Control operations */
    ControlOperation control_operation;
} DtController;

/**
 * Initialize the double-talk controller.
 */
void DtController_Init(DtController* self);

/**
 * Reset the controller state.
 */
void DtController_Reset(DtController* self);

/**
 * Update the controller with new spectral data (128-point).
 */
void DtController_Update(DtController* self,
                         FftData128* Y, FftData128* E, FftData128* S, FftData128* X,
                         const float* y, const float* e,
                         const float* s, const float* x,
                         float nonlinear_level,
                         int audioMixing_flag,
                         int dtd_flag,
                         int submodule_flag,
                         int earphone_flag,
                         float erl, float erl_diff,
                         int extern_echo_state);

/**
 * Update the controller with 512-point FFT data.
 */
void DtController_Update512fft(DtController* self,
                               FftDataPfdkf* Y, FftDataPfdkf* E, FftDataPfdkf* S,
                               FftDataPfdkf* E_nlp, FftDataPfdkf* X,
                               const float* suppression_gain,
                               const float* comfort_noise_spectrum,
                               int aec_level,
                               int aec_low_compute_mode);

/**
 * Get the current control operations.
 */
const ControlOperation* DtController_GetOperations(const DtController* self);

/**
 * Get the echo state (0=no echo, 1=echo).
 */
int DtController_GetEchoState(const DtController* self);

/**
 * Get the acceleration rate for adaptive filter.
 */
float DtController_AccelerateRate(const DtController* self);

/**
 * Get the XdAvg coherence metric.
 */
float DtController_GetXdAvg(const DtController* self);

/**
 * Get the EyCoBand metric.
 */
float DtController_GetEyCoBand(const DtController* self);

/**
 * Get the suppression gain (128-point).
 */
const float* DtController_GetSupGain(const DtController* self);

/**
 * Get the suppression gain (512-point).
 */
const float* DtController_GetSupGainl(const DtController* self);

/**
 * Get the double-talk probability.
 */
float DtController_GetDoubleTalkProbability(const DtController* self);

/**
 * Set earphone flag.
 */
void DtController_SetEarphoneFlag(DtController* self, int flag);

/**
 * Set voip flag.
 */
void DtController_SetVoipFlag(DtController* self, int flag);

/**
 * Set DT control enable.
 */
void DtController_SetAecDtcontrolEnable(DtController* self, int flag);

/**
 * Set double talk count max.
 */
void DtController_SetDoubleTalkCountMax(DtController* self, int max_count);

/**
 * Set ed_ratio_2k threshold.
 */
void DtController_SetEdRatio2kThreshold(DtController* self, float threshold);

/**
 * Set ExcludeNoiseFromEcho flag.
 */
void DtController_SetExcludeNoiseFromEchoFlag(DtController* self, int flag);

/**
 * Get filter divergence state.
 */
int DtController_GetFilterDivergenceState(const DtController* self);

#ifdef __cplusplus
}
#endif

#endif /* DT_CONTROL_H_ */
