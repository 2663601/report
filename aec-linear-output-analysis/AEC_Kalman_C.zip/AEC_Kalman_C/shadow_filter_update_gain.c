/*
 *  ShadowFilterUpdateGain - Pure C Implementation
 *
 *  Ported from WebRTC AEC3 C++ ShadowFilterUpdateGain class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords. Generic (non-SIMD) implementation.
 */

#include "shadow_filter_update_gain.h"
#include <string.h>
#include <assert.h>

/* ================================================================
 * Internal: UpdateCurrentConfig - smooth config transition
 * ================================================================ */
static void UpdateCurrentConfig(ShadowFilterUpdateGain* self)
{
    if (self->config_change_counter > 0) {
        if (--self->config_change_counter > 0) {
            float w = (float)self->config_change_counter *
                      self->one_by_config_change_duration_blocks;
            float w1 = 1.0f - w;

            self->current_config.rate =
                self->old_target_config.rate * w +
                self->target_config.rate * w1;
            self->current_config.noise_gate =
                self->old_target_config.noise_gate * w +
                self->target_config.noise_gate * w1;
        } else {
            self->current_config = self->target_config;
            self->old_target_config = self->target_config;
        }
    }
}

/* ================================================================
 * Public API
 * ================================================================ */

void ShadowFilterUpdateGain_Init(ShadowFilterUpdateGain* self,
                                 const ShadowFilterConfig* config,
                                 int config_change_duration)
{
    assert(self != NULL);
    assert(config != NULL);
    assert(config_change_duration > 0);

    memset(self, 0, sizeof(ShadowFilterUpdateGain));

    self->current_config = *config;
    self->target_config = *config;
    self->old_target_config = *config;

    self->config_change_duration_blocks = config_change_duration;
    self->one_by_config_change_duration_blocks =
        1.0f / (float)config_change_duration;

    self->poor_signal_excitation_counter = 0;
    self->call_counter = 0;
    self->config_change_counter = 0;
}

void ShadowFilterUpdateGain_HandleEchoPathChange(
    ShadowFilterUpdateGain* self)
{
    assert(self != NULL);
    self->poor_signal_excitation_counter = 0;
    self->call_counter = 0;
}

void ShadowFilterUpdateGain_Compute(
    ShadowFilterUpdateGain* self,
    const float* render_power,
    int poor_signal_excitation,
    const FftData128* E_shadow,
    int size_partitions,
    int saturated_capture,
    FftData128* G,
    int* main_reset_shadow_hangover)
{
    int k;
    float mu[AEC3_FFT_LENGTH_BY2_PLUS1];

    assert(self != NULL);
    assert(G != NULL);

    self->call_counter++;
    UpdateCurrentConfig(self);

    if (poor_signal_excitation) {
        self->poor_signal_excitation_counter = 0;
    }

    /* Do not update if render not sufficiently excited */
    if (++self->poor_signal_excitation_counter < size_partitions ||
        saturated_capture ||
        self->call_counter <= size_partitions) {
        memset(G->re, 0, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
        memset(G->im, 0, sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);
        return;
    }

    if (*main_reset_shadow_hangover > 0) {
        (*main_reset_shadow_hangover)--;
    }

    /* Compute mu = rate / X2  (if X2 > noise_gate) */
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; ++k) {
        mu[k] = (render_power[k] > self->current_config.noise_gate)
            ? self->current_config.rate / render_power[k]
            : 0.0f;
    }

    /* G = mu * E_shadow */
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; ++k) {
        G->re[k] = mu[k] * E_shadow->re[k];
        G->im[k] = mu[k] * E_shadow->im[k];
    }
}

void ShadowFilterUpdateGain_SetConfig(ShadowFilterUpdateGain* self,
                                      const ShadowFilterConfig* config,
                                      int immediate_effect)
{
    assert(self != NULL);
    assert(config != NULL);

    if (immediate_effect) {
        self->old_target_config = *config;
        self->current_config = *config;
        self->target_config = *config;
        self->config_change_counter = 0;
    } else {
        self->old_target_config = self->current_config;
        self->target_config = *config;
        self->config_change_counter = self->config_change_duration_blocks;
    }
}
