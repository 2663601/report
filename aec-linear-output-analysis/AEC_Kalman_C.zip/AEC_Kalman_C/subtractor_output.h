/*
 *  Subtractor Output & Auxiliary Data Structures - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Defines SubtractorOutput, DelayEstimate, EchoPathVariability,
 *  and DownsampledRenderBuffer structures used across AEC3 modules.
 */

#ifndef SUBTRACTOR_OUTPUT_H_
#define SUBTRACTOR_OUTPUT_H_

#include "aec3_common.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * SubtractorOutput - Output from the linear echo subtractor
 *
 * Contains time-domain and frequency-domain residual signals
 * from both main and shadow adaptive filters.
 * ================================================================ */
typedef struct {
    float   s_main[AEC3_BLOCK_SIZE];                /* Main filter echo estimate */
    float   s_shadow[AEC3_BLOCK_SIZE];              /* Shadow filter echo estimate */
    float   e_main[AEC3_BLOCK_SIZE];                /* Main filter residual */
    float   e_shadow[AEC3_BLOCK_SIZE];              /* Shadow filter residual */
    float   E2_main[AEC3_FFT_LENGTH_BY2_PLUS1];    /* Main residual power spectrum */
    float   E2_shadow[AEC3_FFT_LENGTH_BY2_PLUS1];  /* Shadow residual power spectrum */
    float   Y2[AEC3_FFT_LENGTH_BY2_PLUS1];         /* Near-end power spectrum */
    float   s2_main;                                 /* Main estimate energy */
    float   s2_shadow;                               /* Shadow estimate energy */
    float   e2_main;                                 /* Main residual energy */
    float   e2_shadow;                               /* Shadow residual energy */
    float   y2;                                      /* Near-end energy */
    int     main_filter_selected;                    /* Which filter is selected */
} SubtractorOutput;

/* ================================================================
 * DelayEstimate - Echo path delay estimation result
 * ================================================================ */
typedef struct {
    int     delay;                      /* Estimated delay in blocks */
    int     quality;                    /* Estimation quality */
    int     blocks_since_last_change;
    int     blocks_since_last_update;
} DelayEstimate;

/* ================================================================
 * EchoPathVariability - Describes echo path changes
 * ================================================================ */
typedef struct {
    int     gain_change;
    int     delay_change;
    int     clock_drift;
} EchoPathVariability;

/* ================================================================
 * DownsampledRenderBuffer - Downsampled render signal buffer
 *   for matched filter delay estimation
 * ================================================================ */
typedef struct {
    float*  buffer;     /* Downsampled render signal data */
    int     size;       /* Buffer capacity */
    int     write;      /* Write index */
    int     read;       /* Read index */
} DownsampledRenderBuffer;

#ifdef __cplusplus
}
#endif

#endif /* SUBTRACTOR_OUTPUT_H_ */
