/*
 *  AEC Kalman C API - Pure C Version (Multi-band interface)
 *
 *  Ring buffer size is controlled internally by Aec3Config.delay_num_filters
 *  (num_matched_filters). Default = 5, which gives:
 *    lr_size  = GetDownSampledBufferSize(4, 5) = 2448
 *    buf_size = 2448/16 + 13 + 1 = 167 blocks
 *
 *  To change buffer size, modify delay_num_filters in Aec3Config_SetDefaults()
 *  (aec3_config.c) or before calling EchoCanceller3_Init().
 */

#include "ys_aec_kalman.h"
#include "ys_aec_kalman_internal.h"
#include <string.h>
#include <stdint.h>

#define AEC_ALIGN16(x)  (((x) + 15) & ~15)

static int calc_render_buf_mem_size(int buf_size, int lr_size)
{
    int size = 0;
    size += AEC_ALIGN16(buf_size * AEC3_MAX_BANDS * AEC3_BLOCK_SIZE * (int)sizeof(float));
    size += AEC_ALIGN16(buf_size * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float));  /* spectra_mem: PFDKF only (128pt removed) */
    /* ffts_mem (FftData128) removed — fft_buffer_128 eliminated, using fft_buffer_pfdkf for index sync */
    size += AEC_ALIGN16(buf_size * (int)sizeof(FftDataPfdkf));
    size += AEC_ALIGN16(lr_size * (int)sizeof(float));  /* low_rate_mem */
    size += AEC_ALIGN16(buf_size * (AEC3_FFT_LENGTH_BY2_PLUS1 + 1) * (int)sizeof(float));  /* binary_dyn_mem */
    return size;
}

int YS_AEC_Kalman_GetMemSize(void)
{
    Aec3Config config;
    AecRuntimeConfig rt;
    int dsf, sub_block_size, lr_size, buf_size;
    int aec_H_usage;
    int size = 0;

    Aec3Config_SetDefaults(&config);
    AecRuntimeConfig_SetDefaults(&rt);
    aec_H_usage = rt.aec_H_usage;

    dsf = config.delay_down_sampling_factor;
    sub_block_size = (dsf > 0) ? AEC3_BLOCK_SIZE / dsf : AEC3_BLOCK_SIZE;
    lr_size = Aec3_GetDownSampledBufferSize(dsf, config.delay_num_filters);
    buf_size = lr_size / sub_block_size + config.filter_main_length_blocks + 1;

    size += AEC_ALIGN16((int)sizeof(AecKalmanHandle));
    size += AEC_ALIGN16((int)sizeof(EchoCanceller3));
    size += calc_render_buf_mem_size(buf_size, lr_size);
    /* NOTE: spectra_mem no longer includes 128pt portion (only PFDKF 257-float slots) */

    /*
     * PFDKF dynamic arrays (7 blocks, sized by aec_H_usage).
     *
     * Memory breakdown per aec_H_usage value (AEC_ALIGN16 applied):
     *   N=5  (default): 5x10288 + 2x5152  = 61,744 bytes ( 60.3 KB)
     *   N=10:           5x20560 + 2x10288  = 123,376 bytes (120.5 KB)
     *   N=30 (old max): 5x61680 + 2x30848  = 370,096 bytes (361.4 KB)
     *
     * Formula:
     *   5 * ALIGN16(N * sizeof(FftDataPfdkf))          -- H_pf, H_pf_speed,
     *                                                      H_pf_update, G_pfdkf,
     *                                                      G_pfdkf_speed
     *   2 * ALIGN16(N * 257 * sizeof(float))            -- H2_pf_update,
     *                                                      H_error_pfdkf
     *
     * Savings vs old static AEC3_MAX_PFDKF_PARTITIONS=30:
     *   N=5:  saves ~301 KB  (370,096 - 61,744 = 308,352 bytes)
     *   N=10: saves ~241 KB  (370,096 - 123,376 = 246,720 bytes)
     */
    size += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));  /* H_pf */
    size += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));  /* H_pf_speed */
    size += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));  /* H_pf_update */
    size += AEC_ALIGN16(aec_H_usage * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float));  /* H2_pf_update */
    size += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));  /* G_pfdkf */
    size += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));  /* G_pfdkf_speed */
    size += AEC_ALIGN16(aec_H_usage * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float));  /* H_error_pfdkf */

    return size;
}

int YS_AEC_Kalman_Create(void* alloc_buf, void** handle,
                          int sample_rate, int frame_len, int nlp_level)
{
    AecKalmanHandle* h;
    unsigned char* ptr;
    Aec3Config config;
    AecRuntimeConfig rt;
    int buf_size, lr_size, dsf, sub_block_size;
    float* blocks_mem;
    float* spectra_mem;
    FftDataPfdkf* ffts2_mem;
    float* low_rate_mem;
    float* binary_dyn_mem;
    int aec_H_usage;
    FftDataPfdkf* H_pf_mem;
    FftDataPfdkf* H_pf_speed_mem;
    FftDataPfdkf* H_pf_update_mem;
    float* H2_pf_update_mem;
    FftDataPfdkf* G_pfdkf_mem;
    FftDataPfdkf* G_pfdkf_speed_mem;
    float* H_error_pfdkf_mem;

    if (!alloc_buf || !handle) return -1;

    Aec3Config_SetDefaults(&config);
    dsf = config.delay_down_sampling_factor;
    sub_block_size = (dsf > 0) ? AEC3_BLOCK_SIZE / dsf : AEC3_BLOCK_SIZE;
    lr_size = Aec3_GetDownSampledBufferSize(dsf, config.delay_num_filters);
    buf_size = lr_size / sub_block_size + config.filter_main_length_blocks + 1;

    ptr = (unsigned char*)alloc_buf;
    h = (AecKalmanHandle*)ptr;
    memset(h, 0, sizeof(AecKalmanHandle));
    ptr += AEC_ALIGN16((int)sizeof(AecKalmanHandle));

    h->ec3 = (EchoCanceller3*)ptr;
    ptr += AEC_ALIGN16((int)sizeof(EchoCanceller3));

    /* Carve out ring buffer memory from the pre-allocated block */
    blocks_mem = (float*)ptr;
    ptr += AEC_ALIGN16(buf_size * AEC3_MAX_BANDS * AEC3_BLOCK_SIZE * (int)sizeof(float));

    spectra_mem = (float*)ptr;
    ptr += AEC_ALIGN16(buf_size * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float));  /* PFDKF only (128pt removed) */

    /* ffts_mem (FftData128) removed — fft_buffer_128 eliminated */

    ffts2_mem = (FftDataPfdkf*)ptr;
    ptr += AEC_ALIGN16(buf_size * (int)sizeof(FftDataPfdkf));

    /* low_rate_mem: dynamic size based on lr_size from config */
    low_rate_mem = (float*)ptr;
    ptr += AEC_ALIGN16(lr_size * (int)sizeof(float));

    /* binary_dyn_mem: farend_history_fft[buf_size*65] + xd_spec_cor[buf_size] */
    binary_dyn_mem = (float*)ptr;
    ptr += AEC_ALIGN16(buf_size * (AEC3_FFT_LENGTH_BY2_PLUS1 + 1) * (int)sizeof(float));

    /* Get aec_H_usage from runtime config defaults */
    AecRuntimeConfig_SetDefaults(&rt);
    aec_H_usage = rt.aec_H_usage;

    /* Carve out PFDKF dynamic array memory (7 blocks) */
    H_pf_mem = (FftDataPfdkf*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));

    H_pf_speed_mem = (FftDataPfdkf*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));

    H_pf_update_mem = (FftDataPfdkf*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));

    H2_pf_update_mem = (float*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float));

    G_pfdkf_mem = (FftDataPfdkf*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));

    G_pfdkf_speed_mem = (FftDataPfdkf*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * (int)sizeof(FftDataPfdkf));

    H_error_pfdkf_mem = (float*)ptr;
    ptr += AEC_ALIGN16(aec_H_usage * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float));

    h->magic       = AEC_KALMAN_MAGIC;
    h->sample_rate = sample_rate;
    h->frame_len   = frame_len;
    h->nlp_level   = nlp_level;
    h->render_buffer_size = buf_size;
    h->fixed_delay_ms = -1;  /* 默认自动延时估计 */

    EchoCanceller3_Init(h->ec3, &config, sample_rate, buf_size,
                        blocks_mem, spectra_mem, ffts2_mem,
                        low_rate_mem, lr_size, binary_dyn_mem,
                        H_pf_mem, H_pf_speed_mem, H_pf_update_mem,
                        H2_pf_update_mem, G_pfdkf_mem, G_pfdkf_speed_mem,
                        H_error_pfdkf_mem, aec_H_usage);

    AecRuntimeConfig_SetDefaults(&rt);
    EchoCanceller3_SetConfig(h->ec3, &rt);

    h->initialized = 1;
    *handle = h;
    return 0;
}

int YS_AEC_Kalman_BufferFarend(void* handle, const float* far_signal,
                                int nrOfSamples)
{
    AecKalmanHandle* h = (AecKalmanHandle*)handle;
    int i, b, len, num_bands;
    float val;

    if (!h || h->magic != AEC_KALMAN_MAGIC || !h->initialized || !far_signal)
        return -1;

    len = nrOfSamples > AEC3_MAX_FRAME_LENGTH ? AEC3_MAX_FRAME_LENGTH : nrOfSamples;
    if (len > 160) len = 160;
    num_bands = Aec3_NumBandsForRate(h->sample_rate);

    /* Band 0: far-end reference */
    for (i = 0; i < len; i++) {
        val = far_signal[i];
        if (val > 32767.0f) val = 32767.0f;
        else if (val < -32768.0f) val = -32768.0f;
        h->work_buf[i] = (float)((int16_t)val);
    }
    /* Upper bands: zero (far-end reference is low-band only) */
    for (b = 1; b < num_bands; b++) {
        memset(&h->work_buf[b * len], 0, len * sizeof(float));
    }

    EchoCanceller3_AnalyzeRender(h->ec3, h->work_buf, num_bands, len);
    return 0;
}

int YS_AEC_Kalman_Process(void* handle,
                           const float* const* nearend,
                           int num_bands,
                           float* const* out,
                           int nrOfSamples)
{
    AecKalmanHandle* h = (AecKalmanHandle*)handle;
    int i, b, len;
    float val;

    if (!h || h->magic != AEC_KALMAN_MAGIC || !h->initialized
        || !nearend || !out)
        return -1;

    len = nrOfSamples > AEC3_MAX_FRAME_LENGTH ? AEC3_MAX_FRAME_LENGTH : nrOfSamples;
    if (len > 160) len = 160;
    if (num_bands > AEC3_MAX_BANDS) num_bands = AEC3_MAX_BANDS;

    /* Pack all bands into work_buf: band0[0..len-1], band1[len..2*len-1], ... */
    for (b = 0; b < num_bands; b++) {
        for (i = 0; i < len; i++) {
            val = nearend[b][i];
            if (val > 32767.0f) val = 32767.0f;
            else if (val < -32768.0f) val = -32768.0f;
            h->work_buf[b * len + i] = (float)((int16_t)val);
        }
    }

    EchoCanceller3_AnalyzeCapture(h->ec3, h->work_buf, len);

    if (h->fixed_delay_ms >= 0) {
        EchoCanceller3_SetAudioBufferDelay(h->ec3, h->fixed_delay_ms);
    } else {
        EchoCanceller3_SetAudioBufferDelay(h->ec3, 0);
    }

    EchoCanceller3_ProcessCapture(h->ec3,
                                   h->work_buf, len, num_bands,
                                   0, 1, 0, h->sample_rate, 0);

    /* Unpack all bands from work_buf */
    for (b = 0; b < num_bands; b++) {
        for (i = 0; i < len; i++) {
            val = h->work_buf[b * len + i];
            if (val > 32767.0f) val = 32767.0f;
            else if (val < -32768.0f) val = -32768.0f;
            out[b][i] = val;
        }
    }

    return 0;
}

int YS_AEC_Kalman_SetFixedDelay(void* handle, int delay_ms)
{
    AecKalmanHandle* h = (AecKalmanHandle*)handle;
    if (!h || h->magic != AEC_KALMAN_MAGIC || !h->initialized)
        return -1;

    h->fixed_delay_ms = delay_ms;

    if (delay_ms >= 0) {
        /* 启用固定延时: 转换 ms -> blocks (1 block ≈ 4ms) */
        int delay_blocks = delay_ms / 4;
        EchoCanceller3_SetFixedDelay(h->ec3, delay_blocks);
        /* 设置外部延时供 render_delay_buffer 初始对齐 */
        EchoCanceller3_SetAudioBufferDelay(h->ec3, delay_ms);
    } else {
        /* 恢复自动延时估计 */
        EchoCanceller3_SetFixedDelay(h->ec3, -1);
    }
    return 0;
}

int YS_AEC_Kalman_Destroy(void* handle)
{
    AecKalmanHandle* h = (AecKalmanHandle*)handle;
    if (!h || h->magic != AEC_KALMAN_MAGIC)
        return -1;

    BlockProcessor_CloseDelayDump();

    h->initialized = 0;
    h->magic = 0;
    return 0;
}

int YS_AEC_Kalman_GetNoiseGateHoldCounter(void* handle)
{
    AecKalmanHandle* h = (AecKalmanHandle*)handle;
    if (!h || h->magic != AEC_KALMAN_MAGIC || !h->initialized)
        return 0;
    return h->ec3->noise_gate_hold_counter;
}

int YS_AEC_Kalman_SetRuntimeConfig(void* handle, const AecRuntimeConfig* config)
{
    AecKalmanHandle* h = (AecKalmanHandle*)handle;
    if (!h || h->magic != AEC_KALMAN_MAGIC || !h->initialized || !config)
        return -1;
    EchoCanceller3_SetConfig(h->ec3, config);
    return 0;
}
