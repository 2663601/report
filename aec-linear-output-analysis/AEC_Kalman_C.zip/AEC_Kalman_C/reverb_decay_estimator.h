/*
 *  ReverbDecayEstimator - Pure C Version
 *
 *  Estimates the decay of late reverb from the adaptive filter.
 *  Ported from WebRTC AEC3 C++ ReverbDecayEstimator class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef REVERB_DECAY_ESTIMATOR_H_
#define REVERB_DECAY_ESTIMATOR_H_

#include "aec3_common.h"
#include "aec3_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Maximum filter length for previous_gains array */
#define REVERB_MAX_FILTER_BLOCKS  AEC3_MAX_FILTER_PARTITIONS

/* ================================================================
 * LateReverbLinearRegressor (inlined)
 * ================================================================ */
typedef struct {
    float   nz;
    float   nn;
    float   count;
    int     N;
    int     n;
} LateReverbLinearRegressor;

/* ================================================================
 * EarlyReverbLengthEstimator (inlined)
 * ================================================================ */
#define EARLY_REVERB_MAX_SECTIONS  (AEC3_MAX_FILTER_PARTITIONS - 3)

typedef struct {
    float   numerators_smooth[EARLY_REVERB_MAX_SECTIONS];
    float   numerators[EARLY_REVERB_MAX_SECTIONS];
    int     max_sections;
    int     coefficients_counter;
    int     block_counter;
    int     n_sections;
} EarlyReverbLengthEstimator;

/* ================================================================
 * ReverbDecayEstimator
 * ================================================================ */
typedef struct {
    int     filter_length_blocks;
    int     filter_length_coefficients;
    int     use_adaptive_echo_decay;

    LateReverbLinearRegressor late_reverb_estimator;
    EarlyReverbLengthEstimator early_reverb_estimator;

    int     late_reverb_start;
    int     late_reverb_end;
    int     block_to_analyze;
    int     estimation_region_candidate_size;
    int     estimation_region_identified;

    float   previous_gains[REVERB_MAX_FILTER_BLOCKS];
    float   decay;
    float   tail_gain;
    float   smoothing_constant;

    /* Adaptive convergence (two-phase smoothing rate) */
    int     update_counter;             /* Update counter for convergence phase tracking */
    float   smoothing_rate_fast;        /* Initial phase smoothing rate (0.15) */
    float   smoothing_rate_slow;        /* Steady-state smoothing rate (0.05) */
    int     fast_convergence_blocks;    /* Duration of fast convergence phase (500) */

    /* Mild decay output for nearend protection */
    float   mild_decay;                 /* = decay * mild_decay_factor */
    float   mild_decay_factor;          /* Mild factor (0.7) */
} ReverbDecayEstimator;

/**
 * Initialize the reverb decay estimator.
 */
void ReverbDecayEstimator_Init(ReverbDecayEstimator* self,
                               const Aec3Config* config);

/**
 * Update the decay estimate with new filter data.
 *
 * @param self                  Pointer to estimator
 * @param filter                Time-domain filter coefficients
 * @param filter_len            Length of filter array
 * @param filter_quality        Linear filter quality (negative if unavailable)
 * @param has_filter_quality    Whether filter_quality is valid
 * @param filter_delay_blocks   Filter delay in blocks
 * @param usable_linear_filter  Whether linear filter is usable
 * @param stationary_signal     Whether signal is stationary
 */
void ReverbDecayEstimator_Update(ReverbDecayEstimator* self,
                                 const float* filter,
                                 int filter_len,
                                 float filter_quality,
                                 int has_filter_quality,
                                 int filter_delay_blocks,
                                 int usable_linear_filter,
                                 int stationary_signal);

/**
 * Get the estimated reverb decay factor.
 */
float ReverbDecayEstimator_Decay(const ReverbDecayEstimator* self);

#ifdef __cplusplus
}
#endif

#endif /* REVERB_DECAY_ESTIMATOR_H_ */
