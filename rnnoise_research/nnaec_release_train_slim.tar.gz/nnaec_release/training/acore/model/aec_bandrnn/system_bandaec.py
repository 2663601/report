#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Band-domain AEC 后置滤波器训练系统 (PyTorch Lightning)

链路:
  laec残差 z / 麦克风 y / 远端 x  (时域波形)
    -> STFT -> 功率谱 -> ERB band log 功率  (三路拼接成特征)
    -> SeidelAEC / PercepNetAEC -> band gain
    -> ERB 映射回频点 -> 乘 mic 幅度谱 (相位用 mic 相位) -> ISTFT -> 估计近端
    -> loss(估计, 目标)

数据集 (use_laec=True) 返回:
  (aecout_s, far_s, near_targt_s, echo_s, near_mic_s, nearend_vad)
即 (z, x, target, echo, y, vad)。本 system 用 z/x/y 做输入, target 做监督。

与现有 system_dcrn 完全独立, 不影响原 CRN 训练。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.lr_scheduler import ReduceLROnPlateau

from .erb_bank import ERBBank

# pytorch_lightning 可选: 服务器训练需要(走 Trainer); 本地冒烟无 pl 时退化为 nn.Module,
# 仍可调用 common_step / forward 做链路验证。
try:
    import pytorch_lightning as pl
    _BASE = pl.LightningModule
    _HAS_PL = True
except Exception:
    _BASE = nn.Module
    _HAS_PL = False


def _stft(y, nfft, hop, win_len, window):
    # y: [B, T_samples] -> complex [B, F, T]
    # center=True + sqrt-hann + 50% hop 保证 ISTFT 满足 NOLA 完美重构
    return torch.stft(y, nfft, hop, win_len, window=window.to(y.device),
                      center=True, return_complex=True)


def _istft(spec, nfft, hop, win_len, window, length=None):
    return torch.istft(spec, nfft, hop, win_len, window=window.to(spec.device),
                       center=True, length=length)


class BandAECSystem(_BASE):
    def __init__(self, model, optimizer, loss_func, train_loader,
                 val_loader=None, scheduler=None, monitor="val_loss",
                 config=None, **kwargs):
        super().__init__()
        self.model = model
        self.optimizer = optimizer
        self.loss_func = loss_func
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.scheduler = scheduler
        self.default_monitor = monitor

        self.nfft = kwargs.get("nfft", 512)
        self.hop_length = kwargs.get("hop_length", 256)
        self.window_size = kwargs.get("window_size", 512)
        self.nbands = kwargs.get("nbands", 32)
        self.model_type = kwargs.get("model_type", "seidel")  # seidel / percepnet
        self.eps = 1e-10

        # ---- 方法A: 强回声样本级重加权(治 PIE/CIE: 稀疏不成比例伤困难/强回声样本) ----
        #   hard_reweight=True 时, 按每条样本的回声/近端能量比(≈回声强度)给 loss 加样本级权重,
        #   回声越强(越像长尾困难样本)权重越大, 抵消"简单样本主导梯度"。默认 False=原行为。
        self.hard_reweight = bool(kwargs.get("hard_reweight", False))
        self.hard_reweight_max = float(kwargs.get("hard_reweight_max", 3.0))   # 权重上限
        self.hard_reweight_gamma = float(kwargs.get("hard_reweight_gamma", 1.0))  # 强度指数

        # ---- 方法B: 稠密 teacher 蒸馏(治稀疏在困难样本的容量不足; teacher 仅训练期前向) ----
        #   distill=True 时加载 frozen 稠密 teacher, student 的 band_gain 对齐 teacher(L2),
        #   让稀疏 student 在强回声上复现 teacher 的"狠压"。推理不加载 teacher, 零部署成本。
        #   占比标定(distill_ratio): 任务 loss(带 beta=200)量级几百, band_gain MSE 量级 ~1e-2,
        #   直接相加蒸馏几乎不起作用。故用 task_loss 的 detach 值把 distill_mse 动态缩放到同量级,
        #   再按 distill_ratio 混合: total = (1-r)*task + r*(task_scale*distill_mse)。
        #   distill_ratio=0.5 => 蒸馏与任务各占一半(量纲无关)。
        self.distill = bool(kwargs.get("distill", False))
        self.distill_ratio = float(kwargs.get("distill_ratio", 0.5))
        self.distill_conditional = bool(kwargs.get("distill_conditional", False))
        self.distill_doubletalk_ratio = float(kwargs.get("distill_doubletalk_ratio", 0.45))
        self.distill_farend_ratio = float(kwargs.get("distill_farend_ratio", 0.75))
        self.distill_low_gain_focus = float(kwargs.get("distill_low_gain_focus", 0.0))
        self.distill_low_gain_power = float(kwargs.get("distill_low_gain_power", 2.0))
        self._teacher = None
        self._teacher_ckpt = kwargs.get("teacher_ckpt", "")

        # sqrt-hann 窗 (完美重构)
        win = torch.hann_window(self.window_size) ** 0.5
        self.register_buffer("window", win)
        self.erb = ERBBank(nbands=self.nbands, nfft=self.nfft, fs=16000)

        if _HAS_PL:
            self.save_hyperparameters(ignore=["model", "optimizer", "loss_func",
                                              "train_loader", "val_loader", "scheduler"])

    # ---- 特征 ----
    def wav_to_bandfeat(self, z, y, x):
        """三路波形 -> 拼接的 log band power 特征 + mic 的幅度/相位(供合成)。"""
        # 防御性: 若数据侧(如 online_augment 的 EQ)漏网产生 inf/nan 或超幅,
        # 这里统一清理并限幅, 避免 STFT/log_band_power 出 nan 毒化训练。
        z = torch.nan_to_num(z, nan=0.0, posinf=1.0, neginf=-1.0).clamp_(-4.0, 4.0)
        y = torch.nan_to_num(y, nan=0.0, posinf=1.0, neginf=-1.0).clamp_(-4.0, 4.0)
        x = torch.nan_to_num(x, nan=0.0, posinf=1.0, neginf=-1.0).clamp_(-4.0, 4.0)
        Z = _stft(z, self.nfft, self.hop_length, self.window_size, self.window)  # [B,F,T]
        Y = _stft(y, self.nfft, self.hop_length, self.window_size, self.window)
        X = _stft(x, self.nfft, self.hop_length, self.window_size, self.window)

        # 功率谱 [B,T,F]
        Zp = (Z.abs() ** 2).permute(0, 2, 1)
        Yp = (Y.abs() ** 2).permute(0, 2, 1)
        Xp = (X.abs() ** 2).permute(0, 2, 1)

        fz = self.erb.log_band_power(Zp)   # [B,T,nbands]
        fy = self.erb.log_band_power(Yp)
        fx = self.erb.log_band_power(Xp)
        feat = torch.cat([fz, fy, fx], dim=-1)   # [B,T,3*nbands]

        mic_mag = Y.abs().permute(0, 2, 1)       # [B,T,F]
        mic_phase = Y.angle().permute(0, 2, 1)
        return feat, mic_mag, mic_phase

    def apply_gain_synth(self, band_gain, mic_mag, mic_phase, length):
        """band gain -> 频点增益 -> 乘 mic 幅度 -> ISTFT。"""
        freq_gain = self.erb.band_gain_to_freq(band_gain)   # [B,T,F]
        enh_mag = mic_mag * freq_gain
        # [B,T,F] -> complex [B,F,T]
        enh_spec = (enh_mag * torch.exp(1j * mic_phase)).permute(0, 2, 1)
        out = _istft(enh_spec, self.nfft, self.hop_length, self.window_size,
                     self.window, length=length)
        return out

    def _model_band_gain(self, model, feat):
        """跑一个 model(student 或 teacher) 出 band_gain, 屏蔽 percepnet/seidel 返回差异。"""
        if self.model_type == "percepnet":
            band_gain, _comb, _h = model(feat)
        else:
            band_gain, _h = model(feat)
        return band_gain

    def forward(self, z, y, x):
        feat, mic_mag, mic_phase = self.wav_to_bandfeat(z, y, x)
        band_gain = self._model_band_gain(self.model, feat)
        est = self.apply_gain_synth(band_gain, mic_mag, mic_phase, length=y.shape[1])
        return est

    def _build_teacher(self):
        """惰性构建 frozen 稠密 teacher(方法B)。teacher 与 student 同结构(稠密版),
        权重来自 teacher_ckpt。只前向、不训练、不保存进 student ckpt。"""
        import copy
        if not self._teacher_ckpt:
            raise ValueError("distill=True 但未提供 teacher_ckpt")
        # teacher 用与 student 完全相同的模型类/结构(稠密, 无稀疏裁剪)。
        # 这里直接深拷贝 student 的模型结构再灌稠密权重(保证 band_gain 口径一致)。
        teacher = copy.deepcopy(self.model)
        # teacher 只加载稠密权重做 frozen 前向；不能继承 student 的固定稀疏 mask 行为。
        if hasattr(teacher, "sparse_freeze_mask"):
            teacher.sparse_freeze_mask = False
            teacher._fixed_masks = {}
        ck = torch.load(self._teacher_ckpt, map_location="cpu")
        sd = ck.get("state_dict", ck) if isinstance(ck, dict) else ck
        msd = {k.replace("model.", "", 1): v for k, v in sd.items() if k.startswith("model.")}
        if not msd:
            msd = sd
        miss, unexp = teacher.load_state_dict(msd, strict=False)
        print(f"I[distill]: teacher 加载 {self._teacher_ckpt} miss={len(miss)} unexp={len(unexp)}")
        teacher.eval()
        for p in teacher.parameters():
            p.requires_grad_(False)
        return teacher

    def _sample_weights(self, target, echo):
        """方法A: 按每条样本回声/近端能量比算样本级权重(回声越强权重越大)。
        w_i = clamp(1 + gamma * echo_pow/near_pow, max=hard_reweight_max), 再归一到均值1(不改总体步长)。"""
        ep = (echo ** 2).mean(dim=-1)                       # [B] 回声能量
        tp = (target ** 2).mean(dim=-1) + 1e-8              # [B] 近端能量
        ratio = (ep / tp).clamp(min=0.0)                    # 回声/近端, 越大越是强回声/低SER
        w = 1.0 + self.hard_reweight_gamma * ratio
        w = w.clamp(max=self.hard_reweight_max)
        w = w / (w.mean() + 1e-8)                           # 归一: 均值=1, 只改样本间相对权重
        return w                                            # [B]

    def common_step(self, batch, batch_nb, train=True):
        # dataset: (z=aecout, x=far, target, echo, y=mic, vad)
        z, x, target, echo, y, vad = batch[0], batch[1], batch[2], batch[3], batch[4], batch[5]

        feat, mic_mag, mic_phase = self.wav_to_bandfeat(z, y, x)
        band_gain = self._model_band_gain(self.model, feat)
        est = self.apply_gain_synth(band_gain, mic_mag, mic_phase, length=y.shape[1])

        # 对齐长度(est 来自 ISTFT, target/echo 原始波形, 三者截到同一最短长度)
        L = min(est.shape[1], target.shape[1], echo.shape[1])
        est_, tgt_, echo_ = est[:, :L], target[:, :L], echo[:, :L]

        # --- 方法A: 强回声样本级重加权 ---
        #   需要逐样本 loss 才能加权。loss_func 返回标量(batch 聚合), 无法直接拆样本,
        #   故对 batch 内每条单独算 loss 再按权重加权平均(batch 不大, 开销可接受)。
        if self.hard_reweight and train:
            w = self._sample_weights(tgt_, echo_)           # [B]
            B = est_.shape[0]
            losses = []
            for i in range(B):
                ei = est_[i:i+1]; ti = tgt_[i:i+1]; hi = echo_[i:i+1]
                try:
                    li = self.loss_func(ei, ti, hi)
                except TypeError:
                    li = self.loss_func(ei, ti)
                losses.append(li)
            loss = torch.stack(losses) * w.to(est_.device)
            loss = loss.mean()
        else:
            try:
                loss = self.loss_func(est_, tgt_, echo_)
            except TypeError:
                loss = self.loss_func(est_, tgt_)

        # --- 方法B: 稠密 teacher 蒸馏(student band_gain 对齐 teacher) ---
        if self.distill and train:
            if self._teacher is None:
                self._teacher = self._build_teacher()
            self._teacher.to(feat.device)
            with torch.no_grad():
                t_gain = self._model_band_gain(self._teacher, feat)
            n = min(band_gain.shape[1], t_gain.shape[1])
            s_gain = band_gain[:, :n]
            t_gain = t_gain[:, :n]

            if self.distill_conditional:
                # nearend_vad: [B, Tv]，1=近端活动(双讲)，0=近端静音(远端单讲/停顿)。
                # 最近邻插值到 gain 帧数；远端单讲提高 teacher 比例，双讲降低比例以守住近端。
                vad_frame = vad.float()
                if vad_frame.ndim == 1:
                    vad_frame = vad_frame.unsqueeze(0)
                vad_frame = F.interpolate(vad_frame.unsqueeze(1), size=n,
                                          mode="nearest").squeeze(1).clamp(0.0, 1.0)
                ratio_map = (self.distill_farend_ratio * (1.0 - vad_frame)
                             + self.distill_doubletalk_ratio * vad_frame).unsqueeze(-1)
                gain_error = (s_gain - t_gain) ** 2
                if self.distill_low_gain_focus > 0:
                    # teacher gain 越低，说明该 band 越应强压；只改变蒸馏关注位置，不改变平均比例。
                    focus = 1.0 + self.distill_low_gain_focus * (
                        1.0 - t_gain).clamp(0.0, 1.0).pow(self.distill_low_gain_power)
                else:
                    focus = torch.ones_like(gain_error)
                weight = ratio_map * focus
                distill_mse = (gain_error * weight).sum() / (weight.sum() + 1e-8)
                r = ratio_map.mean().clamp(0.0, 1.0)
            else:
                distill_mse = torch.mean((s_gain - t_gain) ** 2)
                r = band_gain.new_tensor(self.distill_ratio).clamp(0.0, 1.0)

            # 量纲对齐后按比例做凸组合。conditional 模式下 r 是当前 batch 的场景平均比例。
            scale = loss.detach().abs() / (distill_mse.detach() + 1e-8)
            loss = (1.0 - r) * loss + r * scale * distill_mse

        return loss

    def training_step(self, batch, batch_nb):
        loss = self.common_step(batch, batch_nb, train=True)
        self.log("loss", loss, logger=True, sync_dist=True, prog_bar=True)
        return loss

    def on_train_batch_end(self, *args, **kwargs):
        # 稀疏感知训练: 若 model 提供 sparsify() (如 SeidelAECSparse), 每个优化步后调用,
        # 按调度把 GRU 权重按 4×8 块渐进置零。普通 seidel/percepnet 无此方法, 零影响。
        sparsify = getattr(self.model, "sparsify", None)
        if callable(sparsify):
            sparsify()

    def validation_step(self, batch, batch_nb):
        loss = self.common_step(batch, batch_nb, train=False)
        self.log("val_loss", loss, on_epoch=True, prog_bar=True, sync_dist=True)

    def configure_optimizers(self):
        if self.scheduler is None:
            return self.optimizer
        sched = {"scheduler": self.scheduler, "monitor": self.default_monitor}
        return [self.optimizer], [sched]

    def train_dataloader(self):
        return self.train_loader

    def val_dataloader(self):
        return self.val_loader

    def on_save_checkpoint(self, checkpoint):
        checkpoint["training_config"] = {}
        return checkpoint
