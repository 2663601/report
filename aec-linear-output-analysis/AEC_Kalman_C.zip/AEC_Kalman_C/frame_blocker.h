/*
 *  Frame Blocker - Pure C Version
 *
 *  Converts 80-sample sub-frames into 64-sample processing blocks.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#ifndef FRAME_BLOCKER_H_
#define FRAME_BLOCKER_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float   buffer[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE];
    int     buffer_count;   /* number of samples currently in buffer per band */
    int     num_bands;
} FrameBlocker;

/* Initialize the frame blocker, clearing internal buffer. */
void FrameBlocker_Init(FrameBlocker* self, int num_bands);

/*
 * Insert an 80-sample sub-frame and extract a 64-sample block.
 *
 * sub_frame: input sub-frame, shape [num_bands][AEC3_SUB_FRAME_LENGTH]
 * block:     output block, shape [num_bands][AEC3_BLOCK_SIZE]
 *
 * Returns 1 if a block was extracted, 0 otherwise.
 */
int FrameBlocker_InsertSubFrame(FrameBlocker* self,
                                const float sub_frame[][AEC3_SUB_FRAME_LENGTH],
                                float block[][AEC3_BLOCK_SIZE],
                                int num_bands);

/* Returns 1 if a full 64-sample block is available for extraction. */
int FrameBlocker_IsBlockAvailable(const FrameBlocker* self);

/* Extract a block when IsBlockAvailable() returns 1. */
void FrameBlocker_ExtractBlock(FrameBlocker* self,
                               float block[][AEC3_BLOCK_SIZE],
                               int num_bands);

#ifdef __cplusplus
}
#endif

#endif /* FRAME_BLOCKER_H_ */
