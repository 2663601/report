#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
ERB band 滤波器组 (供 Seidel / PercepNet-AEC 后置滤波器使用)

把 STFT 的 nfreq=nfft//2+1 个线性频点, 用三角 ERB 滤波器压成 nbands 个感知频带。
- bm(): 频点功率谱 -> band 功率谱   (前向压缩)
- bs(): band 增益  -> 频点增益      (用映射矩阵转置, 把 band mask 还原到频点)

ERB 刻度公式与 rnnoise/gtcrn 一致:
    erb_rate = 21.4 * log10(0.00437*f + 1)
低频密、高频疏, 对语音关键区(低频)刻画更细。

设计成 nn.Module, 映射矩阵作为 buffer(不训练), 可随模型 .to(device)。
"""
import numpy as np
import torch
import torch.nn as nn


def _hz2erb(f):
    return 21.4 * np.log10(0.00437 * f + 1.0)


def _erb2hz(e):
    return (10 ** (e / 21.4) - 1.0) / 0.00437


def make_erb_matrix(nbands, nfft=512, fs=16000, low_lim=0.0, high_lim=8000.0):
    """
    返回三角 ERB 滤波器组矩阵 B: [nbands, nfreq], nfreq = nfft//2+1。
    每个 band 是一个三角窗, 在 ERB 刻度上等间隔, 相邻 band 50% 重叠。
    行做了能量归一化(每个 band 的权重和为 1), 使 band 功率是频点功率的加权平均。
    """
    nfreq = nfft // 2 + 1
    # ERB 刻度上均匀取 nbands+2 个中心点 (两端留边)
    erb_low = _hz2erb(max(low_lim, 1.0))
    erb_high = _hz2erb(high_lim)
    erb_points = np.linspace(erb_low, erb_high, nbands + 2)
    hz_points = _erb2hz(erb_points)
    # 映射到 FFT bin 索引
    bins = np.floor((nfft) * hz_points / fs).astype(int)
    bins = np.clip(bins, 0, nfreq - 1)

    B = np.zeros((nbands, nfreq), dtype=np.float32)
    for m in range(1, nbands + 1):
        f_left, f_center, f_right = bins[m - 1], bins[m], bins[m + 1]
        # 左上升沿
        if f_center > f_left:
            for k in range(f_left, f_center):
                B[m - 1, k] = (k - f_left) / (f_center - f_left)
        # 右下降沿
        if f_right > f_center:
            for k in range(f_center, f_right):
                B[m - 1, k] = (f_right - k) / (f_right - f_center)
        B[m - 1, f_center] = 1.0
    # 行归一化(能量平均), 避免宽带 band 数值过大
    row_sum = B.sum(axis=1, keepdims=True)
    row_sum[row_sum < 1e-8] = 1e-8
    B = B / row_sum
    return B


class ERBBank(nn.Module):
    """ERB 频带前向/反向映射。"""

    def __init__(self, nbands=32, nfft=512, fs=16000, high_lim=8000.0, eps=1e-6):
        super().__init__()
        self.nbands = nbands
        self.nfft = nfft
        self.nfreq = nfft // 2 + 1
        self.eps = eps
        B = make_erb_matrix(nbands, nfft=nfft, fs=fs, high_lim=high_lim)  # [nbands, nfreq]
        self.register_buffer("B", torch.from_numpy(B))          # 前向: band = B @ power
        # 反向: 频点增益 = Bt @ band_gain, Bt 列归一化保证增益量级稳定
        Bt = B.T.copy()                                          # [nfreq, nbands]
        col = Bt.sum(axis=1, keepdims=True)
        col[col < 1e-8] = 1e-8
        self.register_buffer("Bt", torch.from_numpy(Bt / col))

    def power_to_band(self, power):
        """
        power: [B, T, nfreq]  线性功率谱 (|X|^2)
        return: [B, T, nbands] band 功率
        """
        return torch.matmul(power, self.B.t())

    def log_band_power(self, power):
        """band 的 log 功率谱特征 (喂网络)。power: [B,T,nfreq] -> [B,T,nbands]

        nan 根治: band 功率可能为 0/极小(静音帧、far 单讲近端全 0、.so 残差异常),
        log10 反向梯度 ∝ 1/x 会在近零处爆成巨值/nan。先 clamp 到 eps 下限,
        保证 log 输入恒 >= eps, 从源头杜绝 log(近零) 的爆炸梯度 (fp16/fp32 都安全)。
        """
        bp = self.power_to_band(power)
        bp = torch.clamp(bp, min=self.eps)
        return torch.log10(bp)

    def band_gain_to_freq(self, band_gain):
        """
        band_gain: [B, T, nbands]  (0~1)
        return: [B, T, nfreq]      频点增益
        """
        return torch.matmul(band_gain, self.Bt.t())


if __name__ == "__main__":
    bank = ERBBank(nbands=32, nfft=512, fs=16000)
    print("B:", bank.B.shape, "Bt:", bank.Bt.shape)
    power = torch.rand(2, 10, 257)
    bp = bank.log_band_power(power)
    print("log band power:", bp.shape)
    g = torch.sigmoid(torch.rand(2, 10, 32))
    fg = bank.band_gain_to_freq(g)
    print("freq gain:", fg.shape, "range", fg.min().item(), fg.max().item())
