/*
 *  AEC3 Common Constants - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 *
 *  All C++ constructs (constexpr, namespace, static_assert) replaced
 *  with C99-compatible macros and inline functions.
 */

#ifndef AEC3_COMMON_H_
#define AEC3_COMMON_H_

#include <stddef.h>

/* ================================================================
 * Memory Alignment
 * ================================================================ */
#ifdef _MSC_VER
  #define AEC3_ALIGN16 __declspec(align(16))
#else
  #define AEC3_ALIGN16 __attribute__((aligned(16)))
#endif

/* ================================================================
 * FFT Sizes - 128 point
 * ================================================================ */
#define AEC3_FFT_LENGTH_BY2             64
#define AEC3_FFT_LENGTH_BY2_PLUS1       65
#define AEC3_FFT_LENGTH_BY2_MINUS1      63
#define AEC3_FFT_LENGTH                 128
#define AEC3_FFT_LENGTH_BY2_LOG2        6
#define AEC3_FFT_LENGTH_LOG2            7

/* ================================================================
 * FFT Sizes - 256 point
 * ================================================================ */
#define AEC3_FFT_LENGTH_256_BY2         128
#define AEC3_FFT_LENGTH_256_BY2_PLUS1   129
#define AEC3_FFT_LENGTH_256_BY2_MINUS1  127
#define AEC3_FFT_LENGTH_256             256
#define AEC3_FFT_LENGTH_256_BY2_LOG2    7
#define AEC3_FFT_LENGTH_256_LOG2        8

/* ================================================================
 * FFT Sizes - 512 point (long)
 * ================================================================ */
#define AEC3_FFT_LENGTH_LONG_BY2        256
#define AEC3_FFT_LENGTH_LONG_BY2_PLUS1  257
#define AEC3_FFT_LENGTH_LONG_BY2_MINUS1 255
#define AEC3_FFT_LENGTH_LONG            512
#define AEC3_FFT_LENGTH_LONG_BY2_LOG2   8
#define AEC3_FFT_LENGTH_LONG_LOG2       9

/* ================================================================
 * Block and Frame Sizes
 * ================================================================ */
#define AEC3_BLOCK_SIZE                 64
#define AEC3_BLOCK_SIZE_LOG2            6
#define AEC3_EXTENDED_BLOCK_SIZE        128   /* 2 * AEC3_FFT_LENGTH_BY2 */
#define AEC3_SUB_FRAME_LENGTH           80
#define AEC3_FRAME_LENGTH               160   /* 10ms @ 16kHz */
#define AEC3_MAX_FRAME_LENGTH           480   /* 10ms @ 48kHz */

/* ================================================================
 * Filter Parameters
 * ================================================================ */
#define AEC3_MAX_FILTER_PARTITIONS      50
#define AEC3_MAX_FILTER_TIME_DOMAIN     (AEC3_MAX_FILTER_PARTITIONS * AEC3_FFT_LENGTH_BY2)
#define AEC3_MAX_BANDS                  3

/* ================================================================
 * Matched Filter Parameters
 * ================================================================ */
#define AEC3_MAX_MATCHED_FILTERS                        5
#define AEC3_MATCHED_FILTER_WINDOW_SIZE_SUB_BLOCKS      32
#define AEC3_MATCHED_FILTER_ALIGNMENT_SHIFT_SUB_BLOCKS  (AEC3_MATCHED_FILTER_WINDOW_SIZE_SUB_BLOCKS * 3 / 4)
#define AEC3_MATCHED_FILTER_WINDOW_SIZE                 (AEC3_MATCHED_FILTER_WINDOW_SIZE_SUB_BLOCKS * AEC3_BLOCK_SIZE / 4)

/* ================================================================
 * Render Buffer
 * ================================================================ */
#define AEC3_RENDER_QUEUE_SIZE          100
#define AEC3_RENDER_BUFFER_SIZE         270
#define AEC3_RENDER_TRANSFER_QUEUE_SIZE 100
#define AEC3_MAX_LOW_RATE_SIZE          4000    /* max downsampled buffer = AEC3_RENDER_BUFFER_SIZE_MAX */

/* ================================================================
 * Metrics
 * ================================================================ */
#define AEC3_NUM_BLOCKS_PER_SECOND              250
#define AEC3_METRICS_REPORTING_INTERVAL_BLOCKS  (10 * AEC3_NUM_BLOCKS_PER_SECOND)
#define AEC3_METRICS_COMPUTATION_BLOCKS         11
#define AEC3_METRICS_COLLECTION_BLOCKS          (AEC3_METRICS_REPORTING_INTERVAL_BLOCKS - AEC3_METRICS_COMPUTATION_BLOCKS)

/* ================================================================
 * PFDKF Parameters
 * ================================================================ */
#define AEC3_LF_BLOCK_NUM               88
#define AEC3_LF_BLOCK_SHIFT             3
#define AEC3_LF_BLOCK_HSIZE             ((AEC3_LF_BLOCK_NUM - 1) / AEC3_LF_BLOCK_SHIFT + 1)
#define AEC3_LF_BLOCK_LENGTH            64
#define AEC3_LF_FFT_LENGTH_BY2          256
#define AEC3_LF_FFT_LENGTH_BY2_PLUS1    257
#define AEC3_LF_FFT_LENGTH              512
#define AEC3_LF_FFT_LENGTH_BY2_LOG2     8
#define AEC3_LF_FFT_LENGTH_LOG2         9
#define AEC3_LF_FFT_DISTANCE            (AEC3_LF_FFT_LENGTH - AEC3_LF_BLOCK_LENGTH)
#define AEC3_LF_FFT_DISTANCE2           (AEC3_LF_FFT_DISTANCE - AEC3_LF_BLOCK_LENGTH)
#define AEC3_MAX_PFDKF_PARTITIONS       AEC3_LF_BLOCK_HSIZE

/* ================================================================
 * Suppressor Parameters
 * ================================================================ */
#define AEC3_SUPPRESSOR_NEAREND_AVG_BLOCKS  4

/* ================================================================
 * Magic Number for Handle Validation
 * ================================================================ */
#define AEC3_KALMAN_MAGIC               0x4B414C4D

/* ================================================================
 * Inline Helper Functions (C99)
 * ================================================================ */

/* Use __inline for MSVC C89 compat, inline for C99+ compilers */
#ifdef _MSC_VER
  #define AEC3_INLINE __inline
#else
  #define AEC3_INLINE inline
#endif

static AEC3_INLINE int Aec3_NumBandsForRate(int sample_rate_hz) {
    return (sample_rate_hz == 8000) ? 1 : (sample_rate_hz / 16000);
}

static AEC3_INLINE int Aec3_LowestBandRate(int sample_rate_hz) {
    return (sample_rate_hz == 8000) ? sample_rate_hz : 16000;
}

static AEC3_INLINE int Aec3_ValidFullBandRate(int sample_rate_hz) {
    return (sample_rate_hz == 8000  || sample_rate_hz == 16000 ||
            sample_rate_hz == 32000 || sample_rate_hz == 48000);
}

static AEC3_INLINE int Aec3_GetTimeDomainLength(int filter_length_blocks) {
    return filter_length_blocks * AEC3_FFT_LENGTH_BY2;
}

static AEC3_INLINE int Aec3_GetDownSampledBufferSize(int down_sampling_factor,
                                                      int num_matched_filters) {
    return AEC3_BLOCK_SIZE / down_sampling_factor *
           (AEC3_MATCHED_FILTER_ALIGNMENT_SHIFT_SUB_BLOCKS * num_matched_filters +
            AEC3_MATCHED_FILTER_WINDOW_SIZE_SUB_BLOCKS + 1);
}

static AEC3_INLINE int Aec3_GetRenderDelayBufferSize(int down_sampling_factor,
                                                      int num_matched_filters,
                                                      int filter_length_blocks) {
    return Aec3_GetDownSampledBufferSize(down_sampling_factor, num_matched_filters) /
               (AEC3_BLOCK_SIZE / down_sampling_factor) + filter_length_blocks + 1;
}

#endif /* AEC3_COMMON_H_ */
