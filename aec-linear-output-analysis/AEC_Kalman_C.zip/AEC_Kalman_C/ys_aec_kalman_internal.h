/*
 *  AEC Kalman Internal Handle - Pure C Version
 *
 *  Defines the top-level AecKalmanHandle structure used by the C API layer.
 *  Contains magic number validation, EchoCanceller3 instance pointer,
 *  and float/int16 conversion buffers.
 *
 *  C99 compatible, no C++ keywords.
 */

#ifndef YS_AEC_KALMAN_INTERNAL_H_
#define YS_AEC_KALMAN_INTERNAL_H_

#include <stdint.h>
#include "aec3_common.h"
#include "echo_canceller3.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AEC_KALMAN_MAGIC  0x4B414C4D  /* "KALM" */

typedef struct {
    unsigned int        magic;
    int                 sample_rate;
    int                 frame_len;
    int                 nlp_level;
    int                 initialized;
    int                 render_buffer_size;  /* ring buffer slot count */
    int                 fixed_delay_ms;      /* >=0: 固定延时(ms), <0: 自动延时估计 */
    EchoCanceller3*     ec3;
    float               work_buf[AEC3_MAX_BANDS * AEC3_MAX_FRAME_LENGTH];
    int16_t             i16_buf[AEC3_MAX_FRAME_LENGTH];
} AecKalmanHandle;

#ifdef __cplusplus
}
#endif

#endif /* YS_AEC_KALMAN_INTERNAL_H_ */
