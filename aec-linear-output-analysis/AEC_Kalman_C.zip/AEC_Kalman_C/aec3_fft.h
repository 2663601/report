/*
 *  Aec3Fft - Pure C FFT Module
 *
 *  Ported from WebRTC AEC3 C++ Aec3Fft class.
 *  Uses Ooura FFT algorithm (tableless variant) for real-valued FFT.
 *  Supports 128-point and 512-point transforms.
 *
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef AEC3_FFT_H_
#define AEC3_FFT_H_

#include "aec3_common.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * Aec3Fft structure
 * ================================================================ */
typedef struct {
    /* 128-point FFT twiddle factors (unused in tableless Ooura, reserved) */
    float   twiddle_128[AEC3_FFT_LENGTH];
    int     ip_128[AEC3_FFT_LENGTH];    /* bit-reversal workspace */

    /* 512-point FFT twiddle factors (unused in tableless Ooura, reserved) */
    float   twiddle_512[AEC3_FFT_LENGTH_LONG];
    int     ip_512[AEC3_FFT_LENGTH_LONG];

    int     initialized;
} Aec3Fft;

/* ================================================================
 * Window type for windowed FFT functions
 * ================================================================ */
typedef enum {
    AEC3_WINDOW_RECTANGULAR = 0,
    AEC3_WINDOW_HANNING,
    AEC3_WINDOW_SQRT_HANNING
} Aec3WindowType;

/* ================================================================
 * Initialization
 * ================================================================ */
void Aec3Fft_Init(Aec3Fft* self);

/* ================================================================
 * 128-point FFT / IFFT -> FftData128
 * ================================================================ */
void Aec3Fft_Fft128_typed(const Aec3Fft* self, float x[AEC3_FFT_LENGTH],
                           FftData128* X);
void Aec3Fft_Ifft128_typed(const Aec3Fft* self, const FftData128* X,
                            float x[AEC3_FFT_LENGTH]);

/* 128-point ZeroPadded FFT: x_old[64] + x[64], FFT128 -> FftData128 */
void Aec3Fft_ZeroPaddedFft128_typed(const Aec3Fft* self,
                                     const float x[AEC3_FFT_LENGTH_BY2],
                                     const float x_old[AEC3_FFT_LENGTH_BY2],
                                     FftData128* X);

/* 128-point Padded FFT: x_old[64] + x[64], window, FFT128 -> FftData128 */
void Aec3Fft_PaddedFft128_typed(const Aec3Fft* self, const float* x,
                                 const float* x_old, Aec3WindowType window,
                                 FftData128* X);

/* ================================================================
 * 512-point FFT / IFFT -> FftDataPfdkf
 * ================================================================ */
void Aec3Fft_Fft512_typed(const Aec3Fft* self, float x[AEC3_FFT_LENGTH_LONG],
                           FftDataPfdkf* X);
void Aec3Fft_Ifft512_typed(const Aec3Fft* self, const FftDataPfdkf* X,
                            float x[AEC3_FFT_LENGTH_LONG]);

/* PFDKF Padded FFT: x_old[448] + x[64], FFT512 -> FftDataPfdkf */
void Aec3Fft_PaddedFftPfdkf_typed(const Aec3Fft* self,
                                    const float x[AEC3_LF_BLOCK_LENGTH],
                                    const float x_old[AEC3_LF_FFT_DISTANCE],
                                    FftDataPfdkf* X);

/* 512-point Padded FFT: x_old[256] + x[256], window, FFT512 -> FftDataPfdkf */
void Aec3Fft_PaddedFft512_typed(const Aec3Fft* self, const float* x,
                                 const float* x_old, Aec3WindowType window,
                                 FftDataPfdkf* X);

#ifdef __cplusplus
}
#endif

#endif /* AEC3_FFT_H_ */
