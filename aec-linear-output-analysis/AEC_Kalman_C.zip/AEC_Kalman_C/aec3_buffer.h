/*
 *  AEC3 Ring Buffers - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ VectorBuffer, MatrixBuffer, FftBuffer.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Circular buffers for one-dimensional vectors, two-dimensional matrices,
 *  and FftData objects. All use pre-allocated memory, no dynamic allocation.
 */

#ifndef AEC3_BUFFER_H_
#define AEC3_BUFFER_H_

#include "aec3_common.h"
#include "fft_data.h"
#include <string.h>  /* memcpy for inline SoA helpers */

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * VectorBuffer - 1D vector circular buffer
 *
 * Stores `size` slots, each containing `height` floats.
 * Memory layout: buffer[slot * height + element]
 * ================================================================ */
typedef struct {
    int     size;           /* number of slots in the ring */
    int     height;         /* number of floats per slot (128-point: 65) */
    int     pfdkf_height;   /* number of floats per PFDKF slot (512-point: 257) */
    float*  buffer;         /* size * height contiguous memory */
    float*  buffer_pfdkf;   /* PFDKF extra buffer (size * pfdkf_height) */
    int     write;          /* current write index */
    int     read;           /* current read index */
} VectorBuffer;

/*
 * Initialize a VectorBuffer.
 *   mem:           pre-allocated float array
 *   size:          number of slots
 *   height:        floats per slot for 128-point spectrum (65)
 *   pfdkf_height:  floats per slot for 512-point PFDKF spectrum (257)
 * mem must have at least (size * height + size * pfdkf_height) elements.
 */
void VectorBuffer_Init(VectorBuffer* self, float* mem, int size, int height, int pfdkf_height);

/*
 * Compute a wrapped index: (size + index + offset) % size
 */
int VectorBuffer_OffsetIndex(const VectorBuffer* self, int index, int offset);

/* Advance write index by one slot (wraps around) */
void VectorBuffer_IncWriteIndex(VectorBuffer* self);

/* Retreat write index by one slot (wraps around) */
void VectorBuffer_DecWriteIndex(VectorBuffer* self);

/* ================================================================
 * MatrixBuffer - 2D matrix circular buffer
 *
 * Stores `size` slots, each a (height x width) matrix.
 * Memory layout: buffer[(slot * height + band) * width + sample]
 * ================================================================ */
typedef struct {
    int     size;           /* number of slots in the ring */
    int     height;         /* number of bands (rows) per slot */
    int     width;          /* number of samples (columns) per band */
    float*  buffer;         /* size * height * width contiguous memory */
    int     write;          /* current write index */
    int     read;           /* current read index */
} MatrixBuffer;

/*
 * Initialize a MatrixBuffer.
 *   mem:    pre-allocated float array of at least (size * height * width) elements
 *   size:   number of slots
 *   height: number of bands per slot
 *   width:  number of samples per band
 * Memory is zeroed.
 */
void MatrixBuffer_Init(MatrixBuffer* self, float* mem,
                       int size, int height, int width);

/*
 * Get a pointer to the float data for a specific slot and band.
 *   index: slot index (0..size-1)
 *   band:  band index (0..height-1)
 * Returns pointer to `width` contiguous floats.
 */
float* MatrixBuffer_GetSlot(const MatrixBuffer* self, int index, int band);

/*
 * Compute a wrapped index: (size + index + offset) % size
 */
int MatrixBuffer_OffsetIndex(const MatrixBuffer* self, int index, int offset);

/* Advance write index by one slot (wraps around) */
void MatrixBuffer_IncWriteIndex(MatrixBuffer* self);

/* Retreat write index by one slot (wraps around) */
void MatrixBuffer_DecWriteIndex(MatrixBuffer* self);

/* Advance read index by one slot (wraps around) */
void MatrixBuffer_IncReadIndex(MatrixBuffer* self);

/* Retreat read index by one slot (wraps around) */
void MatrixBuffer_DecReadIndex(MatrixBuffer* self);

/* ================================================================
 * VectorBuffer read index manipulation
 * ================================================================ */

/* Advance read index by one slot (wraps around) */
void VectorBuffer_IncReadIndex(VectorBuffer* self);

/* Retreat read index by one slot (wraps around) */
void VectorBuffer_DecReadIndex(VectorBuffer* self);

/* ================================================================
 * FftBuffer128 - FftData128 circular buffer
 *
 * Stores `size` FftData128 objects (128-point FFT, 520 bytes each).
 * ================================================================ */
typedef struct {
    int          size;      /* number of FftData128 slots */
    FftData128*  buffer;    /* size FftData128 objects, contiguous memory */
    int          write;     /* current write index */
    int          read;      /* current read index */
} FftBuffer128;

/*
 * Initialize an FftBuffer128.
 *   mem:  pre-allocated FftData128 array of at least `size` elements
 *   size: number of FftData128 slots
 * All entries are cleared to zero.
 */
void FftBuffer128_Init(FftBuffer128* self, FftData128* mem, int size);

/*
 * Compute a wrapped index: (size + index + offset) % size
 */
int FftBuffer128_OffsetIndex(const FftBuffer128* self, int index, int offset);

/* Advance write index by one slot (wraps around) */
void FftBuffer128_IncWriteIndex(FftBuffer128* self);

/* Retreat write index by one slot (wraps around) */
void FftBuffer128_DecWriteIndex(FftBuffer128* self);

/* Advance read index by one slot (wraps around) */
void FftBuffer128_IncReadIndex(FftBuffer128* self);

/* Retreat read index by one slot (wraps around) */
void FftBuffer128_DecReadIndex(FftBuffer128* self);

/* ================================================================
 * FftBufferPfdkf - PFDKF FFT circular buffer (SoA layout)
 *
 * Stores `size` slots of 257-bin complex data in Structure-of-Arrays
 * layout for cache-friendly sequential access.
 *
 * Memory: relf_buf[size * 257] + imlf_buf[size * 257]
 * Total: size * 257 * 2 * sizeof(float) = size * 2056 bytes (same as before)
 *
 * Access: slot i, bin k → relf_buf[i * 257 + k], imlf_buf[i * 257 + k]
 * ================================================================ */
typedef struct {
    int           size;      /* number of slots in the ring */
    float*        relf_buf;  /* SoA real part: size * 257 floats */
    float*        imlf_buf;  /* SoA imag part: size * 257 floats */
    FftDataPfdkf* buffer;    /* AoS alias (kept for cold-path compat, points to relf_buf cast) */
    int           write;     /* current write index */
    int           read;      /* current read index */
} FftBufferPfdkf;

/*
 * Initialize an FftBufferPfdkf with SoA memory layout.
 *   mem:  pre-allocated memory, at least size * 257 * 2 * sizeof(float) bytes.
 *         First half = relf_buf, second half = imlf_buf.
 *   size: number of slots
 * All entries are cleared to zero.
 */
void FftBufferPfdkf_Init(FftBufferPfdkf* self, FftDataPfdkf* mem, int size);

/*
 * Get SoA pointers for a specific slot.
 *   slot:  slot index (0..size-1)
 *   relf:  output pointer to 257 floats (real part)
 *   imlf:  output pointer to 257 floats (imag part)
 */
static inline void FftBufferPfdkf_GetSlot(const FftBufferPfdkf* self, int slot,
                                           const float** relf, const float** imlf) {
    int offset = slot * AEC3_LF_FFT_LENGTH_BY2_PLUS1;
    *relf = self->relf_buf + offset;
    *imlf = self->imlf_buf + offset;
}

/*
 * Get mutable SoA pointers for a specific slot (for writing).
 */
static inline void FftBufferPfdkf_GetSlotMut(FftBufferPfdkf* self, int slot,
                                              float** relf, float** imlf) {
    int offset = slot * AEC3_LF_FFT_LENGTH_BY2_PLUS1;
    *relf = self->relf_buf + offset;
    *imlf = self->imlf_buf + offset;
}

/*
 * Write an FftDataPfdkf (AoS) into a slot (SoA scatter).
 * Used at render insertion (cold path, once per block).
 */
static inline void FftBufferPfdkf_WriteSlot(FftBufferPfdkf* self, int slot,
                                             const FftDataPfdkf* src) {
    int offset = slot * AEC3_LF_FFT_LENGTH_BY2_PLUS1;
    memcpy(self->relf_buf + offset, src->relf, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memcpy(self->imlf_buf + offset, src->imlf, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
}

/*
 * Read a slot (SoA) into an FftDataPfdkf (AoS gather).
 * Used for cold-path compatibility.
 */
static inline void FftBufferPfdkf_ReadSlot(const FftBufferPfdkf* self, int slot,
                                            FftDataPfdkf* dst) {
    int offset = slot * AEC3_LF_FFT_LENGTH_BY2_PLUS1;
    memcpy(dst->relf, self->relf_buf + offset, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memcpy(dst->imlf, self->imlf_buf + offset, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
}

/*
 * Compute a wrapped index: (size + index + offset) % size
 */
int FftBufferPfdkf_OffsetIndex(const FftBufferPfdkf* self, int index, int offset);

/* Advance write index by one slot (wraps around) */
void FftBufferPfdkf_IncWriteIndex(FftBufferPfdkf* self);

/* Retreat write index by one slot (wraps around) */
void FftBufferPfdkf_DecWriteIndex(FftBufferPfdkf* self);

/* Advance read index by one slot (wraps around) */
void FftBufferPfdkf_IncReadIndex(FftBufferPfdkf* self);

/* Retreat read index by one slot (wraps around) */
void FftBufferPfdkf_DecReadIndex(FftBufferPfdkf* self);

#ifdef __cplusplus
}
#endif

#endif /* AEC3_BUFFER_H_ */
