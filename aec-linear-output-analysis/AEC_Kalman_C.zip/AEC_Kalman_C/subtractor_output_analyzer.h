/*
 *  SubtractorOutputAnalyzer - Pure C Version
 *
 *  Analyzes properties of the subtractor output: convergence, divergence.
 *  Ported from WebRTC AEC3 C++ SubtractorOutputAnalyzer class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef SUBTRACTOR_OUTPUT_ANALYZER_H_
#define SUBTRACTOR_OUTPUT_ANALYZER_H_

#include "aec3_common.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int     strict_divergence_check;
    int     shadow_filter_converged;
    int     main_filter_converged;
    int     filter_diverged;
    int     shadow_filter_diverged;
    int     main_filter_diverged;
} SubtractorOutputAnalyzer;

/**
 * Initialize the subtractor output analyzer.
 */
void SubtractorOutputAnalyzer_Init(SubtractorOutputAnalyzer* self);

/**
 * Update the analysis with new subtractor output.
 */
void SubtractorOutputAnalyzer_Update(SubtractorOutputAnalyzer* self,
                                     const SubtractorOutput* output);

/**
 * Returns whether either filter has converged.
 */
int SubtractorOutputAnalyzer_ConvergedFilter(const SubtractorOutputAnalyzer* self);

/**
 * Returns whether the filter has diverged.
 */
int SubtractorOutputAnalyzer_DivergedFilter(const SubtractorOutputAnalyzer* self);

/**
 * Returns whether the main filter has diverged.
 */
int SubtractorOutputAnalyzer_MainDivergedFilter(const SubtractorOutputAnalyzer* self);

/**
 * Returns whether the shadow filter has diverged.
 */
int SubtractorOutputAnalyzer_ShadowDivergedFilter(const SubtractorOutputAnalyzer* self);

/**
 * Handle echo path change: reset convergence/divergence flags.
 */
void SubtractorOutputAnalyzer_HandleEchoPathChange(SubtractorOutputAnalyzer* self);

#ifdef __cplusplus
}
#endif

#endif /* SUBTRACTOR_OUTPUT_ANALYZER_H_ */
