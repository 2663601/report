/*
 *  Cascaded Biquad Filter - Pure C Version
 *
 *  Applies a cascade of biquad (second-order IIR) filters.
 *  Direct Form 1 implementation.
 *  Ported from WebRTC C++ implementation.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#ifndef CASCADED_BIQUAD_FILTER_H_
#define CASCADED_BIQUAD_FILTER_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Maximum number of cascaded biquad stages */
#define BIQUAD_MAX_STAGES  6

typedef struct {
    float b[3];     /* feedforward coefficients */
    float a[2];     /* feedback coefficients */
} BiQuadCoefficients;

typedef struct {
    BiQuadCoefficients coefficients;
    float x[2];     /* input delay line */
    float y[2];     /* output delay line */
} BiQuadState;

typedef struct {
    BiQuadState stages[BIQUAD_MAX_STAGES];
    int         num_stages;
} CascadedBiQuadFilter;

/*
 * BiQuad parameter specification (zero-pole-gain form).
 * Used to compute coefficients during initialization.
 */
typedef struct {
    float zero_re;
    float zero_im;
    float pole_re;
    float pole_im;
    float gain;
    int   mirror_zero;  /* if 1, zeros at z_r and -z_r */
} BiQuadParam;

/* Initialize from an array of zero-pole-gain parameters. */
void CascadedBiQuad_InitFromParams(CascadedBiQuadFilter* self,
                                   const BiQuadParam* params,
                                   int num_stages);

/* Initialize from a single set of coefficients replicated num_stages times. */
void CascadedBiQuad_InitFromCoeffs(CascadedBiQuadFilter* self,
                                   const BiQuadCoefficients* coeffs,
                                   int num_stages);

/* Initialize with zero stages (pass-through). */
void CascadedBiQuad_InitPassThrough(CascadedBiQuadFilter* self);

/* Process: y[k] = filter(x[k]), x and y may alias. */
void CascadedBiQuad_Process(CascadedBiQuadFilter* self,
                            const float* x, float* y, int len);

/* In-place process: y[k] = filter(y[k]). */
void CascadedBiQuad_ProcessInPlace(CascadedBiQuadFilter* self,
                                   float* y, int len);

/* Reset all filter states to zero. */
void CascadedBiQuad_Reset(CascadedBiQuadFilter* self);

#ifdef __cplusplus
}
#endif

#endif /* CASCADED_BIQUAD_FILTER_H_ */
