/*
 *  FftData Types - Pure C Implementation
 *
 *  Ported from WebRTC AEC3 C++ FftData struct.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "fft_data.h"
#include <string.h>  /* memset, memcpy */

/* ================================================================
 * FftData128 functions (128-point FFT, re[65]/im[65])
 * ================================================================ */

void FftData128_Clear(FftData128* self)
{
    memset(self, 0, sizeof(FftData128));
}

void FftData128_Assign(FftData128* dst, const FftData128* src)
{
    memcpy(dst, src, sizeof(FftData128));
}

void FftData128_Spectrum(const FftData128* self, float* power_spectrum)
{
    int k;
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; ++k) {
        power_spectrum[k] = self->re[k] * self->re[k]
                          + self->im[k] * self->im[k];
    }
}

void FftData128_CopyFromPackedArray(FftData128* self, const float* v)
{
    int k, j;

    self->re[0] = v[0];
    self->re[AEC3_FFT_LENGTH_BY2] = v[1];
    self->im[0] = 0.0f;
    self->im[AEC3_FFT_LENGTH_BY2] = 0.0f;
    for (k = 1, j = 2; k < AEC3_FFT_LENGTH_BY2; ++k) {
        self->re[k] = v[j++];
        self->im[k] = v[j++];
    }
}

void FftData128_CopyToPackedArray(const FftData128* self, float* v)
{
    int k, j;

    v[0] = self->re[0];
    v[1] = self->re[AEC3_FFT_LENGTH_BY2];
    for (k = 1, j = 2; k < AEC3_FFT_LENGTH_BY2; ++k) {
        v[j++] = self->re[k];
        v[j++] = self->im[k];
    }
}

/* ================================================================
 * FftDataPfdkf functions (PFDKF/512-point FFT, relf[257]/imlf[257])
 * ================================================================ */

void FftDataPfdkf_Clear(FftDataPfdkf* self)
{
    memset(self, 0, sizeof(FftDataPfdkf));
}

void FftDataPfdkf_Assign(FftDataPfdkf* dst, const FftDataPfdkf* src)
{
    memcpy(dst, src, sizeof(FftDataPfdkf));
}

void FftDataPfdkf_Spectrum(const FftDataPfdkf* self, float* power_spectrum)
{
    int k;
    for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
        power_spectrum[k] = self->relf[k] * self->relf[k]
                          + self->imlf[k] * self->imlf[k];
    }
}

void FftDataPfdkf_CopyFromPackedArray(FftDataPfdkf* self, const float* v)
{
    int k, j;

    self->relf[0] = v[0];
    self->relf[AEC3_LF_FFT_LENGTH_BY2] = v[1];
    self->imlf[0] = 0.0f;
    self->imlf[AEC3_LF_FFT_LENGTH_BY2] = 0.0f;
    for (k = 1, j = 2; k < AEC3_LF_FFT_LENGTH_BY2; ++k) {
        self->relf[k] = v[j++];
        self->imlf[k] = v[j++];
    }
}

void FftDataPfdkf_CopyToPackedArray(const FftDataPfdkf* self, float* v)
{
    int k, j;

    v[0] = self->relf[0];
    v[1] = self->relf[AEC3_LF_FFT_LENGTH_BY2];
    for (k = 1, j = 2; k < AEC3_LF_FFT_LENGTH_BY2; ++k) {
        v[j++] = self->relf[k];
        v[j++] = self->imlf[k];
    }
}
