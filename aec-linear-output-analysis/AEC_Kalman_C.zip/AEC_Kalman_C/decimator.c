/*
 *  Decimator - Pure C Version
 *
 *  Provides signal decimation (downsampling) with anti-aliasing
 *  and noise reduction filtering.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "decimator.h"
#include <assert.h>

/* ================================================================
 * Filter coefficient tables (from scipy filter design)
 * ================================================================ */

/* signal.butter(2, 3400/8000.0, 'lowpass', analog=False) - DS2 */
static const BiQuadParam kLowPassDS2[] = {
    { -1.0f, 0.0f, 0.13833231f, 0.40743176f, 0.22711796393486466f, 0 },
    { -1.0f, 0.0f, 0.13833231f, 0.40743176f, 0.22711796393486466f, 0 },
    { -1.0f, 0.0f, 0.13833231f, 0.40743176f, 0.22711796393486466f, 0 }
};
#define NUM_LOWPASS_DS2  3

/* signal.ellip(6, 1, 40, 1800/8000, btype='lowpass', analog=False) - DS4 */
static const BiQuadParam kLowPassDS4[] = {
    { -0.08873842f, 0.99605496f, 0.75916227f, 0.23841065f, 0.26250696827f, 0 },
    {  0.62273832f, 0.78243018f, 0.74892112f, 0.54101520f, 0.26250696827f, 0 },
    {  0.71107693f, 0.70311421f, 0.74895534f, 0.63924616f, 0.26250696827f, 0 }
};
#define NUM_LOWPASS_DS4  3

/* signal.cheby1(1, 6, [1000/8000, 2000/8000], btype='bandpass', analog=False) - DS8 */
static const BiQuadParam kBandPassDS8[] = {
    { 1.0f, 0.0f, 0.76018150f, 0.46423542f, 0.10330478266505948f, 1 },
    { 1.0f, 0.0f, 0.76018150f, 0.46423542f, 0.10330478266505948f, 1 },
    { 1.0f, 0.0f, 0.76018150f, 0.46423542f, 0.10330478266505948f, 1 },
    { 1.0f, 0.0f, 0.76018150f, 0.46423542f, 0.10330478266505948f, 1 },
    { 1.0f, 0.0f, 0.76018150f, 0.46423542f, 0.10330478266505948f, 1 }
};
#define NUM_BANDPASS_DS8  5

/* signal.butter(2, 1000/8000.0, 'highpass', analog=False) - noise reduction */
static const BiQuadParam kHighPass[] = {
    { 1.0f, 0.0f, 0.72712179f, 0.21296904f, 0.7570763753338849f, 0 }
};
#define NUM_HIGHPASS  1

/* ================================================================
 * Public API
 * ================================================================ */

void Decimator_Init(Decimator* self, int down_sampling_factor) {
    assert(self != NULL);
    assert(down_sampling_factor == 2 || down_sampling_factor == 4 ||
           down_sampling_factor == 8);

    self->down_sampling_factor = down_sampling_factor;

    /* Anti-aliasing filter */
    if (down_sampling_factor == 4) {
        CascadedBiQuad_InitFromParams(&self->anti_aliasing_filter,
                                      kLowPassDS4, NUM_LOWPASS_DS4);
    } else if (down_sampling_factor == 8) {
        CascadedBiQuad_InitFromParams(&self->anti_aliasing_filter,
                                      kBandPassDS8, NUM_BANDPASS_DS8);
    } else {
        CascadedBiQuad_InitFromParams(&self->anti_aliasing_filter,
                                      kLowPassDS2, NUM_LOWPASS_DS2);
    }

    /* Noise reduction filter (pass-through for DS8) */
    if (down_sampling_factor == 8) {
        CascadedBiQuad_InitPassThrough(&self->noise_reduction_filter);
    } else {
        CascadedBiQuad_InitFromParams(&self->noise_reduction_filter,
                                      kHighPass, NUM_HIGHPASS);
    }
}

void Decimator_Decimate(Decimator* self,
                        const float* in, float* out, int in_len) {
    float x[AEC3_BLOCK_SIZE];
    int out_len;
    int j, k;

    assert(self != NULL);
    assert(in_len == AEC3_BLOCK_SIZE);

    out_len = AEC3_BLOCK_SIZE / self->down_sampling_factor;

    /* Apply anti-aliasing filter */
    CascadedBiQuad_Process(&self->anti_aliasing_filter, in, x, AEC3_BLOCK_SIZE);

    /* Apply noise reduction filter (in-place) */
    CascadedBiQuad_ProcessInPlace(&self->noise_reduction_filter, x, AEC3_BLOCK_SIZE);

    /* Downsample by picking every Nth sample */
    for (j = 0, k = 0; j < out_len; ++j, k += self->down_sampling_factor) {
        out[j] = x[k];
    }
}
