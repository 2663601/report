/*
 *  ReverbModel - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ReverbModel class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "reverb_model.h"
#include <string.h>

void ReverbModel_Init(ReverbModel* self) {
    ReverbModel_Reset(self);
}

void ReverbModel_Reset(ReverbModel* self) {
    memset(self->reverb, 0, sizeof(self->reverb));
}

void ReverbModel_AddReverbNoFreqShaping(ReverbModel* self,
                                        const float* power_spectrum,
                                        float power_spectrum_scaling,
                                        float reverb_decay,
                                        float* reverb_power_spectrum) {
    int k;
    if (reverb_decay > 0.0f) {
        for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
            self->reverb[k] = (self->reverb[k] +
                power_spectrum[k] * power_spectrum_scaling) * reverb_decay;
        }
    }
    /* Add reverb to output */
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        reverb_power_spectrum[k] += self->reverb[k];
    }
}

void ReverbModel_AddReverb(ReverbModel* self,
                           const float* power_spectrum,
                           const float* freq_response_tail,
                           float reverb_decay,
                           float* reverb_power_spectrum) {
    int k;
    if (reverb_decay > 0.0f) {
        for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
            self->reverb[k] = (self->reverb[k] +
                power_spectrum[k] * freq_response_tail[k]) * reverb_decay;
        }
    }
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        reverb_power_spectrum[k] += self->reverb[k];
    }
}

void ReverbModel_UpdateNoFreqShaping(ReverbModel* self,
                                     const float* power_spectrum,
                                     float power_spectrum_scaling,
                                     float reverb_decay) {
    int k;
    if (reverb_decay > 0.0f) {
        for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
            self->reverb[k] = (self->reverb[k] +
                power_spectrum[k] * power_spectrum_scaling) * reverb_decay;
        }
    }
}

const float* ReverbModel_GetPowerSpectrum(const ReverbModel* self) {
    return self->reverb;
}

/* ================================================================
 * ReverbModelLong - 512-point FFT (257 bins) version
 * ================================================================ */

void ReverbModelLong_Init(ReverbModelLong* self) {
    ReverbModelLong_Reset(self);
}

void ReverbModelLong_Reset(ReverbModelLong* self) {
    memset(self->reverb, 0, sizeof(self->reverb));
}

void ReverbModelLong_AddReverbNoFreqShaping(ReverbModelLong* self,
                                            const float* power_spectrum,
                                            float power_spectrum_scaling,
                                            float reverb_decay,
                                            float* reverb_power_spectrum) {
    int k;
    if (reverb_decay > 0.0f) {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            self->reverb[k] = (self->reverb[k] +
                power_spectrum[k] * power_spectrum_scaling) * reverb_decay;
        }
    }
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        reverb_power_spectrum[k] += self->reverb[k];
    }
}

void ReverbModelLong_AddReverb(ReverbModelLong* self,
                               const float* power_spectrum,
                               const float* freq_response_tail,
                               float reverb_decay,
                               float* reverb_power_spectrum) {
    int k;
    if (reverb_decay > 0.0f) {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            self->reverb[k] = (self->reverb[k] +
                power_spectrum[k] * freq_response_tail[k]) * reverb_decay;
        }
    }
    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        reverb_power_spectrum[k] += self->reverb[k];
    }
}
