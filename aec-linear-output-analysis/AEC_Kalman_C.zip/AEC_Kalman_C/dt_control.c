/*
 *  DtController - Pure C Version (Optimized)
 *
 *  Ported from WebRTC AEC3 C++ DtController class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Optimizations vs original:
 *  - Removed unused arrays (cohxdl/cohdyl/coheyl/res_echo_estimatel/sx2/se2/sy2)
 *  - Eliminated sy2==sd2 redundancy, sx2 (computed but never read)
 *  - Removed dead Step2 (noise floor forced to 0)
 *  - Compressed echo_sup_dt from per-bin array to scalar
 *  - se2 replaced by scalar seSum for divergence detection
 *  Savings: ~8.3 KB memory, ~34% fewer loops, ~16% fewer sqrtf calls.
 */

#include "dt_control.h"
#include <string.h>
#include <math.h>

void DtController_Init(DtController* self) {
    int i;
    memset(self, 0, sizeof(DtController));

    for (i = 0; i < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; i++) {
        self->echo_sup_gainl[i] = 1.0f;
    }

    self->echo_sup_dt_scalar = 1.0f;
    self->double_talk_count_max = 30;
    self->dtd_flag = 1;
    self->aec_dtcontrol_enable = 0;
    self->ed_ratio_2k_threshold = -1.0f;
    self->frame_cnt = 1;
    self->double_talk_probability = 1.0f;
    self->accelerate = 0.0f;

    /* Initialize control operations to safe defaults */
    self->control_operation.AccelerateAdaptive = 0;
    self->control_operation.StopAdaptive = 0;
    self->control_operation.StopNLP = 0;
    self->control_operation.StopFiltering = 0;
    self->control_operation.OverSuppress = 0;
    self->control_operation.ExOverSuppress = 0;
    self->control_operation.UnderSuppress = 0;
    self->control_operation.NearMaintain = 0;
    self->control_operation.ERLEUpdate = 0;
    self->control_operation.StopERLUpdate = 0;
    self->control_operation.StopNearAdjust = 0;
    self->control_operation.UseWeinerGain[0] = 0;
    self->control_operation.UseWeinerGain[1] = 0;
    self->control_operation.UseWeinerGain[2] = 0;
}

void DtController_Reset(DtController* self) {
    DtController_Init(self);
}

/* 128pt DtController_Update is dead code in PFDKF path.
 * Stub retained for AecState_Update compilation compatibility. */
void DtController_Update(DtController* self,
                         FftData128* Y, FftData128* E, FftData128* S, FftData128* X,
                         const float* y, const float* e,
                         const float* s, const float* x,
                         float nonlinear_level,
                         int audioMixing_flag,
                         int dtd_flag,
                         int submodule_flag,
                         int earphone_flag,
                         float erl, float erl_diff,
                         int extern_echo_state) {
    (void)Y; (void)E; (void)S; (void)X;
    (void)y; (void)e; (void)s; (void)x;
    (void)nonlinear_level; (void)erl; (void)erl_diff;
    (void)extern_echo_state;

    self->nonlinear_level = nonlinear_level;
    self->audioMixing_flag = audioMixing_flag;
    self->dtd_flag = dtd_flag;
    self->submodule_flag = submodule_flag;
    self->earphone_flag = earphone_flag;
    self->frame_cnt++;
}

void DtController_Update512fft(DtController* self,
                               FftDataPfdkf* Y, FftDataPfdkf* E, FftDataPfdkf* S,
                               FftDataPfdkf* E_nlp, FftDataPfdkf* X,
                               const float* suppression_gain,
                               const float* comfort_noise_spectrum,
                               int aec_level,
                               int aec_low_compute_mode) {
    int k;
    float kMinFarendPSD = 15.f;

    /* ================================================================
     * Step 1: Compute sd2 and se2_nlp power spectra
     * Also compute sdSum/seSum for filter divergence detection.
     * Removed: sx2 (never read), sy2 (== sd2), se2 (replaced by seSum scalar)
     * ================================================================ */
    {
        float sdSum = 0.0f, seSum = 0.0f;
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            self->sd2_512fft[k] = Y->relf[k] * Y->relf[k] + Y->imlf[k] * Y->imlf[k];
            seSum += E->relf[k] * E->relf[k] + E->imlf[k] * E->imlf[k];

            /* se2_nlp: NLP-applied error power, floored by kMinFarendPSD */
            {
                float e_nlp_pow = E_nlp->relf[k] * E_nlp->relf[k] + E_nlp->imlf[k] * E_nlp->imlf[k];
                self->se2_nlp_512fft[k] = e_nlp_pow > kMinFarendPSD ? e_nlp_pow : kMinFarendPSD;
            }

            sdSum += self->sd2_512fft[k];
        }
        /* Filter divergence detection */
        self->filter_divergence_state =
            (self->filter_divergence_state ? 1.05f : 1.0f) * seSum > sdSum ? 1 : 0;
    }

    /* Step 2 (noise floor) removed — was disabled (forced to 0) */

    /* ================================================================
     * Step 3: crosscor_512fft (UpdateCorState_512fft)
     * Computes spec_cor_de between sd2_512fft and se2_nlp_512fft
     * over bins [0, 48), also updates near_energy and capture_energy.
     * ================================================================ */
    {
        float spec_a[48], spec_b[48];
        float avg_a = 0.0f, avg_b = 0.0f;
        float spec_cor_ab = 0.0f, sum_a = 0.0f, sum_b = 0.0f;
        float spec_val, sumab_val;

        for (k = 0; k < 48; k++) {
            spec_a[k] = self->sd2_512fft[k] > 0.0f ? sqrtf(self->sd2_512fft[k]) : 0.0f;
            spec_b[k] = self->se2_nlp_512fft[k] > 0.0f ? sqrtf(self->se2_nlp_512fft[k]) : 0.0f;
            avg_a += spec_a[k];
            avg_b += spec_b[k];
        }
        avg_a /= 49.0f;
        avg_b /= 49.0f;

        for (k = 0; k < 48; k++) {
            float a_spec = spec_a[k] - avg_a;
            float b_spec = spec_b[k] - avg_b;
            spec_cor_ab += a_spec * b_spec;
            sum_a += a_spec * a_spec;
            sum_b += b_spec * b_spec;
        }

        /* Update near_energy and capture_energy (asymmetric smoothing) */
        {
            float ne_target = avg_b / 100.0f;
            float ce_target = avg_a / 100.0f;
            if (self->near_energy < ne_target)
                self->near_energy += (ne_target - self->near_energy) * 0.05f;
            else
                self->near_energy += (ne_target - self->near_energy) * 0.8f;
            if (self->capture_energy < ce_target)
                self->capture_energy += (ce_target - self->capture_energy) * 0.05f;
            else
                self->capture_energy += (ce_target - self->capture_energy) * 0.8f;
        }

        /* Compute correlation with VAD gating */
        {
            float ce_thr = 20.0f;
            if (self->earphone_flag) {
                ce_thr = 2.0f;
            }
            if (self->capture_energy < ce_thr) {
                self->spec_cor_de_512fft = 0.0f;
            } else {
                spec_val = spec_cor_ab > 0.0f ? spec_cor_ab : 0.0f;
                {
                    double sa_sb = (double)sum_a * (double)sum_b;
                    sumab_val = (float)sqrt(sa_sb > 0.0 ? sa_sb : -sa_sb);
                }
                if (sumab_val == 0.0f) {
                    self->spec_cor_de_512fft = 0.0f;
                } else {
                    float new_cor = spec_val / (sumab_val + 1e-6f);
                    if (self->spec_cor_de_512fft < new_cor) {
                        if (new_cor > 0.9f)
                            self->spec_cor_de_512fft += (new_cor - self->spec_cor_de_512fft) * 1.0f;
                        else
                            self->spec_cor_de_512fft += (new_cor - self->spec_cor_de_512fft) * 0.1f;
                    } else {
                        self->spec_cor_de_512fft = new_cor;
                    }
                }
            }
        }
    }

    /* ================================================================
     * Step 4: CheckEchoState_512fft
     * Multi-condition near-end detection -> echo_state decision
     * ================================================================ */
    {
        int near_state = 0;
        float ne_thr;

        if (self->double_talk_count > 0)
            self->double_talk_count--;

        /* NO.1: spec_cor_de based near-end detection */
        ne_thr = 8.0f;
        if (self->earphone_flag) ne_thr = 2.0f;
        if (self->spec_cor_de_512fft >= 0.25f && self->near_energy > ne_thr) {
            if (self->spec_cor_de_last[0] >= 0.25f) {
                if (self->spec_cor_de_last[1] >= 0.25f) {
                    self->double_talk_count = self->double_talk_count_max;
                }
            }
        }
        self->spec_cor_de_last[2] = self->spec_cor_de_last[1];
        self->spec_cor_de_last[1] = self->spec_cor_de_last[0];
        self->spec_cor_de_last[0] = (self->near_energy > ne_thr) ? self->spec_cor_de_512fft : 0.0f;

        if (self->spec_cor_de_512fft >= 0.25f && self->double_talk_count > 0) {
            self->double_talk_count = self->double_talk_count_max;
        }

        /* NO.2: ed_ratio_2k based near-end detection */
        {
            double sd2_sum = 0.0, se2_nlp_sum = 0.0;
            for (k = 0; k < 128; k++) {
                sd2_sum += self->sd2_512fft[k];
                se2_nlp_sum += (self->se2_nlp_512fft[k] < self->sd2_512fft[k])
                    ? self->se2_nlp_512fft[k] : self->sd2_512fft[k];
            }
            self->ed_ratio_2k = (float)(se2_nlp_sum / (sd2_sum + 1e-6));
            if (self->ed_ratio_2k > 1.0f) self->ed_ratio_2k = 1.0f;
        }
        if (!self->earphone_flag) {
            if (self->ed_ratio_2k > 0.7f) near_state = 1;
        } else {
            if (self->ed_ratio_2k > 0.2f) near_state = 1;
        }

        /* NO.4: gain_bigthan090_count based near-end detection */
        {
            float ce_thr = 20.0f;
            if (self->earphone_flag) ce_thr = 2.0f;
            if (self->capture_energy > ce_thr) {
                float gain_count = 0.0f;
                for (k = 4; k <= 18; k++) {
                    if (self->sd2_512fft[k] > 4.0f * comfort_noise_spectrum[k]) {
                        if (suppression_gain[k] >= 0.9f) {
                            gain_count += 1.0f;
                        }
                    }
                }
                ne_thr = 8.0f;
                if (self->earphone_flag) ne_thr = 2.0f;
                if (gain_count >= 12.0f && self->gain_bigthan090_count_last >= 12.0f
                    && self->near_energy > ne_thr) {
                    if (self->double_talk_count < self->double_talk_count_max)
                        self->double_talk_count = self->double_talk_count_max;
                }
                self->gain_bigthan090_count_last = gain_count;
            }
        }
        /* Near energy fallback */
        ne_thr = 8.0f;
        if (self->earphone_flag) ne_thr = 6.0f;
        if (self->near_energy > ne_thr) {
            if (self->echo_state_count < 20) {
                if (self->double_talk_count < self->double_talk_count_max)
                    self->double_talk_count = self->double_talk_count_max;
            }
        }

        /* Final echo_state decision */
        if (self->double_talk_count > 0) {
            self->echo_state_count = 0;
        } else {
            self->echo_state_count++;
        }

        if (near_state) {
            self->echo_state = 0;
        } else if (self->double_talk_count > 0) {
            self->echo_state = 0;
        } else {
            self->echo_state = 1;
        }

        /* Earphone: suppress by ed_ratio_2k */
        if (self->earphone_flag) {
            if (self->near_exist_count_512fft > 0) self->near_exist_count_512fft--;
            if (self->near_energy > 30.0f) self->near_exist_count_512fft = 5;
            if (self->ed_ratio_2k < 0.05f && self->near_exist_count_512fft == 0) {
                self->echo_state = 1;
            }
        }
    }

    /* ================================================================
     * Step 5: ControlSuppress_512fft
     * Compute echo_sup_gainl based on echo_state and ed_ratio.
     * Optimized: echo_sup_dt compressed from per-bin array to scalar
     * (all bins were updated with the same value anyway).
     * Echo VAD uses sd2_512fft directly (sy2 == sd2 redundancy removed).
     * ================================================================ */
    {
        /* Initialize to 1 (pass-through) */
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            self->echo_sup_gainl[k] = 1.0f;
        }

        /* Linear echo VAD (uses sd2 directly, was identical to sy2) */
        {
            float avg = 0.0f;
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                avg += self->sd2_512fft[k] > 0.0f ? sqrtf(self->sd2_512fft[k]) : 0.0f;
            }
            avg /= (float)AEC3_FFT_LENGTH_LONG_BY2_PLUS1;
            if (avg / 100.0f >= (float)self->ExcludeNoiseFromEchoFlag) {
                self->echo_exist_count = 2;
            }
            if (self->echo_exist_count > 0) self->echo_exist_count--;
        }

        /* Compute smoothed ed_ratio for 2k and 8k */
        {
            double sd2_8k = 0.0, se2_nlp_8k = 0.0;
            double sd2_2k = 0.0, se2_nlp_2k = 0.0;
            float ed_ratio_8k_tmp, ed_ratio_2k_tmp;

            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                sd2_8k += self->sd2_512fft[k];
                se2_nlp_8k += (self->se2_nlp_512fft[k] < self->sd2_512fft[k])
                    ? self->se2_nlp_512fft[k] : self->sd2_512fft[k];
            }
            for (k = 0; k < 64; k++) {
                sd2_2k += self->sd2_512fft[k];
                se2_nlp_2k += (self->se2_nlp_512fft[k] < self->sd2_512fft[k])
                    ? self->se2_nlp_512fft[k] : self->sd2_512fft[k];
            }
            ed_ratio_8k_tmp = (float)(se2_nlp_8k / (sd2_8k + 1e-6));
            if (ed_ratio_8k_tmp > 1.0f) ed_ratio_8k_tmp = 1.0f;
            if (ed_ratio_8k_tmp < 0.0f) ed_ratio_8k_tmp = 0.0f;
            ed_ratio_2k_tmp = (float)(se2_nlp_2k / (sd2_2k + 1e-6));
            if (ed_ratio_2k_tmp > 1.0f) ed_ratio_2k_tmp = 1.0f;
            if (ed_ratio_2k_tmp < 0.0f) ed_ratio_2k_tmp = 0.0f;

            self->ed_ratio_2k_smooth = self->ed_ratio_2k_smooth * 0.5f + ed_ratio_2k_tmp * 0.5f;
            self->ed_ratio_8k_smooth = self->ed_ratio_8k_smooth * 0.5f + ed_ratio_8k_tmp * 0.5f;

            if (self->echo_state && self->aec_dtcontrol_enable) {
                /* Echo state: suppress */
                if (self->ExcludeNoiseFromEchoFlag > 0) {
                    if (self->echo_exist_count > 0) {
                        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++)
                            self->echo_sup_gainl[k] = 0.0f;
                    }
                } else {
                    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++)
                        self->echo_sup_gainl[k] = 0.0f;
                }
            } else {
                /* Double-talk: suppress by ed_ratio */
                if ((!self->earphone_flag && aec_level != 0) || self->voip_flag) {
                    float dt = self->echo_sup_dt_scalar;

                    /* Update scalar echo_sup_dt (was per-bin, all bins identical) */
                    if (ed_ratio_8k_tmp < self->ed_ratio_2k_threshold) {
                        dt = dt * 0.2f + ed_ratio_8k_tmp * 0.8f;
                    } else {
                        dt = dt * 0.9f + 0.1f;
                    }
                    if (dt > 1.0f) dt = 1.0f;
                    if (dt < 0.0f) dt = 0.0f;
                    self->echo_sup_dt_scalar = dt;

                    if (self->ed_ratio_8k_smooth < self->ed_ratio_2k_threshold ||
                        ed_ratio_8k_tmp < self->ed_ratio_2k_threshold) {
                        /* Apply to high band (k >= 65) */
                        for (k = 65; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                            self->echo_sup_gainl[k] *= dt;
                        }
                        /* Apply to low band (k < 65) if ed_ratio_2k is also low */
                        if (self->ed_ratio_2k_smooth < self->ed_ratio_2k_threshold) {
                            for (k = 0; k < 65; k++) {
                                self->echo_sup_gainl[k] *= dt;
                            }
                        } else if (aec_low_compute_mode) {
                            float dt_tmp = self->ed_ratio_2k_smooth;
                            float decrease = (dt_tmp - dt) / 64.0f;
                            for (k = 0; k < 65; k++) {
                                self->echo_sup_gainl[k] *= dt_tmp;
                                dt_tmp -= decrease;
                            }
                        }
                    }
                }
            }
        }
    }
}

const ControlOperation* DtController_GetOperations(const DtController* self) {
    return &self->control_operation;
}

int DtController_GetEchoState(const DtController* self) {
    return self->echo_state;
}

float DtController_AccelerateRate(const DtController* self) {
    return self->accelerate;
}

float DtController_GetXdAvg(const DtController* self) {
    (void)self;
    return 0.0f;
}

float DtController_GetEyCoBand(const DtController* self) {
    (void)self;
    return 0.0f;
}

const float* DtController_GetSupGain(const DtController* self) {
    (void)self;
    return NULL;
}

const float* DtController_GetSupGainl(const DtController* self) {
    return self->echo_sup_gainl;
}

float DtController_GetDoubleTalkProbability(const DtController* self) {
    return self->double_talk_probability;
}

void DtController_SetEarphoneFlag(DtController* self, int flag) {
    self->earphone_flag = flag;
}

void DtController_SetVoipFlag(DtController* self, int flag) {
    self->voip_flag = flag;
}

void DtController_SetAecDtcontrolEnable(DtController* self, int flag) {
    self->aec_dtcontrol_enable = flag;
}

void DtController_SetDoubleTalkCountMax(DtController* self, int max_count) {
    self->double_talk_count_max = max_count;
}

void DtController_SetEdRatio2kThreshold(DtController* self, float threshold) {
    self->ed_ratio_2k_threshold = threshold;
}

void DtController_SetExcludeNoiseFromEchoFlag(DtController* self, int flag) {
    self->ExcludeNoiseFromEchoFlag = flag;
}

int DtController_GetFilterDivergenceState(const DtController* self) {
    return self->filter_divergence_state;
}
