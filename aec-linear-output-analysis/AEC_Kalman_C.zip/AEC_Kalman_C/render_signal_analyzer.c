/*
 *  RenderSignalAnalyzer - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ render_signal_analyzer.cc
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#include "render_signal_analyzer.h"

#include <assert.h>
#include <math.h>
#include <string.h>

/* ================================================================
 * Constants
 * ================================================================ */
#define COUNTER_THRESHOLD       5
#define X2_ENERGY_THRESHOLD     44015068.0f

/* ================================================================
 * Internal helpers
 * ================================================================ */

/* Identify local bands with narrow characteristics */
static void IdentifySmallNarrowBandRegions(
    const RenderBuffer* render_buffer,
    int delay_partitions,
    int has_delay,
    int* narrow_band_counters)
{
    const float* X2;
    int k;

    if (!has_delay) {
        memset(narrow_band_counters, 0,
               sizeof(int) * (AEC3_FFT_LENGTH_BY2 - 1));
        return;
    }

    X2 = RenderBuffer_Spectrum(render_buffer, delay_partitions);
    if (!X2) {
        memset(narrow_band_counters, 0,
               sizeof(int) * (AEC3_FFT_LENGTH_BY2 - 1));
        return;
    }

    for (k = 1; k < AEC3_FFT_LENGTH_BY2; ++k) {
        float neighbor_max = X2[k - 1] > X2[k + 1] ? X2[k - 1] : X2[k + 1];
        if (X2[k] > 3.0f * neighbor_max) {
            narrow_band_counters[k - 1] += 1;
        } else {
            narrow_band_counters[k - 1] = 0;
        }
    }
}

/* Identify a single strong narrow-band spectral peak */
static void IdentifyStrongNarrowBandComponent(
    const RenderBuffer* render_buffer,
    int strong_peak_freeze_duration,
    int* narrow_peak_band,
    int* has_narrow_peak_band,
    int* narrow_peak_counter)
{
    const float* X2_latest;
    int peak_bin = 0;
    float peak_val;
    float non_peak_power = 0.0f;
    float max_abs = 0.0f;
    const float* x_band0;
    int k, i;

    X2_latest = RenderBuffer_Spectrum(render_buffer, 0);
    if (!X2_latest) return;

    /* Find spectral peak */
    peak_val = X2_latest[0];
    for (k = 1; k < AEC3_FFT_LENGTH_BY2_PLUS1; ++k) {
        if (X2_latest[k] > peak_val) {
            peak_val = X2_latest[k];
            peak_bin = k;
        }
    }

    /* Compute level around the peak */
    for (k = (peak_bin - 14 > 0 ? peak_bin - 14 : 0);
         k < peak_bin - 4; ++k) {
        if (X2_latest[k] > non_peak_power) {
            non_peak_power = X2_latest[k];
        }
    }
    for (k = peak_bin + 5;
         k < (peak_bin + 15 < AEC3_FFT_LENGTH_BY2_PLUS1
              ? peak_bin + 15 : AEC3_FFT_LENGTH_BY2_PLUS1);
         ++k) {
        if (X2_latest[k] > non_peak_power) {
            non_peak_power = X2_latest[k];
        }
    }

    /* Assess render signal strength from time-domain block */
    x_band0 = RenderBuffer_Block(render_buffer, 0, 0);
    for (i = 0; i < AEC3_BLOCK_SIZE; ++i) {
        float abs_val = (float)fabs(x_band0[i]);
        if (abs_val > max_abs) {
            max_abs = abs_val;
        }
    }

    /* Detect strong narrowband peak */
    if (peak_bin > 0 && max_abs > 100.0f &&
        X2_latest[peak_bin] > 100.0f * non_peak_power) {
        *narrow_peak_band = peak_bin;
        *has_narrow_peak_band = 1;
        *narrow_peak_counter = 0;
    } else {
        if (*has_narrow_peak_band) {
            ++(*narrow_peak_counter);
            if (*narrow_peak_counter > strong_peak_freeze_duration) {
                *has_narrow_peak_band = 0;
            }
        }
    }
}

/* Identify voice component based on spectrum vs noise */
static void IdentifyVoiceComponent(
    const RenderBuffer* render_buffer,
    int delay_partitions,
    const float* render_noise,
    int* voice_band_counter)
{
    const float* X2;
    int band_counter = 0;
    int i;

    X2 = RenderBuffer_Spectrum(render_buffer, delay_partitions);
    if (!X2) { *voice_band_counter = 0; return; }

    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; ++i) {
        if (X2[i] > 16.0f * render_noise[i] && X2[i] > 300.0f * 300.0f) {
            band_counter += 1;
        }
    }
    *voice_band_counter = band_counter;
}

/* Identify non-voice tone from 128-point spectrum */
static void IdentifyVoiceTone(
    const RenderBuffer* render_buffer,
    int delay_partitions,
    float* X2_long,
    int* is_unvoice,
    int* trigger_counter,
    int trigger_threshold,
    int* hold_counter,
    int hold_duration)
{
    const float* X2;
    float lowbandpower = 0.0f;
    float highbandpower = 0.0f;
    int i;

    /* Band boundaries for 128-point FFT (8kHz Nyquist) */
    const int kLowBand = (64 * 1000) / 8000;       /* 8 */
    const int kHighBand = (64 * 3000) / 8000;       /* 24 */
    const int kHighUpperBand = (64 * 5000) / 8000;  /* 40 */

    float oneByLowBands;
    float oneByHighBands;

    X2 = RenderBuffer_Spectrum(render_buffer, delay_partitions);
    if (!X2) return;

    /* Smooth spectrum */
    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; ++i) {
        X2_long[i] = 0.95f * X2_long[i] + 0.05f * X2[i];
    }

    /* Compute low-band average power */
    oneByLowBands = 1.0f / (float)(kLowBand - 2 + 1);
    for (i = 2; i < kLowBand; ++i) {
        lowbandpower += X2_long[i];
    }
    lowbandpower *= oneByLowBands;

    /* Compute high-band average power */
    oneByHighBands = 1.0f / (float)(kHighUpperBand - kHighBand + 1);
    for (i = kHighBand; i < kHighUpperBand; ++i) {
        highbandpower += X2_long[i];
    }
    highbandpower *= oneByHighBands;

    /* Tone detection logic */
    if (highbandpower > 1.25f * lowbandpower &&
        highbandpower > X2_ENERGY_THRESHOLD) {
        if (++(*trigger_counter) >= trigger_threshold) {
            *hold_counter = hold_duration;
            *trigger_counter = trigger_threshold;
        }
    } else {
        *trigger_counter = (*trigger_counter > 0) ? *trigger_counter - 1 : 0;
    }

    if (highbandpower < 0.8f * lowbandpower) {
        *hold_counter = 0;
    }

    *hold_counter = (*hold_counter > 0) ? *hold_counter - 1 : 0;
    *is_unvoice = (*hold_counter > 0);
}

/* Identify non-voice tone from 512-point spectrum */
static void IdentifyVoiceTone512fft(
    const float* X2,
    int* is_unvoice,
    int* trigger_counter,
    int trigger_threshold,
    int* hold_counter,
    int hold_duration)
{
    float lowbandpower = 0.0f;
    float highbandpower = 0.0f;
    int i;

    /* Band boundaries for 512-point FFT (8kHz Nyquist) */
    const int kLowBand = (4 * 64 * 1000) / 8000;       /* 32 */
    const int kHighBand = (4 * 64 * 3000) / 8000;       /* 96 */
    const int kHighUpperBand = (4 * 64 * 8000) / 8000;  /* 256 */

    float oneByLowBands = 1.0f / (float)(kLowBand - 2 + 1);
    float oneByHighBands = 1.0f / (float)(kHighUpperBand - kHighBand + 1);

    for (i = 2; i < kLowBand; ++i) {
        lowbandpower += X2[i];
    }
    lowbandpower *= oneByLowBands;

    for (i = kHighBand; i < kHighUpperBand; ++i) {
        highbandpower += X2[i];
    }
    highbandpower *= oneByHighBands;

    if (highbandpower > 1.25f * lowbandpower &&
        highbandpower > X2_ENERGY_THRESHOLD) {
        if (++(*trigger_counter) >= trigger_threshold) {
            *hold_counter = hold_duration;
            *trigger_counter = trigger_threshold;
        }
    } else {
        *trigger_counter = (*trigger_counter > 0) ? *trigger_counter - 1 : 0;
    }

    if (highbandpower < 0.8f * lowbandpower) {
        *hold_counter = 0;
    }

    *hold_counter = (*hold_counter > 0) ? *hold_counter - 1 : 0;
    *is_unvoice = (*hold_counter > 0);
}

/* ================================================================
 * Public API
 * ================================================================ */

void RenderSignalAnalyzer_Init(RenderSignalAnalyzer* self,
                               const Aec3Config* config)
{
    assert(self != NULL);
    assert(config != NULL);

    self->strong_peak_freeze_duration = config->filter_main_length_blocks;

    memset(self->narrow_band_counters, 0, sizeof(self->narrow_band_counters));
    self->narrow_peak_band = -1;
    self->has_narrow_peak_band = 0;
    self->narrow_peak_counter = 0;
    self->voice_band_counter = 0;

    memset(self->X2_long, 0, sizeof(self->X2_long));

    self->is_unvoice = 0;
    self->trigger_counter = 0;
    self->trigger_threshold = 2;
    self->hold_counter = 0;
    self->hold_duration = 50;

    self->is_unvoice_512fft = 0;
    self->trigger_counter_512fft = 0;
    self->trigger_threshold_512fft = 2;
    self->hold_counter_512fft = 0;
    self->hold_duration_512fft = 50;
}

void RenderSignalAnalyzer_Update(RenderSignalAnalyzer* self,
                                 const RenderBuffer* render_buffer,
                                 int delay_partitions,
                                 int has_delay,
                                 const float* render_noise)
{
    assert(self != NULL);

    /* Identify narrow-band regions */
    IdentifySmallNarrowBandRegions(render_buffer, delay_partitions,
                                   has_delay, self->narrow_band_counters);

    /* Identify strong narrow-band peak */
    IdentifyStrongNarrowBandComponent(render_buffer,
                                      self->strong_peak_freeze_duration,
                                      &self->narrow_peak_band,
                                      &self->has_narrow_peak_band,
                                      &self->narrow_peak_counter);

    /* Identify voice component */
    if (has_delay) {
        IdentifyVoiceComponent(render_buffer, delay_partitions,
                               render_noise, &self->voice_band_counter);
    }

    /* Identify tone (128-point) */
    if (has_delay) {
        IdentifyVoiceTone(render_buffer, delay_partitions,
                          self->X2_long,
                          &self->is_unvoice,
                          &self->trigger_counter,
                          self->trigger_threshold,
                          &self->hold_counter,
                          self->hold_duration);
    }
}

void RenderSignalAnalyzer_Update512fft(RenderSignalAnalyzer* self,
                                       const float* X2)
{
    assert(self != NULL);

    IdentifyVoiceTone512fft(X2,
                            &self->is_unvoice_512fft,
                            &self->trigger_counter_512fft,
                            self->trigger_threshold_512fft,
                            &self->hold_counter_512fft,
                            self->hold_duration_512fft);
}

int RenderSignalAnalyzer_PoorSignalExcitation(const RenderSignalAnalyzer* self)
{
    int i;
    assert(self != NULL);

    for (i = 0; i < AEC3_FFT_LENGTH_BY2 - 1; ++i) {
        if (self->narrow_band_counters[i] > 10) {
            return 1;
        }
    }
    return 0;
}

int RenderSignalAnalyzer_VoiceSignal(const RenderSignalAnalyzer* self)
{
    assert(self != NULL);
    return (self->voice_band_counter > 20);
}

int RenderSignalAnalyzer_IsUnVoiceSignal(const RenderSignalAnalyzer* self)
{
    assert(self != NULL);
    return self->is_unvoice;
}

int RenderSignalAnalyzer_IsUnVoiceSignal512fft(const RenderSignalAnalyzer* self)
{
    assert(self != NULL);
    return self->is_unvoice_512fft;
}

void RenderSignalAnalyzer_MaskRegionsAroundNarrowBands(
    const RenderSignalAnalyzer* self, float* v)
{
    int k;
    assert(self != NULL);
    assert(v != NULL);

    /* Zero v around narrow-band signal regions */
    if (self->narrow_band_counters[0] > COUNTER_THRESHOLD) {
        v[1] = v[0] = 0.0f;
    }

    for (k = 2; k < AEC3_FFT_LENGTH_BY2 - 1; ++k) {
        if (self->narrow_band_counters[k - 1] > COUNTER_THRESHOLD) {
            v[k - 2] = 0.0f;
            v[k - 1] = 0.0f;
            v[k]     = 0.0f;
            v[k + 1] = 0.0f;
            v[k + 2] = 0.0f;
        }
    }

    if (self->narrow_band_counters[AEC3_FFT_LENGTH_BY2 - 2] > COUNTER_THRESHOLD) {
        v[AEC3_FFT_LENGTH_BY2] = v[AEC3_FFT_LENGTH_BY2 - 1] = 0.0f;
    }
}

int RenderSignalAnalyzer_NarrowPeakBand(const RenderSignalAnalyzer* self,
                                        int* out_band)
{
    assert(self != NULL);
    if (self->has_narrow_peak_band && out_band != NULL) {
        *out_band = self->narrow_peak_band;
    }
    return self->has_narrow_peak_band;
}
