/*
 *  Echo Path Delay Estimator - Pure C Version
 *
 *  Coordinates MatchedFilter and MatchedFilterLagAggregator to produce
 *  echo path delay estimates. Also includes binary spectral correlation
 *  delay estimation and GCC-based fine delay estimation.
 *
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef ECHO_PATH_DELAY_ESTIMATOR_H_
#define ECHO_PATH_DELAY_ESTIMATOR_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "aec3_fft.h"
#include "decimator.h"
#include "fft_data.h"
#include "matched_filter.h"
#include "matched_filter_lag_aggregator.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Clockdrift detection levels */
#define CLOCKDRIFT_NONE         0
#define CLOCKDRIFT_PROBABLE     1
#define CLOCKDRIFT_VERIFIED     2

/* Binary delay estimator constants */
#define BINARY_HISTORY_SIZE     625
#define BINARY_BAND_LOW         16
#define BINARY_BAND_HIGH        40

/* GCC delay estimator removed — not used in current pipeline */

/* ================================================================
 * ClockdriftDetector - Detects clock drift from delay history
 * ================================================================ */
typedef struct {
    int     delay_history[3];
    int     level;              /* CLOCKDRIFT_NONE/PROBABLE/VERIFIED */
    int     stability_counter;
} ClockdriftDetector;

void ClockdriftDetector_Init(ClockdriftDetector* self);
void ClockdriftDetector_Update(ClockdriftDetector* self, int delay_estimate);

/* ================================================================
 * BinaryDelayEstimator - Spectral correlation delay estimator
 *
 * Memory optimization: farend_history_fft and xd_spec_cor are now
 * dynamically sized based on render_buffer_size instead of fixed
 * BINARY_HISTORY_SIZE (625). Pointers reference memory within the
 * EchoPathDelayEstimator's trailing buffer.
 * ================================================================ */
typedef struct {
    float*  farend_history_fft;     /* [history_size * AEC3_FFT_LENGTH_BY2_PLUS1] */
    int     continue_cnt;
    float   farend_longtimefft[AEC3_FFT_LENGTH_BY2_PLUS1];
    int     best_pos;
    int     history_size;
    float   probability;
    float   last_valid;
    float   nearend_fft[AEC3_FFT_LENGTH_BY2_PLUS1];
    float   nearend_longtime_fft[AEC3_FFT_LENGTH_BY2_PLUS1];
    float*  xd_spec_cor;            /* [history_size] */
} BinaryDelayEstimator;

/* ================================================================
 * EchoPathDelayEstimator - Main delay estimation coordinator
 * ================================================================ */
typedef struct {
    int                         down_sampling_factor;
    int                         sub_block_size;
    Decimator                   capture_decimator;
    MatchedFilter               matched_filter;
    MatchedFilterLagAggregator  lag_aggregator;

    /* Old aggregated lag for consistency tracking */
    DelayEstimate               old_aggregated_lag;
    int                         has_old_aggregated_lag;
    int                         consistent_estimate_counter;

    ClockdriftDetector          clockdrift_detector;

    /* Binary delay estimator */
    BinaryDelayEstimator        binary_estimator;

    /* FFT for binary estimator */
    Aec3Fft                     fft;
    float                       y_old[AEC3_FFT_LENGTH_BY2];
    float                       x_old[AEC3_FFT_LENGTH_BY2];

    /* Histogram for GCC fine delay */
    int                         histogram0[150];
    int                         histogram_data0[50];
    int                         histogram_data_index0;

    int                         aec_H_usage;
} EchoPathDelayEstimator;

/**
 * Compute the memory size needed for BinaryDelayEstimator dynamic arrays.
 *
 * @param render_buffer_size    Ring buffer slot count (= history_size)
 * @return                      Required bytes for farend_history_fft + xd_spec_cor
 */
int BinaryDelayEstimator_GetDynMemSize(int render_buffer_size);

/**
 * Initialize the echo path delay estimator.
 *
 * @param self              Pointer to estimator
 * @param config            AEC3 configuration
 * @param render_buffer_size Ring buffer slot count (controls binary estimator history)
 * @param binary_dyn_mem    Pre-allocated memory for binary estimator dynamic arrays
 */
void EchoPathDelayEstimator_Init(EchoPathDelayEstimator* self,
                                 const Aec3Config* config,
                                 int render_buffer_size,
                                 float* binary_dyn_mem);

/**
 * Reset the estimator.
 *
 * @param self                      Pointer to estimator
 * @param reset_delay_confidence    If true, fully reset delay confidence
 */
void EchoPathDelayEstimator_Reset(EchoPathDelayEstimator* self,
                                  int reset_delay_confidence);

/**
 * Estimate the echo path delay.
 *
 * @param self                          Pointer to estimator
 * @param render_buffer                 Downsampled render buffer
 * @param capture                       Capture block (AEC3_BLOCK_SIZE samples)
 * @param capture_len                   Length of capture
 * @param earphone_flag                 Earphone mode
 * @param voip_mode_enable              VoIP mode
 * @param delay_default                 Default delay
 * @param CastScreen                    Screen casting mode
 * @param matched_filter_enable_flag    Enable matched filter
 * @param aec_low_compute_mode          Low compute mode
 * @param out_delay                     Output delay estimate
 * @return                              1 if valid delay produced, 0 otherwise
 */
int EchoPathDelayEstimator_EstimateDelay(
    EchoPathDelayEstimator* self,
    const DownsampledRenderBuffer* render_buffer,
    const float* capture, int capture_len,
    int earphone_flag,
    int voip_mode_enable,
    int delay_default,
    int CastScreen,
    int matched_filter_enable_flag,
    int aec_low_compute_mode,
    DelayEstimate* out_delay);

/**
 * Set aec_H_usage parameter.
 */
void EchoPathDelayEstimator_SetAecHUsage(EchoPathDelayEstimator* self,
                                         int size);

/**
 * Buffer render spectrum for binary delay estimator.
 */
void EchoPathDelayEstimator_BufferRenderSpec(EchoPathDelayEstimator* self,
                                             const float* far_spectrum,
                                             int spectrum_len);

/**
 * Buffer render block for binary/GCC delay estimator.
 */
void EchoPathDelayEstimator_BufferRenderBlock(EchoPathDelayEstimator* self,
                                              const float* far_block,
                                              int block_len);

/**
 * Get the current clockdrift level.
 */
int EchoPathDelayEstimator_GetClockdriftLevel(const EchoPathDelayEstimator* self);

#ifdef __cplusplus
}
#endif

#endif /* ECHO_PATH_DELAY_ESTIMATOR_H_ */
