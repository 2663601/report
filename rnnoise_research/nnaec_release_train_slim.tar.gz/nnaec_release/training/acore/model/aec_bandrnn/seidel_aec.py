#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Seidel 式 AEC 后置滤波器 == NSNet2 骨架 (FC + GRU, 无卷积)

严格对照开源 NSNet2 官方实现:
  AEC/_ref_opensource/NSNet2/model/nsnet2.py
原版 NSNet2 结构 (单路 freq_bins 输入 -> freq_bins mask):
  fc_input(freq->400,ReLU) -> GRU(400->400, 2层, dropout0.2)
  -> dense0(400->600,ReLU) -> dense1(600->600,ReLU) -> dense2(600->freq,Sigmoid)

Seidel (arXiv:2404.11621) 的后置滤波器自述为 "NSNet2-like architecture
(FC + GRU layers)", 并把输入从 DFT 换成 Bark/ERB band 的三路功率谱
(|E|^2,|Y|^2,|X|^2)。本文件 = NSNet2 骨架, 仅做两处对齐 Seidel 的改动:
  1. 输入维度: freq_bins -> nbands*num_inputs   (三路 band 特征拼接)
  2. 输出维度: freq_bins -> nbands              (band mask)
其余 (400/600 隐藏维、2 层 GRU、ReLU/Sigmoid、dropout0.2) 严格照搬 NSNet2。
"""
import torch
import torch.nn as nn


class SeidelAEC(nn.Module):
    def __init__(self,
                 nbands=32,
                 num_inputs=3,
                 fc_input_dim=400,
                 gru_hidden=400,
                 n_gru=2,
                 gru_dropout=0.2,
                 dense_hidden=600,
                 **kwargs):
        super().__init__()
        self.nbands = nbands
        self.num_inputs = num_inputs
        self.n_gru = n_gru
        self.gru_hidden = gru_hidden

        in_dim = nbands * num_inputs          # Seidel: 三路 band 拼接
        out_dim = nbands                      # band mask

        # 严格对照 NSNet2:
        self.fc_input = nn.Linear(in_dim, fc_input_dim)
        self.gru = nn.GRU(
            batch_first=True,
            input_size=fc_input_dim,
            hidden_size=gru_hidden,
            num_layers=n_gru,
            dropout=gru_dropout,
        )
        self.dense0 = nn.Linear(gru_hidden, dense_hidden)
        self.dense1 = nn.Linear(dense_hidden, dense_hidden)
        self.dense2 = nn.Linear(dense_hidden, out_dim)

    def forward(self, feat, hidden=None):
        """
        feat: [B, T, nbands*num_inputs]  (三路 log band power 拼接)
        hidden: GRU 初始态 (流式用, 训练传 None)
        return: band_gain [B,T,nbands] (0~1), hidden
        """
        x = torch.relu(self.fc_input(feat))
        x, hidden = self.gru(x, hidden)
        x = torch.relu(self.dense0(x))
        x = torch.relu(self.dense1(x))
        band_gain = torch.sigmoid(self.dense2(x))
        return band_gain, hidden


if __name__ == "__main__":
    nbands = 32
    model = SeidelAEC(nbands=nbands, num_inputs=3)
    nparam = sum(p.numel() for p in model.parameters())
    print(f"SeidelAEC(NSNet2 backbone) params = {nparam} ({nparam/1e3:.1f}K)")
    feat = torch.randn(2, 50, nbands * 3)
    g, h = model(feat)
    print("band_gain:", g.shape, "range", g.min().item(), g.max().item())
