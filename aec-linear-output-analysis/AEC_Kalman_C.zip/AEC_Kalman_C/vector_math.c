/*
 *  Vector Math Utilities - Pure C Version
 *
 *  Common vector operations for AEC3 signal processing.
 *  All functions operate on float arrays with explicit length parameters.
 *  No STL or C++ dependencies.
 */

#include "vector_math.h"
#include <string.h>

void VecMath_Add(const float* a, const float* b, float* out, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        out[i] = a[i] + b[i];
    }
}

void VecMath_Sub(const float* a, const float* b, float* out, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        out[i] = a[i] - b[i];
    }
}

void VecMath_Mul(const float* a, const float* b, float* out, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        out[i] = a[i] * b[i];
    }
}

void VecMath_Scale(const float* a, float scale, float* out, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        out[i] = a[i] * scale;
    }
}

void VecMath_ScaleInPlace(float* a, float scale, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        a[i] *= scale;
    }
}

float VecMath_DotProduct(const float* a, const float* b, int len) {
    float sum = 0.0f;
    int i;
    for (i = 0; i < len; ++i) {
        sum += a[i] * b[i];
    }
    return sum;
}

float VecMath_Energy(const float* a, int len) {
    float sum = 0.0f;
    int i;
    for (i = 0; i < len; ++i) {
        sum += a[i] * a[i];
    }
    return sum;
}

void VecMath_Accumulate(float* dst, const float* src, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        dst[i] += src[i];
    }
}

void VecMath_Clear(float* a, int len) {
    memset(a, 0, (size_t)len * sizeof(float));
}

void VecMath_Copy(float* dst, const float* src, int len) {
    memcpy(dst, src, (size_t)len * sizeof(float));
}

float VecMath_Max(const float* a, int len) {
    float max_val;
    int i;
    if (len <= 0) {
        return 0.0f;
    }
    max_val = a[0];
    for (i = 1; i < len; ++i) {
        if (a[i] > max_val) {
            max_val = a[i];
        }
    }
    return max_val;
}

float VecMath_Min(const float* a, int len) {
    float min_val;
    int i;
    if (len <= 0) {
        return 0.0f;
    }
    min_val = a[0];
    for (i = 1; i < len; ++i) {
        if (a[i] < min_val) {
            min_val = a[i];
        }
    }
    return min_val;
}

void VecMath_Clamp(float* a, float min_val, float max_val, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        if (a[i] < min_val) {
            a[i] = min_val;
        } else if (a[i] > max_val) {
            a[i] = max_val;
        }
    }
}
