/*
 *  ComfortNoiseGenerator - Pure C Version
 *
 *  Generates comfort noise to fill in suppressed echo regions.
 *  Ported from WebRTC AEC3 C++ ComfortNoiseGenerator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point path retained.
 *  C99 compatible, no C++ keywords.
 */

#ifndef COMFORT_NOISE_GENERATOR_H_
#define COMFORT_NOISE_GENERATOR_H_

#include "aec3_common.h"
#include "fft_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declaration */
struct AecState_;

/* ================================================================
 * ComfortNoiseGenerator
 * ================================================================ */
typedef struct {
    unsigned int    seed;

    /* 512-point noise estimation */
    float   N2_initial_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    int     N2_initial_long_valid;
    float   Y2_smoothed_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   N2_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   Y2min_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float   Y2tmp_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    int     N2_counter;
    int     min_count;
} ComfortNoiseGenerator;

/**
 * Initialize the comfort noise generator.
 */
void CNG_Init(ComfortNoiseGenerator* self);

/**
 * Compute comfort noise (512-point).
 */
void CNG_Compute512(ComfortNoiseGenerator* self,
                    const struct AecState_* aec_state,
                    const float* capture_spectrum,
                    FftDataPfdkf* lower_band_noise,
                    FftDataPfdkf* upper_band_noise,
                    int cng_level,
                    float near_activity,
                    int music_flag);

/**
 * Get the current noise spectrum estimate (512-point).
 */
const float* CNG_NoiseSpectrumLong(const ComfortNoiseGenerator* self);

#ifdef __cplusplus
}
#endif

#endif /* COMFORT_NOISE_GENERATOR_H_ */
