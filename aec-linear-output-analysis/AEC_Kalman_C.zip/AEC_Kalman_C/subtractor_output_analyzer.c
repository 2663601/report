/*
 *  SubtractorOutputAnalyzer - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ SubtractorOutputAnalyzer class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "subtractor_output_analyzer.h"

static const float kConvergenceThreshold = 50.0f * 50.0f * AEC3_BLOCK_SIZE;

void SubtractorOutputAnalyzer_Init(SubtractorOutputAnalyzer* self) {
    self->strict_divergence_check = 1;  /* enabled by default */
    self->shadow_filter_converged = 0;
    self->main_filter_converged = 0;
    self->filter_diverged = 0;
    self->shadow_filter_diverged = 0;
    self->main_filter_diverged = 0;
}

void SubtractorOutputAnalyzer_Update(SubtractorOutputAnalyzer* self,
                                     const SubtractorOutput* output) {
    float y2 = output->y2;
    float e2_main = output->e2_main;
    float e2_shadow = output->e2_shadow;
    float min_e2;

    self->main_filter_converged =
        (e2_main < 0.5f * y2 && y2 > kConvergenceThreshold);
    self->shadow_filter_converged =
        (e2_shadow < 0.05f * y2 && y2 > kConvergenceThreshold);

    min_e2 = self->strict_divergence_check ?
             (e2_main < e2_shadow ? e2_main : e2_shadow) : e2_main;
    self->filter_diverged =
        (min_e2 > 1.5f * y2 && y2 > 30.0f * 30.0f * AEC3_BLOCK_SIZE);

    self->main_filter_diverged =
        ((self->main_filter_diverged ? 1.05f : 1.0f) * e2_main > y2);
    self->shadow_filter_diverged =
        ((self->shadow_filter_diverged ? 1.05f : 1.0f) * e2_shadow > y2);
}

int SubtractorOutputAnalyzer_ConvergedFilter(const SubtractorOutputAnalyzer* self) {
    return self->main_filter_converged || self->shadow_filter_converged;
}

int SubtractorOutputAnalyzer_DivergedFilter(const SubtractorOutputAnalyzer* self) {
    return self->filter_diverged;
}

int SubtractorOutputAnalyzer_MainDivergedFilter(const SubtractorOutputAnalyzer* self) {
    return self->main_filter_diverged;
}

int SubtractorOutputAnalyzer_ShadowDivergedFilter(const SubtractorOutputAnalyzer* self) {
    return self->shadow_filter_diverged;
}

void SubtractorOutputAnalyzer_HandleEchoPathChange(SubtractorOutputAnalyzer* self) {
    self->shadow_filter_converged = 0;
    self->main_filter_converged = 0;
    self->filter_diverged = 0;
    self->shadow_filter_diverged = 0;
    self->main_filter_diverged = 0;
}
