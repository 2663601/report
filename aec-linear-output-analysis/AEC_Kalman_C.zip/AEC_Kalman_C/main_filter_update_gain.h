/*
 *  MainFilterUpdateGain - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ MainFilterUpdateGain class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Computes the Kalman gain for the main adaptive filter.
 *  Supports single-gain (NLMS-like), full Kalman, and PFDKF modes.
 *  C99 compatible, no C++ keywords.
 */

#ifndef MAIN_FILTER_UPDATE_GAIN_H_
#define MAIN_FILTER_UPDATE_GAIN_H_

#include "aec3_common.h"
#include "fft_data.h"
#include "subtractor_output.h"
#include "render_buffer.h"
#include "adaptive_fir_filter.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * MainFilterConfig - Main filter gain configuration
 *
 * Extracted from Aec3Config main filter fields.
 * ================================================================ */
typedef struct {
    int     length_blocks;
    float   leakage_converged;
    float   leakage_diverged;
    float   error_floor;
    float   error_ceil;
    float   noise_gate;
} MainFilterConfig;

/* ================================================================
 * SubtractorOutputFrequency - PFDKF frequency-domain output
 *
 * Used by ComputePfdkf for PFDKF gain computation.
 * ================================================================ */
typedef struct {
    /* Existing fields */
    FftDataPfdkf E_out;
    float   E2_out[AEC3_LF_FFT_LENGTH_BY2_PLUS1];

    /* Frequency-domain signals */
    FftDataPfdkf E;
    FftDataPfdkf E_speed;
    FftDataPfdkf S;
    FftDataPfdkf S_speed;
    FftDataPfdkf Y;
    FftDataPfdkf S_out;
    FftDataPfdkf S_out_tmp;

    /* Power spectra */
    float   E2[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float   E2_speed[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float   Y2[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float   S2_out[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float   S2_out_tmp[AEC3_LF_FFT_LENGTH_BY2_PLUS1];

    /* Accumulators */
    float   E2_accum;
    float   Y2_accum;
} SubtractorOutputFrequency;

/* ================================================================
 * MainFilterUpdateGain
 * ================================================================ */
typedef struct {
    int             config_change_duration_blocks;
    float           one_by_config_change_duration_blocks;

    MainFilterConfig current_config;
    MainFilterConfig target_config;
    MainFilterConfig old_target_config;

    float           alpha_e;

    int             poor_excitation_counter;
    int             call_counter;
    int             config_change_counter;
    int             aec_H_usage;

    /* PFDKF state (externally allocated, flat layout [partition * 257 + bin]) */
    float*          H_error_pfdkf;
    int             max_pfdkf_partitions;
    float           E2_smooth_pfdkf[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           E2_smooth_pfdkf_speed[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           E2_smooth_pfdkf_speed_suppress[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           mu_pf[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           mu_speed[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           mu_speed_suppress[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           conv_ee[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           conv_ee_speed[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           conv_ee_speed_suppress[AEC3_LF_FFT_LENGTH_BY2_PLUS1];
    float           suppress_gain[AEC3_LF_FFT_LENGTH_BY2_PLUS1];

    float           suppress_floor_coeff;   /* multiplicative factor for suppress_floor_k (0~1) */

    int             pfdkf_partitions_count;
} MainFilterUpdateGain;

/* ================================================================
 * Initialization
 *
 * config:                  main filter configuration
 * config_change_duration:  blocks for smooth config transitions
 * config_after_initial:    config used after initial convergence
 * ================================================================ */
void MainFilterUpdateGain_Init(MainFilterUpdateGain* self,
                               const MainFilterConfig* config,
                               int config_change_duration,
                               const MainFilterConfig* config_after_initial,
                               float* H_error_pfdkf_mem,
                               int aec_H_usage);

/* ================================================================
 * Handle echo path change: reset H_error and counters
 * ================================================================ */
void MainFilterUpdateGain_HandleEchoPathChange(
    MainFilterUpdateGain* self,
    const EchoPathVariability* echo_path_variability);

/* ================================================================
 * Set config with optional smooth transition
 * ================================================================ */
void MainFilterUpdateGain_SetConfig(MainFilterUpdateGain* self,
                                    const MainFilterConfig* config,
                                    int immediate_effect);

/* ================================================================
 * Set PFDKF H usage count
 * ================================================================ */
void MainFilterUpdateGain_SetAecHUsage(MainFilterUpdateGain* self, int size);

/* ================================================================
 * ComputePfdkf: PFDKF Kalman gain computation
 *
 * Computes per-partition Kalman gains for PFDKF adaptive filter
 * using render power spectrum and error signal in relf/imlf domain.
 *
 * render_buffer:       render buffer providing PFDKF power spectra
 * output:              PFDKF frequency-domain subtractor output (E_out modified in-place)
 * filter:              adaptive FIR filter (provides H2_pf_update, pfdkf_partitions_count)
 * G_pfdkf:             output per-partition gain for H_pf (relf/imlf fields)
 * G_pfdkf_speed:       output per-partition gain for H_pf_speed (relf/imlf fields)
 * E2_fix:              nearend energy fix array [AEC3_LF_FFT_LENGTH_BY2_PLUS1]
 * E2_fix_suppress:     nearend energy fix suppress array [AEC3_LF_FFT_LENGTH_BY2_PLUS1]
 * earphone_flag:       earphone mode flag (disables suppress_gain application to E_out)
 * ================================================================ */
void MainFilterUpdateGain_ComputePfdkf(
    MainFilterUpdateGain* self,
    const RenderBuffer* render_buffer,
    SubtractorOutputFrequency* output,
    const AdaptiveFirFilter* filter,
    FftDataPfdkf* G_pfdkf,
    FftDataPfdkf* G_pfdkf_speed,
    const float* E2_fix,
    const float* E2_fix_suppress,
    int earphone_flag);

#ifdef __cplusplus
}
#endif

#endif /* MAIN_FILTER_UPDATE_GAIN_H_ */
