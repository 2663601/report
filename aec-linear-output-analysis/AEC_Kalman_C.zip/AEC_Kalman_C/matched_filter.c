/*
 *  Matched Filter - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ matched_filter.cc
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Implements NLMS-based matched filtering for time-domain delay estimation.
 *  The generic (non-SIMD) MatchedFilterCore is ported; NEON/SSE2 variants
 *  can be added later as platform-specific optimizations.
 */

#include "matched_filter.h"

#include <math.h>
#include <string.h>
#include <assert.h>

/* ================================================================
 * MatchedFilterCore - Generic C implementation
 *
 * For each sample in y (capture sub-block):
 *   1. Compute h * x (filter output) and x * x (excitation energy)
 *   2. Compute error e = y[i] - s
 *   3. If excitation sufficient and no saturation, update h via NLMS
 *   4. Advance x_start_index backwards through circular buffer
 * ================================================================ */
static void MatchedFilterCore(int x_start_index,
                              float x2_sum_threshold,
                              float smoothing,
                              const float* x, int x_size,
                              const float* y, int y_size,
                              float* h, int h_size,
                              int* filters_updated,
                              float* error_sum)
{
    int i, k;

    for (i = 0; i < y_size; ++i) {
        float x2_sum = 0.0f;
        float s = 0.0f;
        int x_index = x_start_index;

        /* Compute filter output s = h * x and excitation x2_sum = x * x */
        for (k = 0; k < h_size; ++k) {
            x2_sum += x[x_index] * x[x_index];
            s += h[k] * x[x_index];
            x_index = (x_index < x_size - 1) ? x_index + 1 : 0;
        }

        /* Compute matched filter error */
        {
            float e = y[i] - s;
            int saturation = (y[i] >= 32000.0f || y[i] <= -32000.0f);
            (*error_sum) += e * e;

            /* Update filter in NLMS manner */
            if (x2_sum > x2_sum_threshold && !saturation) {
                float alpha = smoothing * e / x2_sum;
                x_index = x_start_index;
                for (k = 0; k < h_size; ++k) {
                    h[k] += alpha * x[x_index];
                    x_index = (x_index < x_size - 1) ? x_index + 1 : 0;
                }
                *filters_updated = 1;
            }
        }

        x_start_index = (x_start_index > 0) ? x_start_index - 1 : x_size - 1;
    }
}

/* ================================================================
 * Public API
 * ================================================================ */

void MatchedFilter_Init(MatchedFilter* self,
                        int sub_block_size,
                        int window_size_sub_blocks,
                        int num_filters,
                        int alignment_shift_sub_blocks,
                        float excitation_limit,
                        float smoothing,
                        float matching_filter_threshold)
{
    int n;

    assert(self != NULL);
    assert(num_filters > 0 && num_filters <= AEC3_MAX_MATCHED_FILTERS);
    assert(window_size_sub_blocks > 0);
    assert((AEC3_BLOCK_SIZE % sub_block_size) == 0);
    assert((sub_block_size % 4) == 0);

    self->sub_block_size = sub_block_size;
    self->filter_intra_lag_shift = alignment_shift_sub_blocks * sub_block_size;
    self->num_filters = num_filters;
    self->window_size = window_size_sub_blocks * sub_block_size;
    self->excitation_limit = excitation_limit;
    self->smoothing = smoothing;
    self->matching_filter_threshold = matching_filter_threshold;

    /* Ensure window_size fits in our static array */
    assert(self->window_size <= AEC3_MATCHED_FILTER_WINDOW_SIZE);

    /* Zero all filters and lag estimates */
    memset(self->filters, 0, sizeof(self->filters));
    memset(self->filters_offsets, 0, sizeof(self->filters_offsets));

    for (n = 0; n < AEC3_MAX_MATCHED_FILTERS; ++n) {
        self->lag_estimates[n].accuracy = 0.0f;
        self->lag_estimates[n].reliable = 0;
        self->lag_estimates[n].lag = 0;
        self->lag_estimates[n].updated = 0;
    }
}

void MatchedFilter_Reset(MatchedFilter* self)
{
    int n;
    assert(self != NULL);

    memset(self->filters, 0, sizeof(self->filters));

    for (n = 0; n < self->num_filters; ++n) {
        self->lag_estimates[n].accuracy = 0.0f;
        self->lag_estimates[n].reliable = 0;
        self->lag_estimates[n].lag = 0;
        self->lag_estimates[n].updated = 0;
    }
}

int MatchedFilter_GetMaxFilterLag(const MatchedFilter* self)
{
    assert(self != NULL);
    return self->num_filters * self->filter_intra_lag_shift + self->window_size;
}

void MatchedFilter_Update(MatchedFilter* self,
                          const DownsampledRenderBuffer* render_buffer,
                          const float* capture, int capture_len,
                          int delay_default)
{
    int n, i;
    int alignment_shift;
    float x2_sum_threshold;

    assert(self != NULL);
    assert(render_buffer != NULL);
    assert(capture != NULL);
    assert(capture_len == self->sub_block_size);

    x2_sum_threshold = (float)self->window_size *
                       self->excitation_limit * self->excitation_limit;

    alignment_shift = 0;

    for (n = 0; n < self->num_filters; ++n) {
        float error_sum = 0.0f;
        int filters_updated = 0;
        int x_start_index;
        float error_sum_anchor;
        int lag_estimate;
        float max_abs_value;

        /* Compute starting index in the circular render buffer */
        x_start_index = (render_buffer->read + delay_default * 4 +
                         alignment_shift + self->sub_block_size - 1) %
                        render_buffer->size;

        /* Run the matched filter core */
        MatchedFilterCore(x_start_index,
                          x2_sum_threshold,
                          self->smoothing,
                          render_buffer->buffer, render_buffer->size,
                          capture, capture_len,
                          self->filters[n], self->window_size,
                          &filters_updated,
                          &error_sum);

        /* Compute anchor: sum of y^2 (capture energy) */
        error_sum_anchor = 0.0f;
        for (i = 0; i < capture_len; ++i) {
            error_sum_anchor += capture[i] * capture[i];
        }

        /* Find the peak of the matched filter (lag estimate) */
        lag_estimate = 0;
        max_abs_value = (float)fabs(self->filters[n][0]);
        for (i = 1; i < self->window_size; ++i) {
            float abs_val = (float)fabs(self->filters[n][i]);
            if (abs_val > max_abs_value) {
                max_abs_value = abs_val;
                lag_estimate = i;
            }
        }

        /* Update lag estimate for this filter */
        self->lag_estimates[n].accuracy = error_sum_anchor - error_sum;
        self->lag_estimates[n].reliable =
            (lag_estimate > 2 &&
             lag_estimate < (self->window_size - 10) &&
             error_sum < self->matching_filter_threshold * error_sum_anchor);
        self->lag_estimates[n].lag = lag_estimate + alignment_shift;
        self->lag_estimates[n].updated = filters_updated;

        alignment_shift += self->filter_intra_lag_shift;
    }
}
