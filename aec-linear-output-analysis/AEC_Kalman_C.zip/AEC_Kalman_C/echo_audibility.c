/*
 *  EchoAudibility - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ EchoAudibility class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "echo_audibility.h"
#include <string.h>
#include <math.h>

static void StationarityEstimator_Init(StationarityEstimator* self) {
    int i;
    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; i++) {
        self->noise_spectrum[i] = 0.0f;
        self->hangovers[i] = 0;
        self->stationarity_flags[i] = 0;
    }
    self->noise_block_counter = 0;
}

static void StationarityEstimator_UpdateNoiseEstimator(
    StationarityEstimator* self, const float* spectrum) {
    int k;
    float alpha = 0.9f;
    self->noise_block_counter++;
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        if (self->noise_block_counter < 10) {
            self->noise_spectrum[k] += (1.0f / 10.0f) *
                (spectrum[k] - self->noise_spectrum[k]);
        } else {
            if (spectrum[k] < self->noise_spectrum[k]) {
                self->noise_spectrum[k] = spectrum[k];
            } else {
                self->noise_spectrum[k] =
                    alpha * self->noise_spectrum[k] +
                    (1.0f - alpha) * spectrum[k];
            }
        }
    }
}

static void StationarityEstimator_UpdateFlags(
    StationarityEstimator* self,
    const float* spectrum,
    const float* reverb_spectrum,
    int idx_at_delay,
    int num_lookahead) {
    int k;
    (void)idx_at_delay;
    (void)num_lookahead;
    (void)reverb_spectrum;

    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        float noise = self->noise_spectrum[k];
        if (noise > 0.0f && spectrum[k] < 3.0f * noise) {
            self->hangovers[k] = 0;
            self->stationarity_flags[k] = 1;
        } else {
            if (self->hangovers[k] > 0) {
                self->hangovers[k]--;
            } else {
                self->stationarity_flags[k] = 0;
            }
        }
    }
}

void EchoAudibility_Init(EchoAudibility* self,
                         int use_render_stationarity_at_init) {
    memset(self, 0, sizeof(EchoAudibility));
    self->use_render_stationarity_at_init = use_render_stationarity_at_init;
    EchoAudibility_Reset(self);
}

void EchoAudibility_Reset(EchoAudibility* self) {
    StationarityEstimator_Init(&self->render_stationarity);
    self->non_zero_render_seen = 0;
    self->has_render_spectrum_write_prev = 0;
    self->render_spectrum_write_prev = 0;
    self->render_block_write_prev = 0;
}

void EchoAudibility_Update(EchoAudibility* self,
                           const RenderBuffer* render_buffer,
                           const float* render_reverb_contribution_spectrum,
                           int delay_blocks,
                           int external_delay_seen) {
    /* Update noise estimator with latest render spectrum */
    const float* spectrum = RenderBuffer_Spectrum(render_buffer, 0);
    if (spectrum) {
        if (!self->non_zero_render_seen && !external_delay_seen) {
            /* Check if render is non-zero */
            const float* block = RenderBuffer_Block(render_buffer, 0, 0);
            if (block) {
                int k;
                float max_abs = 0.0f;
                for (k = 0; k < AEC3_BLOCK_SIZE; k++) {
                    float a = fabsf(block[k]);
                    if (a > max_abs) max_abs = a;
                }
                if (max_abs >= 10.0f) {
                    self->non_zero_render_seen = 1;
                }
            }
        }
        if (self->non_zero_render_seen) {
            StationarityEstimator_UpdateNoiseEstimator(
                &self->render_stationarity, spectrum);
        }
    }

    /* Update stationarity flags */
    if (external_delay_seen || self->use_render_stationarity_at_init) {
        if (spectrum) {
            StationarityEstimator_UpdateFlags(
                &self->render_stationarity,
                spectrum,
                render_reverb_contribution_spectrum,
                delay_blocks, 0);
        }
    }
}

void EchoAudibility_GetResidualEchoScaling(const EchoAudibility* self,
                                           int filter_has_had_time_to_converge,
                                           float* residual_scaling) {
    int k;
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        if (self->render_stationarity.stationarity_flags[k] &&
            filter_has_had_time_to_converge) {
            residual_scaling[k] = 0.0f;
        } else {
            residual_scaling[k] = 1.0f;
        }
    }
}

int EchoAudibility_IsBlockStationary(const EchoAudibility* self) {
    int k;
    /* Block is stationary if majority of bands are stationary */
    int count = 0;
    for (k = 0; k < AEC3_FFT_LENGTH_BY2_PLUS1; k++) {
        if (self->render_stationarity.stationarity_flags[k]) {
            count++;
        }
    }
    return (count > AEC3_FFT_LENGTH_BY2_PLUS1 / 2);
}
