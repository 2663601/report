/*
 *  ShadowFilterUpdateGain - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ShadowFilterUpdateGain class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Computes the fixed gain for the shadow adaptive filter.
 *  C99 compatible, no C++ keywords.
 */

#ifndef SHADOW_FILTER_UPDATE_GAIN_H_
#define SHADOW_FILTER_UPDATE_GAIN_H_

#include "aec3_common.h"
#include "fft_data.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * ShadowFilterConfig - Shadow filter gain configuration
 *
 * Extracted from Aec3Config shadow filter fields.
 * ================================================================ */
typedef struct {
    int     length_blocks;
    float   rate;
    float   noise_gate;
} ShadowFilterConfig;

/* ================================================================
 * ShadowFilterUpdateGain
 * ================================================================ */
typedef struct {
    ShadowFilterConfig  current_config;
    ShadowFilterConfig  target_config;
    ShadowFilterConfig  old_target_config;

    int     config_change_duration_blocks;
    float   one_by_config_change_duration_blocks;

    int     poor_signal_excitation_counter;
    int     call_counter;
    int     config_change_counter;
} ShadowFilterUpdateGain;

/* ================================================================
 * Initialization
 *
 * config:                  shadow filter configuration
 * config_change_duration:  blocks for smooth config transitions
 * ================================================================ */
void ShadowFilterUpdateGain_Init(ShadowFilterUpdateGain* self,
                                 const ShadowFilterConfig* config,
                                 int config_change_duration);

/* ================================================================
 * Handle echo path change: reset counters
 * ================================================================ */
void ShadowFilterUpdateGain_HandleEchoPathChange(
    ShadowFilterUpdateGain* self);

/* ================================================================
 * Compute: shadow filter gain
 *
 * render_power:            X2 power spectrum
 * poor_signal_excitation:  1 if render signal is poorly excited
 * E_shadow:                shadow filter error in frequency domain
 * size_partitions:         current filter size
 * saturated_capture:       1 if capture is saturated
 * G:                       output gain (FftData re/im)
 * main_reset_shadow_hangover: hangover counter
 * ================================================================ */
void ShadowFilterUpdateGain_Compute(
    ShadowFilterUpdateGain* self,
    const float* render_power,
    int poor_signal_excitation,
    const FftData128* E_shadow,
    int size_partitions,
    int saturated_capture,
    FftData128* G,
    int* main_reset_shadow_hangover);

/* ================================================================
 * Set config with optional smooth transition
 * ================================================================ */
void ShadowFilterUpdateGain_SetConfig(ShadowFilterUpdateGain* self,
                                      const ShadowFilterConfig* config,
                                      int immediate_effect);

#ifdef __cplusplus
}
#endif

#endif /* SHADOW_FILTER_UPDATE_GAIN_H_ */
