/*
 *  ComfortNoiseGenerator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ ComfortNoiseGenerator class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point path retained.
 */

#include "comfort_noise_generator.h"
#include "aec_state.h"
#include <string.h>
#include <math.h>

/* ================================================================
 * Random number generator (same as WebRTC TableRandomValue)
 * ================================================================ */
static void TableRandomValue(short* vector, int vector_length,
                             unsigned int* seed) {
    int i;
    for (i = 0; i < vector_length; i++) {
        *seed = (*seed * (unsigned int)69069 + 1) & 0x7FFFFFFF;
        vector[i] = (short)(*seed >> 16);
    }
}

/* ================================================================
 * GenerateComfortNoise (512-point)
 * ================================================================ */
static void GenerateComfortNoise512(const float* N2_long, unsigned int* seed,
                                    FftDataPfdkf* lower_band_noise,
                                    FftDataPfdkf* upper_band_noise) {
    float N_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    short random_values[AEC3_FFT_LENGTH_LONG_BY2 - 1];
    float high_band_noise_level;
    float sum = 0.0f;
    const float kScale = 6.28318530717959f / 32768.0f;
    const float kSqrt2 = 1.4142135623f;
    int k;

    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        N_long[k] = sqrtf(N2_long[k]);
    }

    for (k = AEC3_FFT_LENGTH_LONG_BY2_PLUS1 / 2; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        sum += N_long[k];
    }
    high_band_noise_level = sum / (float)(AEC3_FFT_LENGTH_LONG_BY2_PLUS1 / 2 + 1);

    TableRandomValue(random_values, AEC3_FFT_LENGTH_LONG_BY2 - 1, seed);

    lower_band_noise->relf[0] = 0.0f;
    lower_band_noise->relf[AEC3_FFT_LENGTH_LONG_BY2] = 0.0f;
    upper_band_noise->relf[0] = 0.0f;
    upper_band_noise->relf[AEC3_FFT_LENGTH_LONG_BY2] = 0.0f;

    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2 - 1; k++) {
        float s = -sinf(kScale * random_values[k]) * kSqrt2;
        float c = cosf(kScale * random_values[k]) * kSqrt2;
        lower_band_noise->relf[k + 1] = c * N_long[k + 1];
        lower_band_noise->imlf[k + 1] = s * N_long[k + 1];
        upper_band_noise->relf[k + 1] = c * high_band_noise_level;
        upper_band_noise->imlf[k + 1] = s * high_band_noise_level;
    }
}

/* ================================================================
 * CNG_Init
 * ================================================================ */
void CNG_Init(ComfortNoiseGenerator* self) {
    int k;
    memset(self, 0, sizeof(ComfortNoiseGenerator));
    self->seed = 42;
    self->N2_initial_long_valid = 1;

    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        self->N2_long[k] = 1.0e5f;
        self->Y2tmp_long[k] = 1.0e5f;
        self->Y2min_long[k] = 1.0e5f;
    }
}

/* ================================================================
 * CNG_Compute512 (512-point)
 * ================================================================ */
void CNG_Compute512(ComfortNoiseGenerator* self,
                    const struct AecState_* aec_state,
                    const float* capture_spectrum,
                    FftDataPfdkf* lower_band_noise,
                    FftDataPfdkf* upper_band_noise,
                    int cng_level,
                    float near_activity,
                    int music_flag) {
    int k, min_range;
    const float kNoiseFloor = 440.0f;
    const float* N2_use;
    float smooth_alpha = (cng_level == 1) ? 0.4f : 0.2f;

    self->min_count++;

    if (self->N2_counter < 125)
        min_range = 38;
    else if (self->N2_counter < 250)
        min_range = 125;
    else
        min_range = 250;

    if (!AecState_SaturatedCapture(aec_state)) {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            self->Y2_smoothed_long[k] += smooth_alpha * (capture_spectrum[k] - self->Y2_smoothed_long[k]);
        }

        if (self->N2_counter > 13) {
            if (!music_flag) {
                if (cng_level == 0) {
                    if (near_activity < 0.0f) {
                        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                            self->N2_long[k] = (self->Y2_smoothed_long[k] < self->N2_long[k])
                                ? (0.9f * self->Y2_smoothed_long[k] + 0.1f * self->N2_long[k]) * 1.0002f
                                : self->N2_long[k] * 1.0002f;
                        }
                    } else if (near_activity < 0.1f) {
                        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                            self->N2_long[k] = (self->Y2_smoothed_long[k] < self->N2_long[k])
                                ? (0.9f * self->Y2_smoothed_long[k] + 0.1f * self->N2_long[k]) * 1.0002f
                                : self->N2_long[k] * 1.02f;
                        }
                    } else {
                        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                            self->N2_long[k] = (self->Y2_smoothed_long[k] < self->N2_long[k])
                                ? (0.9f * self->Y2_smoothed_long[k] + 0.1f * self->N2_long[k]) * 1.0002f
                                : self->N2_long[k] * 1.0002f;
                        }
                    }
                } else if (cng_level == 1) {
                    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                        if (self->Y2_smoothed_long[k] * 0.8f < self->Y2min_long[k]) {
                            self->N2_long[k] = (0.05f * self->Y2_smoothed_long[k] + 0.95f * self->N2_long[k]) * 1.0002f;
                        }
                    }
                }
            }
        }

        if (self->min_count > min_range) {
            self->min_count = 0;
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                self->Y2min_long[k] = (self->Y2tmp_long[k] < self->Y2_smoothed_long[k])
                    ? self->Y2tmp_long[k] : self->Y2_smoothed_long[k];
                self->Y2tmp_long[k] = self->Y2_smoothed_long[k];
            }
        } else {
            for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                if (self->Y2_smoothed_long[k] < self->Y2min_long[k])
                    self->Y2min_long[k] = self->Y2_smoothed_long[k];
                if (self->Y2_smoothed_long[k] < self->Y2tmp_long[k])
                    self->Y2tmp_long[k] = self->Y2_smoothed_long[k];
            }
        }

        if (self->N2_initial_long_valid) {
            self->N2_counter++;
            if (self->N2_counter >= 250) {
                self->N2_initial_long_valid = 0;
            } else {
                for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
                    if (self->N2_long[k] > self->N2_initial_long[k]) {
                        self->N2_initial_long[k] += 0.001f * (self->N2_long[k] - self->N2_initial_long[k]);
                    } else {
                        self->N2_initial_long[k] = self->N2_long[k];
                    }
                }
            }
        }
    }

    for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
        if (self->N2_long[k] < kNoiseFloor) self->N2_long[k] = kNoiseFloor;
    }
    if (self->N2_initial_long_valid) {
        for (k = 0; k < AEC3_FFT_LENGTH_LONG_BY2_PLUS1; k++) {
            if (self->N2_initial_long[k] < kNoiseFloor) self->N2_initial_long[k] = kNoiseFloor;
        }
    }

    N2_use = self->N2_initial_long_valid ? self->N2_initial_long : self->N2_long;
    GenerateComfortNoise512(N2_use, &self->seed, lower_band_noise, upper_band_noise);
}

const float* CNG_NoiseSpectrumLong(const ComfortNoiseGenerator* self) {
    return self->N2_initial_long_valid ? self->N2_initial_long : self->N2_long;
}
