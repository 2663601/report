#! /usr/bin/env python3
# -*- coding:utf-8 -*-
# Author:   LiPingping
# Time:     2021/11/10
# Desc:     audio utils needes.

import os
import sys
import torch
import random
import numpy as np
import importlib
import getpass
from pytorch_lightning import seed_everything

sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..")))
import acore.acoustics.windows as windows

def expand_path(path):
    ''''''
    return os.path.abspath(os.path.expanduser(path))


def basename(path):
    ''' Splite basename to get filename and ext.'''
    filename, ext = os.path.splitext(os.path.basename(path))
    return filename, ext


def prepare_server_setting(config):
    ''' Prepare setting for server.'''
    username = getpass.getuser()
    print("I: current user: {}.".format(username))
    if "root" == username:
        for key, value in config["train_dataset"]["server"].items():
            config["train_dataset"]["args"][key] = value
            print(key, config["train_dataset"]["args"][key])

        for key, value in config["validation_dataset"]["server"].items():
            config["validation_dataset"]["args"][key] = value
            print(key, config["validation_dataset"]["args"][key])

        for key, value in config["test"]["server"].items():
            config["test"][key] = config["test"]["server"][key]


def prepare_dataset_args(conf):
    # Acoustics params.
    win_type = conf["acoustics"]["window"]
    conf["acoustics"]["window"] = getattr(windows, win_type)(conf["acoustics"]["window_size"])

    conf["loss_function"]["args"]["window"] = conf["acoustics"]["window"]
    conf["loss_function"]["args"]["nfft"] = conf["acoustics"]["nfft"]
    conf["loss_function"]["args"]["window_size"] = conf["acoustics"]["window_size"]
    conf["loss_function"]["args"]["hop_length"] = conf["acoustics"]["hop_length"]
    # for multires loss.
    conf["loss_function"]["args"]["window_type"] = win_type

    conf["system"]["args"]["window"] = conf["acoustics"]["window"]
    conf["system"]["args"]["nfft"] = conf["acoustics"]["nfft"]
    conf["system"]["args"]["window_size"] = conf["acoustics"]["window_size"]
    conf["system"]["args"]["hop_length"] = conf["acoustics"]["hop_length"]

    conf["train_dataset"]["args"]["sr"] = conf["acoustics"]["sr"]
    # conf["validation_dataset"]["args"]["sr"] = conf["acoustics"]["sr"]

def prepare_utils(config):
    '''Prepare utils for training.'''
    # create weights dir
    # os.makedirs(os.path.join(config["meta"]["save_dir"], config["meta"]["tag"]), exist_ok=True)

    # os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':16:8'
    #
    # # seed init.
    # random.seed(config["meta"]["seed"])
    # np.random.seed(config["meta"]["seed"])
    # os.environ['PYTHONHASHSEED'] = str(config["meta"]["seed"])
    #
    # # torch seed init.
    # torch.manual_seed(config["meta"]["seed"])
    # torch.cuda.manual_seed(config["meta"]["seed"])
    # torch.cuda.manual_seed_all(config["meta"]["seed"])
    #
    # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = False
    # # torch.backends.cudnn.enabled = False
    #
    # # avoiding nondeterministic algorithms (see https://pytorch.org/docs/stable/notes/randomness.html)
    # # torch.use_deterministic_algorithms(True)
    torch.set_num_threads(32)

    seed_everything(config["meta"]["seed"], workers=True)

    # torch.set_float32_matmul_precision("medium")

    # prepare server setting.
    prepare_server_setting(config)

    # prepare dataset args.
    prepare_dataset_args(config)

def flatten_dict(d, parent_key="", sep="_"):
    """Flattens a dictionary into a single-level dictionary while preserving
    parent keys. Taken from
    `SO <https://stackoverflow.com/questions/6027558/flatten-nested-dictionaries-compressing-keys>`_

    Args:
        d (MutableMapping): Dictionary to be flattened.
        parent_key (str): String to use as a prefix to all subsequent keys.
        sep (str): String to use as a separator between two key levels.

    Returns:
        dict: Single-level dictionary, flattened.
    """
    items = []
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, MutableMapping):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def initialize_module(path: str, args: dict = None, initialize: bool = True):
    """
    Load module dynamically with "args".

    Args:
        path: module path in this project.
        args: parameters that passes to the Class or the Function in the module.
        initialize: initialize the Class or the Function with args.
    """
    module_path = ".".join(path.split(".")[:-1])
    class_or_function_name = path.split(".")[-1]

    module = importlib.import_module(module_path)
    class_or_function = getattr(module, class_or_function_name)

    if initialize:
        if args:
            return class_or_function(**args)
        else:
            return class_or_function()
    else:
        return class_or_function
