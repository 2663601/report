/*
 *  Moving Average - Pure C Version
 *
 *  Fixed-window moving average computation for spectral smoothing.
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef MOVING_AVERAGE_H_
#define MOVING_AVERAGE_H_

#include "aec3_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Maximum supported element count and memory length.
 * 257 = AEC3_FFT_LENGTH_LONG_BY2_PLUS1 (512-point FFT)
 * 65  = AEC3_FFT_LENGTH_BY2_PLUS1 (128-point FFT)
 * mem_len up to 6 (typical usage in AEC3)
 */
#define MOVING_AVG_MAX_ELEM      257
#define MOVING_AVG_MAX_MEM_LEN   6

typedef struct {
    int     num_elem;           /* number of elements per input vector */
    int     num_elem_long;      /* 257 for 512-point FFT variant */
    int     mem_len;            /* memory length (mem_len - 1 previous frames) */
    float   scaling;            /* 1.0f / (mem_len + 1) ... actually 1/mem_len_total */
    float   memory[MOVING_AVG_MAX_MEM_LEN * MOVING_AVG_MAX_ELEM];
    float   memory_long[MOVING_AVG_MAX_MEM_LEN * MOVING_AVG_MAX_ELEM];
    int     mem_index;
} MovingAverage;

/*
 * Initialize the moving average.
 * num_elem: number of elements per input vector (e.g. 65 or 257)
 * mem_len:  total window length (current + mem_len-1 previous)
 */
void MovingAverage_Init(MovingAverage* self, int num_elem, int mem_len);

/*
 * Compute the average of input and (mem_len-1) previous inputs.
 * input:  array of num_elem floats
 * output: array of num_elem floats (result)
 */
void MovingAverage_Average(MovingAverage* self,
                           const float* input, float* output);

/*
 * 512-point FFT variant (num_elem_long = 257).
 */
void MovingAverage_Average512(MovingAverage* self,
                              const float* input, float* output);

#ifdef __cplusplus
}
#endif

#endif /* MOVING_AVERAGE_H_ */
