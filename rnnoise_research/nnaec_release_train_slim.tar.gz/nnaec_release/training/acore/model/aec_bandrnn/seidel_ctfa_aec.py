#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SeidelCTFA — 忠实 UL-UNAS cTFA 门控的 band-AEC 后置滤波器。

与 seidel_x_aec.py 的关键区别(纠正三处偏差, 详见 docs/06_aec/seidel结构创新设计.md):
  1. 频率建模改回"门控"而非"concat增广":
     旧 SeidelX 把频率 GRU 输出 concat 进 fc_input -> 维度膨胀到 ~2240, fc_input 占 57% 参数,
     把时间 GRU 挤到 hidden 96。本版照 cTFA Fig.5: FA 分支用频率 BiGRU **生成门** 乘回特征图,
     维度不膨胀, 省下的容量还给时间 GRU(hidden 回到 128)。
  2. TA 用真正的"时间 GRU"生成门, 不再用 cumsum 累积均值(那是积分器, 对瞬态回声反应迟钝)。
  3. 特征以 4D band 图 (B,T,F=nbands,C) 贯穿 cTFA, 对齐论文 U:(B,C,T,F) 的 TA×FA 门控,
     之后再聚合进 Seidel 主干(FC+时间GRU+dense), 保持部署友好(全 Linear/GRU/sigmoid/逐点乘)。

忠实 cTFA (Fig.5):
  TA: squeeze 掉 F -> (B,T,C) -> GRU_t(沿T,因果) -> FC -> sigmoid -> g_ta, 广播回 F
  FA: squeeze 掉 C -> (B,T,F) -> BiGRU_f(沿F,无因果可双向) -> FC -> sigmoid -> g_fa, 广播回 C
  U_out = U * g_fa * g_ta   (维度不变)

偏离声明(诚实):
  - 论文 cTFA 作用在 U-Net 卷积特征图上; 本项目是 band 后置滤波器、无卷积 encoder,
    这里把 cTFA 门控移植到"band 特征图"(C=由3路输入投影而来)。方向可借、数值不可照搬,
    收益须本任务消融重验。新引入超参: 通道数 ctfa_ch(C0)、FA 隐藏 fa_hidden(R)。
  - 为部署友好, 1x1 通道投影用 Linear 作用在最后一维(等价逐(t,f)位置的 compute_dense)。

forward 返回 (band_gain, hidden), 与 system_bandaec 的 "seidel" 两元组分支签名一致。
输入 feat: [B,T,nbands*3] = cat(fz,fy,fx)。
"""
import torch
import torch.nn as nn


class FarModAttention(nn.Module):
    """远端调制注意力(用输入里的远端 fx 这一路生成逐维 sigmoid 门调制主干特征)。"""
    def __init__(self, nbands, feat_dim, hidden=None, out_bias_init=0.0):
        super().__init__()
        hidden = hidden or max(8, nbands // 2)
        self.fc1 = nn.Linear(nbands, hidden)
        self.fc2 = nn.Linear(hidden, feat_dim)
        if out_bias_init != 0.0:
            nn.init.constant_(self.fc2.bias, out_bias_init)

    def forward(self, feat, fx):
        g = torch.relu(self.fc1(fx))
        g = torch.sigmoid(self.fc2(g))
        return feat * g


class CTFA(nn.Module):
    """忠实 cTFA 门控: 作用在 band 特征图 X [B,T,F,C], 返回同形状(门控后)。"""
    def __init__(self, nbands, ch, fa_hidden=16):
        super().__init__()
        # TA(时间注意力): 沿 T 的单向 GRU, 对通道轴 C 生成门
        self.ta_gru = nn.GRU(ch, ch, 1, batch_first=True)
        self.ta_fc = nn.Linear(ch, ch)
        # FA(频率注意力): 沿 F 的双向 GRU(每 band 标量输入), 对频率轴 F 生成门
        self.fa_gru = nn.GRU(1, fa_hidden, 1, batch_first=True, bidirectional=True)
        self.fa_fc = nn.Linear(fa_hidden * 2, 1)
        self.nbands = nbands

    def forward(self, X, ta_hidden=None):
        # X: [B, T, F, C]
        B, T, F, C = X.shape
        # ---- TA: squeeze F (当前帧内均值, 不跨帧) ----
        ta_in = X.mean(dim=2)                       # [B,T,C]
        ta, ta_hidden = self.ta_gru(ta_in, ta_hidden)  # [B,T,C] 沿时间, 因果
        g_ta = torch.sigmoid(self.ta_fc(ta))        # [B,T,C]
        # ---- FA: squeeze C ----
        fa_in = X.mean(dim=3)                        # [B,T,F]
        fa_seq = fa_in.reshape(B * T, F, 1)          # [B*T,F,1] 沿频率
        fa, _ = self.fa_gru(fa_seq)                  # [B*T,F,2R]
        g_fa = torch.sigmoid(self.fa_fc(fa)).reshape(B, T, F)  # [B,T,F]
        # ---- U * g_fa * g_ta (广播) ----
        X = X * g_fa.unsqueeze(-1) * g_ta.unsqueeze(2)
        return X, ta_hidden


class SeidelCTFA(nn.Module):
    def __init__(self,
                 nbands=64,
                 num_inputs=3,
                 ctfa_ch=16,            # cTFA 特征图通道数 C0(3路输入投影到此)
                 fa_hidden=16,          # FA 频率 BiGRU 隐藏维 R
                 fc_input_dim=128,
                 gru_hidden=128,        # 时间 GRU 恢复到 128(容量从频率concat挪回时间)
                 n_gru=2,
                 gru_dropout=0.2,
                 dense_hidden=192,
                 use_ctfa=True,
                 use_farmod_attn=True,
                 farmod_bias_init=0.0,
                 **kwargs):
        super().__init__()
        self.nbands = nbands
        self.num_inputs = num_inputs
        self.use_ctfa = use_ctfa
        self.use_farmod_attn = use_farmod_attn
        self.n_gru = n_gru
        self.gru_hidden = gru_hidden

        # 1) 3 路输入投影到 band 特征图的通道维 C0 (Linear 作用在最后一维 = 1x1 通道卷积)
        if use_ctfa:
            self.up_proj = nn.Linear(num_inputs, ctfa_ch)     # [B,T,F,3] -> [B,T,F,C0]
            self.ctfa = CTFA(nbands, ctfa_ch, fa_hidden=fa_hidden)
            self.down_proj = nn.Linear(ctfa_ch, 1)            # 聚合通道 -> 每 band 标量
            fc_in_total = nbands * num_inputs + nbands        # 原始三路 + cTFA 聚合(1路)
        else:
            fc_in_total = nbands * num_inputs

        # 2) Seidel 主干: fc_input + 时间 GRU + dense0/1/2
        self.fc_input = nn.Linear(fc_in_total, fc_input_dim)
        self.gru = nn.GRU(batch_first=True, input_size=fc_input_dim,
                          hidden_size=gru_hidden, num_layers=n_gru, dropout=gru_dropout)
        if use_farmod_attn:
            self.farmod = FarModAttention(nbands, gru_hidden, out_bias_init=farmod_bias_init)
        self.dense0 = nn.Linear(gru_hidden, dense_hidden)
        self.dense1 = nn.Linear(dense_hidden, dense_hidden)
        self.dense2 = nn.Linear(dense_hidden, nbands)

    def forward(self, feat, hidden=None):
        B, T, _ = feat.shape
        nb = self.nbands
        fz = feat[..., 0:nb]; fy = feat[..., nb:2 * nb]; fx = feat[..., 2 * nb:3 * nb]

        if self.use_ctfa:
            X = torch.stack([fz, fy, fx], dim=-1)   # [B,T,F=nb,3]
            X = self.up_proj(X)                     # [B,T,F,C0]
            X, _ = self.ctfa(X)                     # 门控后 [B,T,F,C0]
            Xa = self.down_proj(X).squeeze(-1)      # [B,T,F=nb]
            x_in = torch.cat([feat, Xa], dim=-1)    # [B,T,3nb+nb]
        else:
            x_in = feat

        x = torch.relu(self.fc_input(x_in))
        x, hidden = self.gru(x, hidden)
        if self.use_farmod_attn:
            x = self.farmod(x, fx)
        x = torch.relu(self.dense0(x))
        x = torch.relu(self.dense1(x))
        band_gain = torch.sigmoid(self.dense2(x))
        return band_gain, hidden


if __name__ == "__main__":
    nb = 64
    m = SeidelCTFA(nbands=nb, num_inputs=3)
    n = sum(p.numel() for p in m.parameters())
    print(f"SeidelCTFA(band={nb}) params = {n} ({n/1e3:.1f}K)")
    agg = {}
    for name, p in m.named_parameters():
        agg[name.split(".")[0]] = agg.get(name.split(".")[0], 0) + p.numel()
    for k in sorted(agg, key=lambda x: -agg[x]):
        print(f"  {k:12s} {agg[k]:>9d}  {agg[k]/n*100:5.1f}%")
    feat = torch.randn(2, 50, nb * 3)
    g, h = m(feat)
    print("band_gain:", tuple(g.shape), "range", float(g.min()), float(g.max()),
          "finite", bool(torch.isfinite(g).all()))
    # 消融: 关 cTFA 应退化成 Seidel
    m0 = SeidelCTFA(nbands=nb, use_ctfa=False, use_farmod_attn=False)
    print(f"SeidelCTFA(ctfa-off,farmod-off) = {sum(p.numel() for p in m0.parameters())/1e3:.1f}K")
    # 3步反向冒烟
    opt = torch.optim.Adam(m.parameters(), lr=1e-3)
    for _ in range(3):
        g, _ = m(feat); loss = (g - 0.5).abs().mean()
        opt.zero_grad(); loss.backward(); opt.step()
    print("3-step backward OK, finite:", bool(torch.isfinite(g).all()))
