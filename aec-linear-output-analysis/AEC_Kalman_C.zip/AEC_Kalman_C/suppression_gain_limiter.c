/*
 *  SuppressionGainUpperLimiter - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ SuppressionGainUpperLimiter class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#include "suppression_gain_limiter.h"
#include <math.h>

void SuppressionGainUpperLimiter_Init(SuppressionGainUpperLimiter* self,
                                      const Aec3Config* config) {
    self->initial_gain = config->gain_rampup_initial_gain;
    self->first_non_zero_gain = config->gain_rampup_first_non_zero_gain;
    self->non_zero_gain_blocks = config->gain_rampup_non_zero_gain_blocks;
    self->full_gain_blocks = config->gain_rampup_full_gain_blocks;

    /* Compute rampup increase factor */
    if (self->first_non_zero_gain > 0.0f && self->non_zero_gain_blocks > 0) {
        self->gain_rampup_increase = powf(
            1.0f / self->first_non_zero_gain,
            1.0f / (float)self->non_zero_gain_blocks);
    } else {
        self->gain_rampup_increase = 1.0f;
    }

    self->call_startup_phase = 1;
    self->realignment_counter = 0;
    self->active_render_seen = 0;
    self->suppressor_gain_limit = 1.0f;
    self->recent_reset = 0;

    SuppressionGainUpperLimiter_Reset(self);
}

void SuppressionGainUpperLimiter_Reset(SuppressionGainUpperLimiter* self) {
    self->recent_reset = 1;
}

void SuppressionGainUpperLimiter_Update(SuppressionGainUpperLimiter* self,
                                        int render_activity,
                                        int transparent_mode) {
    if (transparent_mode) {
        self->active_render_seen = 1;
        self->call_startup_phase = 0;
        self->recent_reset = 0;
        self->suppressor_gain_limit = 1.0f;
        return;
    }

    if (self->recent_reset && !self->call_startup_phase) {
        /* 250 ms full suppression after in-call resets */
        int kMuteFramesAfterReset = AEC3_NUM_BLOCKS_PER_SECOND / 4;
        self->realignment_counter = kMuteFramesAfterReset;
    } else if (!self->active_render_seen && render_activity) {
        /* Tailored suppression limiting during call startup */
        self->active_render_seen = 1;
        self->realignment_counter = self->full_gain_blocks;
    } else if (self->realignment_counter > 0) {
        if (--self->realignment_counter == 0) {
            self->call_startup_phase = 0;
        }
    }
    self->recent_reset = 0;

    /* No active limiting */
    if (!SuppressionGainUpperLimiter_IsActive(self)) {
        self->suppressor_gain_limit = 1.0f;
        return;
    }

    /* Full suppression phase */
    if (self->realignment_counter > self->non_zero_gain_blocks ||
        (!self->call_startup_phase && self->realignment_counter > 0)) {
        self->suppressor_gain_limit = self->initial_gain;
        return;
    }

    /* Start increasing */
    if (self->realignment_counter == self->non_zero_gain_blocks) {
        self->suppressor_gain_limit = self->first_non_zero_gain;
        return;
    }

    /* Ramp up */
    if (self->suppressor_gain_limit > 0.0f) {
        self->suppressor_gain_limit *= self->gain_rampup_increase;
        if (self->suppressor_gain_limit > 1.0f) {
            self->suppressor_gain_limit = 1.0f;
        }
    }
}

float SuppressionGainUpperLimiter_Limit(const SuppressionGainUpperLimiter* self) {
    return self->suppressor_gain_limit;
}

int SuppressionGainUpperLimiter_IsActive(const SuppressionGainUpperLimiter* self) {
    return (self->realignment_counter > 0);
}

void SuppressionGainUpperLimiter_Deactivate(SuppressionGainUpperLimiter* self) {
    self->realignment_counter = 0;
    self->suppressor_gain_limit = 1.0f;
}
