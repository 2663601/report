/*
 *  EchoCanceller3 - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ EchoCanceller3 class.
 *  Original copyright (c) 2016 The WebRTC project authors.
 */

#include "echo_canceller3.h"
#include <string.h>
#include <math.h>

/* ================================================================
 * High-pass filter coefficients
 * [B,A] = butter(2, 100/8000, 'high')
 * ================================================================ */
static const BiQuadCoefficients kHPCoeffs_16kHz = {
    { 0.97261f, -1.94523f, 0.97261f },
    { -1.94448f, 0.94598f }
};

static const BiQuadCoefficients kHPCoeffs_8kHz = {
    { 0.94598f, -1.89195f, 0.94598f },
    { -1.88903f, 0.89487f }
};

/* ================================================================
 * Saturation detection
 * ================================================================ */
static int DetectSaturation(const float* y, int len) {
    int k;
    for (k = 0; k < len; k++) {
        if (y[k] >= 32700.0f || y[k] <= -32700.0f) {
            return 1;
        }
    }
    return 0;
}

/* ================================================================
 * Render queue operations (removed — synchronous mode, unused)
 * ================================================================ */

/* ================================================================
 * EchoCanceller3_Init
 * ================================================================ */
void EchoCanceller3_Init(EchoCanceller3* self, const Aec3Config* config,
                         int sample_rate_hz, int render_buffer_size,
                         float* blocks_mem, float* spectra_mem,
                         FftDataPfdkf* ffts2_mem,
                         float* low_rate_mem, int low_rate_size,
                         float* binary_dyn_mem,
                         FftDataPfdkf* H_pf_mem,
                         FftDataPfdkf* H_pf_speed_mem,
                         FftDataPfdkf* H_pf_update_mem,
                         float* H2_pf_update_mem,
                         FftDataPfdkf* G_pfdkf_mem,
                         FftDataPfdkf* G_pfdkf_speed_mem,
                         float* H_error_pfdkf_mem,
                         int aec_H_usage) {
    int num_bands;
    const BiQuadCoefficients* hp_coeffs;

    memset(self, 0, sizeof(EchoCanceller3));
    self->config = *config;
    self->sample_rate_hz = sample_rate_hz;
    self->render_buffer_size = (render_buffer_size > 0) ? render_buffer_size : AEC3_RENDER_BUFFER_SIZE;
    num_bands = Aec3_NumBandsForRate(sample_rate_hz);
    self->num_bands = num_bands;
    self->frame_length = Aec3_LowestBandRate(sample_rate_hz) / 100; /* 10ms */

    /* Initialize frame/block converters */
    BlockFramer_Init(&self->output_framer, num_bands);
    FrameBlocker_Init(&self->capture_blocker, num_bands);
    FrameBlocker_Init(&self->render_blocker, num_bands);

    /* Initialize block processor with external ring buffer memory */
    BlockProcessor_Init(&self->block_processor, config, sample_rate_hz,
                        self->render_buffer_size,
                        blocks_mem, spectra_mem, ffts2_mem,
                        low_rate_mem, low_rate_size, binary_dyn_mem,
                        H_pf_mem, H_pf_speed_mem, H_pf_update_mem,
                        H2_pf_update_mem, G_pfdkf_mem, G_pfdkf_speed_mem,
                        H_error_pfdkf_mem, aec_H_usage);

    /* Initialize high-pass filters */
    hp_coeffs = (sample_rate_hz == 8000) ? &kHPCoeffs_8kHz : &kHPCoeffs_16kHz;
    CascadedBiQuad_InitFromCoeffs(&self->capture_highpass_filter, hp_coeffs, 1);
    CascadedBiQuad_InitFromCoeffs(&self->render_highpass_filter, hp_coeffs, 1);
    self->use_highpass_filter = 1;
    self->use_render_highpass_filter = 1;

    self->saturated_microphone_signal = 0;
    self->echo_process_enable = 1;
    self->noise_gate_hold_counter = 0;
    self->aec_energy_before = 0.0f;
    self->aec_energy_after = 0.0f;

    AecRuntimeConfig_SetDefaults(&self->aec_config_parameter);
}

/* ================================================================
 * EchoCanceller3_AnalyzeRender
 *
 * Called from the render (far-end) path. Applies high-pass filter
 * and pushes blocks into the render queue.
 * ================================================================ */
void EchoCanceller3_AnalyzeRender(EchoCanceller3* self,
                                  const float* farend,
                                  int num_bands,
                                  int frame_length) {
    float render_frame[AEC3_MAX_BANDS][AEC3_FRAME_LENGTH];
    float render_block[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE];
    int sub_frame_idx, b, k;
    int num_sub_frames;

    /* Copy input to render frame */
    for (b = 0; b < num_bands && b < AEC3_MAX_BANDS; b++) {
        for (k = 0; k < frame_length && k < AEC3_FRAME_LENGTH; k++) {
            render_frame[b][k] = farend[b * frame_length + k];
        }
    }

    /* Apply high-pass filter to lowest band */
    if (self->use_render_highpass_filter) {
        CascadedBiQuad_ProcessInPlace(&self->render_highpass_filter,
                                      render_frame[0], frame_length);
    }

    /* Process sub-frames through render blocker -> directly to BlockProcessor
     * (synchronous mode: skip render queue, matching AEC_webrtc behavior) */
    num_sub_frames = (self->sample_rate_hz == 8000) ? 1 : 2;
    for (sub_frame_idx = 0; sub_frame_idx < num_sub_frames; sub_frame_idx++) {
        float sub_frame[AEC3_MAX_BANDS][AEC3_SUB_FRAME_LENGTH];
        int offset = sub_frame_idx * AEC3_SUB_FRAME_LENGTH;

        for (b = 0; b < num_bands && b < AEC3_MAX_BANDS; b++) {
            for (k = 0; k < AEC3_SUB_FRAME_LENGTH; k++) {
                if (offset + k < frame_length) {
                    sub_frame[b][k] = render_frame[b][offset + k];
                } else {
                    sub_frame[b][k] = 0.0f;
                }
            }
        }

        if (FrameBlocker_InsertSubFrame(&self->render_blocker,
                (const float (*)[AEC3_SUB_FRAME_LENGTH])sub_frame,
                render_block, num_bands)) {
            /* Directly feed to BlockProcessor (synchronous) */
            BlockProcessor_BufferRender(&self->block_processor,
                (const float (*)[AEC3_BLOCK_SIZE])render_block, num_bands);
        }
    }

    /* Extract any remaining block */
    if (FrameBlocker_IsBlockAvailable(&self->render_blocker)) {
        FrameBlocker_ExtractBlock(&self->render_blocker, render_block, num_bands);
        BlockProcessor_BufferRender(&self->block_processor,
            (const float (*)[AEC3_BLOCK_SIZE])render_block, num_bands);
    }
}

/* ================================================================
 * EchoCanceller3_AnalyzeCapture
 * ================================================================ */
void EchoCanceller3_AnalyzeCapture(EchoCanceller3* self,
                                   const float* capture,
                                   int num_samples) {
    self->saturated_microphone_signal = DetectSaturation(capture, num_samples);
}

/* ================================================================
 * EchoCanceller3_ProcessCapture
 *
 * Main capture processing entry point. Drains render queue,
 * applies high-pass filter, converts frames to blocks, processes
 * through BlockProcessor, and converts blocks back to frames.
 * ================================================================ */
void EchoCanceller3_ProcessCapture(EchoCanceller3* self,
                                   float* capture,
                                   int num_samples,
                                   int num_bands,
                                   int level_change,
                                   int apm_submodule_switch,
                                   int earphone_flag,
                                   int sample_rate,
                                   int adm_mute) {
    float capture_block[AEC3_MAX_BANDS][AEC3_BLOCK_SIZE];
    float sub_frame_in[AEC3_MAX_BANDS][AEC3_SUB_FRAME_LENGTH];
    float sub_frame_out[AEC3_MAX_BANDS][AEC3_SUB_FRAME_LENGTH];
    int sub_frame_idx, b, k;
    int num_sub_frames;
    int frame_length = self->frame_length;
    float energy_before = 0.0f;
    float energy_after  = 0.0f;

    /* Compute capture energy before AEC (band0 only) */
    for (k = 0; k < num_samples; k++) {
        energy_before += capture[k] * capture[k];
    }
    self->aec_energy_before = energy_before;

    /* Apply high-pass filter to capture lowest band */
    if (self->use_highpass_filter) {
        CascadedBiQuad_ProcessInPlace(&self->capture_highpass_filter,
                                      capture, frame_length);
    }

    /* Process sub-frames */
    num_sub_frames = (self->sample_rate_hz == 8000) ? 1 : 2;
    for (sub_frame_idx = 0; sub_frame_idx < num_sub_frames; sub_frame_idx++) {
        int offset = sub_frame_idx * AEC3_SUB_FRAME_LENGTH;

        /* Extract sub-frame from capture */
        for (b = 0; b < num_bands && b < AEC3_MAX_BANDS; b++) {
            for (k = 0; k < AEC3_SUB_FRAME_LENGTH; k++) {
                if (offset + k < num_samples) {
                    sub_frame_in[b][k] = capture[b * num_samples + offset + k];
                } else {
                    sub_frame_in[b][k] = 0.0f;
                }
            }
        }

        /* Insert sub-frame and extract block */
        if (FrameBlocker_InsertSubFrame(&self->capture_blocker,
                (const float (*)[AEC3_SUB_FRAME_LENGTH])sub_frame_in,
                capture_block, num_bands)) {
            /* Process the block */
            BlockProcessor_ProcessCapture(&self->block_processor,
                                          level_change,
                                          self->saturated_microphone_signal,
                                          apm_submodule_switch,
                                          capture_block, num_bands,
                                          self->echo_process_enable,
                                          earphone_flag, adm_mute);

            /* Insert processed block and extract output sub-frame */
            BlockFramer_InsertBlockAndExtractSubFrame(
                &self->output_framer,
                (const float (*)[AEC3_BLOCK_SIZE])capture_block,
                sub_frame_out, num_bands);

            /* Write output sub-frame back to capture */
            for (b = 0; b < num_bands && b < AEC3_MAX_BANDS; b++) {
                for (k = 0; k < AEC3_SUB_FRAME_LENGTH; k++) {
                    if (offset + k < num_samples) {
                        capture[b * num_samples + offset + k] = sub_frame_out[b][k];
                    }
                }
            }
        }
    }

    /* Process any remaining block */
    if (FrameBlocker_IsBlockAvailable(&self->capture_blocker)) {
        FrameBlocker_ExtractBlock(&self->capture_blocker, capture_block, num_bands);
        BlockProcessor_ProcessCapture(&self->block_processor,
                                      level_change,
                                      self->saturated_microphone_signal,
                                      apm_submodule_switch,
                                      capture_block, num_bands,
                                      self->echo_process_enable,
                                      earphone_flag, adm_mute);
        BlockFramer_InsertBlock(&self->output_framer,
                                (const float (*)[AEC3_BLOCK_SIZE])capture_block,
                                num_bands);
    }

    /* Compute capture energy after AEC (band0 only) */
    for (k = 0; k < num_samples; k++) {
        energy_after += capture[k] * capture[k];
    }
    self->aec_energy_after = energy_after;

    /* Update noise_gate_hold_counter:
     * If AEC output energy < 30% of input energy, echo was detected,
     * set hold_counter to 100 frames (~1s). Otherwise decrement. */
    self->noise_gate_hold_counter = (self->noise_gate_hold_counter > 0)
        ? self->noise_gate_hold_counter - 1 : 0;
    if (energy_after < energy_before * 0.3f) {
        self->noise_gate_hold_counter = 100;
    }
}

/* ================================================================
 * EchoCanceller3_Reset
 * ================================================================ */
void EchoCanceller3_Reset(EchoCanceller3* self) {
    /* Save state needed for re-initialization */
    Aec3Config config = self->config;
    int sample_rate_hz = self->sample_rate_hz;
    int rbs = self->render_buffer_size;
    float* blocks_mem = self->block_processor.blocks_mem;
    float* spectra_mem = self->block_processor.spectra_mem;
    FftDataPfdkf* ffts2_mem = self->block_processor.ffts2_mem;
    float* low_rate_mem = self->block_processor.low_rate_mem;
    int low_rate_size = self->block_processor.low_rate_size;
    float* binary_dyn_mem = self->block_processor.binary_dyn_mem;

    /* Save PFDKF memory pointers from subtractor */
    Subtractor* sub = &self->block_processor.echo_remover.subtractor;
    FftDataPfdkf* H_pf_mem = sub->main_filter.H_pf;
    FftDataPfdkf* H_pf_speed_mem = sub->main_filter.H_pf_speed;
    FftDataPfdkf* H_pf_update_mem = sub->main_filter.H_pf_update;
    float* H2_pf_update_mem = sub->main_filter.H2_pf_update;
    FftDataPfdkf* G_pfdkf_mem = sub->G_pfdkf;
    FftDataPfdkf* G_pfdkf_speed_mem = sub->G_pfdkf_speed;
    float* H_error_pfdkf_mem = sub->G_main.H_error_pfdkf;
    int aec_H_usage = sub->max_pfdkf_partitions;

    EchoCanceller3_Init(self, &config, sample_rate_hz, rbs,
                        blocks_mem, spectra_mem, ffts2_mem,
                        low_rate_mem, low_rate_size, binary_dyn_mem,
                        H_pf_mem, H_pf_speed_mem, H_pf_update_mem,
                        H2_pf_update_mem, G_pfdkf_mem, G_pfdkf_speed_mem,
                        H_error_pfdkf_mem, aec_H_usage);
}

/* ================================================================
 * EchoCanceller3_SetAudioBufferDelay
 * ================================================================ */
void EchoCanceller3_SetAudioBufferDelay(EchoCanceller3* self, int delay_ms) {
    BlockProcessor_SetAudioBufferDelay(&self->block_processor, delay_ms);
}

/* ================================================================
 * EchoCanceller3_SetFixedDelay
 * ================================================================ */
void EchoCanceller3_SetFixedDelay(EchoCanceller3* self, int fixed_delay_blocks) {
    BlockProcessor_SetFixedDelay(&self->block_processor, fixed_delay_blocks);
}

/* ================================================================
 * EchoCanceller3_SetConfig
 * ================================================================ */
void EchoCanceller3_SetConfig(EchoCanceller3* self,
                              const AecRuntimeConfig* config) {
    self->aec_config_parameter = *config;
    self->echo_process_enable = config->apm_submodule_switch;
    self->use_highpass_filter = config->highpass_enable_capture;
    self->use_render_highpass_filter = config->highpass_enable_render;

    /* Propagate runtime config to EchoRemover (matches C++ SetProcessConfig) */
    self->block_processor.echo_remover.rt_config = *config;

    /* Propagate aec_512fft_enable to BlockProcessor */
    self->block_processor.aec_512fft_enable = config->aec_512fft_enable;

    /* Propagate delay estimation flags to BlockProcessor
     * (matches C++ BlockProcessorImpl2::SetProcessConfig) */
    self->block_processor.matched_filter_enable_flag = config->matched_filter_enable;
    self->block_processor.voip_mode_enable = config->voip_mode_enable;
    self->block_processor.delay_default = config->delay_default;
    self->block_processor.CastScreen = config->CastScreen;
    self->block_processor.aec_low_compute_mode = config->aec_low_compute_mode;
    self->block_processor.earphone_capture_mode_flag = config->earphone_capture_mode;

    /* Propagate DtController parameters (matches C++ SetProcessConfig in echo_remover.cc) */
    {
        DtController* dt = &self->block_processor.echo_remover.aec_state.dt_controller;
        DtController_SetExcludeNoiseFromEchoFlag(dt, config->ExcludeNoiseFromEchoFlag);
        DtController_SetAecDtcontrolEnable(dt, config->aec_dtcontrol_enable);
        DtController_SetEarphoneFlag(dt, config->earphone_capture_mode);
        DtController_SetVoipFlag(dt, config->voip_mode_enable);
        DtController_SetDoubleTalkCountMax(dt, config->double_talk_count_max);
        DtController_SetEdRatio2kThreshold(dt, config->ed_ratio_2k_threshold);
    }

    /* Propagate aec_H_usage to subtractor and delay controller
     * Must be called after Init to properly resize PFDKF arrays */
    if (config->aec_H_usage > 0) {
        Subtractor_SetAecHUsage(
            &self->block_processor.echo_remover.subtractor,
            config->aec_H_usage);
        RenderDelayController_SetAecHUsage(
            &self->block_processor.render_delay_controller,
            config->aec_H_usage);
    }
}
