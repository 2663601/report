/*
 *  Vector Math Utilities - Pure C Version
 *
 *  Common vector operations for AEC3 signal processing.
 *  All functions operate on float arrays with explicit length parameters.
 *  No STL or C++ dependencies.
 */

#ifndef VECTOR_MATH_H_
#define VECTOR_MATH_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Element-wise addition: out[i] = a[i] + b[i]
 */
void VecMath_Add(const float* a, const float* b, float* out, int len);

/**
 * Element-wise subtraction: out[i] = a[i] - b[i]
 */
void VecMath_Sub(const float* a, const float* b, float* out, int len);

/**
 * Element-wise multiplication: out[i] = a[i] * b[i]
 */
void VecMath_Mul(const float* a, const float* b, float* out, int len);

/**
 * Scalar multiplication: out[i] = a[i] * scale
 */
void VecMath_Scale(const float* a, float scale, float* out, int len);

/**
 * In-place scalar multiplication: a[i] *= scale
 */
void VecMath_ScaleInPlace(float* a, float scale, int len);

/**
 * Dot product: returns sum of a[i] * b[i]
 */
float VecMath_DotProduct(const float* a, const float* b, int len);

/**
 * Energy (sum of squares): returns sum of a[i] * a[i]
 */
float VecMath_Energy(const float* a, int len);

/**
 * Accumulate: dst[i] += src[i]
 */
void VecMath_Accumulate(float* dst, const float* src, int len);

/**
 * Clear: set all elements to zero
 */
void VecMath_Clear(float* a, int len);

/**
 * Copy: dst[i] = src[i] (memcpy wrapper)
 */
void VecMath_Copy(float* dst, const float* src, int len);

/**
 * Maximum value in array. Returns 0.0f for len <= 0.
 */
float VecMath_Max(const float* a, int len);

/**
 * Minimum value in array. Returns 0.0f for len <= 0.
 */
float VecMath_Min(const float* a, int len);

/**
 * Clamp all values: a[i] = max(min_val, min(a[i], max_val))
 */
void VecMath_Clamp(float* a, float min_val, float max_val, int len);

#ifdef __cplusplus
}
#endif

#endif /* VECTOR_MATH_H_ */
