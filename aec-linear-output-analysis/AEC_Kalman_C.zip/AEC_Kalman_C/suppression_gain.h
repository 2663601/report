/*
 *  SuppressionGain - Pure C Version
 *
 *  Computes the suppression gain for echo removal.
 *  Ported from WebRTC AEC3 C++ SuppressionGain class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  128-point arrays and functions removed — only 512-point path retained.
 *  C99 compatible, no C++ keywords.
 */

#ifndef SUPPRESSION_GAIN_H_
#define SUPPRESSION_GAIN_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "fft_data.h"
#include "render_signal_analyzer.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declarations */
struct AecState_;

/* ================================================================
 * GainParameters - Per-tuning gain curve parameters (512-point only)
 * ================================================================ */
typedef struct {
    float max_inc_factor;
    float max_dec_factor_lf;
    float enr_transparent_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float enr_suppress_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float emr_transparent_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
} GainParameters;

/* ================================================================
 * GainParametersEarphone - Earphone/voip-specific 512fft gain curves
 * Uses different LF/HF boundaries (128/192) vs normal (32/128).
 * ================================================================ */
typedef struct {
    float max_inc_factor;
    float max_dec_factor_lf;
    float enr_transparent_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float enr_suppress_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float emr_transparent_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
} GainParametersEarphone;

/* ================================================================
 * DominantNearendDetector - Inlined in SuppressionGain
 *
 * Continuous-probability version of the C++ binary detector.
 *
 * C++ reference (suppression_gain.cc UpdateLoop_512fft):
 *   - trigger_counter increments when echo_sum < enr_threshold*ne_sum,
 *     fires nearend_state after trigger_threshold consecutive hits,
 *     holds for hold_duration frames, exits early on strong echo.
 *
 * This port keeps all thresholds and time constants equivalent but
 * produces a continuous probability in [0, 1] via log-domain mapping
 * of the ENR ratio and asymmetric IIR smoothing whose rise/fall
 * time constants match trigger_threshold / hold_duration.
 * ================================================================ */
typedef struct {
    float   enr_threshold;       /* 0.25f  — ENR below this => near dominant */
    float   enr_exit_threshold;  /* 10.f   — ENR above this => strong echo   */
    float   snr_threshold;       /* 30.f   — used only in early-exit gate    */
    int     hold_duration;       /* 50     — IIR fall time constant (frames) */
    int     trigger_threshold;   /* 12     — IIR rise time constant (frames) */
    int     use_during_initial_phase;  /* 1 — update during warm-up         */

    /* Continuous nearend-speech probability in [0, 1].
     * Smoothed with asymmetric IIR (fast rise ~192ms, slow fall ~800ms).
     * Primary output; consumers should use this for soft decisions. */
    float   nearend_probability;

    /* Long-term render reference power for p_far silence gate.
     * Slow IIR tracking of far-end active level. */
    float   render_ref_power;

    /* Frames since render became clearly below render_ref_power.
     * Gated by a reverb-tail hangover before p_far may fire, because
     * mic-side echo persists for RT60 after render goes silent and
     * would otherwise be misidentified as nearend. */
    int     render_silent_frames;

    /* Binary state derived from nearend_probability via hysteresis
     * (enter at >= 0.5, leave at < 0.3). Kept for legacy consumers
     * that still need a hard boolean decision. */
    int     nearend_state;

    /* Legacy fields kept only for struct-size / ABI stability.
     * No longer drive detection logic. */
    int     trigger_counter;
    int     hold_counter;
    int     echoend_state;
    int     echoend_trigger_counter;
    int     echoend_hold_counter;
} DominantNearendDetector;

/* ================================================================
 * SuppressionGain
 * ================================================================ */
typedef struct {
    Aec3Config  config;
    int         sample_rate_hz;

    int         state_change_duration_blocks;
    float       one_by_state_change_duration_blocks;

    float       last_gain_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float       last_nearend_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];
    float       last_echo_long[AEC3_FFT_LENGTH_LONG_BY2_PLUS1];

    int         initial_state;
    int         initial_state_change_counter;

    GainParameters nearend_params;
    GainParameters normal_params_512fft;
    GainParametersEarphone normal_params_512fft_earphone;

    DominantNearendDetector dominant_nearend_detector;

    /* Low noise render detector */
    float       low_render_average_power;

    float       avggain_m;
    int         aec_level;
    int         earphone_flag;
    int         voip_flag;
    int         howl_supp;
} SuppressionGain;

/**
 * Initialize the suppression gain module.
 */
void SuppressionGain_Init(SuppressionGain* self, const Aec3Config* config,
                          int sample_rate_hz);

/**
 * Compute the suppression gain (512-point).
 */
void SuppressionGain_GetGain512(SuppressionGain* self,
                                const float* E2,
                                const float* R2,
                                const float* S2_linear,
                                const float* Y2,
                                const struct AecState_* aec_state,
                                const float* render_spectrum,
                                const float* comfort_noise_spectrum,
                                float* gain_out,
                                float* high_bands_gain);

/**
 * Set the initial state flag.
 */
void SuppressionGain_SetInitialState(SuppressionGain* self, int state);

/**
 * Set earphone flag.
 */
void SuppressionGain_SetEarphoneFlag(SuppressionGain* self, int flag);

/**
 * Set voip flag.
 */
void SuppressionGain_SetVoipFlag(SuppressionGain* self, int flag);

/**
 * Set AEC level.
 */
void SuppressionGain_SetLevel(SuppressionGain* self, int level);

#ifdef __cplusplus
}
#endif

#endif /* SUPPRESSION_GAIN_H_ */
