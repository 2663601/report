/*
 *  AecState - Pure C Version
 *
 *  AEC state management: aggregates ERL, ERLE, filter analysis,
 *  double-talk control, reverb estimation, and various sub-state
 *  machines (InitialState, FilterDelay, TransparentMode,
 *  FilteringQualityAnalyzer, SaturationDetector).
 *
 *  Ported from WebRTC AEC3 C++ AecState class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef AEC_STATE_H_
#define AEC_STATE_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "fft_data.h"
#include "subtractor_output.h"
#include "render_buffer.h"
#include "erl_estimator.h"
#include "erle_estimator.h"
#include "filter_analyzer.h"
#include "subtractor_output_analyzer.h"
#include "echo_audibility.h"
#include "dt_control.h"
#include "suppression_gain_limiter.h"
#include "reverb_model_estimator.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * AecState
 * ================================================================ */
typedef struct AecState_ {
    Aec3Config      config;

    /* ---- InitialState (inlined) ---- */
    int             initial_state_active;
    int             initial_transition_triggered;
    int             initial_strong_render_blocks;
    float           initial_state_seconds;
    int             conservative_initial_phase;

    /* ---- FilterDelay (inlined) ---- */
    int             external_delay_reported;
    int             filter_delay_blocks;
    int             delay_headroom_blocks;
    DelayEstimate   external_delay;
    int             has_external_delay;

    /* ---- TransparentMode (inlined) ---- */
    int             transparency_activated;
    int             transparent_capture_block_counter;
    int             transparent_active_blocks_since_sane;
    int             transparent_sane_filter_observed;
    int             transparent_non_converged_seq;
    int             transparent_diverged_seq;
    int             transparent_num_converged;
    int             transparent_strong_render_blocks;

    /* ---- FilteringQualityAnalyzer (inlined) ---- */
    int             usable_linear_estimate;
    int             filter_update_blocks_since_reset;
    int             filter_update_blocks_since_start;
    int             convergence_seen;

    /* ---- SaturationDetector (inlined) ---- */
    int             saturated_echo;
    int             saturated_echo_dt_counter;

    /* ---- Core state ---- */
    ErlEstimator    erl_estimator;
    ErleEstimator   erle_estimator;
    int             strong_not_saturated_render_blocks;
    int             blocks_with_active_render;
    int             capture_signal_saturation;
    float           erl_time_domain_diff;

    SuppressionGainUpperLimiter suppression_gain_limiter;
    FilterAnalyzer  filter_analyzer;
    EchoAudibility  echo_audibility;
    ReverbModelEstimator reverb_model_estimator;
    DtController    dt_controller;
    SubtractorOutputAnalyzer subtractor_output_analyzer;
    float           double_talk_probability;
} AecState;

/**
 * Initialize the AEC state.
 */
void AecState_Init(AecState* self, const Aec3Config* config);

/**
 * Update the AEC state with new data (128-point main path).
 *
 * @param self                  Pointer to AEC state
 * @param external_delay        External delay estimate
 * @param has_external_delay    Whether external delay is valid
 * @param H2                    Filter frequency response [partitions][65]
 * @param H2_partitions         Number of partitions
 * @param h                     Time-domain impulse response
 * @param h_len                 Length of impulse response
 * @param render_buffer         Render buffer
 * @param E2_main               Main error power spectrum (65 floats)
 * @param Y2                    Capture power spectrum (65 floats)
 * @param Y_fft                 Capture FFT data
 * @param E_fft                 Error FFT data
 * @param S_fft                 Echo estimate FFT data
 * @param y                     Time-domain capture (64 samples)
 * @param e                     Time-domain error (64 samples)
 * @param subtractor_output     Subtractor output
 * @param nonlinear_level       Nonlinear suppression level
 * @param audioMixing_flag      Audio mixing flag
 * @param dtd_flag              Double-talk detection flag
 * @param earphone_flag         Earphone mode flag
 * @param submodule_flag        Submodule switch flag
 */
void AecState_Update(AecState* self,
                     const DelayEstimate* external_delay,
                     int has_external_delay,
                     const float (*H2)[AEC3_FFT_LENGTH_BY2_PLUS1],
                     int H2_partitions,
                     const float* h, int h_len,
                     const RenderBuffer* render_buffer,
                     const float* E2_main,
                     const float* Y2,
                     FftData128* Y_fft,
                     FftData128* E_fft,
                     FftData128* S_fft,
                     const float* y,
                     const float* e,
                     const SubtractorOutput* subtractor_output,
                     float nonlinear_level,
                     int audioMixing_flag,
                     int dtd_flag,
                     int earphone_flag,
                     int submodule_flag);

/**
 * Update ERLE with 512-point FFT data.
 */
void AecState_UpdateErle(AecState* self,
                         const SubtractorOutput* subtractor_output,
                         const float* E2_long,
                         const float* Y2_long,
                         const float* X2_long);

/**
 * Update echo saturation detection (512-point).
 */
void AecState_UpdateEchoSaturation(AecState* self,
                                   int capture_signal_saturation,
                                   const float* S2_linear,
                                   const float* E2,
                                   const float* Y2);

/**
 * Handle echo path change.
 */
void AecState_HandleEchoPathChange(AecState* self,
                                   const EchoPathVariability* variability);

/* ---- Accessor functions ---- */

int AecState_UsableLinearEstimate(const AecState* self);
int AecState_UseLinearFilterOutput(const AecState* self);
float AecState_EchoPathGain(const AecState* self);
int AecState_FilterDelayBlocks(const AecState* self);
int AecState_ActiveRender(const AecState* self);
int AecState_TransparentMode(const AecState* self);
int AecState_SaturatedEcho(const AecState* self);
int AecState_SaturatedEcho512fft(const AecState* self);
int AecState_SaturatedCapture(const AecState* self);
void AecState_UpdateCaptureSaturation(AecState* self, int saturation);
float AecState_ReverbDecay(const AecState* self);
const float* AecState_GetReverbFrequencyResponse(const AecState* self);
float AecState_SuppressionGainLimit(const AecState* self);
int AecState_IsSuppressionGainLimitActive(const AecState* self);
int AecState_TransitionTriggered(const AecState* self);
const float* AecState_Erl(const AecState* self);
float AecState_ErlTimeDomain(const AecState* self);
float AecState_ErlTimeDomainDiff(const AecState* self);
const float* AecState_ErleLong(const AecState* self);
const float* AecState_ErleLongGreater(const AecState* self);
int AecState_FilterLengthBlocks(const AecState* self);
int AecState_UseStationaryProperties(const AecState* self);
void AecState_GetResidualEchoScaling(const AecState* self, float* scaling);
float AecState_GetDoubleTalkProbability(const AecState* self);
int AecState_GetEchoState(const AecState* self);
const ControlOperation* AecState_GetOperations(const AecState* self);
float AecState_AccelerateRate(AecState* self);

/**
 * Update reverb decay estimate from PFDKF filter H2 data (512-point).
 *
 * Computes decay from the energy ratio between early and late partitions
 * of the PFDKF adaptive filter's frequency response H2_pf_update.
 *
 * @param self              Pointer to AEC state
 * @param H2_pf_update      Flat array [partition * 257 + bin], 512-point H2
 * @param num_partitions    Number of PFDKF partitions
 */
void AecState_UpdateReverbDecayPfdkf(AecState* self,
                                     const float* H2_pf_update,
                                     int num_partitions);

#ifdef __cplusplus
}
#endif

#endif /* AEC_STATE_H_ */
