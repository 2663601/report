/*
 *  MainFilterUpdateGain - Pure C Implementation
 *
 *  Ported from WebRTC AEC3 C++ MainFilterUpdateGain class.
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  C99 compatible, no C++ keywords. Generic (non-SIMD) implementation.
 */

#include "main_filter_update_gain.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <assert.h>

/* ================================================================
 * Constants matching C++ version
 * ================================================================ */
#define K_H_ERROR_INITIAL           10000.0f
#define K_POOR_EXCITATION_INITIAL   1000

/* ================================================================
 * Internal: UpdateCurrentConfig - smooth config transition
 * ================================================================ */
static void UpdateCurrentConfig(MainFilterUpdateGain* self)
{
    if (self->config_change_counter > 0) {
        if (--self->config_change_counter > 0) {
            float w = (float)self->config_change_counter *
                      self->one_by_config_change_duration_blocks;
            float w1 = 1.0f - w;

            self->current_config.leakage_converged =
                self->old_target_config.leakage_converged * w +
                self->target_config.leakage_converged * w1;
            self->current_config.leakage_diverged =
                self->old_target_config.leakage_diverged * w +
                self->target_config.leakage_diverged * w1;
            self->current_config.error_floor =
                self->old_target_config.error_floor * w +
                self->target_config.error_floor * w1;
            self->current_config.error_ceil =
                self->old_target_config.error_ceil * w +
                self->target_config.error_ceil * w1;
            self->current_config.noise_gate =
                self->old_target_config.noise_gate * w +
                self->target_config.noise_gate * w1;
        } else {
            self->current_config = self->target_config;
            self->old_target_config = self->target_config;
        }
    }
}

/* ================================================================
 * Internal helpers
 * ================================================================ */
static float maxf(float a, float b) { return (a > b) ? a : b; }
static float minf(float a, float b) { return (a < b) ? a : b; }
static int mini(int a, int b) { return (a < b) ? a : b; }

/* ================================================================
 * Public API
 * ================================================================ */

void MainFilterUpdateGain_Init(MainFilterUpdateGain* self,
                               const MainFilterConfig* config,
                               int config_change_duration,
                               const MainFilterConfig* config_after_initial,
                               float* H_error_pfdkf_mem,
                               int aec_H_usage)
{
    assert(self != NULL);
    assert(config != NULL);
    assert(config_after_initial != NULL);
    assert(config_change_duration > 0);
    assert(H_error_pfdkf_mem != NULL);
    assert(aec_H_usage > 0);

    memset(self, 0, sizeof(MainFilterUpdateGain));

    self->config_change_duration_blocks = config_change_duration;
    self->one_by_config_change_duration_blocks = 1.0f / (float)config_change_duration;

    self->current_config = *config;
    self->target_config = *config;
    self->old_target_config = *config;
    self->config_change_counter = 0;

    self->alpha_e = 0.15f;

    self->poor_excitation_counter = K_POOR_EXCITATION_INITIAL;
    self->call_counter = 0;
    self->aec_H_usage = aec_H_usage;
    self->suppress_floor_coeff = 1.0f;  /* default, overridden by config */
    self->pfdkf_partitions_count = 0;

    /* Assign externally allocated H_error_pfdkf memory */
    self->H_error_pfdkf = H_error_pfdkf_mem;
    self->max_pfdkf_partitions = aec_H_usage;

    /* Clear PFDKF state */
    memset(self->H_error_pfdkf, 0,
           aec_H_usage * AEC3_LF_FFT_LENGTH_BY2_PLUS1 * sizeof(float));
    memset(self->E2_smooth_pfdkf, 0, sizeof(self->E2_smooth_pfdkf));
    memset(self->E2_smooth_pfdkf_speed, 0, sizeof(self->E2_smooth_pfdkf_speed));
    memset(self->E2_smooth_pfdkf_speed_suppress, 0,
           sizeof(self->E2_smooth_pfdkf_speed_suppress));
    memset(self->mu_pf, 0, sizeof(self->mu_pf));
    memset(self->mu_speed, 0, sizeof(self->mu_speed));
    memset(self->mu_speed_suppress, 0, sizeof(self->mu_speed_suppress));
    memset(self->conv_ee, 0, sizeof(self->conv_ee));
    memset(self->conv_ee_speed, 0, sizeof(self->conv_ee_speed));
    memset(self->conv_ee_speed_suppress, 0, sizeof(self->conv_ee_speed_suppress));
    memset(self->suppress_gain, 0, sizeof(self->suppress_gain));
}

void MainFilterUpdateGain_HandleEchoPathChange(
    MainFilterUpdateGain* self,
    const EchoPathVariability* echo_path_variability)
{
    int i, k;
    assert(self != NULL);

    if (echo_path_variability->delay_change != 0) {
        /* Reset PFDKF H_error */
        if (self->aec_H_usage > 5) {
            for (k = 0; k < self->pfdkf_partitions_count; ++k) {
                for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
                    self->H_error_pfdkf[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + i] = 0.1f;
                }
            }
        } else {
            for (k = 0; k < self->pfdkf_partitions_count; ++k) {
                for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
                    self->H_error_pfdkf[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + i] = K_H_ERROR_INITIAL;
                }
            }
        }
    }

    if (!echo_path_variability->gain_change) {
        self->poor_excitation_counter = K_POOR_EXCITATION_INITIAL;
        self->call_counter = 0;
    }
}


void MainFilterUpdateGain_SetConfig(MainFilterUpdateGain* self,
                                    const MainFilterConfig* config,
                                    int immediate_effect)
{
    assert(self != NULL);
    assert(config != NULL);

    if (immediate_effect) {
        self->old_target_config = *config;
        self->current_config = *config;
        self->target_config = *config;
        self->config_change_counter = 0;
    } else {
        self->old_target_config = self->current_config;
        self->target_config = *config;
        self->config_change_counter = self->config_change_duration_blocks;
    }
}

void MainFilterUpdateGain_SetAecHUsage(MainFilterUpdateGain* self, int size)
{
    int i, k;
    assert(self != NULL);

    self->aec_H_usage = size;
    self->pfdkf_partitions_count = mini(size, self->max_pfdkf_partitions);

    if (self->aec_H_usage > 5) {
        for (k = 0; k < self->pfdkf_partitions_count; ++k) {
            for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
                self->H_error_pfdkf[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + i] = 0.1f;
            }
        }
    } else {
        for (k = 0; k < self->pfdkf_partitions_count; ++k) {
            for (i = 0; i < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++i) {
                self->H_error_pfdkf[k * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + i] = K_H_ERROR_INITIAL;
            }
        }
    }
}

/* ================================================================
 * ComputePfdkf: PFDKF Kalman gain computation
 *
 * Ported from C++ MainFilterUpdateGain::ComputePfdkf().
 * Computes per-partition Kalman gains for PFDKF adaptive filter.
 * ================================================================ */
void MainFilterUpdateGain_ComputePfdkf(
    MainFilterUpdateGain* self,
    const RenderBuffer* render_buffer,
    SubtractorOutputFrequency* output,
    const AdaptiveFirFilter* filter,
    FftDataPfdkf* G_pfdkf,
    FftDataPfdkf* G_pfdkf_speed,
    const float* E2_fix,
    const float* E2_fix_suppress,
    int earphone_flag)
{
    int i, k;
    const int size_partitions = mini(filter->pfdkf_partitions_count,
                                     self->aec_H_usage);
    FftDataPfdkf* E = &output->E_out;
    float* E2 = output->E2_out;
    const float* H2 = filter->H2_pf_update;
    float tmp_max_suppress;
    float tmp_scale;

    assert(self != NULL);
    assert(render_buffer != NULL);
    assert(output != NULL);
    assert(filter != NULL);
    assert(G_pfdkf != NULL);
    assert(G_pfdkf_speed != NULL);

    self->call_counter++;

    /* Input NaN check */
    {
        static int input_nan_logged = 0;
        if (!input_nan_logged) {
            int found_nan = 0;
            for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1 && !found_nan; ++k) {
                if (!isfinite(E2[k]) || !isfinite(E->relf[k]) || !isfinite(E->imlf[k])) {
                    fprintf(stderr, "[NaN] ComputePfdkf INPUT: call=%d k=%d E2=%.6g E_re=%.6g E_im=%.6g\n",
                            self->call_counter, k, E2[k], E->relf[k], E->imlf[k]);
                    found_nan = 1;
                    input_nan_logged = 1;
                }
            }
            for (i = 0; i < size_partitions && !found_nan; ++i) {
                for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1 && !found_nan; ++k) {
                    if (!isfinite(H2[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k])) {
                        fprintf(stderr, "[NaN] ComputePfdkf INPUT: call=%d H2[%d][%d]=%.6g\n",
                                self->call_counter, i, k,
                                H2[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k]);
                        found_nan = 1;
                        input_nan_logged = 1;
                    }
                }
            }
        }
    }

    /* ---- Step 1: Accumulate covariance error spectrum ---- */
    memset(self->conv_ee, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memset(self->conv_ee_speed, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    memset(self->conv_ee_speed_suppress, 0, sizeof(float) * AEC3_LF_FFT_LENGTH_BY2_PLUS1);
    for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
        self->suppress_gain[k] = 1.0f;
    }

    for (i = 0; i < size_partitions; ++i) {
        const float* X2 = RenderBuffer_SpectrumPfdkf(render_buffer,
                                                      AEC3_LF_BLOCK_SHIFT * i);
        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            self->conv_ee[k] += 0.5f * X2[k] *
                self->H_error_pfdkf[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k];
        }
    }

    /* ---- Step 2: Smooth E2 and build denominators ---- */
    for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
        self->conv_ee_speed_suppress[k] = self->conv_ee[k];
        self->conv_ee_speed[k] = self->conv_ee[k];

        self->E2_smooth_pfdkf[k] =
            0.85f * self->E2_smooth_pfdkf[k] + 0.15f * E2[k];
        self->E2_smooth_pfdkf_speed[k] =
            0.85f * self->E2_smooth_pfdkf_speed[k] + 0.15f * E2_fix[k];
        self->E2_smooth_pfdkf_speed_suppress[k] =
            0.85f * self->E2_smooth_pfdkf_speed_suppress[k] + 0.15f * E2_fix_suppress[k];

        self->conv_ee[k] += self->E2_smooth_pfdkf[k] + 1e-8f;
        self->conv_ee_speed[k] += self->E2_smooth_pfdkf_speed[k] + 1e-8f;
        self->conv_ee_speed_suppress[k] += self->E2_smooth_pfdkf_speed_suppress[k] + 1e-8f;
    }

    /* ---- Step 3: Per-partition gain computation ---- */
    for (i = 0; i < size_partitions; ++i) {
        const float* X2 = RenderBuffer_SpectrumPfdkf(render_buffer,
                                                      AEC3_LF_BLOCK_SHIFT * i);
        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            float noise_gate = 15438.0f;
            float H_err = self->H_error_pfdkf[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k];

            /* mu for main gain */
            self->mu_pf[k] = (X2[k] > noise_gate)
                ? 0.5f * H_err / self->conv_ee[k]
                : 0.0f;

            /* mu for speed gain (three-tier noise gate) */
            if (X2[k] < 15438.0f) {
                self->mu_speed[k] = 0.0f;
                self->mu_speed_suppress[k] = 0.0f;
            } else if (X2[k] < 1543800.0f) {
                self->mu_speed[k] = 0.0f;
                self->mu_speed_suppress[k] =
                    0.5f * H_err / self->conv_ee_speed_suppress[k];
            } else {
                self->mu_speed[k] =
                    0.5f * H_err / self->conv_ee_speed[k];
                self->mu_speed_suppress[k] =
                    0.5f * H_err / self->conv_ee_speed_suppress[k];
            }

            /* NaN/Inf guard */
            if (!isfinite(self->mu_pf[k]) || !isfinite(self->mu_speed[k])
                || !isfinite(self->mu_speed_suppress[k])) {
                static int nan_count = 0;
                if (nan_count < 5) {
                    fprintf(stderr, "[NaN] ComputePfdkf: call=%d part=%d k=%d "
                        "mu_pf=%.6g mu_speed=%.6g mu_sup=%.6g "
                        "H_err=%.6g conv_ee=%.6g conv_sp=%.6g conv_sps=%.6g "
                        "X2=%.6g E2[k]=%.6g H2=%.6g\n",
                        self->call_counter, i, k,
                        self->mu_pf[k], self->mu_speed[k], self->mu_speed_suppress[k],
                        H_err, self->conv_ee[k],
                        self->conv_ee_speed[k], self->conv_ee_speed_suppress[k],
                        X2[k], E2[k],
                        H2[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k]);
                    nan_count++;
                }
                self->mu_pf[k] = 0.0f;
                self->mu_speed[k] = 0.0f;
                self->mu_speed_suppress[k] = 0.0f;
            }

            /* Update H_error_pfdkf: Kalman covariance update */
            H_err = (1.0f - 0.5f * self->mu_pf[k] * X2[k]) * H_err
                + 0.0199f * H2[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k];
            H_err = maxf(H_err, 0.003f);
            H_err = minf(H_err, 20.0f);
            self->H_error_pfdkf[i * AEC3_LF_FFT_LENGTH_BY2_PLUS1 + k] = H_err;

            /* Accumulate suppress_gain */
            self->suppress_gain[k] -= self->mu_speed_suppress[k] * X2[k];
        }

        /* G_pfdkf[i] = mu_pf * E_out (relf/imlf domain) */
        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            G_pfdkf[i].relf[k] = self->mu_pf[k] * E->relf[k];
            G_pfdkf[i].imlf[k] = self->mu_pf[k] * E->imlf[k];
        }

        /* G_pfdkf_speed[i] = mu_speed * E_out (relf/imlf domain) */
        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            G_pfdkf_speed[i].relf[k] = self->mu_speed[k] * E->relf[k];
            G_pfdkf_speed[i].imlf[k] = self->mu_speed[k] * E->imlf[k];
        }
    }

    /* ---- Step 4: Post-process suppress_gain ---- */
    /* Two-dimensional nearend detection for better double-talk protection:
     * Dim1: coherence-based (ne_indicator ≈ 1-coherence) — echo vs nearend
     * Dim2: E2/Y2 ratio — nearend presence indicator
     * Geometric mean ensures both dimensions must agree before protection. */
    {
        float suppress_floor_k;

        tmp_max_suppress = 0.0f;
        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            /* Dim1: coherence-based nearend indicator */
            float ne_coh = E2_fix_suppress[k] / (E2[k] + 1e-10f);
            ne_coh = minf(ne_coh, 1.0f);

            /* Dim2: E2/Y2 ratio — high when nearend is present in error */
            float ey_ratio = E2[k] / (output->Y2[k] + 1e-10f);
            ey_ratio = minf(ey_ratio, 1.0f);

            /* Geometric mean of two dimensions */
            float combined = sqrtf(ne_coh * ey_ratio);

            /* Quadratic mapping: combined^2 * suppress_floor_coeff */
            suppress_floor_k = combined * combined * self->suppress_floor_coeff;

            self->suppress_gain[k] = maxf(self->suppress_gain[k], suppress_floor_k);
            if (k > 0 && k < 16) {
                tmp_max_suppress = maxf(tmp_max_suppress, self->suppress_gain[k]);
            }
        }
        for (k = 1; k < 16; ++k) {
            self->suppress_gain[k] = 0.5f * (tmp_max_suppress + self->suppress_gain[k]);
        }
    }

    /* ---- Step 5: Apply suppress_gain to E_out (unless earphone mode) ---- */
    if (!earphone_flag) {
        for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
            E->relf[k] *= self->suppress_gain[k];
            E->imlf[k] *= self->suppress_gain[k];
        }
    }

    /* ---- Step 6: Recompute E2_out and scale E_out if E2 > Y2 ---- */
    FftDataPfdkf_Spectrum(E, E2);
    for (k = 0; k < AEC3_LF_FFT_LENGTH_BY2_PLUS1; ++k) {
        if (E2[k] > output->Y2[k]) {
            tmp_scale = sqrtf(output->Y2[k] / (E2[k] + 1e-10f));
            E->relf[k] *= tmp_scale;
            E->imlf[k] *= tmp_scale;
        }
    }
}
