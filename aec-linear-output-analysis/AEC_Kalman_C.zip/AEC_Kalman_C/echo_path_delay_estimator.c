/*
 *  Echo Path Delay Estimator - Pure C Version
 *
 *  Ported from WebRTC AEC3 C++ echo_path_delay_estimator.cc
 *  Original copyright (c) 2017 The WebRTC project authors.
 *
 *  Coordinates matched filter, binary spectral correlation, and GCC
 *  delay estimation methods.
 */

#include "echo_path_delay_estimator.h"
#include "aec3_config.h"

#include <math.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

/* ================================================================
 * ClockdriftDetector implementation
 * ================================================================ */

void ClockdriftDetector_Init(ClockdriftDetector* self)
{
    assert(self != NULL);
    self->delay_history[0] = 0;
    self->delay_history[1] = 0;
    self->delay_history[2] = 0;
    self->level = CLOCKDRIFT_NONE;
    self->stability_counter = 0;
}

void ClockdriftDetector_Update(ClockdriftDetector* self, int delay_estimate)
{
    int d1, d2, d3;
    int probable_drift_up, drift_up;
    int probable_drift_down, drift_down;

    assert(self != NULL);

    if (delay_estimate == self->delay_history[0]) {
        if (++self->stability_counter > 7500) {
            self->level = CLOCKDRIFT_NONE;
        }
        return;
    }

    self->stability_counter = 0;
    d1 = self->delay_history[0] - delay_estimate;
    d2 = self->delay_history[1] - delay_estimate;
    d3 = self->delay_history[2] - delay_estimate;

    probable_drift_up = (d1 == -1 && d2 == -2) || (d1 == -2 && d2 == -1);
    drift_up = probable_drift_up && (d3 == -3);

    probable_drift_down = (d1 == 1 && d2 == 2) || (d1 == 2 && d2 == 1);
    drift_down = probable_drift_down && (d3 == 3);

    if (drift_up || drift_down) {
        self->level = CLOCKDRIFT_VERIFIED;
    } else if ((probable_drift_up || probable_drift_down) &&
               self->level == CLOCKDRIFT_NONE) {
        self->level = CLOCKDRIFT_PROBABLE;
    }

    self->delay_history[2] = self->delay_history[1];
    self->delay_history[1] = self->delay_history[0];
    self->delay_history[0] = delay_estimate;
}

/* ================================================================
 * Binary delay estimator helpers
 * ================================================================ */

static void AddFarendFFT(BinaryDelayEstimator* binary,
                          const float* cur_farend_fft)
{
    const float kScale = 1.0f / 64.0f;
    int i;

    /* Shift history: move all entries one position forward */
    memmove(&binary->farend_history_fft[1 * AEC3_FFT_LENGTH_BY2_PLUS1],
            &binary->farend_history_fft[0 * AEC3_FFT_LENGTH_BY2_PLUS1],
            (size_t)(binary->history_size - 1) * sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);

    memcpy(&binary->farend_history_fft[0],
           cur_farend_fft,
           sizeof(float) * AEC3_FFT_LENGTH_BY2_PLUS1);

    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; ++i) {
        binary->farend_longtimefft[i] +=
            (cur_farend_fft[i] - binary->farend_longtimefft[i]) * kScale;
    }
}

static int GetSpecCorPos(int x_start_index,
                          BinaryDelayEstimator* binary,
                          int delay_stable,
                          int aec_H_usage)
{
    int block_size, k, i, j, tk;
    float near_specavg, recip_bandw;
    float nearend_fft_cur[AEC3_FFT_LENGTH_BY2_PLUS1];
    int bandw = BINARY_BAND_HIGH - BINARY_BAND_LOW;
    float shift_factor;
    int best_candidate;
    float value_best_candidate, value_worst_candidate, valley_depth;
    int valid_candidate;
    int candidate_valid;

    block_size = binary->history_size;

    k = x_start_index % binary->history_size;

    /* Compute near-end spectral average */
    near_specavg = 0.0f;
    for (j = BINARY_BAND_LOW; j < BINARY_BAND_HIGH; ++j) {
        near_specavg += binary->nearend_fft[j];
    }
    near_specavg /= (float)bandw;

    memset(nearend_fft_cur, 0, sizeof(nearend_fft_cur));
    for (j = BINARY_BAND_LOW; j < BINARY_BAND_HIGH; ++j) {
        nearend_fft_cur[j] = binary->nearend_fft[j] - near_specavg;
    }

    recip_bandw = 1.0f / (float)bandw;

    for (i = 1; i < block_size; ++i) {
        float d_sum = 0.0f, x_sum = 0.0f, far_specavg = 0.0f;
        float best_value = binary->xd_spec_cor[binary->best_pos];
        float xd_fft_val = 0.0f;

        tk = k * AEC3_FFT_LENGTH_BY2_PLUS1;

        for (j = BINARY_BAND_LOW; j < BINARY_BAND_HIGH; ++j) {
            far_specavg += binary->farend_history_fft[tk + j];
        }
        far_specavg *= recip_bandw;

        for (j = BINARY_BAND_LOW; j < BINARY_BAND_HIGH; ++j) {
            float far_spec = binary->farend_history_fft[tk + j] - far_specavg;
            float product = far_spec * nearend_fft_cur[j];
            xd_fft_val += (float)fabs(product);
            x_sum += far_spec * far_spec;
            d_sum += nearend_fft_cur[j] * nearend_fft_cur[j];
        }

        xd_fft_val /= ((float)sqrt(x_sum) * (float)sqrt(d_sum) + 1e-6f);

        if (x_sum > 10000.0f && xd_fft_val > best_value) {
            shift_factor = 0.1f;
        } else {
            shift_factor = 0.01f;
        }
        if (x_sum < 500.0f * bandw) {
            shift_factor = 0.0f;
        }
        if (binary->xd_spec_cor[i] > xd_fft_val) {
            shift_factor *= 0.1f;
        }

        binary->xd_spec_cor[i] = binary->xd_spec_cor[i] * (1.0f - shift_factor) +
                                  xd_fft_val * shift_factor;

        k = (k + 1) % binary->history_size;
    }

    /* Find best candidate */
    best_candidate = 0;
    value_best_candidate = 0.0f;
    value_worst_candidate = 1.0f;
    for (i = 1; i < block_size; ++i) {
        if (value_best_candidate < binary->xd_spec_cor[i]) {
            value_best_candidate = binary->xd_spec_cor[i];
            best_candidate = i;
        }
        if (value_worst_candidate > binary->xd_spec_cor[i]) {
            value_worst_candidate = binary->xd_spec_cor[i];
        }
    }

    valley_depth = value_best_candidate - value_worst_candidate;
    candidate_valid = 0;

    if (!delay_stable) {
        candidate_valid = (value_best_candidate > 0.80f && valley_depth > 0.2f) ||
                          (value_best_candidate > 0.85f && valley_depth > 0.15f);
    } else {
        candidate_valid = (value_best_candidate > 0.95f && valley_depth > 0.2f);
    }

    if (candidate_valid) {
        if (best_candidate != binary->best_pos) {
            if (value_best_candidate >
                binary->xd_spec_cor[binary->best_pos] + 0.15f) {
                valid_candidate = 1;
            } else {
                valid_candidate = 0;
            }
            binary->continue_cnt = 0;
        } else {
            if (binary->last_valid != 1.0f) {
                if (binary->continue_cnt++ > 10) {
                    valid_candidate = 1;
                } else {
                    valid_candidate = 0;
                }
            } else {
                valid_candidate = 1;
            }
        }
    } else {
        valid_candidate = 0;
    }

    binary->probability = (float)valid_candidate;
    binary->last_valid = (float)valid_candidate;

    {
        if (best_candidate > 2 && best_candidate < binary->history_size) {
            binary->best_pos = best_candidate;
        } else {
            binary->probability = 0.0f;
        }
    }

    return binary->best_pos;
}

/* ================================================================
 * BinaryEstimateDelay - Spectral + GCC delay estimation
 * ================================================================ */
static int BinaryEstimateDelay(EchoPathDelayEstimator* self,
                                const DownsampledRenderBuffer* render_buffer,
                                const float* capture, int capture_len,
                                int voip_mode_enable,
                                int delay_default,
                                int aec_low_compute_mode)
{
    FftData128 Y;
    float Y2[AEC3_FFT_LENGTH_BY2_PLUS1];
    float abs_near_spectrum[AEC3_FFT_LENGTH_BY2_PLUS1];
    int i, start_index;
    int delay_stable;

    /* Compute capture FFT (windowed padded: y_old[64] + capture[64]) */
    Aec3Fft_PaddedFft128_typed(&self->fft, capture, self->y_old,
                          AEC3_WINDOW_SQRT_HANNING, &Y);
    memcpy(self->y_old, capture,
           sizeof(float) * (capture_len < AEC3_FFT_LENGTH_BY2 ? capture_len : AEC3_FFT_LENGTH_BY2));

    FftData128_Spectrum(&Y, Y2);
    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; ++i) {
        abs_near_spectrum[i] = (float)sqrt(Y2[i]);
    }

    /* Update binary estimator nearend spectrum */
    {
        const float kScale = 1.0f / (float)AEC3_FFT_LENGTH_BY2;
        for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; ++i) {
            self->binary_estimator.nearend_fft[i] = abs_near_spectrum[i];
            self->binary_estimator.nearend_longtime_fft[i] +=
                (abs_near_spectrum[i] - self->binary_estimator.nearend_longtime_fft[i]) * kScale;
        }
    }

    /* Compute start index */
    if (render_buffer->write <= render_buffer->read) {
        start_index = render_buffer->read - render_buffer->write;
    } else {
        start_index = render_buffer->read + render_buffer->size - render_buffer->write;
    }
    start_index += delay_default * 4;

    delay_stable = self->lag_aggregator.delay_stable;
    GetSpecCorPos(start_index / 16, &self->binary_estimator, delay_stable,
                  self->aec_H_usage);

    /* Binary probability check - return block-level delay */
    if (self->binary_estimator.probability > 0.0f) {
        return self->binary_estimator.best_pos - 1;
    }

    return 0;
}

/* ================================================================
 * Public API
 * ================================================================ */

int BinaryDelayEstimator_GetDynMemSize(int render_buffer_size)
{
    int hist_fft = render_buffer_size * AEC3_FFT_LENGTH_BY2_PLUS1 * (int)sizeof(float);
    int xd_cor   = render_buffer_size * (int)sizeof(float);
    return hist_fft + xd_cor;
}

void EchoPathDelayEstimator_Init(EchoPathDelayEstimator* self,
                                 const Aec3Config* config,
                                 int render_buffer_size,
                                 float* binary_dyn_mem)
{
    DelaySelectionThresholds thresholds;
    float excitation_limit;

    assert(self != NULL);
    assert(config != NULL);

    self->down_sampling_factor = config->delay_down_sampling_factor;
    self->sub_block_size = (self->down_sampling_factor != 0)
        ? AEC3_BLOCK_SIZE / self->down_sampling_factor
        : AEC3_BLOCK_SIZE;

    Decimator_Init(&self->capture_decimator, self->down_sampling_factor);

    excitation_limit = (config->delay_down_sampling_factor == 8)
        ? config->render_levels_poor_excitation_render_limit_ds8
        : config->render_levels_poor_excitation_render_limit;

    MatchedFilter_Init(&self->matched_filter,
                       self->sub_block_size,
                       AEC3_MATCHED_FILTER_WINDOW_SIZE_SUB_BLOCKS,
                       config->delay_num_filters,
                       AEC3_MATCHED_FILTER_ALIGNMENT_SHIFT_SUB_BLOCKS,
                       excitation_limit,
                       config->delay_estimate_smoothing,
                       config->delay_candidate_detection_threshold);

    thresholds.initial = config->delay_selection_thresholds_initial;
    thresholds.converged = config->delay_selection_thresholds_converged;

    MatchedFilterLagAggregator_Init(&self->lag_aggregator,
                                    MatchedFilter_GetMaxFilterLag(&self->matched_filter),
                                    &thresholds);

    self->has_old_aggregated_lag = 0;
    self->consistent_estimate_counter = 0;

    ClockdriftDetector_Init(&self->clockdrift_detector);

    /* Initialize binary delay estimator with dynamic memory */
    self->binary_estimator.history_size = render_buffer_size;
    self->binary_estimator.farend_history_fft = binary_dyn_mem;
    self->binary_estimator.xd_spec_cor = binary_dyn_mem +
        render_buffer_size * AEC3_FFT_LENGTH_BY2_PLUS1;
    self->binary_estimator.best_pos = 0;
    self->binary_estimator.continue_cnt = 0;
    self->binary_estimator.probability = 0.0f;
    self->binary_estimator.last_valid = 0.0f;
    memset(self->binary_estimator.farend_history_fft, 0,
           sizeof(float) * (size_t)render_buffer_size * AEC3_FFT_LENGTH_BY2_PLUS1);
    memset(self->binary_estimator.xd_spec_cor, 0,
           sizeof(float) * (size_t)render_buffer_size);
    memset(self->binary_estimator.farend_longtimefft, 0, sizeof(self->binary_estimator.farend_longtimefft));
    memset(self->binary_estimator.nearend_fft, 0, sizeof(self->binary_estimator.nearend_fft));
    memset(self->binary_estimator.nearend_longtime_fft, 0, sizeof(self->binary_estimator.nearend_longtime_fft));

    /* Initialize FFT */
    Aec3Fft_Init(&self->fft);
    memset(self->y_old, 0, sizeof(self->y_old));
    memset(self->x_old, 0, sizeof(self->x_old));

    memset(self->histogram0, 0, sizeof(self->histogram0));
    memset(self->histogram_data0, 0, sizeof(self->histogram_data0));
    self->histogram_data_index0 = 0;

    self->aec_H_usage = 0;
}

void EchoPathDelayEstimator_Reset(EchoPathDelayEstimator* self,
                                  int reset_delay_confidence)
{
    assert(self != NULL);

    MatchedFilterLagAggregator_Reset(&self->lag_aggregator, reset_delay_confidence);
    MatchedFilter_Reset(&self->matched_filter);
    self->has_old_aggregated_lag = 0;
    self->consistent_estimate_counter = 0;
}

void EchoPathDelayEstimator_SetAecHUsage(EchoPathDelayEstimator* self,
                                         int size)
{
    assert(self != NULL);
    self->aec_H_usage = size;
    MatchedFilterLagAggregator_SetAecHUsage(&self->lag_aggregator, size);
}

void EchoPathDelayEstimator_BufferRenderSpec(EchoPathDelayEstimator* self,
                                             const float* far_spectrum,
                                             int spectrum_len)
{
    float abs_far_spectrum[AEC3_FFT_LENGTH_BY2_PLUS1];
    int i;
    int len = (spectrum_len < AEC3_FFT_LENGTH_BY2_PLUS1)
              ? spectrum_len : AEC3_FFT_LENGTH_BY2_PLUS1;

    assert(self != NULL);

    for (i = 0; i < len; ++i) {
        abs_far_spectrum[i] = (float)sqrt(far_spectrum[i]);
    }
    AddFarendFFT(&self->binary_estimator, abs_far_spectrum);
}

void EchoPathDelayEstimator_BufferRenderBlock(EchoPathDelayEstimator* self,
                                              const float* far_block,
                                              int block_len)
{
    FftData128 X;
    float far_spectrum[AEC3_FFT_LENGTH_BY2_PLUS1];
    float abs_far_spectrum[AEC3_FFT_LENGTH_BY2_PLUS1];
    int i;

    assert(self != NULL);

    /* Windowed padded FFT of render block */
    Aec3Fft_PaddedFft128_typed(&self->fft, far_block, self->x_old,
                          AEC3_WINDOW_SQRT_HANNING, &X);
    memcpy(self->x_old, far_block,
           sizeof(float) * (block_len < AEC3_FFT_LENGTH_BY2 ? block_len : AEC3_FFT_LENGTH_BY2));

    FftData128_Spectrum(&X, far_spectrum);
    for (i = 0; i < AEC3_FFT_LENGTH_BY2_PLUS1; ++i) {
        abs_far_spectrum[i] = (float)sqrt(far_spectrum[i]);
    }
    AddFarendFFT(&self->binary_estimator, abs_far_spectrum);
}

int EchoPathDelayEstimator_EstimateDelay(
    EchoPathDelayEstimator* self,
    const DownsampledRenderBuffer* render_buffer,
    const float* capture, int capture_len,
    int earphone_flag,
    int voip_mode_enable,
    int delay_default,
    int CastScreen,
    int matched_filter_enable_flag,
    int aec_low_compute_mode,
    DelayEstimate* out_delay)
{
    int delay_estimate = 0;
    int has_aggregated = 0;
    DelayEstimate aggregated_lag;

    assert(self != NULL);
    assert(capture_len == AEC3_BLOCK_SIZE);

    /* Run matched filter if enabled */
    if (matched_filter_enable_flag || CastScreen) {
        float downsampled_capture[AEC3_BLOCK_SIZE];
        Decimator_Decimate(&self->capture_decimator,
                           capture, downsampled_capture, capture_len);
        MatchedFilter_Update(&self->matched_filter,
                             render_buffer, downsampled_capture,
                             self->sub_block_size, delay_default);
    }

    /* Run binary spectral delay estimation */
    if (!CastScreen) {
        delay_estimate = BinaryEstimateDelay(self, render_buffer, capture,
                                              capture_len, voip_mode_enable,
                                              delay_default, aec_low_compute_mode);
    }

    /* Dump matched filter and binary delay results to PCM files */
    if (access("enable_vqe_dump", 0) == 0)
    {
        static FILE* fp_mf = NULL;
        static FILE* fp_bin = NULL;
        static int dump_init = 0;
        if (!dump_init) {
            fp_mf = fopen("delay_matched_filter.pcm", "wb");
            fp_bin = fopen("delay_binary.pcm", "wb");
            dump_init = 1;
        }
        /* Matched filter: best reliable lag converted to ms */
        if (fp_mf) {
            int best_mf_lag = 0;
            short val;
            int di;
            if (matched_filter_enable_flag || CastScreen) {
                float best_acc = 0.f;
                int k;
                for (k = 0; k < self->matched_filter.num_filters; k++) {
                    if (self->matched_filter.lag_estimates[k].updated &&
                        self->matched_filter.lag_estimates[k].reliable &&
                        self->matched_filter.lag_estimates[k].accuracy > best_acc) {
                        best_acc = self->matched_filter.lag_estimates[k].accuracy;
                        best_mf_lag = self->matched_filter.lag_estimates[k].lag;
                    }
                }
            }
            val = (short)(best_mf_lag * self->down_sampling_factor * 1000 / 16000);
            for (di = 0; di < AEC3_BLOCK_SIZE; di++)
                fwrite(&val, sizeof(short), 1, fp_mf);
        }
        /* Binary: delay_estimate in blocks * 4ms */
        if (fp_bin) {
            short val = (short)(delay_estimate * 4);
            int di;
            for (di = 0; di < AEC3_BLOCK_SIZE; di++)
                fwrite(&val, sizeof(short), 1, fp_bin);
        }
    }

    /* Aggregate delay estimates */
    memset(&aggregated_lag, 0, sizeof(aggregated_lag));

    if (matched_filter_enable_flag || CastScreen) {
        has_aggregated = MatchedFilterLagAggregator_Aggregate(
            &self->lag_aggregator,
            self->matched_filter.lag_estimates,
            self->matched_filter.num_filters,
            delay_estimate,
            1, /* earphone_flag always 1 in C++ */
            voip_mode_enable && !CastScreen,
            &aggregated_lag);
    } else {
        has_aggregated = MatchedFilterLagAggregator_AggregateBinary(
            &self->lag_aggregator,
            delay_estimate,
            voip_mode_enable,
            &aggregated_lag);
    }

    /* Run clockdrift detection */
    if (has_aggregated && aggregated_lag.quality == 1) {
        ClockdriftDetector_Update(&self->clockdrift_detector,
                                  aggregated_lag.delay);
    }

    /* Scale delay by downsampling factor */
    if (has_aggregated) {
        aggregated_lag.delay *= self->down_sampling_factor;
    }

    /* Track consistency */
    if (self->has_old_aggregated_lag && has_aggregated &&
        self->old_aggregated_lag.delay == aggregated_lag.delay) {
        ++self->consistent_estimate_counter;
    } else {
        self->consistent_estimate_counter = 0;
    }

    if (has_aggregated) {
        self->old_aggregated_lag = aggregated_lag;
        self->has_old_aggregated_lag = 1;
    }

    /* Soft reset after sustained consistency */
    if (self->consistent_estimate_counter > AEC3_NUM_BLOCKS_PER_SECOND / 2) {
        MatchedFilter_Reset(&self->matched_filter);
        self->has_old_aggregated_lag = 0;
        self->consistent_estimate_counter = 0;
    }

    if (has_aggregated && out_delay != NULL) {
        *out_delay = aggregated_lag;
    }

    return has_aggregated;
}

int EchoPathDelayEstimator_GetClockdriftLevel(const EchoPathDelayEstimator* self)
{
    assert(self != NULL);
    return self->clockdrift_detector.level;
}
