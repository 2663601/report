/*
 *  Matched Filter Lag Aggregator - Pure C Version
 *
 *  Aggregates lag estimates produced by the MatchedFilter into a single
 *  reliable combined lag estimate using histogram-based voting.
 *
 *  Ported from WebRTC AEC3 C++ implementation.
 *  Original copyright (c) 2017 The WebRTC project authors.
 */

#ifndef MATCHED_FILTER_LAG_AGGREGATOR_H_
#define MATCHED_FILTER_LAG_AGGREGATOR_H_

#include "aec3_common.h"
#include "matched_filter.h"
#include "subtractor_output.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Maximum histogram size: must cover the max possible lag */
#define MF_LAG_AGGREGATOR_MAX_HISTOGRAM     2500
#define MF_LAG_AGGREGATOR_HISTORY_SIZE      2500

/* ================================================================
 * DelaySelectionThresholds - Thresholds for delay candidate selection
 * ================================================================ */
typedef struct {
    int     initial;        /* Threshold before convergence */
    int     converged;      /* Threshold after convergence */
} DelaySelectionThresholds;

/* ================================================================
 * MatchedFilterLagAggregator
 *
 * Uses a histogram to accumulate lag estimates over time.
 * The most frequent lag that exceeds the threshold is selected.
 * ================================================================ */
typedef struct {
    int     histogram[MF_LAG_AGGREGATOR_MAX_HISTOGRAM];
    int     histogram_size;     /* Actual histogram size (max_filter_lag + 1) */
    int     histogram_data[MF_LAG_AGGREGATOR_HISTORY_SIZE];
    int     histogram_data_index;
    int     significant_candidate_found;
    int     candidate_last;
    int     delay_stable;

    DelaySelectionThresholds thresholds;
    int     aec_H_usage;
} MatchedFilterLagAggregator;

/**
 * Initialize the lag aggregator.
 *
 * @param self              Pointer to aggregator
 * @param max_filter_lag    Maximum lag from the matched filter
 * @param thresholds        Delay selection thresholds
 */
void MatchedFilterLagAggregator_Init(MatchedFilterLagAggregator* self,
                                     int max_filter_lag,
                                     const DelaySelectionThresholds* thresholds);

/**
 * Reset the aggregator.
 *
 * @param self          Pointer to aggregator
 * @param hard_reset    If true, also reset significant_candidate_found
 */
void MatchedFilterLagAggregator_Reset(MatchedFilterLagAggregator* self,
                                      int hard_reset);

/**
 * Set aec_H_usage parameter.
 */
void MatchedFilterLagAggregator_SetAecHUsage(MatchedFilterLagAggregator* self,
                                             int size);

/**
 * Aggregate lag estimates from matched filters and binary delay estimator.
 *
 * @param self              Pointer to aggregator
 * @param lag_estimates     Array of lag estimates from MatchedFilter
 * @param num_estimates     Number of lag estimates
 * @param delay_estimate    Binary delay estimate (0 if none)
 * @param earphone_flag     Earphone mode flag
 * @param voip_mode_enable  VoIP mode flag
 * @param out_delay         Output: aggregated delay estimate
 * @return                  1 if a valid delay was produced, 0 otherwise
 */
int MatchedFilterLagAggregator_Aggregate(
    MatchedFilterLagAggregator* self,
    const MatchedFilterLagEstimate* lag_estimates, int num_estimates,
    int delay_estimate,
    int earphone_flag,
    int voip_mode_enable,
    DelayEstimate* out_delay);

/**
 * Aggregate using only binary delay estimate (no matched filter).
 *
 * @param self              Pointer to aggregator
 * @param delay_estimate    Binary delay estimate
 * @param voip_mode_enable  VoIP mode flag
 * @param out_delay         Output: aggregated delay estimate
 * @return                  1 if a valid delay was produced, 0 otherwise
 */
int MatchedFilterLagAggregator_AggregateBinary(
    MatchedFilterLagAggregator* self,
    int delay_estimate,
    int voip_mode_enable,
    DelayEstimate* out_delay);

#ifdef __cplusplus
}
#endif

#endif /* MATCHED_FILTER_LAG_AGGREGATOR_H_ */
