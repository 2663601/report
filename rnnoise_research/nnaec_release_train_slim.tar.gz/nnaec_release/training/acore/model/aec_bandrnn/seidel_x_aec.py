#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SeidelX-AEC — Seidel(NSNet2 FC+GRU) 的结构增强版, 与原 seidel_aec.py 完全隔离。

在原 Seidel 骨架 (FC + 时间GRU + dense) 基础上, 用三个**可独立开关**的模块做创新:
  1. use_dualpath   : 频率轴 GRU(band 维双路 RNN)  —— 配 band 64 才有意义(频率轴够长)
  2. use_se_attn    : SE-style band 注意力(逐 band 门控)
  3. use_farmod_attn: 远端调制注意力(用输入里的远端 fx 这一路, AEC 任务感知)

设计原则(对齐 docs/06_aec/seidel结构创新设计.md):
  - 全部拆成 Linear(dense) / GRU / sigmoid / 逐点乘 四种基元, 对标 rnnoise 手写 C 的
    compute_dense + compute_gru + 逐点乘, 不引入新算子类型, int8+sparse 友好。
  - 频率轴 GRU 是"帧内沿 band 的循环", 隐藏态每帧重置, 不跨帧(手写 C 里多一层 for 循环)。
  - 三个开关默认全开, 但可单独关掉做消融; 全关 ≈ 退化回原 Seidel(仅隐藏维可能不同)。

forward 返回 (band_gain, hidden), 与 system_bandaec 的 "seidel" 分支签名一致
(system 用 model_type="seidel_x" 时也走两元组 else 分支, 无需改 system)。

输入 feat: [B, T, nbands*3]  = cat(fz, fy, fx), 三路各 nbands(z=laec残差, y=mic, x=远端)。
"""
import torch
import torch.nn as nn


class SEBandAttention(nn.Module):
    """SE-style band 注意力: 对时间做因果统计 -> 小瓶颈 FC -> sigmoid -> 逐 band 门控。

    注意力权重作用在 band 维特征上 (在时间 GRU 之后、输出 dense 之前)。
    为保证流式因果, 统计量用"当前帧自身"(不跨未来帧); 这里直接用当前帧的 band 向量
    过瓶颈 FC 生成门控, 等价一个逐帧的 channel-attention。
    """
    def __init__(self, dim, reduction=4):
        super().__init__()
        hidden = max(4, dim // reduction)
        self.fc1 = nn.Linear(dim, hidden)
        self.fc2 = nn.Linear(hidden, dim)

    def gate(self, x):
        """只返回门 (0,1), 供 cTFA 风格 TA×FA 相乘复用; forward 内部乘。"""
        w = torch.relu(self.fc1(x))
        return torch.sigmoid(self.fc2(w))   # [B,T,dim] in (0,1)

    def forward(self, x):
        # x: [B, T, dim]
        return x * self.gate(x)


class TimeAttention(nn.Module):
    """因果时间注意力 (对齐 UL-UNAS cTFA 的 TA 分支)。

    论文 cTFA = TA(时间注意力) × FA(频率注意力) 两路相乘, 且消融结论:
    **FA 单独≈0, TA 单独+0.10, 两路合用才 +0.16**。原 SeidelXAEC 只有退化的
    FA(SEBandAttention 逐帧 FC), 缺 TA, 对应论文里"单独无效"的那一支。本类补上 TA,
    与 SE(当 FA) 相乘凑成 cTFA 的 TA×FA 结构。

    偏离声明(诚实):
      - 论文 TA 用 GRU 沿时间建模; 这里为与现有时间 GRU 主干不重复、保持轻量,
        用"因果累积均值(到当前帧的历史统计) + 瓶颈 FC"生成逐帧门, 不看未来帧(流式因果)。
      - 论文是降噪(VCTK)非 AEC, 方向可借、数值不可照搬; 收益须本任务消融重验。
    """
    def __init__(self, dim, reduction=4):
        super().__init__()
        hidden = max(4, dim // reduction)
        self.fc1 = nn.Linear(dim, hidden)
        self.fc2 = nn.Linear(hidden, dim)

    def gate(self, x):
        # x: [B,T,dim]; 因果累积均值(含当前帧)作时间统计, 不泄露未来
        csum = torch.cumsum(x, dim=1)
        cnt = torch.arange(1, x.shape[1] + 1, device=x.device, dtype=x.dtype).view(1, -1, 1)
        ctx = csum / cnt                       # [B,T,dim] 到当前帧的历史均值
        w = torch.relu(self.fc1(ctx))
        return torch.sigmoid(self.fc2(w))      # [B,T,dim] in (0,1)

    def forward(self, x):
        return x * self.gate(x)


class FarModAttention(nn.Module):
    """远端调制注意力(AEC 任务感知, 差异化创新; 收益需消融证明非冗余)。

    用**远端 x 的 band log 功率 fx**(输入里现成有)生成一组逐 band 的 sigmoid 调制权重,
    去调制主干特征。直觉: 远端活跃的 band -> 回声风险高 -> 调制收紧; 远端静默 -> 放开。
    与 echo-aware loss 正交: loss 用真值 echo 在训练期调梯度; 本模块用输入远端 x 在
    训练+推理期调掩码。详见 docs/06_aec/seidel结构创新设计.md 第三节。
    """
    def __init__(self, nbands, feat_dim, hidden=None, out_bias_init=0.0):
        """
        out_bias_init: fc2.bias 初始值。>0 时让 sigmoid 门初始偏大(≈不压),
            训练再学收紧; band 输出模式下用正 bias(如 2.0→sigmoid≈0.88)避免
            一上来把近端也压掉, 破坏双讲保真。
        """
        super().__init__()
        hidden = hidden or max(8, nbands // 2)
        self.fc1 = nn.Linear(nbands, hidden)
        self.fc2 = nn.Linear(hidden, feat_dim)
        if out_bias_init != 0.0:
            nn.init.constant_(self.fc2.bias, out_bias_init)

    def forward(self, feat, fx):
        # feat: [B,T,feat_dim]  被调制对象(主干特征 或 band gain);
        # fx:   [B,T,nbands]    远端 band log 功率
        g = torch.relu(self.fc1(fx))
        g = torch.sigmoid(self.fc2(g))   # [B,T,feat_dim]
        return feat * g


class SeidelXAEC(nn.Module):
    def __init__(self,
                 nbands=64,
                 num_inputs=3,
                 fc_input_dim=96,
                 freq_gru_hidden=16,     # 频率轴 GRU 隐藏维(小)
                 freq_gru_bidir=True,    # 频率轴可双向(band 不涉及因果)
                 gru_hidden=96,          # 时间 GRU 隐藏维
                 n_gru=2,
                 gru_dropout=0.2,
                 dense_hidden=128,
                 use_dualpath=True,
                 use_se_attn=True,
                 use_farmod_attn=True,
                 se_reduction=4,
                 # ---- 新增(默认 False/0=保持原 SeidelX 行为, 旧 ckpt 可加载) ----
                 use_time_attn=False,       # 补 cTFA 的 TA 分支, 与 SE(当FA)相乘凑 TA×FA
                 farmod_on_band=False,      # True=FarMod 直接调制最终 band_gain(对症); False=原调制抽象特征
                 farmod_bias_init=0.0,      # farmod_on_band 时建议 2.0(sigmoid≈0.88 起步, 初始几乎不压)
                 **kwargs):
        super().__init__()
        self.nbands = nbands
        self.num_inputs = num_inputs
        self.use_dualpath = use_dualpath
        self.use_se_attn = use_se_attn
        self.use_farmod_attn = use_farmod_attn
        self.use_time_attn = use_time_attn
        self.farmod_on_band = farmod_on_band
        self.freq_gru_bidir = freq_gru_bidir
        self.n_gru = n_gru
        self.gru_hidden = gru_hidden

        in_dim = nbands * num_inputs      # 三路 band 拼接
        out_dim = nbands

        # 1) 频率轴 GRU(双路 RNN 的 intra-frame 分支): 直接在"每 band 的 3 路特征"上跑,
        #    序列 = nbands 个 band, 每步输入 = [fz,fy,fx] 3 维(天然通道, 不额外投影, 省大矩阵)。
        #    输出每 band 一个 freq_gru_hidden*fdir 向量, 作为频率上下文拼回 band 特征。
        self.freq_in_ch = num_inputs      # 每 band 3 路
        if use_dualpath:
            self.freq_gru = nn.GRU(self.freq_in_ch, freq_gru_hidden, 1,
                                   batch_first=True, bidirectional=freq_gru_bidir)
            fdir = 2 if freq_gru_bidir else 1
            # 频率上下文 [B,T,nbands*freq_gru_hidden*fdir] 与原始 in_dim 一起进 fc_input
            fc_in_total = in_dim + nbands * freq_gru_hidden * fdir
        else:
            fc_in_total = in_dim

        # 入口 FC (对齐 Seidel 的 fc_input; 融合原始三路 + 频率上下文)
        self.fc_input = nn.Linear(fc_in_total, fc_input_dim)

        # 2) 时间 GRU (对齐 Seidel 主干)
        self.gru = nn.GRU(batch_first=True, input_size=fc_input_dim,
                          hidden_size=gru_hidden, num_layers=n_gru, dropout=gru_dropout)

        # 3) SE band 注意力(作用在时间 GRU 输出) = cTFA 的 FA 分支(退化为逐帧FC)
        if use_se_attn:
            self.se = SEBandAttention(gru_hidden, reduction=se_reduction)

        # 3b) 时间注意力 TA(作用在时间 GRU 输出) = cTFA 的 TA 分支, 与 SE(FA)相乘
        if use_time_attn:
            self.ta = TimeAttention(gru_hidden, reduction=se_reduction)

        # 4) 远端调制注意力(用 fx 调制)
        #    farmod_on_band=False: 调制 gru_hidden 抽象特征(原行为);
        #    farmod_on_band=True : 调制最终 band_gain(feat_dim=nbands, 关系直达, 对症单讲漏回声)。
        if use_farmod_attn:
            _fd = nbands if farmod_on_band else gru_hidden
            self.farmod = FarModAttention(nbands, _fd, out_bias_init=farmod_bias_init)

        # 输出 dense (对齐 Seidel 的 dense0/1/2)
        self.dense0 = nn.Linear(gru_hidden, dense_hidden)
        self.dense1 = nn.Linear(dense_hidden, dense_hidden)
        self.dense2 = nn.Linear(dense_hidden, out_dim)

    def forward(self, feat, hidden=None):
        """
        feat: [B, T, nbands*3]  (fz, fy, fx 拼接)
        return: band_gain [B,T,nbands] (0~1), hidden
        """
        B, T, _ = feat.shape
        nb = self.nbands
        # 取远端那一路 fx (第三段), 供远端调制用
        fx = feat[..., 2 * nb:3 * nb]            # [B,T,nbands]

        # ---- 频率轴 GRU (双路 RNN 的 intra-frame 分支) ----
        if self.use_dualpath:
            # feat [B,T,3*nb] -> 每 band 的 3 路 [B,T,nb,3] -> [B*T, nb, 3] 沿 band 跑
            fz = feat[..., 0:nb]; fy = feat[..., nb:2 * nb]
            per_band = torch.stack([fz, fy, fx], dim=-1)      # [B,T,nb,3]
            seq = per_band.reshape(B * T, nb, self.freq_in_ch)
            fctx, _ = self.freq_gru(seq)         # [B*T, nb, freq_gru_hidden*fdir]
            fctx = fctx.reshape(B, T, -1)        # [B,T,nb*freq_gru_hidden*fdir]
            x_in = torch.cat([feat, fctx], dim=-1)
        else:
            x_in = feat

        x = torch.relu(self.fc_input(x_in))      # [B,T,fc_dim]

        # ---- 时间 GRU (inter-frame 分支) ----
        x, hidden = self.gru(x, hidden)          # [B,T,gru_hidden]

        # ---- 注意力 ----
        # cTFA 风格: TA(时间) × FA(SE, 频率) 两路门相乘后作用主干(论文 TA×FA 才 +0.16);
        # 未开 TA 时退化为原来的"仅 SE 乘"。
        if self.use_se_attn and self.use_time_attn:
            g = self.se.gate(x) * self.ta.gate(x)   # 两路门相乘 (对齐 cTFA)
            x = x * g
        elif self.use_se_attn:
            x = self.se(x)
        elif self.use_time_attn:
            x = self.ta(x)

        # FarMod 调制抽象特征(原行为, farmod_on_band=False 时在这里)
        if self.use_farmod_attn and not self.farmod_on_band:
            x = self.farmod(x, fx)

        # ---- 输出 ----
        x = torch.relu(self.dense0(x))
        x = torch.relu(self.dense1(x))
        band_gain = torch.sigmoid(self.dense2(x))

        # FarMod 调制最终 band_gain(对症版, farmod_on_band=True 时在这里):
        # 远端第k带强 -> 对应第k带 gain 压低, 物理关系直达; bias 正初始化保证初始几乎不压。
        if self.use_farmod_attn and self.farmod_on_band:
            band_gain = self.farmod(band_gain, fx)

        return band_gain, hidden


if __name__ == "__main__":
    nbands = 64
    model = SeidelXAEC(nbands=nbands, num_inputs=3)
    n = sum(p.numel() for p in model.parameters())
    print(f"SeidelXAEC(band={nbands}) params = {n} ({n/1e3:.1f}K)")
    feat = torch.randn(2, 50, nbands * 3)
    g, h = model(feat)
    print("band_gain:", g.shape, "range", float(g.min()), float(g.max()))
    # 消融: 全关应退化成 FC+GRU
    m0 = SeidelXAEC(nbands=nbands, use_dualpath=False, use_se_attn=False, use_farmod_attn=False)
    n0 = sum(p.numel() for p in m0.parameters())
    print(f"SeidelXAEC(all-off) params = {n0/1e3:.1f}K")

    # 新增开关冒烟: cTFA(TA×FA) + FarMod 作用在 band gain(偏正 bias)
    print("--- new switches smoke ---")
    m1 = SeidelXAEC(nbands=nbands, use_time_attn=True,
                    farmod_on_band=True, farmod_bias_init=2.0)
    n1 = sum(p.numel() for p in m1.parameters())
    g1, _ = m1(feat)
    print(f"cTFA+farmod_on_band params = {n1/1e3:.1f}K, gain range "
          f"[{float(g1.min()):.3f},{float(g1.max()):.3f}]")
    # farmod_on_band 偏正 bias: 初始门应接近 1(几乎不压), gain 不应被整体拉死
    import torch.nn as _nn
    opt = torch.optim.Adam(m1.parameters(), lr=1e-3)
    for _ in range(3):
        g1, _ = m1(feat); loss = (g1 - 0.5).abs().mean()
        opt.zero_grad(); loss.backward(); opt.step()
    print("  3-step backward OK, finite:", bool(torch.isfinite(g1).all()))
    # 各开关单独组合
    for kw in [dict(use_time_attn=True, use_se_attn=True),
               dict(use_time_attn=True, use_se_attn=False),
               dict(use_farmod_attn=True, farmod_on_band=True, farmod_bias_init=2.0),
               dict(use_farmod_attn=False)]:
        mm = SeidelXAEC(nbands=nbands, **kw)
        gg, _ = mm(feat)
        print(f"  {kw} -> gain [{float(gg.min()):.3f},{float(gg.max()):.3f}] finite={bool(torch.isfinite(gg).all())}")
