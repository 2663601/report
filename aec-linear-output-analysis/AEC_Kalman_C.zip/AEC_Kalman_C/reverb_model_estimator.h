/*
 *  ReverbModelEstimator - Pure C Version
 *
 *  Estimates reverb model parameters: decay and frequency response.
 *  Ported from WebRTC AEC3 C++ ReverbModelEstimator class.
 *  Original copyright (c) 2018 The WebRTC project authors.
 */

#ifndef REVERB_MODEL_ESTIMATOR_H_
#define REVERB_MODEL_ESTIMATOR_H_

#include "aec3_common.h"
#include "aec3_config.h"
#include "reverb_decay_estimator.h"
#include "reverb_frequency_response.h"
#include "reverb_frequency_response_long.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    ReverbDecayEstimator        reverb_decay_estimator;
    ReverbFrequencyResponse     reverb_frequency_response;
    ReverbFrequencyResponseLong reverb_freq_resp_long;
} ReverbModelEstimator;

/**
 * Initialize the reverb model estimator.
 */
void ReverbModelEstimator_Init(ReverbModelEstimator* self,
                               const Aec3Config* config);

/**
 * Update the reverb model estimates.
 *
 * @param self                      Pointer to estimator
 * @param impulse_response          Time-domain filter impulse response
 * @param impulse_response_len      Length of impulse response
 * @param H2                        Filter frequency response [partitions][65]
 * @param num_partitions            Number of partitions
 * @param linear_filter_quality     Quality estimate (negative if unavailable)
 * @param has_quality               Whether quality is valid
 * @param filter_delay_blocks       Filter delay in blocks
 * @param usable_linear_estimate    Whether linear estimate is usable
 * @param stationary_block          Whether current block is stationary
 */
void ReverbModelEstimator_Update(ReverbModelEstimator* self,
                                 const float* impulse_response,
                                 int impulse_response_len,
                                 const float (*H2)[AEC3_FFT_LENGTH_BY2_PLUS1],
                                 int num_partitions,
                                 float linear_filter_quality,
                                 int has_quality,
                                 int filter_delay_blocks,
                                 int usable_linear_estimate,
                                 int stationary_block);

/**
 * Get the estimated reverb decay factor.
 */
float ReverbModelEstimator_ReverbDecay(const ReverbModelEstimator* self);

/**
 * Get the estimated reverb frequency response.
 */
const float* ReverbModelEstimator_GetReverbFrequencyResponse(
    const ReverbModelEstimator* self);

#ifdef __cplusplus
}
#endif

#endif /* REVERB_MODEL_ESTIMATOR_H_ */
